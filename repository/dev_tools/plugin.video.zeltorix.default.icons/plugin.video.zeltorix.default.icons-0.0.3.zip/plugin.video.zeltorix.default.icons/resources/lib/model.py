# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
import re
# Стандартные модули, пакеты
from re import findall

from bs4 import BeautifulSoup

# Модули с дополнения
try:
    from web_api_request import WebApiRequest, headers, https_checking
except ImportError:
    from source.release.utilitys.resources.lib.web_api_request import WebApiRequest, headers, https_checking


class Model(WebApiRequest):
    __slots__ = []
    _link: str = "https://kodi.wiki/view/Default_Icons"

    def main(self) -> dict:
        model: list = []
        response = self.request_get(https_checking(self._link))
        if response and response is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            for item in soup.find_all("pre"):
                for p in re.findall(r"\w+\.png", item.text):
                    model.append({
                        "title": p,
                        "data": "",
                        "router": "",
                        "icon": p,
                    })
        return {
            "category": "",
            "list": tuple(model)
        }
