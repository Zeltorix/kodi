# -*- coding: utf-8 -*-
# Module: web_api_request
# Author: Zeltorix
# Created on: 2023.09.28
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from pathlib import Path
from re import findall

try:
    from web_api_request import WebApiRequest, headers
    from view import View, ViewDialogProgressBG
except ImportError:
    try:
        from source.utility.utility.resources.lib.web_api_request import WebApiRequest, headers
        from source.utility.utility.resources.view import View, ViewDialogProgressBG
    except ImportError:
        from .web_api_request import WebApiRequest, headers
        from .view import View, ViewDialogProgressBG


class Download:
    __slots__ = [
        "_web",
        "_path_folder",
        "_view_dialog_progress_bg"
    ]

    def __init__(self, path_folder: str, heads: dict = None):
        self._view_dialog_progress_bg = ViewDialogProgressBG()

        if heads is None:
            heads = headers
        self._web = WebApiRequest(heads)
        self._path_folder = path_folder
        if not Path(path_folder).exists():
            Path(path_folder).mkdir(parents=True)

    def download(self, link: str, fail_name: str, path_anime: str, params: dict = None):
        if not Path(self._path_folder, path_anime).exists():
            Path(self._path_folder, path_anime).mkdir(parents=True)
        with open(Path(self._path_folder, path_anime, fail_name), 'wb') as fail:
            for chunk in self._web.download(link=link, params=params):
                fail.write(chunk)
            return True

    def hls(self, link, fail_name, path_video):
        if not Path(self._path_folder, path_video).exists():
            Path(self._path_folder, path_video).mkdir(parents=True)
        response = self._web.request_get(link)
        if response and type(response) is not dict:
            find_all_ts = findall(r"http.*?\.ts", response.text)
            with open(Path(self._path_folder, path_video, fail_name), 'wb') as fail:
                self._view_dialog_progress_bg.create(fail_name, "")
                self._view_dialog_progress_bg.update(0, "")
                num = 1
                sum_data = len(find_all_ts)
                for ts in find_all_ts:
                    self._view_dialog_progress_bg.update(int((num / (sum_data + 1)) * 100), "")
                    ts_data = self._web.request_get(ts)
                    if ts_data and type(ts_data) is not dict:
                        fail.write(ts_data.content)
                self._view_dialog_progress_bg.close()
                return True
