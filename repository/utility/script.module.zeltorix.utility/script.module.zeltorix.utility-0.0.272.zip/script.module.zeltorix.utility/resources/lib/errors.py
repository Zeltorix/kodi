try:
    from view import View
except ImportError:
    try:
        from .view import View
    except ImportError:
        class View:
            @staticmethod
            def output_logs(msg):
                print(msg)


class Errors:
    _view = View()

    def log_web_error(self, response) -> None:
        if response:
            self._view.output_logs(response)

            if response.get("status_code"):
                pass

            if response.get("response"):
                self._view.output_logs(response["response"].text)
            self._view.dialog_ok(
                "Возникла ошибка доступа к ресурсу",
                f"Рекомендуется сообщить в соответсвующий раздел на форум\n"
                f"https://kodi.moy.su/forum/2 и приложить лог файл для устранения ошибки.\n"
                f"{response}"
            )
            raise
