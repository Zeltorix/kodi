# -*- coding: utf-8 -*-
# Module: alerts_and_logs
# Author: Zeltorix
# Created on: 2024.06.09
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль адона для KODI 19.x "Matrix" и выше.
Модуль оповещений и логов.
"""

try:
    from view import View
except ImportError:
    try:
        from .view import View
    except ImportError:
        class View:
            @staticmethod
            def output_logs(msg):
                print(msg)

            @staticmethod
            def dialog_notification(
                    heading: str = "",
                    message: str = "",
                    icon: str = "info",
                    milliseconds: int = 5000,
                    sound: bool = True,
            ):
                print(
                    f"heading: {heading}\n"
                    f"message: {message}"
                )

            @staticmethod
            def get_setting_bool(
                    id_setting: str,
                    id_addon: str,
            ):
                if id_setting == "log":
                    return True


class KLog:
    __slots__ = []
    _view = View()

    def debug_k_log(self,
                    heading: str = "",
                    message: str = "",
                    data: str = "",
                    level: int = 0
                    ):
        self._view.output_logs(
            f"{heading}\n"
            f"{message}\n"
            f"{data}",
            level
        )


class KAlert:
    __slots__ = []
    _view = View()
    _log = KLog()

    def info(self,
             heading: str = "",
             message: str = "",
             data: str = ""
             ):
        self._log.debug_k_log(
            heading=heading,
            message=message,
            data=data,
            level=0
        )
        self._view.dialog_notification(
            heading=heading,
            message=message,
            icon="info",
            milliseconds=1000,
            sound=False,
        )

    def warning(self,
                heading: str = "",
                message: str = "",
                data: str = ""
                ):
        self._log.debug_k_log(
            heading=heading,
            message=message,
            data=data,
            level=2
        )
        self._view.dialog_notification(
            heading=heading,
            message=message,
            icon="warning",
            milliseconds=3000,
            sound=True,
        )

    def error(self,
              heading: str = "",
              message: str = "",
              data: str = ""
              ):
        self._log.debug_k_log(
            heading=heading,
            message=message,
            data=data,
            level=3
        )
        self._view.dialog_notification(
            heading=heading,
            message=message,
            icon="error",
            milliseconds=5000,
            sound=True,
        )
        raise ValueError("Проблема выведена выше")
