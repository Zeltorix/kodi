# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.10.19
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль адаптации взаимодействия KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
from pathlib import Path

# Модули KODI
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


SORT_METHOD_ALBUM = 14
SORT_METHOD_ALBUM_IGNORE_THE = 15
SORT_METHOD_ARTIST = 11
SORT_METHOD_ARTIST_IGNORE_THE = 13
SORT_METHOD_BITRATE = 43
SORT_METHOD_CHANNEL = 41
SORT_METHOD_COUNTRY = 17
SORT_METHOD_DATE = 3
SORT_METHOD_DATEADDED = 21
SORT_METHOD_DATE_TAKEN = 44
SORT_METHOD_DRIVE_TYPE = 6
SORT_METHOD_DURATION = 8
SORT_METHOD_EPISODE = 24
SORT_METHOD_FILE = 5
SORT_METHOD_FULLPATH = 35
SORT_METHOD_GENRE = 16
SORT_METHOD_LABEL = 1
SORT_METHOD_LABEL_IGNORE_FOLDERS = 36
SORT_METHOD_LABEL_IGNORE_THE = 2
SORT_METHOD_LASTPLAYED = 37
SORT_METHOD_LISTENERS = 39
SORT_METHOD_MPAA_RATING = 31
SORT_METHOD_NONE = 0
SORT_METHOD_PLAYCOUNT = 38
SORT_METHOD_PLAYLIST_ORDER = 23
SORT_METHOD_PRODUCTIONCODE = 28
SORT_METHOD_PROGRAM_COUNT = 22
SORT_METHOD_SIZE = 4
SORT_METHOD_SONG_RATING = 29
SORT_METHOD_SONG_USER_RATING = 30
SORT_METHOD_STUDIO = 33
SORT_METHOD_STUDIO_IGNORE_THE = 34
SORT_METHOD_TITLE = 9
SORT_METHOD_TITLE_IGNORE_THE = 10
SORT_METHOD_TRACKNUM = 7
SORT_METHOD_UNSORTED = 40
SORT_METHOD_VIDEO_RATING = 19
SORT_METHOD_VIDEO_RUNTIME = 32
SORT_METHOD_VIDEO_SORT_TITLE = 26
SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE = 27
SORT_METHOD_VIDEO_TITLE = 25
SORT_METHOD_VIDEO_USER_RATING = 20
SORT_METHOD_VIDEO_YEAR = 18


RESOLUTION_CHECK = {
    360: "480p",
    480: "480p",
    640: "640p",
    720: "720p",
    1080: "1080p",
    1440: "1440p",
    2160: "4K",
}


class ViewDialogProgress:
    """
    Класс вывода прогрессов по центу экрана
    """

    __slots__ = ["dialog"]

    def __init__(self):
        self.dialog = xbmcgui.DialogProgress()

    def create(self, header: str, message: str):
        """
        Создание прогресса
        """
        return self.dialog.create(header, message)

    def is_canceled(self) -> bool:
        """
        Проверка нажатия отмены
        """
        return self.dialog.iscanceled()

    def update(self, percent: int(0-100), message: str):
        """
        Обновления прогресса
        """
        return self.dialog.update(percent, message)

    def close(self):
        """
        Завершения отображения прогресса
        """
        return self.dialog.close()


class ViewDialogProgressBG:
    """
    Класс вывода прогрессов на заднем фоне (сверху с право)
    """

    __slots__ = ["dialog_progress_bg"]

    def __init__(self):
        self.dialog_progress_bg = xbmcgui.DialogProgressBG()

    def create(self, header: str, message: str):
        """
        Создание прогресса
        """
        return self.dialog_progress_bg.create(header, message)

    def is_finished(self) -> bool:
        """
        Если завершить заранее
        """
        return self.dialog_progress_bg.isFinished()

    def update(self, percent: int(0-100), message: str):
        """
        Обновления прогресса
        """
        return self.dialog_progress_bg.update(percent, message)

    def close(self):
        """
        Завершения отображения прогресса
        """
        return self.dialog_progress_bg.close()


class View:
    """
    Класс вывода и взаимодействия с KODI
    """

    __slots__ = [
        "_url",
        "id_plugin",
        "_handle",
        "_kodi_version_major",
        "plugin_folder",
        "library_folder",
    ]

    def __init__(self):
        # Получите URL-адрес плагина в формате plugin://id_плагина.
        self._url = sys.argv[0]
        # ID плагина
        self.id_plugin: str = self._url.split("/")[2]
        # Получить заготовка плагина в виде целого числа.
        self._handle: int = int(sys.argv[1])
        self._kodi_version_major: int = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
        self.plugin_folder = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        self.library_folder = Path(
            Path(
                xbmcvfs.translatePath(
                    xbmcaddon.Addon().getAddonInfo('profile')
                )
            ).parent.parent, "library")

    def convert_to_url(self, **kwargs) -> str:
        # Преобразование ключа и значения в ссылку данных для дополнения в виде URL
        return f"{self._url}/?{urlencode(kwargs)}"

    @staticmethod
    def jsonrpc(data: str) -> str:
        return xbmc.executeJSONRPC(data)

    @staticmethod
    def script(data: str):
        return xbmc.executescript(data)

    def reload(self, **kwargs) -> None:
        xbmc.executebuiltin(f"Container.Update({self.convert_to_url(**kwargs)})")

    @staticmethod
    def get_addon_info(api_key: str, addon_id: str = None):
        # author, changelog, description, disclaimer, fanart, icon, id, name, path, profile, stars, summary, type,
        # version
        if addon_id:
            return xbmcaddon.Addon(addon_id).getAddonInfo(api_key)
        return xbmcaddon.Addon().getAddonInfo(api_key)

    @staticmethod
    def get_plugin_folder(addon_id: str = None) -> str:
        if addon_id:
            return xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile'))
        return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

    @staticmethod
    def get_windows_width_height() -> dict:
        get_height = xbmcgui.Window().getHeight()
        get_width = xbmcgui.Window().getWidth()
        if get_width > get_height:
            height = get_height
            width = get_width
        else:
            width = get_height
            height = get_width
        return {
            "width": width,
            "height": height,
        }

    @staticmethod
    def open_settings(addon_id: str = None):
        if addon_id:
            return xbmcaddon.Addon(addon_id).openSettings()
        return xbmcaddon.Addon().openSettings()

    @staticmethod
    def get_setting_str(api_key: str, addon_id: str = None) -> str:
        if addon_id:
            return xbmcaddon.Addon(addon_id).getSetting(api_key)
        return xbmcaddon.Addon().getSetting(api_key)

    @staticmethod
    def get_setting_bool(api_key: str, addon_id: str = None) -> bool:
        if addon_id:
            return xbmcaddon.Addon(addon_id).getSettingBool(api_key)
        return xbmcaddon.Addon().getSettingBool(api_key)

    @staticmethod
    def get_setting_int(api_key: str, addon_id: str = None) -> int:
        if addon_id:
            return xbmcaddon.Addon(addon_id).getSettingInt(api_key)
        return xbmcaddon.Addon().getSettingInt(api_key)

    @staticmethod
    def set_setting(id_: str, value: str, addon_id: str = None) -> bool:
        if addon_id:
            xbmcaddon.Addon(addon_id).setSetting(id=id_, value=value)
        xbmcaddon.Addon().setSetting(id=id_, value=value)
        return True

    @staticmethod
    def dialog_text_input(label: str = "Ввод текста") -> str:
        item = xbmcgui.Dialog().input(
            label,
            type=xbmcgui.INPUT_ALPHANUM)

        if len(item) > 3:
            return item

    @staticmethod
    def dialog_input(type_: str = "text", label: str = "Ввод", autoclose: int = None) -> str:
        type_input = xbmcgui.INPUT_ALPHANUM
        if type_ == "text":
            type_input = xbmcgui.INPUT_ALPHANUM
        elif type_ == "int":
            type_input = xbmcgui.INPUT_NUMERIC
        elif type_ == "date":
            label += " (format: DD/MM/YYYY)"
            type_input = xbmcgui.INPUT_DATE
        elif type_ == "time":
            label += " (format: HH:MM)",
            type_input = xbmcgui.INPUT_TIME
        elif type_ == "ip":
            label += " (format: #.#.#.#)"
            type_input = xbmcgui.INPUT_IPADDRESS

        if autoclose:
            return xbmcgui.Dialog().input(
                heading=label,
                type=type_input,
                autoclose=autoclose,
            )

        return xbmcgui.Dialog().input(
            heading=label,
            type=type_input,
        )

    @staticmethod
    def dialog_notification(
            heading: str = "",
            message: str = "",
            icon: str = "info",
            milliseconds: int = 5000,
            sound: bool = True) -> None:
        """
        :icon: info, warning, error,
        """
        xbmcgui.Dialog().notification(
            heading=heading,
            message=message,
            icon=icon,
            time=milliseconds,
            sound=sound,
        )

    @staticmethod
    def dialog_ok(heading: str, message: str) -> bool:
        return xbmcgui.Dialog().ok(heading=heading, message=message)

    @staticmethod
    def dialog_yesno(heading: str, message: str) -> bool:
        return xbmcgui.Dialog().yesno(heading=heading, message=message)

    @staticmethod
    def dialog_select(heading: str, data: list) -> int:
        return xbmcgui.Dialog().select(heading=heading, list=data, useDetails=True)

    @staticmethod
    def dialog_multiselect(heading: str, data: list) -> list:
        # return xbmcgui.Dialog().multiselect(heading=header, data, useDetails=True)
        return xbmcgui.Dialog().multiselect(heading=heading, options=data)

    @staticmethod
    def dialog_text_viewer(heading: str, message: str, monospace_font: bool = False) -> bool:
        return xbmcgui.Dialog().textviewer(heading=heading, text=message, usemono=monospace_font)

    @staticmethod
    def check_modules() -> None:
        def target_module(check_module: str) -> None:
            try:
                xbmcaddon.Addon(check_module)
            except:
                xbmcgui.Dialog().notification(
                    heading=f"Установка библиотеки {check_module}",
                    message=f"{check_module}",
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin(f"RunPlugin('plugin://{check_module}')")

        target_module("inputstream.adaptive")

    @staticmethod
    def restart():
        xbmc.restart()

    def output_logs(self,
                    message: str,
                    level: int = 0,
                    name_function: str = "",
                    ) -> None:
        """
        Вывод лога в журнал KODI.

        :param str message:         Сообщение для вывода в логи.
        :param int level:           Тип вывода логов, по умолчанию тип ОШИБКИ
        :param str name_function:   Названия функции

        ==========   =============================================
        Значение     Описание
        ==========   =============================================
        0            Для дебагера или любое число кроме 1,2,3,4,5
        1            Для информационных
        2            Для вывода предупреждений
        3            Для вывода ошибок
        4            Для вывода критической ошибки
        5            OFF?
        ==========   =============================================
        Используются числовые
        """

        xbmc.log(
            msg=f"{self.id_plugin}\n{name_function}\n\n\n{message}\n\n",
            level=level,
        )

    def play(self, data: (str, dict), manifest_type: (str, bool) = False) -> None:
        headers_play: dict = {}
        if type(data) is dict:
            path = data["link_play"]
            manifest_type = data["type"]
            if data.get("add_headers"):
                for header, value in data["add_headers"].items():
                    headers_play[header] = value
        else:
            path = data

        if manifest_type == "mpd":
            mime_type = "application/dash+xml"
        elif manifest_type == "hls":
            mime_type = "application/x-mpegURL"
        else:
            mime_type = "video/mp4"

        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)

        if self.get_setting_bool("inputstream", "script.module.zeltorix.utility"):
            if self.get_setting_bool("inputstream_adaptive_bool", "script.module.zeltorix.utility") and manifest_type:
                # Использовать inputstream.adaptive для входящего медиапотока
                play_item.setProperty("inputstream", "inputstream.adaptive")

                if self._kodi_version_major < 21:
                    # Тип манифеста медиапотока
                    play_item.setProperty("inputstream.adaptive.manifest_type", manifest_type)
                    # Обновление манифеста, возможно это убирает баг с зависанием
                    play_item.setProperty("inputstream.adaptive.manifest_update_parameter", "full")

                if self.get_setting_bool("inputstream_adaptive_selection_resolution_bool",
                                         "script.module.zeltorix.utility"):
                    selection_resolution = [
                        "adaptive",
                        "fixed-res",
                        "ask-quality",
                        "manual-osd",
                    ][self.get_setting_int("inputstream_adaptive_selection_resolution",
                                           "script.module.zeltorix.utility")]

                    if self._kodi_version_major == 21 and \
                            self.get_addon_info("version", "inputstream.adaptive") <= "21.4.1" and \
                            selection_resolution == "manual-osd":
                        # Выбор разрешения перед просмотром
                        play_item.setProperty("inputstream.adaptive.stream_selection_type", "ask-quality")
                    else:
                        # Выбор разрешения в меню
                        play_item.setProperty("inputstream.adaptive.stream_selection_type", selection_resolution)
                        # При выборе ручного выбора
                        if selection_resolution == "fixed-res":
                            # Доступны значения: 480p, 640p, 720p, 1080p, 2K, 1440p, 4K
                            # Адаптация настроек для значений inputstream
                            res = self.get_setting_int(
                                    "video_resolution",
                                    "script.module.zeltorix.utility"
                            )
                            if res:
                                resolution = RESOLUTION_CHECK[res]
                                play_item.setProperty("inputstream.adaptive.chooser_resolution_max", resolution)
                                play_item.setProperty("inputstream.adaptive.chooser_resolution_secure_max", resolution)

                if headers_play:
                    # Заголовки для загрузки манифестов и потоков (аудио/видео/субтитры) до KODI 20
                    play_item.setProperty("inputstream.adaptive.stream_headers", urlencode(headers_play))

                    if self._kodi_version_major >= 20:
                        play_item.setProperty("inputstream.adaptive.manifest_headers", urlencode(headers_play))

                # Тип запрашиваемого контента
                play_item.setMimeType(mime_type)
                # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
                play_item.setContentLookup(False)

            elif self.get_setting_bool("inputstream_ffmpegdirect_bool", "script.module.zeltorix.utility"):
                play_item.setProperty("inputstream", "inputstream.ffmpegdirect")

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def output(self, input_data: dict) -> None:
        if input_data.get("content"):
            # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
            xbmcplugin.setContent(self._handle, input_data["content"])
        else:
            content: str = [
                "files",  # 0
                "songs",  # 1
                "artists",  # 2
                "albums",  # 3
                "movies",  # 4
                "tvshows",  # 5
                "episodes",  # 6
                "musicvideos",  # 7
                "videos",  # 8
                "images",  # 9
                "games"  # 10
            ][int(self.get_setting_str("view_content", "script.module.zeltorix.utility"))]
            xbmcplugin.setContent(self._handle, content)

        if input_data.get("category"):
            xbmcplugin.setPluginCategory(self._handle, input_data["category"])
        else:
            xbmcplugin.setPluginCategory(self._handle, "")

        if input_data.get("sort"):
            for sort in input_data["sort"]:
                xbmcplugin.addSortMethod(self._handle, sort)
        else:
            xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)

        if input_data.get("translate") and input_data["translate"]:
            list_item = xbmcgui.ListItem(label=input_data["translate"]["title"])
            vinfo = list_item.getVideoInfoTag()
            vinfo.setTitle(input_data["translate"]["title"])
            is_folder = False
            data_translate = f"{input_data['translate']['data']},{'|'.join(input_data['translate']['list'])}"
            url = self.convert_to_url(router=input_data["translate"]["router"], data=data_translate)
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)

        for item in input_data["list"]:
            list_item = xbmcgui.ListItem(label=item["title"])

            if item.get("context_menu"):
                list_item.addContextMenuItems(item["context_menu"])

            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item["title"])
                if item.get("plot"):
                    vinfo.setPlot(item["plot"])
                if item.get("genres"):
                    vinfo.setGenres(item["genres"])
                if item.get("premiered"):
                    vinfo.setPremiered(item["premiered"])
                if item.get("duration"):
                    vinfo.setDuration(item["duration"])
                if item.get("episode"):
                    vinfo.setEpisode(item["episode"])
                if item.get("season"):
                    vinfo.setSeason(item["season"])
                if item.get("dateadded"):
                    vinfo.setDateAdded(item["dateadded"])
                if item.get("year"):
                    vinfo.setYear(item["year"])
                if item.get("votes"):
                    vinfo.setVotes(item["votes"])
                if item.get("artists"):
                    vinfo.setArtists(item["artists"])
                vinfo.setMediaType("video")
            else:
                list_item.setInfo("video", {"title": item["title"]})
                if item.get("plot"):
                    list_item.setInfo("video", {"plot": item["plot"]})
                if item.get("genres"):
                    list_item.setInfo("video", {"genre": item["genres"]})
                if item.get("premiered"):
                    list_item.setInfo("video", {"premiered": item["premiered"]})
                if item.get("duration"):
                    list_item.setInfo("video", {"duration": item["duration"]})
                if item.get("episode"):
                    list_item.setInfo("video", {"episode": item["episode"]})
                if item.get("season"):
                    list_item.setInfo("video", {"season": item["season"]})
                if item.get("dateadded"):
                    list_item.setInfo("video", {"dateadded": item["dateadded"]})
                if item.get("year"):
                    list_item.setInfo("video", {"year": item["year"]})
                if item.get("votes"):
                    list_item.setInfo("video", {"votes": item["votes"]})
                list_item.setInfo("video", {"mediatype": "video"})

            if item.get("images"):
                list_item.setArt({"thumb": item["images"]})
                list_item.setArt({"icon": item["images"]})
                list_item.setArt({"fanart": item["images"]})

            if item.get("thumb"):
                list_item.setArt({"thumb": item["thumb"]})
            if item.get("poster"):
                list_item.setArt({"poster": item["poster"]})
            if item.get("banner"):
                list_item.setArt({"banner": item["banner"]})
            if item.get("fanart"):
                list_item.setArt({"fanart": item["fanart"]})
            if item.get("clearart"):
                list_item.setArt({"clearart": item["clearart"]})
            if item.get("clearlogo"):
                list_item.setArt({"clearlogo": item["clearlogo"]})
            if item.get("landscape"):
                list_item.setArt({"landscape": item["landscape"]})
            if item.get("icon"):
                list_item.setArt({"icon": item["icon"]})

            if item.get("select"):
                list_item.select(item["select"])

            # Внутренний переход есть
            is_folder: bool = True
            if item.get("not_folder"):
                is_folder: bool = False
            if item.get("play"):
                list_item.setProperty("IsPlayable", "true")
                # Переход внутрь не требуется, можно отключить
                is_folder: bool = False
            if not item.get("router") and not item.get("data"):
                is_folder: bool = False
            if item.get("router"):
                router = item["router"]
            else:
                router = ""
            url: str = self.convert_to_url(router=router)
            if item.get("data") and type(item["data"]) is dict:
                url: str = self.convert_to_url(router=router, **item["data"])
            elif item.get("data"):
                url: str = self.convert_to_url(router=router, data=item["data"])

            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)

        xbmcplugin.endOfDirectory(self._handle)
