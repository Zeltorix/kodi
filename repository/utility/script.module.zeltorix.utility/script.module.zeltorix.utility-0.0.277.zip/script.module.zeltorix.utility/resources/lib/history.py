# -*- coding: utf-8 -*-
# Module: history
# Author: Zeltorix
# Created on: 2023.10.22
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль истории работы с поиском.
"""
# Стандартные модули
import json
from itertools import islice
from pathlib import Path

try:
    from view import View
except ImportError:
    from .view import View


class History:
    __slots__ = []

    _view = View()
    history_file = Path(_view.plugin_folder, "history.json")

    def history_replace(self) -> bool:
        history: str = self._view.get_setting_str("history_dict")
        if self.history_file.exists():
            return False
        elif history:
            history_dict: dict = json.loads(history)
            if not Path(self._view.plugin_folder).exists():
                Path(self._view.plugin_folder).mkdir(parents=True)
            with open(self.history_file, "w") as fail:
                fail.write(json.dumps(history_dict, indent=2))
            self._view.set_setting("history_dict", json.dumps({}))
            return True
        else:
            if not Path(self._view.plugin_folder).exists():
                Path(self._view.plugin_folder).mkdir(parents=True)
            with open(self.history_file, "w+") as fail:
                fail.write(json.dumps({}, indent=2))
            return False

    def history_clearing(self) -> bool:
        with open(self.history_file, "w") as fail:
            fail.write(json.dumps({}, indent=2))
            return True

    def history_del_item(self, item: str) -> bool:
        if self.history_file.exists():
            with open(self.history_file, "r", encoding='utf-8') as fail:
                history_dict: dict = json.loads(fail.read())
                if history_dict.pop(item, None):
                    with open(self.history_file, "w") as new_fail:
                        new_fail.write(json.dumps(history_dict, indent=2))
                        return True

    def history_add_item(self, item: str) -> bool:
        history_limit: int = int(self._view.get_setting_int("history_limit"))
        if self.history_file.exists():
            with open(self.history_file, "r", encoding='utf-8') as fail:
                history_dict: dict = json.loads(fail.read())
            new_item: dict = {item: f"search_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            history_dict: dict = dict(islice(history_dict.items(), history_limit))
            with open(self.history_file, "w") as new_fail:
                new_fail.write(json.dumps(history_dict, indent=2))
                return True
        else:
            with open(self.history_file, "w") as new_fail:
                new_fail.write(json.dumps({item: f"search_history"}, indent=2))
                return True

    def search_menu(self) -> dict:
        if self.history_replace():
            self._view.dialog_ok(
                "История перенесена в новое место",
                f"Теперь история находится в файле {self.history_file}\nРекомендуется сбросить настройки")
        model: list = [{
            "title": "Поиск",
            "data": "",
            "router": "search",
            "icon": "DefaultAddonsSearch.png",
        }]
        if self._view.get_setting_bool("history"):
            if self.history_file.exists():
                with open(self.history_file, "r", encoding='utf-8') as fail:
                    history_dict: dict = json.loads(fail.read())
                    for key, value in history_dict.items():
                        model.append({
                            "title": f"[COLOR grey]{key}[/COLOR]",
                            "router": value,
                            "data": key,
                            "context_menu": [
                                (
                                    "Удалить из истории",
                                    f"Container.Update({self._view.convert_to_url(router='history_del_item',data=key)})"
                                ),
                            ],
                        })
        return {
            "category": "Меню поиска",
            "list": tuple(model)
        }
