from base64 import standard_b64decode
from hashlib import md5
from pathlib import Path

from re import findall
from json import loads, dumps, dump, load

from bs4 import BeautifulSoup

try:
    from view import View
    from web_api_request import WebApiRequest, https_checking, headers
except ImportError:
    from source.utility.utility.resources.lib.web_api_request import WebApiRequest, https_checking, headers

    class View:
        @staticmethod
        def plugin_folder():
            return Path.cwd()

        @staticmethod
        def get_setting_str(data):
            if data == "video_size":
                return "720"

        @staticmethod
        def output_logs(data, data_2):
            print(data)


class Kodik:
    __slots__ = []
    _view = View()
    _web = WebApiRequest()
    _kodik_folder = Path(_view.plugin_folder, "kodik")
    _cache_translate_file = Path(_view.plugin_folder, "cache_translate_file.json")

    @staticmethod
    def __decoding_url(data_url: str) -> str:
        old: str = "9876543210zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA"[::-1]
        new: str = "9876543210rqponmlkjihgfedcbazyxwvutsRQPONMLKJIHGFEDCBAZYXWVUTS"[::-1]
        return standard_b64decode("".join(new[old.index(char)] for char in data_url) + "===").decode("utf-8")

    def _file_save(self, link: str, data: dict):
        if not self._kodik_folder.exists():
            self._kodik_folder.mkdir(parents=True)
        path = Path(self._kodik_folder, md5(link.encode()).hexdigest())
        with open(path, "w") as file:
            dump(data, file)

    def translate_check(self, link: str, translate_num: int):
        if not self._cache_translate_file.is_file():
            with open(self._cache_translate_file, "w", encoding="utf-8") as f:
                dump({}, f,)
        with open(self._cache_translate_file, "r", encoding="utf-8") as f:
            data = load(f)
        if data.get(link) and translate_num is None:
            return data[link]
        elif translate_num or translate_num is 0:
            data[link] = translate_num
        elif not data.get(link):
            data[link] = 0
        else:
            raise
        with open(self._cache_translate_file, "w", encoding="utf-8") as f:
            dump(data, f, ensure_ascii=False)
        return data[link]

    def kodik_play(
            self,
            link: str,
            season_num: str,
            episode: str,
            translate: str = None,
    ):
        if not self._kodik_folder.exists():
            self._kodik_folder.mkdir(parents=True)
        play_file_link = Path(
            self._kodik_folder,
            md5(str(link + season_num + episode + str(translate)).encode()).hexdigest()
        )
        with open(play_file_link, "r") as file:
            data_dict: dict = load(file)

        domain: str = "https://" + data_dict["list_data"]["pd"]
        post: dict = {
            "d": data_dict["list_data"]["d"],
            "d_sign": data_dict["list_data"]["d_sign"],
            "pd": data_dict["list_data"]["pd"],
            "pd_sign": data_dict["list_data"]["pd_sign"],
            "ref": data_dict["list_data"]["ref"],
            "ref_sign": data_dict["list_data"]["ref_sign"],
            "bad_user": "false",
            "cdn_is_working": "true",
            "type": data_dict["list_data"]["type"],
            "hash": data_dict["list_data"]["hash"],
            "id": data_dict["list_data"]["id"],
            "info": "{}"
        }
        headers["Sec-Fetch-Dest"] = "iframe"
        headers["Sec-Fetch-Site"] = "cross-site"
        headers["Referer"] = link
        self._web.__init__(headers)
        response_link = self._web.request_get(https_checking(link))
        if response_link and type(response_link) is not dict:
            link_js = findall(r"/assets/js/app.*?\.js", response_link.text)[0]
            headers["Sec-Fetch-Dest"] = "script"
            headers["Sec-Fetch-Site"] = "same-origin"
            headers["Accept"] = "*/*"
            self._web.__init__(headers)
            response_js = self._web.request_get(https_checking(domain + link_js))
            if response_js and type(response_js) is not dict:
                link_chunk: str = standard_b64decode(
                    findall(r'url:atob\("\S+"\),', response_js.text)[0].split('"')[1]).decode("utf-8")
            else:
                raise ValueError(f"Ошибка доступа части ссылка запроса {response_js}")
        else:
            raise ValueError(f"Ошибка доступа входящей ссылки {link}")

        if link_chunk:

            headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
            headers["Referer"] = link
            headers["Sec-Fetch-Dest"] = "empty"
            headers["Sec-Fetch-Mode"] = "cors"
            headers["Sec-Fetch-Site"] = "same-origin"
            headers["X-Requested-With"] = "XMLHttpRequest"
            self._web.__init__(headers)
            response = self._web.request_post(https_checking(domain + link_chunk), data=post)
            if response and type(response) is not dict:
                data_json = loads(response.text)
                video_size: int = self._view.get_setting_int("video_resolution", "script.module.zeltorix.utility")

                if video_size:
                    height = str(video_size)
                else:
                    height: str = str(self._view.get_windows_width_height()["height"])

                data_2: str = data_json["links"][height][0]["src"]
                return https_checking(self.__decoding_url(data_2))

            else:
                raise ValueError("Не удалось получить доступ к ссылкам на потоки")
        else:
            raise ValueError("Отсутствует часть ссылки")

    def kodik_play_one(self, link: str) -> dict:
        link_play = ""
        link_chunk: str = ""
        del headers["Referer"]
        headers["Sec-Fetch-Dest"] = "iframe"
        headers["Sec-Fetch-Site"] = "cross-site"
        headers["Upgrade-Insecure-Requests"] = "1"
        response = WebApiRequest(headers).request_get(link)
        if response and type(response) is not dict:
            response_text = response.text
            url_params = loads(findall(r"urlParams.*?}';", response_text)[0].split("'")[1])
            data_type = findall(r"videoInfo\.type.*?;", response_text)[0].split("'")[1]
            data_hash = findall(r"videoInfo\.hash.*?;", response_text)[0].split("'")[1]
            data_id = findall(r"videoInfo\.id.*?;", response_text)[0].split("'")[1]
            domain: str = "https://" + url_params["pd"]
            post: dict = {
                "d": url_params["d"],
                "d_sign": url_params["d_sign"],
                "pd": url_params["pd"],
                "pd_sign": url_params["pd_sign"],
                "ref": url_params["ref"],
                "ref_sign": url_params["ref_sign"],
                "bad_user": "false",
                "cdn_is_working": "true",
                "type": data_type,
                "hash": data_hash,
                "id": data_id,
                "info": "{}"
            }
            link_js = findall(r"/assets/js/app.*?\.js", response_text)[0]
            headers["Priority"] = "u=1"
            headers["Referer"] = link
            headers["Sec-Fetch-Dest"] = "script"
            headers["Sec-Fetch-Mode"] = "no-cors"
            headers["Sec-Fetch-Site"] = "same-origin"
            headers["Accept"] = "*/*"
            response_js = WebApiRequest(headers).request_get(domain + link_js)
            if response_js and type(response_js) is not dict:
                link_chunk: str = standard_b64decode(
                    findall(r'url:atob\("\S+"\),', response_js.text)[0].split('"')[1]).decode("utf-8")

            if link_chunk:
                headers["Referer"] = https_checking(url_params["pd"])
                WebApiRequest(headers).request_get("https://cloud.kodik-storage.com/test/t")
                headers["Accept"] = "application/json, text/javascript, */*; q=0.01"
                headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
                headers["Priority"] = "u=1, i"
                headers["Referer"] = link
                headers["Sec-Fetch-Dest"] = "empty"
                headers["Sec-Fetch-Mode"] = "cors"
                headers["Sec-Fetch-Site"] = "same-origin"
                headers["X-Requested-With"] = "XMLHttpRequest"
                headers["Origin"] = https_checking(url_params["pd"])
                response_json = WebApiRequest(headers).request_post(domain + link_chunk, data=post)
                if response_json and type(response_json) is not dict:
                    data_json = response_json.json()

                    video_size: int = self._view.get_setting_int("video_resolution", "script.module.zeltorix.utility")
                    if video_size:
                        height = video_size
                    else:
                        height: int = self._view.get_windows_width_height()["height"]

                    if height <= 360:
                        if data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                    elif 360 < height <= 480:
                        if data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                    elif 480 < height <= 720:
                        if data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                    elif 720 < height <= 1080:
                        if data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]

        if link_play:
            return {
                "type": "hls",
                "link_play": https_checking(self.__decoding_url(link_play)),
            }
        else:
            raise ValueError("Отсутствия потоков на видео")

    def kodik_list(self,
                   link: str,
                   translate_num: int = None,
                   link_site: str = "",
                   plot: str = "",
                   duration: int = 0,
                   images: str = "",
                   category: str = "",
                   ):
        model: list = []
        translate_data: list = []
        model_translate: list = []
        response = self._web.request_get(https_checking(link))
        translate_num = self.translate_check(link, translate_num)
        if response:
            data_text: str = response.text
            data_json: dict = loads(findall(r"urlParams.*?;", data_text)[0].split("'")[1])
            type_video: str = findall(r"videoInfo.type = '.*?'", data_text)[0].split("'")[1]
            media_genre: str = findall(r'mediaGenre.*;?', data_text)[0].split('"')[1]
            json_data: dict = loads(findall(r'\{.*?}', response.text)[0])
            soup_seasons = BeautifulSoup(data_text, features="html.parser")
            if not category:
                category = soup_seasons.title.text.strip()
            if type_video == "seria":
                if soup_seasons.find(class_="serial-translations-box"):
                    if translate_num is not None:
                        data_media_id: str = soup_seasons.find(
                            class_="serial-translations-box").find_all("option")[int(translate_num)]['data-media-id']
                        data_media_hash: str = soup_seasons.find(
                            class_="serial-translations-box").find_all("option")[int(translate_num)]['data-media-hash']
                        new_link: str = (
                            f"https://{data_json['pd']}/"
                            f"{media_genre}/"
                            f"{data_media_id}/"
                            f"{data_media_hash}/"
                            f"720p"
                        )
                        if headers.get("Referer"):
                            del headers["Referer"]
                        self._web.__init__(headers)
                        response_season = self._web.request_get(https_checking(new_link))
                        if response_season and type(response) is not dict:
                            type_video: str = findall(r"videoInfo.type = '.*?'", response_season.text)[0].split("'")[1]
                            soup_seasons = BeautifulSoup(response_season.text, features="html.parser")
                            json_data: dict = loads(findall(r'\{.*?}', response_season.text)[0])
                        else:
                            raise ValueError("Страница сезона не доступна")
                    for translate in soup_seasons.find(class_="serial-translations-box").find_all("option"):
                        if translate['data-translation-type'] == "subtitles":
                            title: str = f"Субтитры: [COLOR=yellow]{translate.text}[/COLOR]"
                        elif translate['data-translation-type'] == "voice":
                            title: str = f"Озвучка: [COLOR=green]{translate.text}[/COLOR]"
                        else:
                            title: str = f"Озвучка/Субтитры: [COLOR=yellowgreen]{translate.text}[/COLOR]"
                        model_translate.append(title)

                    data_media_id: str = soup_seasons.find(
                        class_="serial-translations-box").find_all("option")[int(translate_num)]["data-media-id"]
                    data_media_hash: str = soup_seasons.find(
                        class_="serial-translations-box").find_all("option")[int(translate_num)]["data-media-hash"]

                    for season in soup_seasons.find(class_="series-options").find_all("div"):
                        season_num: str = findall(r"\d+", season['class'][0])[0]
                        for episode in season.find_all("option"):
                            data: dict = {
                                "link": f"https://{data_json['pd']}/{media_genre}/{data_media_id}/{data_media_hash}/720p",
                                "list_data": {
                                    "d": json_data["d"],
                                    "d_sign": json_data["d_sign"],
                                    "pd": json_data["pd"],
                                    "pd_sign": json_data["pd_sign"],
                                    "ref": json_data["ref"],
                                    "ref_sign": json_data["ref_sign"],
                                    "advert_debug": json_data["advert_debug"],
                                    "min_age": json_data["min_age"],
                                    "first_url": json_data["first_url"],
                                    "season": season_num,
                                    "episode": episode["value"],
                                    "link": link,
                                    "type": type_video,
                                    "hash": episode["data-hash"],
                                    "id": episode["data-id"],
                                },
                            }

                            self._file_save(
                                link=link + season_num + episode["value"] + str(translate_num),
                                data=data)

                            model.append({
                                "title": f"[B][COLOR=blue]S{season_num}[/COLOR][COLOR=yellow]E{episode['value']}[/COLOR][/B]",
                                "data": {
                                    "data": link,
                                    "season_num": season_num,
                                    "episode": episode["value"],
                                    "translate_num": translate_num,
                                    "link_site": link_site,
                                },
                                "router": "kodik_play",
                                "plot": plot,
                                "duration": duration,
                                "images": images,
                                "play": True,
                            })
                    translate_data: dict = {
                        "title": f"[COLOR=yellowgreen]{model_translate[int(translate_num)]}[/COLOR]",
                        "data": link_site,
                        # "data": link,
                        # "link_site": link_site,
                        "router": "translate",
                        "list": model_translate
                    }
                elif soup_seasons.find(class_="serial-series-box"):
                    data_media_id = findall(r"videoInfo.id = '.*?';", response.text)[0].split("'")[1]
                    data_media_hash = findall(r"videoInfo.hash = '.*?';", response.text)[0].split("'")[1]
                    type_media = findall(r"videoInfo.type = '.*?';", response.text)[0].split("'")[1]
                    for season in soup_seasons.find(class_="series-options").find_all("div"):
                        season_num: str = findall(r"\d+", season['class'][0])[0]
                        for episode in season.find_all("option"):
                            data: dict = {
                                "link": f"https://{data_json['pd']}/{media_genre}/{data_media_id}/{data_media_hash}/720p",
                                "list_data": {
                                    "d": json_data["d"],
                                    "d_sign": json_data["d_sign"],
                                    "pd": json_data["pd"],
                                    "pd_sign": json_data["pd_sign"],
                                    "ref": json_data["ref"],
                                    "ref_sign": json_data["ref_sign"],
                                    "advert_debug": json_data["advert_debug"],
                                    "min_age": json_data["min_age"],
                                    "first_url": json_data["first_url"],
                                    "season": season_num,
                                    "episode": episode["value"],
                                    "link": link,
                                    "type": type_video,
                                    "hash": episode["data-hash"],
                                    "id": episode["data-id"],
                                },
                            }

                            self._file_save(
                                link=link + season_num + episode["value"] + str(translate_num),
                                data=data)

                            model.append({
                                "title": f"[B][COLOR=blue]S{season_num}[/COLOR][COLOR=yellow]E{episode['value']}[/COLOR][/B]",
                                "data": {
                                    "data": link,
                                    "season_num": season_num,
                                    "episode": episode['value'],
                                    "translate_num": translate_num,
                                },
                                "router": "kodik_play",
                                "plot": plot,
                                "duration": duration,
                                "images": images,
                                "play": True,
                            })
                else:
                    raise TypeError("Отсутствуют нужные теги")
            elif type_video == "video":
                for translate in soup_seasons.find(class_="movie-translations-box").find_all("option"):
                    data: dict = {
                        "link": f"https://{data_json['pd']}/{media_genre}/{translate['data-media-id']}/{translate['data-media-hash']}/720p",
                        "list_data": (
                            f"d={json_data['d']}&"
                            f"d_sign={json_data['d_sign']}&"
                            f"pd={json_data['pd']}&"
                            f"pd_sign={json_data['pd_sign']}&"
                            f"ref={json_data['ref']}&"
                            f"ref_sign={json_data['ref_sign']}&"
                            f"advert_debug={json_data['advert_debug']}&"
                            f"first_url={json_data['first_url']}&"
                            f"link={link}&"
                            f"type={type_video}&"
                            f"hash={translate['data-media-hash']}&"
                            f"id={translate['data-media-id']}"
                        ),
                    }

                    if translate['data-translation-type'] == "subtitles":
                        title: str = f"{category} (Субтитры: [COLOR=yellow]{translate['data-title']}[/COLOR])"
                    elif translate['data-translation-type'] == "voice":
                        title: str = f"{category} (Озвучка: [COLOR=green]{translate['data-title']}[/COLOR])"
                    else:
                        title: str = f"{category} (Озвучка/Субтитры: [COLOR=yellowgreen]{translate['data-title']}[/COLOR])"

                    model.append({
                        "title": title,
                        "data": data,
                        "router": "kodik_play_one",
                        "plot": plot,
                        "duration": duration,
                        "images": images,
                        "play": True,
                    })
            else:
                raise TypeError("Неизвестный тип для воспроизведения")

        return {
            "category": category,
            "list": tuple(model),
            "translate": translate_data,
        }
