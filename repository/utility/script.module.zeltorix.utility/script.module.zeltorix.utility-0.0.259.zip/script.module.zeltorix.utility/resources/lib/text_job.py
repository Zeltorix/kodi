import time
from re import compile, split, sub, findall
from unicodedata import normalize
from datetime import datetime
from base64 import standard_b64decode, standard_b64encode
from locale import getlocale, LC_ALL, LC_NUMERIC, LC_TIME, LC_CTYPE, LC_COLLATE

try:
    from view import View
except ModuleNotFoundError:
    class View:
        @staticmethod
        def output_logs(data):
            print(data)

def date_to_time_stamp(data_input: str, format_input: str, format_output: str = False) -> str:

    View().output_logs(
        f"{getlocale(category=LC_ALL)}\n"
        f"{getlocale(category=LC_NUMERIC)}\n"
        f"{getlocale(category=LC_TIME)}\n"
        f"{getlocale(category=LC_CTYPE)}\n"
        f"{getlocale(category=LC_COLLATE)}\n",
        1
    )

    if getlocale()[0] in ["ru_RU", "Russian_Russia", "ru", "Ru"]:
        title: str = findall(r"[а-яА-Я]+", data_input)[0]
        data_input: str = data_input.replace(title, title.title())
    else:
        months: dict = {
            "January": "Январь",
            "February": "Февраль",
            "March": "Март",
            "April": "Апрель",
            "May": "Май",
            "June": "Июнь",
            "July": "Июль",
            "August": "Август",
            "September": "Сентябрь",
            "October": "Октябрь",
            "November": "Ноябрь",
            "December": "Декабрь",
        }
        data_input: str = [data_input.replace(findall(r"[а-яА-Я]+", data_input)[0], k) for k, v in months.items() if v.lower() in data_input][0]
    if format_output:
        try:
            return str(datetime.strptime(data_input, format_input).strftime(format_output))
        except TypeError:
            return str(datetime(*(time.strptime(data_input, format_input)[0:6])).strftime(format_output))
    else:
        try:
            return str(datetime.strptime(data_input, format_input))
        except TypeError:
            return str(datetime(*(time.strptime(data_input, format_input)[0:6])))


def sanitize(filename):
    """Return a fairly safe version of the filename.

    We don't limit ourselves to ascii, because we want to keep municipality
    names, etc, but we do want to get rid of anything potentially harmful,
    and make sure we do not exceed Windows filename length limits.
    Hence a less safe blacklist, rather than a whitelist.
    """
    blacklist = ["\\", "/", ":", "*", "?", "\"", "<", ">", "|", "\0"]
    reserved = [
        "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5",
        "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5",
        "LPT6", "LPT7", "LPT8", "LPT9",
    ]  # Reserved words on Windows
    filename = "".join(c for c in filename if c not in blacklist)
    # Remove all charcters below code point 32
    filename = "".join(c for c in filename if 31 < ord(c))
    filename = normalize("NFKD", filename)
    filename = filename.rstrip(". ")  # Windows does not allow these at end
    filename = filename.strip()
    if all([x == "." for x in filename]):
        filename = "__" + filename
    if filename in reserved:
        filename = "__" + filename
    if len(filename) == 0:
        filename = "__"
    if len(filename) > 255:
        parts = split(r"/|\\", filename)[-1].split(".")
        if len(parts) > 1:
            ext = "." + parts.pop()
            filename = filename[:-len(ext)]
        else:
            ext = ""
        if filename == "":
            filename = "__"
        if len(ext) > 254:
            ext = ext[254:]
        maxl = 255 - len(ext)
        filename = filename[:maxl]
        filename = filename + ext
        # Re-check last character (if there was no extension)
        filename = filename.rstrip(". ")
        if len(filename) == 0:
            filename = "__"
    return filename.encode('utf-8').decode('utf-8')


def date_time_to_local(data_input: str, format_input: str, format_output: str = False, second_output: bool = False) -> (str, int):
    """
    Преобразование даты в локальную

    :param str data_input:      "Fri, 27 Oct 2023 20:33:40 +0300"
    :param str format_input:    "%a, %d %b %Y %H:%M:%S %z"
    :param str format_output:   "%H:%M:%S"

    ======  ===========================================================  ===========================
    Символ	Описание	                                                 Пример
    ======  ===========================================================  ===========================
    %a	    День недели, короткий вариант                                Wed
    %A	    Будний день, полный вариант                                  Wednesday
    %w	    День недели числом 0-6, 0 — воскресенье                      3
    %d	    День месяца 01-31                                            31
    %b	    Название месяца, короткий вариант                            Dec
    %B	    Название месяца, полное название                             December
    %m	    Месяц числом 01-12                                           12
    %y	    Год, короткий вариант, без века                              18
    %Y	    Год, полный вариант                                          2018
    %H	    Час 00-23                                                    17
    %I	    Час 00-12                                                    05
    %p	    AM/PM                                                        PM
    %M	    Минута 00-59                                                 41
    %S	    Секунда 00-59                                                08
    %f	    Микросекунда 000000-999999                                   548513
    %z	    Разница UTC                                                  +0100
    %Z	    Часовой пояс                                                 CST
    %j	    День в году 001-366                                          365
    %U	    Неделя числом в году, Воскресенье первый день недели, 00-53  52
    %W	    Неделя числом в году, Понедельник первый день недели, 00-53  52
    %c	    Локальная версия даты и времени	                             Mon Dec 31 17:41:00 2018
    %x	    Локальная версия даты                                        12/31/18
    %X	    Локальная версия времени                                     17:41:00
    %%	    Символ “%”                                                   %
    ======  ===========================================================  ===========================
    Вывод строкой
    """
    if format_output:
        try:
            return str(datetime.astimezone(datetime.strptime(data_input, format_input)).strftime(format_output))
        except TypeError:
            return str(
                datetime.astimezone(datetime(*(time.strptime(data_input, format_input)[0:6]))).strftime(format_output)
            )
    elif second_output:
        try:
            return int(datetime.astimezone(datetime.strptime(data_input, format_input)).timestamp())
        except TypeError:
            return int(datetime.astimezone(datetime(*(time.strptime(data_input, format_input)[0:6]))).timestamp())
    else:
        try:
            return str(datetime.astimezone(datetime.strptime(data_input, format_input)))
        except TypeError:
            return str(datetime.astimezone(datetime(*(time.strptime(data_input, format_input)[0:6]))))


def clear_html_tags(raw_html: str) -> str:
    before_html = (raw_html
                   .replace("▶", "")
                   )

    return (" ".join(sub(compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});'), ' ', before_html).split())
            .replace(" .", ".")
            .replace(" ,", ",")
            .replace(" :", ":")
            .replace(" ;", ";")
            .replace(" !", "!")
            .replace(" ?", "?")
            )


def shy(data: str) -> str:
    return standard_b64encode(data.encode()).decode()[::-1]


def ras(data: str) -> str:
    return standard_b64decode(data[::-1].encode()).decode()
