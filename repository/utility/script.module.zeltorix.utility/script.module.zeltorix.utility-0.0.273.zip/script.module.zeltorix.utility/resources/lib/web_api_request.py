# -*- coding: utf-8 -*-
# Module: web_api_request
# Author: Zeltorix
# Created on: 2023.09.28
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль запросов
"""

# Стандартные библиотеки
import asyncio
from shutil import rmtree
from re import findall
from pathlib import Path
from json import load, dump
from urllib.parse import urlencode
from datetime import datetime, timedelta
from time import time, sleep
from hashlib import md5

# Не стандартные библиотеки
from httpx import Client, AsyncClient, TimeoutException, Response, ConnectError
from requests import Session

try:
    from view import View, ViewDialogProgressBG
    from headers import headers, headers_download
except ImportError:
    try:
        from source.utility.utility.resources.lib.headers import headers, headers_download


        class ViewDialogProgressBG:
            @staticmethod
            def create(h, m):
                print(f"{h}\n{m}")

            @staticmethod
            def is_finished():
                pass

            @staticmethod
            def update(p: int, m):
                print(f"{p}\n{m}")

            @staticmethod
            def close():
                pass


        class View:
            @staticmethod
            def get_setting_str(data, data_2):
                if data == "request_timeout":
                    return 8
                elif data == "request_retry":
                    return 2
                elif data == "request_time_sleep":
                    return 1
                elif data == "proxy_query":
                    return Proxy().censortracker()

            @staticmethod
            def get_setting_bool(data, data_2):
                if data == "request_verify":
                    return True

            @staticmethod
            def get_setting_int(data, data_2):
                if data == "proxy_type":
                    return 1

            @staticmethod
            def set_setting(data, data_2, data_3):
                if data == "proxy_query":
                    print(data_2)

            @staticmethod
            def output_logs(data, n):
                print(data)

            @staticmethod
            def dialog_notification(h, m, *args):
                print(f"{h}\n{m}")

            plugin_folder = Path(Path().cwd(), "temp")

    except ImportError:
        from .view import View, ViewDialogProgressBG
        from .headers import headers, headers_download


def https_checking(url_check: str, start_url: (str, bool) = False) -> str:
    if url_check.startswith("https"):
        return url_check
    elif url_check.startswith("http"):
        return url_check.replace("http", "https")
    elif url_check.startswith("//"):
        return "https:" + url_check
    elif "." in url_check.split("/")[0]:
        return "https://" + url_check
    elif start_url:
        if start_url in url_check:
            return url_check
        elif url_check.startswith("/"):
            return start_url + url_check
        elif "/" in url_check:
            return f"{start_url}/{url_check}"
    else:
        raise ValueError(f"Неизвестный тип ссылки - {url_check}")


class Proxy:
    __slots__ = []
    _view = View()

    def __init__(self):
        pass

    def proxy_provider_reload(self):
        if self._view.get_setting_int("proxy_type", "script.module.zeltorix.utility") == 1:
            proxy_address = self.antizapret()
        elif self._view.get_setting_int("proxy_type", "script.module.zeltorix.utility") == 2:
            proxy_address = self.censortracker()
        else:
            raise
        self._view.set_setting("proxy_query", proxy_address, "script.module.zeltorix.utility")
        return True

    @staticmethod
    def antizapret(proxies: bool = False) -> (str, list):
        headers["Accept"] = "application/x-ns-proxy-autoconfig"
        response = WebApiRequest(headers).request_get("cap.yxorp/3448:lol.enoweneht.p//:sptth"[::-1])
        if response and type(response) is not dict:
            response_text: str = response.text
            find_data: str = findall(r'return ".*?DIRECT";', response_text)[-2]
            if findall(r"HTTPS", find_data):
                find_proxy = findall(r"HTTPS .*?\.\w+\.\w+:\d+", find_data)[0].replace("HTTPS ", "")
            elif findall(r"PROXY", find_data):
                find_proxy = findall(r"PROXY .*?\.\w+\.\w+:\d+", find_data)[0].replace("PROXY ", "")
            else:
                raise ValueError("Отсутствуют нужные паттерны")
            if proxies:
                return {"https://": "https://" + find_proxy, "http://": "http://" + find_proxy, }
            else:
                return "https://" + find_proxy

    @staticmethod
    def censortracker() -> str:
        headers["Accept"] = "application/x-ns-proxy-autoconfig"
        response = WebApiRequest(headers).request_get("/gifnoc-yxorp/ipa/ed.evresertc.ppa//:sptth"[::-1])
        if response and type(response) is not dict:
            data = response.json()
            return f"https://{data['server']}:{data['port']}"


class WebApiRequest:
    __slots__ = [
        "_session",
        "_session_requests",
        "_verify",
        "_timeout",
        "_proxies",
        "heads",
    ]
    _view = View()
    _view_dialog_progress_bg = ViewDialogProgressBG()
    retry = int(_view.get_setting_str("request_retry", "script.module.zeltorix.utility"))
    time_sleep = int(_view.get_setting_str("request_time_sleep", "script.module.zeltorix.utility"))

    def __init__(self,
                 heads: dict = None,
                 proxies: dict = None,
                 proxy: str = None,
                 redirects=True,
                 verify=None,
                 timeout=None):
        self._proxies = proxies

        if verify:
            self._verify = verify
        else:
            self._verify = self._view.get_setting_bool("request_verify", "script.module.zeltorix.utility")

        if timeout:
            self._timeout = timeout
        else:
            self._timeout = float(self._view.get_setting_str("request_timeout", "script.module.zeltorix.utility"))

        self.heads = heads
        if heads is None:
            self.heads = headers

        self._session = Client(
            headers=self.heads,
            follow_redirects=redirects,
            timeout=self._timeout,
            http2=True,
            verify=self._verify,
            proxy=proxy,
        )
        self._session_requests = Session()

    def request_get(self,
                    link: str,
                    params: dict = None,
                    retry: int = retry) -> (Response, dict):
        try:
            response: Response = self._session.get(https_checking(link), params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                sleep(time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            elif response.status_code != 200:
                if retry:
                    sleep(self.time_sleep)
                    return self.request_get(link, params=params, retry=retry - 1)
                else:
                    return {
                        "status": "status_code",
                        "status_code": response.status_code,
                        "link": link,
                        "params": params,
                        "headers": self.heads,
                        "response": response,
                    }
        except TimeoutException:
            if retry:
                sleep(self.time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                sleep(self.time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                sleep(self.time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}", 3)
                raise

    def request_post(self,
                     link: str,
                     params: dict = None,
                     data: (str, dict) = None,
                     json: dict = None,
                     content: str = None,
                     retry: int = retry) -> (Response, dict):
        try:
            response: Response = self._session.post(
                https_checking(link),
                data=data,
                json=json,
                content=content,
                params=params
            )
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                sleep(time_sleep)
                return self.request_post(link, params=params, data=data, json=json, retry=retry - 1)
            elif response.status_code != 200:
                sleep(self.time_sleep)
                if retry:
                    return self.request_post(link, params=params, data=data, json=json, retry=retry - 1)
                else:
                    raise ValueError(
                        f"Неизвестный код ответа\n"
                        f"{response.status_code}\n"
                        f"{link}\n"
                        f"{params}\n"
                        f"{data}\n"
                        f"{self.heads}\n"
                        f"{response.text}\n"
                    )
        except TimeoutException:
            if retry:
                sleep(self.time_sleep)
                return self.request_post(link, params=params, data=data, json=json, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                sleep(self.time_sleep)
                return self.request_post(link, params=params, data=data, json=json, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                sleep(self.time_sleep)
                return self.request_post(link, params=params, data=data, json=json, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}", 3)
                raise

    def request_put(self,
                    link: str,
                    params: dict = None,
                    data: str = None,
                    json: dict = None,
                    retry: int = retry) -> (Response, dict):
        try:
            response: Response = self._session.put(https_checking(link), data=data, json=json, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                sleep(time_sleep)
                return self.request_put(link, params=params, data=data, json=json, retry=retry - 1)
            elif response.status_code != 200:
                sleep(self.time_sleep)
                if retry:
                    return self.request_put(link, params=params, data=data, json=json, retry=retry - 1)
                else:
                    raise ValueError(
                        f"Неизвестный код ответа\n"
                        f"{response.status_code}\n"
                        f"{link}\n"
                        f"{params}\n"
                        f"{data}\n"
                        f"{self.heads}")
        except TimeoutException:
            if retry:
                sleep(self.time_sleep)
                return self.request_put(link, params=params, data=data, json=json, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                sleep(self.time_sleep)
                return self.request_put(link, params=params, data=data, json=json, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                sleep(self.time_sleep)
                return self.request_put(link, params=params, data=data, json=json, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}", 3)
                raise

    def request_delete(self,
                       link: str,
                       params: dict = None,
                       data: (str, dict) = None,
                       json: dict = None,
                       retry: int = retry
                       ) -> (Response, dict):
        try:
            response: Response = self._session_requests.delete(
                https_checking(link),
                headers=self.heads,
                timeout=self._timeout,
                verify=self._verify,
                proxies=self._proxies,
                data=data,
                json=json,
                params=params,
            )
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                sleep(time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            elif response.status_code != 200:
                sleep(self.time_sleep)
                if retry:
                    return self.request_delete(link, params=params, retry=retry - 1)
                else:
                    raise ValueError(
                        f"Неизвестный код ответа\n"
                        f"{response.status_code}\n"
                        f"{link}\n"
                        f"{params}\n"
                        f"{self.heads}")
        except TimeoutException:
            if retry:
                sleep(self.time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                sleep(self.time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                sleep(self.time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def request_stream(self,
                       *,
                       method: str,
                       link: str,
                       params: dict = None,
                       data: (str, dict) = None,
                       json: dict = None,
                       content: str = None,
                       retry: int = retry) -> (Response, dict):
        try:
            response: Response = self._session.stream(
                method,
                https_checking(link),
                data=data,
                json=json,
                content=content,
                params=params
            )
            return response
        except TimeoutException:
            if retry:
                sleep(self.time_sleep)
                return self.request_stream(method=method, link=link, params=params, data=data, json=json,
                                           retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                sleep(self.time_sleep)
                return self.request_stream(method=method, link=link, params=params, data=data, json=json,
                                           retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                sleep(self.time_sleep)
                return self.request_stream(method=method, link=link, params=params, data=data, json=json,
                                           retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}", 3)
                raise

    def download(self,
                 link: str,
                 method: str = "GET",
                 params: dict = None,
                 data: str = None,
                 json: dict = None):
        with self._session.stream(method=method, url=https_checking(link), params=params, data=data,
                                  json=json) as response:
            # content_length = int(response.headers["Content-Length"])
            for data in response.iter_bytes():
                yield data


class WebApiRequestAsync:
    """
    Требуется полностью переписать
    """
    __slots__ = [
        "_session_async",
    ]
    _view = View()

    def __init__(self, heads: dict = None, proxies: dict = None, proxy: str = None, redirects=True):

        timeout = float(self._view.get_setting_str("request_timeout", "script.module.zeltorix.utility"))

        if heads is None:
            heads = headers
        self._session_async = AsyncClient(
            headers=heads,
            follow_redirects=redirects,
            timeout=timeout,
            http2=True,
            proxy=proxy,
            proxies=proxies,
        )

    def request_get(self, link: str, params: dict = None, retry: int = 5) -> (Response, None):
        try:
            response: Response = self._session_async.get(link, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                sleep(time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                raise ValueError(f"Неизвестный код ответа {response.status_code} {link}")
        except TimeoutException:
            if retry:
                sleep(5)
                return self.request_get(link, params=params, retry=retry - 1)
        except ConnectError:
            if retry:
                sleep(5)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                raise ValueError(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def request_post(self, link: str, params: dict = None, data: dict = None, retry: int = 10) -> (Response, int, None):
        try:
            response: Response = self._session_async.post(link, data=data, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                sleep(time_sleep)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            elif response.status_code != 200:
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                raise ValueError(f"Неизвестный код ответа {response.status_code} {link}")
        except TimeoutException:
            if retry:
                sleep(5)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
        except ConnectError:
            if retry:
                sleep(5)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                raise ValueError(f"Проблемы с получением данных с ссылки {link}\n{e}")


class WebCache:
    __slots__ = [
        "_web",
    ]

    _view = View()
    _cache_folder = Path(_view.plugin_folder, "cache")

    def __init__(self, heads: dict = None, proxy=None):
        if heads is None:
            heads = headers
        self._web = WebApiRequest(heads=heads, proxy=proxy)

    def web(self,
            link: str,
            *,
            params: dict = None,
            data: (str, dict) = None,
            json: dict = None,
            time_expires: int = 0
            ) -> (str, None):
        if not self._cache_folder.exists():
            self._cache_folder.mkdir(parents=True)
        if params is None:
            params = {}
        if data is None:
            data = {}
        if json is None:
            json = {}
        link = https_checking(link)
        response_data = None
        file_name = f"{link}?{urlencode(params)}|{urlencode(data)}|{urlencode(json)}"
        file_cache = Path(self._cache_folder, md5(file_name.encode()).hexdigest())
        if self._view.get_setting_bool("cache"):
            if file_cache.exists() and file_cache.stat().st_mtime + time_expires > time():
                with open(file_cache, "r", encoding="utf-8") as file:
                    response_data = file.read()
                    self._view.dialog_notification(
                        f"Используется кэш",
                        f'от {datetime.fromtimestamp(file_cache.stat().st_mtime).strftime("%Y.%m.%d %H:%M:%S")}',
                        milliseconds=500,
                        sound=False,
                    )
            else:
                if data or json:
                    response = self._web.request_post(
                        link,
                        params=params,
                        data=data,
                        json=json
                    )
                else:
                    response = self._web.request_get(
                        link,
                        params=params
                    )

                if response and type(response) is not dict:
                    with open(file_cache, "w", encoding="utf-8") as file:
                        response_data = response.text
                        file.write(response_data)
                        self._view.dialog_notification(
                            f"Кэш обновлён",
                            f'от {datetime.fromtimestamp(file_cache.stat().st_mtime).strftime("%Y.%m.%d %H:%M:%S")}',
                            milliseconds=500,
                            sound=False,
                        )
        else:
            if data or json:
                response = self._web.request_post(
                    link,
                    params=params,
                    data=data,
                    json=json
                )
            else:
                response = self._web.request_get(
                    link,
                    params=params
                )

            if response and type(response) is not dict:
                response_data = response.text

        if response_data:
            return response_data

        if self._view.dialog_yesno(
                "Проблемы с доступом к ресурсу!",
                "Использовать старую кэш, при её наличии?"
        ):
            with open(file_cache, "r", encoding="utf-8") as file:
                self._view.dialog_notification(
                    f"Используется старая кэш",
                    f'от {datetime.fromtimestamp(file_cache.stat().st_mtime).strftime("%Y.%m.%d %H:%M:%S")}',
                    icon="warning",
                    milliseconds=500,
                    sound=False,
                )
                return file.read()

    def cache_clearing(self):
        size = self.cache_size()
        self._view.output_logs(
            f"Размер кэши {size} для очищения",
            1
        )
        if self._cache_folder.exists():
            rmtree(self._cache_folder)
            self._view.dialog_ok(
                "Кэш",
                f"Папка кэши очищена.\n"
                f"Очищено {size}"
            )
            self._view.output_logs(
                f"Кэш очищена",
                1
            )
            return True
        self._view.dialog_ok("Кэш", "Папка кэши отсутствует, удалять нечего")
        return False

    @staticmethod
    def __convert_bytes(size):
        for x in ["байт", "КБ", "МБ", "ГБ", "ТБ"]:
            if size < 1024.0:
                return f"{size: 3.1f} {x}"
            size /= 1024.0

    def cache_size(self):
        return self.__convert_bytes(sum(f.stat().st_size for f in self._cache_folder.rglob('*') if f.is_file()))
