# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Не тестируемый модуль.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View

# Импорт модуля плагина
from .model import Model
from history import History


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _history = History()

    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict['router'] == "search_history":
            _view.output(_model.search(params_dict['data']))
        elif params_dict['router'] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict['router'] == "history_del_item":
            if _history.history_del_item(params_dict['data']):
                _view.output(_history.search_menu())

        # Блок воспроизведения
        elif params_dict["router"] == "play":
            _view.play(params_dict["data"])
        elif params_dict["router"] == "angelcam":
            _view.play(_model.angelcam(params_dict["data"]), "hls")
        elif params_dict["router"] == "earthcam":
            _view.play(_model.earthcam(params_dict["data"]), "hls")
        elif params_dict["router"] == "youtube":
            _view.play(_model.youtube_stream(params_dict["data"]), "hls")
        elif params_dict["router"] == "pacpark":
            _view.play(_model.pacpark(params_dict["data"]), "hls")
        elif params_dict["router"] == "ipcamlive":
            _view.play(_model.ipcamlive(params_dict["data"]))
        elif params_dict["router"] == "skylinewebcams":
            _view.play(_model.skylinewebcams(params_dict["data"]))
        elif params_dict["router"] == "galveston":
            _view.play(_model.galveston(params_dict["data"]), "hls")
        elif params_dict["router"] == "earthtv":
            _view.play(_model.earthtv(params_dict["data"]), "hls")
        elif params_dict["router"] == "whatsupcams":
            _view.play(_model.whatsupcams(params_dict["data"]))
        elif params_dict["router"] == "aspects-holidays":
            _view.play(_model.aspects_holidays(params_dict["data"]), "hls")
        elif params_dict["router"] == "balticlivecam":
            _view.play(_model.balticlivecam(params_dict["data"]))
        elif params_dict["router"] == "ibiza-style":
            _view.play(_model.ibiza_style(params_dict["data"]), "hls")
        elif params_dict["router"] == "video_nest":
            _view.play(_model.video_nest(params_dict["data"]), "hls")

        elif params_dict["router"] in ["hls", "mpd"]:
            _view.output_logs(params_dict["data"])
            _view.play(params_dict["data"], params_dict["router"])

        # Блок вывода списков
        elif params_dict['router'] == 'realise':
            _view.output(_model.realise(params_dict['data']))
        elif params_dict["router"] == "new":
            _view.output(_model.new())
        elif params_dict["router"] == "catalog":
            _view.output(_model.catalog(params_dict["data"]))
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
