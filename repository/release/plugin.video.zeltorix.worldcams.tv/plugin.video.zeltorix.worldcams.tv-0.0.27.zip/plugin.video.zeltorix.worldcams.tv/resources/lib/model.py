# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули, пакеты
from json import dumps, loads
from html import unescape
from random import shuffle
from re import findall

from bs4 import BeautifulSoup

from .provider import Provider

# Модули с дополнения
from web_api_request import WebApiRequest, headers, https_checking
from get_video_link import VideoLink
from view import View
from history import History


class Model:
    __slots__ = []
    _web = WebApiRequest()
    _history = History()
    _view = View()
    _provider = Provider()
    _link: str = "vt.smacdlrow//:sptth"[::-1]

    def search(self, find_item: str) -> dict:
        self._history.history_add_item(find_item)
        link: str = self._link + f"/list/?q={find_item}"
        return self.catalog(link)

    def realise(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(link)
        if response and response is not int and response is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            category = soup.find("h1").text.strip()
            iframe_and_cam_box_items = findall(r"streams.*?';", response.text)
            list_name = soup.find_all(class_="streams__item")
            num_name = 0
            if iframe_and_cam_box_items:
                for i in iframe_and_cam_box_items:
                    iframe_link = findall(r'http.*?\\', i)[0][:-1]
                    if "worldcams" in iframe_link:
                        iframe_link = iframe_link[32:]
                    elif "isstracker" in iframe_link:
                        continue
                    elif iframe_link in ["https://worldcams.tv/united-kingdom/london/traffic",
                                         "https://worldcams.tv/london-traffic"]:
                        continue
                    model.append(self._provider.iframe_link_check(iframe_link, list_name[num_name].text))
                    num_name += 1
            else:
                if soup.find("iframe"):
                    tag_iframe_link = soup.find("iframe").get("src")
                    if "worldcams" in tag_iframe_link:
                        tag_iframe_link = tag_iframe_link[32:]
                    model.append(self._provider.iframe_link_check(tag_iframe_link, category))
                elif soup.find(class_="cam-box__big open_ext"):
                    onclick_link = soup.find(class_='cam-box__big open_ext').get('onclick').split("'")[1]
                    if "worldcams" in onclick_link:
                        onclick_link = onclick_link[32:]
                    elif "isstracker" in onclick_link:
                        pass
                    elif onclick_link in ["https://worldcams.tv/united-kingdom/london/traffic",
                                          "https://worldcams.tv/london-traffic"]:
                        pass
                    model.append(self._provider.iframe_link_check(onclick_link, category))
                else:
                    raise ValueError(f"Не найдено ссылки на трансляцию - {link}")

        return {
            "category": category,
            "list": tuple(model)
        }

    def catalog(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(link)
        if response and response is not int and response is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            category = soup.find("h1").text.strip()
            for cam_promo in soup.find_all(class_="cam-promo"):
                context_menu: list = []
                if cam_promo.find(class_="cam-promo__sights"):
                    a = cam_promo.find(class_="cam-promo__sights").find_all("a")
                    context_menu.append((
                        f"Категория: {a[0].text}",
                        f"Container.Update({self._view.convert_to_url(router='catalog', data=https_checking(a[0].get('href'), self._link))})"
                    ))
                    context_menu.append((
                        f"Страна: {a[1].text}",
                        f"Container.Update({self._view.convert_to_url(router='catalog', data=https_checking(a[1].get('href'), self._link))})"
                    ))
                model.append({
                    "title": cam_promo.find(class_="cam-promo__title").text.strip(),
                    "data": self._link + cam_promo.find(class_="cam-promo__link").get("href"),
                    "images": self._link + cam_promo.find("source", type="image/webp").get("srcset"),
                    "router": "realise",
                    "context_menu": context_menu,
                })
            if soup.find(class_="pagenator__next"):
                model.append({
                    "title": "===> Следующая страница ===>",
                    "data": self._link + soup.find(class_="pagenator__next").get("href"),
                    "router": "catalog",
                })
            if soup.find(class_="pagenator"):
                for page in soup.find(class_="pagenator").find_all("a", class_=False):
                    model.append({
                        "title": f"Страница {page.text}",
                        "data": self._link + page.get("href"),
                        "router": "catalog",
                    })
        return {
            "category": category,
            "list": tuple(model)
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(https_checking(self._link))
        if response and response is not int and response is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            for nav__item in soup.find_all(class_="nav__item"):
                if nav__item.find("a").get("href") in ["/map/", "/list/?mobile=1"]:
                    continue
                if nav__item.find("span"):
                    model.append({
                        "title": f"[B][COLOR=grey]{nav__item.find('span').text.strip()} =>[/COLOR][/B]",
                        "data": "",
                        "router": "",
                        "icon": "DefaultAddonInfoProvider.png",
                    })
                    for popup__item in soup.find_all(class_="nav-popup__item"):
                        model.append({
                            "title": f"[COLOR=grey]{nav__item.find('span').text.strip()}[/COLOR] => {popup__item.find('a').text.strip()}",
                            "data": self._link + popup__item.find("a").get("href"),
                            "router": "catalog",
                            "icon": "DefaultAddonContextItem.png",
                        })
                else:
                    model.append({
                        "title": nav__item.find("a").text.strip(),
                        "data": self._link + nav__item.find("a").get("href"),
                        "router": "catalog",
                        "icon": "DefaultPlaylist.png",
                    })

            model.append({
                "title": f"[B][COLOR=grey]{soup.find(class_='ctg-btn').text.strip()}[/COLOR][/B]",
                "data": "",
                "router": "",
                "icon": "DefaultAddonInfoProvider.png",
            })
            for popup__item in soup.find(class_="tabs").find_all("a"):
                model.append({
                    "title": f"[COLOR=grey]{soup.find(class_='ctg-btn').text.strip()}[/COLOR] => {popup__item.text.strip()}",
                    "data": self._link + popup__item.get("href"),
                    "router": "catalog",
                    "icon": "DefaultAddonContextItem.png",
                })
        model.append({
            "title": "Меню поиска",
            "data": "",
            "router": "search_menu",
            "icon": "DefaultAddonsSearch.png",
        })
        return {
            "category": "Меню",
            "list": tuple(model)
        }
