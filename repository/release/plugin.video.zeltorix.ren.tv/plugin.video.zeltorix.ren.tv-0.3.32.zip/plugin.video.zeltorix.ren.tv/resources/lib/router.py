# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Не тестируемый модуль.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

# Импорт модуля плагина
from .model import Model
from .library import Library


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _history = History()
    _library = Library()

    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict['router'] == "search_history":
            _view.output(_model.search(params_dict['data']))
        elif params_dict['router'] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict['router'] == "history_del_item":
            if _history.history_del_item(params_dict['data']):
                _view.output(_history.search_menu())

        # Блок работы с библиотекой
        elif params_dict['router'] == "library_folder_default":
            if _library.folder_default():
                _view.dialog_ok(
                    "Сброс папки по умолчанию",
                    "Папка возращена на домашнею папку, согласно Ваше ОС"
                )
        elif params_dict['router'] == "add_to_library":
            if _library.add_to_library(params_dict['data']):
                _view.dialog_ok(
                    "Добавлен в библиотеку-источник",
                    f"Сохранено по пути {_view.get_setting_str('library_folder')}, согласно настройкам"
                )
        elif params_dict['router'] == "library_folder_del":
            if _view.dialog_yesno(
                "Удаление папки библиотеки-источника",
                f"Удалить папку библиотеки-источника: {_view.get_setting_str('library_folder')} ?"
            ):
                if _view.folder_remove(path=_library.library_folder, force=True):
                    _view.dialog_ok(
                        "Папка библиотеки-источника удалена",
                        f"Папка библиотеки-источника удалена:\n{_view.get_setting_str('library_folder')}"
                    )

        # Блок воспроизведения
        elif params_dict["router"] == "platformcraft":
            _view.play(params_dict["data"])
        elif params_dict["router"] == "rutube":
            _view.play(_model.rutube(params_dict["data"]), manifest_type="hls")
        elif params_dict["router"] == "ok":
            _view.play(_model.ok(params_dict["data"]), manifest_type="hls")
        elif params_dict["router"] == "vk":
            _view.play(_model.vk(params_dict["data"]), manifest_type="hls")
        elif params_dict["router"] == "youtube":
            _view.output_logs(_model.youtube(params_dict["data"]))
            _view.play(_model.youtube(params_dict["data"]))
        elif params_dict["router"] in ["hls", "mpd"]:
            _view.play(params_dict["data"], params_dict["router"])

        # Блок текста
        elif params_dict["router"] == "dialog_text_viewer":
            _view.dialog_text_viewer(*_model.api_site(params_dict["data"], only_text=True))

        # Блок вывода списков
        elif params_dict["router"] == "online":
            _view.output(_model.online())
        elif params_dict["router"] == "tv_program":
            _view.output(_model.tv_program())
        elif params_dict['router'] == 'realise':
            if _view.get_setting_bool("history_realise"):
                _view.set_setting("history_realise_item", params_dict['data'])
            _view.output(_model.realise(params_dict['data']))
        elif params_dict['router'] == 'last_realise':
            _view.output(_model.realise(params_dict['data']))
        elif params_dict["router"] == "new":
            _view.output(_model.new())
        elif params_dict["router"] == "category":
            _view.output(_model.category())
        elif params_dict["router"] == "catalog":
            _view.output(_model.catalog(params_dict["data"]))
        elif params_dict["router"] == "news":
            _view.output(_model.news())
        elif params_dict["router"] == "api_site":
            _view.output(_model.api_site(params_dict["data"]))
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
