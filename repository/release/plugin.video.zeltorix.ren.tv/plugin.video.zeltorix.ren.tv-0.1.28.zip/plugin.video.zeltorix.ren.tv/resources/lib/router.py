# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Не тестируемый модуль.
"""
# Стандартные модули
from urllib.parse import parse_qsl

# Импорт модуля плагина
from .model import ModelRenTv
from .view import View


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    # import logging
    # logger = logging.getLogger(__name__)
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    view = View()
    model = ModelRenTv()
    if params_dict:
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                view.main(model.search(params_dict['keyword']))
            else:
                # Вывод поиска, импортировано из модуля view
                view.main(model.search(view.search()))
        elif params_dict['router'] == 'platformcraft':
            view.play(params_dict['data'], adaptive=False)
        elif params_dict['router'] == 'rutube':
            view.play(model.rutube(params_dict['data']))
        elif params_dict['router'] == 'ok_vk':
            view.play(model.ok_vk_youtube(params_dict['data']))
        elif params_dict['router'] == 'youtube':
            view.play(model.ok_vk_youtube(params_dict['data']), adaptive=False)
        elif params_dict['router'] == "project":
            project = model.project(params_dict['data'])
            view.project(project)
        elif params_dict['router'] == "online":
            view.main(model.online())
        elif params_dict['router'] == "online_play":
            view.play(params_dict['data'])
        elif params_dict['router'] == "new":
            new = model.new()
            view.main(model.check_projects(new[0], category=new[1]))
        elif params_dict['router'] == "categories":
            view.main(model.categories())
        elif params_dict['router'] == "category":
            category = model.category(params_dict['data'])
            view.main(model.check_projects(category[0], category=category[1], sort_title=True))
        elif params_dict['router'] == "all_projects":
            all_projects = model.all_projects()
            view.main(model.check_projects(all_projects[0], category=all_projects[1], sort_title=True))
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        view.main(model.main())
