# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""

import requests


class ParserRenTv:
    """
    Клас для получения данных
    """
    __slots__ = []
    session = requests.Session()
    _link_api_rentv: str = "0/ipa/vt.ner//:sptth"[::-1]
    _link_api_rutube: str = "/snoitpo/yalp/ipa/ur.ebutur//:sptth"[::-1]
    _link_online_getting = "lmth.reyalp/bew_vtner/vtner/ur.anirtivaidem.reyalp//:sptth"[::-1]
    _link_online: str = "&7473002=di_noisrev_sserge&=652ahs_muskcehc_gifnoc&vt.ner=emantsoh_rerefer_reyalp&=di_noitacilppa?nosj.yarra_sa_vt-ner/tsilyalp/gmn/3v/ipa/ur.anirtivaidem.aidem//:sptth"[::-1]
    _link_current_time = "emit_tnerruc/ur.anirtivaidem.aidem//:sptth"[::-1]
    _headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.57",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    }
    _headers_online = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Referer": "/ur.anirtivaidem.reyalp//:sptth"[::-1]
    }

    def api(self, data: str) -> dict:
        return self._rest_api(self._link_api_rentv + data)

    def rutube(self, id_: str) -> dict:
        return self._rest_api(self._link_api_rutube + id_)

    def online(self) -> dict:
        # return self.session.get(self._link_online, headers=self._headers_online).json()
        response: str = self.session.get(self._link_online_getting).text
        from re import search
        mirror: str = search(r"'?*./ipa/ur.anirtivaidem.aidem//:sptth'"[::-1], response)[0].strip("'")
        link: str = mirror.replace("{{APPLICATION_ID}}", "").replace("{{PLAYER_REFERER_HOSTNAME}}", "ren.tv").replace(
            "{{CONFIG_CHECKSUM_SHA256}}", "")
        return self.session.get(link, headers=self._headers_online).json()

    def current_time(self) -> str:
        return self.session.get(self._link_current_time).text

    def _rest_api(self, link: str, retry: int = 10) -> (dict, str):
        import xbmc
        xbmc.log(msg=f'_rest_api: {link}', level=xbmc.LOGINFO)
        from random import randint
        # Не стандартный модуль импортируется в addon.xml как script.module.requests
        response = self.session.get(link, headers=self._headers, timeout=randint(5, 15))
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self._rest_api(link, retry - 1)
            elif response.status_code == 404:
                if response.json()["detail"]["languages"][0]["title"] == "Видео скрыто":
                    # TODO Добавить оповещение в интерфейс
                    return "Видео ещё не опубликовано"
                # TODO Добавить оповещение в интерфейс
                return "Изменился API"
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            if retry:
                from time import sleep
                # TODO Добавить оповещение в интерфейс
                sleep(randint(2, 10))
                return self._rest_api(link, retry - 1)
            else:
                raise ValueError("Что то не то с API...")
