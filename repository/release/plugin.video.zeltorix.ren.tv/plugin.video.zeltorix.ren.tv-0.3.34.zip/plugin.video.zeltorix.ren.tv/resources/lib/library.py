# -*- coding: utf-8 -*-
# Module: library
# Author: Zeltorix
# Created on: 2023.09.13
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль истории работы с поиском.
"""
# Стандартные модули
import json
from pathlib import Path
import re

from sanitize_filename import sanitize
from view import View
from web_api_request import WebApiRequest, headers, https_checking

# Импорт модуля плагина из текущего каталога
from .model import Model


class Library():
    __slots__ = []
    _view = View()
    _model = Model()
    _web = WebApiRequest()
    library_folder: str = str(Path(_view.library_folder, _view.id_plugin))

    def default(self) -> bool:
        if self._view.get_setting_str("library_folder"):
            pass
        else:
            self._view.set_setting("library_folder", self.library_folder)
            return True

    def folder_default(self) -> bool:
        self._view.set_setting("library_folder", self.library_folder)
        return True

    def add_to_library(self, link: str) -> bool:
        # # Наследуемый метод интерфейса
        # path_lib: str = self._view.set_setting_str("library_folder")
        # # Наследуемый метод запроса
        # response = self.request_get(https_checking(link, self._link_api_rentv))
        # if response and response is not int and response is not dict:
        #     j_data = response.json()["data"]
        #     for season in j_data['seasons']:
        #             self._realise_content(
        #                 self.request_get(
        #                     https_checking(
        #                         f"/episode/list/{j_data['id']}/{season['id']}",
        #                         self._link_api_rentv)
        #                 ).json()
        #             )
        #     category = j_data["title"]
        #
        #     for season in seasons:
        #         if season["season"] >= 2 and not Path.is_dir(path_lib_serial):
        #             path_lib_serial = Path(
        #                 path_lib.encode('utf-8').decode('utf-8'),
        #                 "serials".encode('utf-8').decode('utf-8'),
        #                 category_s.encode('utf-8').decode('utf-8')
        #             )
        #         for episode in season["episodes"]:
        #             if Path.is_dir(path_lib_serial):
        #                 pass
        #             else:
        #                 Path(path_lib_serial).mkdir(parents=True, exist_ok=True)
        #
        #             season_num: str = str(season["season"])
        #             if len(season_num) == 1:
        #                 season_num: str = "00" + season_num
        #             elif len(season_num) == 2:
        #                 season_num: str = "0" + season_num
        #
        #             episode_num: str = str(episode["episode"])
        #             if len(episode_num) == 1:
        #                 episode_num: str = "00" + episode_num
        #             elif len(episode_num) == 2:
        #                 episode_num: str = "0" + episode_num
        #
        #             path_file = Path(
        #                 path_lib_serial,
        #                 f's{season_num}e{episode_num}.strm'.encode('utf-8').decode('utf-8')
        #             )
        #             with open(path_file, "w+") as strm:
        #                 # Наследуемый метод интерфейса
        #                 strm.write(self._view.convert_to_url(router="play", data={episode["hls"]}))
        #
            return True
