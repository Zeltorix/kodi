# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули, пакеты
from json import dumps, loads
from html import unescape
from random import shuffle
from re import findall

# Модули с дополнения
from web_api_request import WebApiRequest, headers, https_checking
from get_video_link import VideoLink
from view import View
from history import History
from text_job import clear_html_tags, date_time_to_local
import xmltodict


class Model:
    __slots__ = []

    _view = View()
    _web = WebApiRequest()
    _video_link = VideoLink()
    _history = History()
    _link_rentv: str = "/vt.ner//:sptth"[::-1]
    _link_api_rentv: str = _link_rentv + "0/ipa"[::-1]
    _link_online: str = "lmth.reyalp/bew_vtner/vtner/ur.anirtivaidem.reyalp//:sptth"[::-1]
    _link_news: str = _link_rentv + "lmx.ssr/labolg/tropxe"[::-1]
    # Проекты без видео, как сделать проверку без лишних запросов, за что зацепится не нашёл.
    _no_video_projects: list = [
        308,  # Экстренный вызов 112
        713,  # Кино
        65914,  # Сериал по выходным
        73618,  # Знахарь (2008)
        127221,  # Кремень (2012)
        141631,  # Благотворительный проект WorldVita и РЕН ТВ
        145900,  # Джокер (2012)
        151234,  # «Гроб Господень - открытие главной тайны человечества» — Документальный фильм
        238476,  # С бодрым утром!
        411519,  # СМЕРШ (2019)
        445808,  # «Игра Престолов» на РЕН ТВ
        446472,  # СМЕРШ: продолжение (2019)
        446551,  # И снова здравствуйте! (2022)
        446589,  # Варяг (2021)
        446596,  # Лапси (2018)
        446662,  # Крутые меры (2023)
        446663,  # РэмбО (2023)
        446665,  # Операция «Неман» (2023)
        446705,  # Библиотекарь (2023)
    ]
    # Отсутствует жанр сериалов, ставлю на своё усмотрение
    _no_genres_serials: list = [
        446593,  # Вкус убийства (2003)
        446594,  # Стая (2005)
        446595,  # Отцы (2016)
    ]
    # Отсутствует жанр передач, ставлю на свое усмотрение
    _no_genres_broadcasts: list = [
        108180,  # #Спецпроект
        238483,  # Документальный проект
    ]

    def _realise_content(self, data: dict) -> list:
        """
        Обработка годов проектов или сезонов сериалов

        :param dict data:
        :return list:
        """

        model_list: list = []

        # def no_video_content():
        #     """
        #     При отсутствие видео контента
        #
        #     """
        #     model["title"]: str = f"[COLOR=red]-----Нет потока для видео----- {item['title'] or ''}[/COLOR]"
        #     model["data"]: str = ""
        #     model["router"]: str = ""

        for item in data["data"]:
            model: dict = {
                "title": str(item["title"]),
                "premiered": item["published_at"].split("T")[0] or "",
                "plot": clear_html_tags(item["description"] or ""),
                "play": True,
            }
            if item.get("image"):
                model["images"] = item["image"]["url"] or ""
            else:
                model["images"] = str()
            if item["config"]["provider"] == "platformcraft":
                if item["config"]["platformcraft"] and item["config"]["platformcraft"]["list"]:
                    model["data"]: str = "http://" + item["config"]["platformcraft"]["list"][0]["cdn_url"]
                    model["router"]: str = "platformcraft"
                else:
                    # no_video_content()
                    continue
            elif item["config"]["provider"] == "rutube" and item["config"]["rutube"]:
                if item["config"]["rutube"].get("duration"):
                    duration: int = item["config"]["rutube"]["duration"]
                else:
                    duration = 0
                model["data"]: str = item["config"]["rutube"]["id"]
                model["router"]: str = "rutube"
                model["duration"]: int = duration
            elif item["config"]["provider"] == "ok" and item["config"]["ok"]:
                model["data"]: str = item["config"]["ok"]["id"] or ""
                model["router"]: str = "ok"
            elif item["config"]["provider"] == "vk" and item["config"]["vk"]:
                model["data"]: str = item["config"]["vk"]["id"] or ""
                model["router"]: str = "vk"
            elif item["config"]["provider"] == "youtube" and item["config"]["youtube"]:
                if item["config"]["youtube"]["id"].startswith("http"):
                    model["data"]: str = item["config"]["youtube"]["id"] or ""
                else:
                    model["data"]: str = "https://www.youtube.com/watch?v=" + item["config"]["youtube"]["id"]
                model["router"]: str = "youtube"
            elif not item["config"]["provider"]:
                # no_video_content()
                continue
            else:
                raise ValueError(
                    f"Неизвестный поставщик видео: {dumps(item['config'], indent=2)} - {item['title']}")

            model_list.append(model)
        return model_list

    def realise(self, link: str) -> dict:
        """
        Перебор годов проектов или сезонов сериалов

        :param str link:
        :return dict:
        """
        model: list = []
        category = ""
        response = self._web.request_get(https_checking(link, self._link_api_rentv))
        if response and type(response) is not dict:
            j_data = response.json()["data"]
            for season in j_data['seasons']:
                model.extend(
                    self._realise_content(
                        self._web.request_get(
                            https_checking(
                                f"/episode/list/{j_data['id']}/{season['id']}",
                                self._link_api_rentv)
                        ).json()
                    )
                )
            category = j_data["title"]
        return {
            "category": category,
            "list": tuple(model)
        }

    def rutube(self, link: str) -> str:
        return self._video_link.rutube_link(link)

    def ok(self, link: str) -> str:
        return self._video_link.ok_link(link)

    def vk(self, link: str) -> str:
        return self._video_link.vk_link(link)

    def youtube(self, link: str) -> str:
        return self._video_link.youtube_link(link)

    def online(self) -> dict:
        """
        Обработка прямого эфира

        :return dict:
        """
        model: list = []
        plot = "Далее:"
        current_program = ""
        images: str = ""

        response_tv_program = self._web.request_get(https_checking("/tv-program", self._link_api_rentv))
        if response_tv_program and type(response_tv_program) is not dict:
            tv_program: dict = response_tv_program.json()["data"]

            if tv_program["current"]["title"]:
                current_program: str = tv_program["current"]["title"]
            else:
                current_program: str = tv_program["current"]["projects"][0]["title"]

            if tv_program["current"].get("image") and tv_program["current"]["image"].get("previews") and \
                    tv_program["current"]["image"]["previews"].get("thumb"):
                images: str = tv_program["current"]["image"]["previews"]["thumb"]

            current_time: str = tv_program["current"]["started_at"]

            pr_num: int = 0
            for program in tv_program["list"]:
                if program["started_at"] > current_time:
                    tv_pro: str = program["title"]
                    if program["title"] == "":
                        for project in program["projects"]:
                            tv_pro: str = project["title"]

                    try:
                        time_tv_program = date_time_to_local(
                            data_input=program['started_at'],
                            format_input="%Y-%m-%dT%H:%M:%S%z",
                            format_output="%H:%M")
                    except:
                        time_tv_program = "[COLOR=red]TIME KODI ERROR[/COLOR]"

                    plot += f"\n{time_tv_program} - {tv_pro}"
                    pr_num += 1
                    if pr_num == int(self._view.get_setting_int("online__tv_program")):
                        break

            model.append(
                {
                    "title": "Телепрограмма",
                    "router": "tv_program",
                    "plot": "Телепрограмма c сайта РЕН ТВ",
                    "icon": "DefaultAddonTvInfo.png",
                }
            )

        data_dict: dict = {}
        response_site = self._web.request_get(self._link_rentv)
        if response_site and type(response_site) is not dict:
            link_find: list = findall(r"\w+://\w+\.\w+\.\w+/\w+/\w+/\w+\.\w{4}", response_site.text)
            if link_find:
                data_dict = VideoLink().mediavitrina_links(link_find[0])
            else:
                data_dict = VideoLink().mediavitrina_links(self._link_online)

        num: int = 1
        if data_dict:
            hls = data_dict["hls"]
            shuffle(hls)
            for stream in hls:
                model.append(
                    {
                        "title": f"Источник - {num}. В эфире - {current_program}",
                        "router": "hls",
                        "data": stream,
                        "plot": plot,
                        "images": images,
                        "play": True,
                    }
                )
                num += 1

            if self._view.get_setting_bool("online__tv_program_all"):
                mpd = data_dict["mpd"]
                shuffle(mpd)
                for stream in mpd:
                    model.append(
                        {
                            "title": f"Источник - {num}. В эфире - {current_program}",
                            "router": "mpd",
                            "data": stream,
                            "plot": plot,
                            "images": images,
                            "play": True,
                        }
                    )
                    num += 1

        return {
            "category": "Прямой Эфир",
            "list": tuple(model)
        }

    def tv_program(self) -> dict:
        """
        Обработка телепрограммы

        :return dict:
        """
        model: list = []
        response_tv_program = self._web.request_get(https_checking("/tv-program", self._link_api_rentv))
        if response_tv_program and type(response_tv_program) is not dict:
            tv_program: dict = response_tv_program.json()["data"]
            current_time: str = tv_program["current"]["started_at"]

            for program in tv_program["list"]:
                title: str = ""
                images: str = ""
                select = False

                if program["title"] == "":
                    for project in program["projects"]:
                        title: str = project["title"]
                else:
                    title: str = program["title"]

                try:
                    time_tv_program = date_time_to_local(
                        data_input=program['started_at'],
                        format_input="%Y-%m-%dT%H:%M:%S%z",
                        format_output="%Y/%m/%d %H:%M")
                except:
                    time_tv_program = "[COLOR=red]TIME KODI ERROR[/COLOR]"

                title = f"{time_tv_program} {title}"

                if program["started_at"] < current_time:
                    title = f"[COLOR=grey]{title}[/COLOR]"

                if program.get("image") and program["image"].get("previews") and \
                        program["image"]["previews"].get("thumb"):
                    images: str = program["image"]["previews"]["thumb"]

                if program["url"] == "/live":
                    select = True

                model.append({
                        "title": title,
                        "router": "",
                        "data": "",
                        "icon": images,
                        "thumb": images,
                        "select": select,
                    })
        return {
            "category": "Телепрограмма",
            "list": tuple(model)
        }

    def new(self) -> dict:
        """
        Обработка новых выпусков

        :return dict:
        """
        model: list = []
        response = self._web.request_get(https_checking("/project?page=1", self._link_api_rentv))
        if response and type(response) is not dict:
            model.extend(self._checking_projects(response.json()["data"]["items"]))

        return {
            "category": "Новые выпуски",
            "list": tuple(model)
        }

    def search(self, find_item: str) -> dict:
        """
        Обработка поиска

        :param str find_item:
        :return dict:
        """
        # Наследуемый метод истории
        self._history.history_add_item(find_item)
        model: list = []
        response = self._web.request_get(https_checking("/project?page=1&limit=0", self._link_api_rentv))
        if response and type(response) is not dict:
            for item in self._checking_projects(response.json()["data"]["items"]):
                if (find_item.lower() in item["title"].lower()) or (find_item.lower() in item["plot"].lower()):
                    model.append(item)
        return {
            "category": "Найдено",
            "list": tuple(model),
            "sort": [
                10,  # SORT_METHOD_TITLE_IGNORE_THE
            ],
        }

    def catalog(self, link: str) -> dict:
        """
        Обработка каталога

        :param str link:
        :return dict:
        """
        model: list = []
        response = self._web.request_get(https_checking(link, self._link_api_rentv))
        if response and type(response) is not dict:
            model.extend(self._checking_projects(response.json()["data"]["items"]))

        return {
            "category": "Каталог",
            "list": tuple(model),
            "sort": [
                10,  # SORT_METHOD_TITLE_IGNORE_THE
            ],
        }

    def _checking_projects(self, response: list) -> list:
        """
        Проверка проектов и сериалов на наличие. Создание пункта меню

        :param list response:
        :return list:
        """
        model: list = []
        for project in response:

            if project["id"] in self._no_video_projects:
                continue

            model_dict: dict = {
                "title": project["title"] or "",
                "router": "realise",
                "data": https_checking(project["url"], self._link_api_rentv),
                "plot": clear_html_tags(project["description"] or "")
            }

            if project.get("genres"):
                model_dict["genres"] = [*[category["title"] for category in project["categories"]],
                                        str(project["genres"][0]["title"])]
            else:
                if project["id"] in self._no_genres_serials:
                    model_dict["genres"] = ["Сериалы", "Развлекательные"]
                elif project["id"] in self._no_genres_broadcasts:
                    model_dict["genres"] = ["Передачи", "Документальные"]

            if project.get("image"):
                model_dict["images"] = project["image"]["url"] or ""
            else:
                model_dict["images"] = project["poster"]["url"] or ""

            model.append(model_dict)
        return model

    def category(self) -> dict:
        """
        Обработка категорий проектов

        :return dict:
        """
        model: list = []
        response = self._web.request_get(https_checking("/category", self._link_api_rentv))
        if response and type(response) is not dict:
            for category in response.json()["data"]["items"]:
                if category.get("description"):
                    plot = clear_html_tags(category["description"])
                else:
                    plot = ""
                model.append({
                    "title": category["title"] or "",
                    "router": "catalog",
                    "data": https_checking(f"/project?page=1&limit=0&category={category['id']}", self._link_api_rentv),
                    "plot": plot,
                    "icon": "DefaultMovieTitle.png"
                })
        return {
            "category": "Категории проектов",
            "list": tuple(model)
        }

    def api_site(self, link: str, only_text: bool = False) -> (dict, str):
        """
        Обработка ссылок сайта

        :param str link:
        :param bool only_text:
        :return dict, str:
        """
        category = ""
        model: list = []
        long_text: list = []
        response = self._web.request_get(link)
        if response and type(response) is not dict:
            json_data = response.json()
            category = json_data["data"]["title"]
            plot = json_data["data"]["description"]
            video = ""
            if json_data["data"].get("image"):
                images = json_data["data"]["image"]["url"]
            else:
                images = json_data["config"]["og_image"]
            if json_data["data"]["type"] == "news":
                for item in json_data["data"]["contents"]:
                    if item["type"] == "text":
                        long_text.append(clear_html_tags(item['body']))
                if long_text:
                    model.append({
                        "title": "Текстовая версия",
                        "data": link,
                        "router": "dialog_text_viewer",
                        "images": images,
                        "not_folder": True,
                        "plot": plot,
                    })

                for item in response.json()["data"]["contents"]:
                    if item["type"] == "video":
                        video = "http://" + item["materials"][0]["config"]["platformcraft"]["list"][0]["cdn_url"]
                        images = "http://" + item["materials"][0]["config"]["platformcraft"]["list"][0]["previews"][0]
                if video:
                    model.append({
                        "title": "Видео",
                        "data": video,
                        "router": "platformcraft",
                        "images": images,
                        "play": True,
                        "plot": plot,
                    })
            elif json_data["data"]["type"] == "video":
                model.append({
                    "title": "Видео",
                    "data": "http://" + json_data["data"]["config"]["platformcraft"]["list"][0]["cdn_url"],
                    "router": "platformcraft",
                    "images": images,
                    "play": True,
                    "plot": plot,
                })

        if only_text:
            return category, "\n".join(long_text),

        return {
            "category": category,
            "list": tuple(model),
        }

    def news(self) -> dict:
        """
        Обработка новостей

        :return:
        """
        model: list = []
        response = self._web.request_get(https_checking(self._link_news, self._link_api_rentv))
        if response and type(response) is not dict:
            dict_rss = xmltodict.parse(response.text)
            for item in dict_rss["rss"]["channel"]["item"]:
                try:
                    time_title = date_time_to_local(
                        data_input=item['pubDate'],
                        format_input='%a, %d %b %Y %H:%M:%S %z',
                        format_output='%H:%M')
                except:
                    time_title = "[COLOR=red]TIME KODI ERROR[/COLOR]"

                try:
                    time_premiered = date_time_to_local(
                        data_input=item['pubDate'],
                        format_input='%a, %d %b %Y %H:%M:%S %z')
                except:
                    time_premiered = "[COLOR=red]TIME KODI ERROR[/COLOR]"

                model_item: dict = {
                    "title": f"[B]{time_title}[/B] {item['title']}",
                    "data": self._link_api_rentv + item["link"][14:],
                    "premiered": time_premiered,
                    "router": "api_site",
                    "icon": dict_rss["rss"]["channel"]["image"]["url"],
                }
                plot = ""
                if item.get("category"):
                    plot += f"[B]{item['category']}[/B]\n"
                if item.get("description"):
                    plot += (" ".join(unescape(item["description"]).split()))
                if item.get("enclosure"):
                    model_item["icon"] = item["enclosure"]["@url"]
                model_item["plot"] = plot
                model.append(model_item)
            return {
                "category": dict_rss["rss"]["channel"]["description"],
                "list": tuple(model),
            }

    def main(self) -> dict:
        """
        Создание модели начального меню

        :return dict:
        """
        model: list = [
            {
                "title": "Прямой эфир",
                "router": "online",
                "plot": "Прямой эфир канала с телепрограммой",
                "icon": "DefaultAddonPVRClient.png",
            },
            {
                "title": "Новости",
                "router": "news",
                "plot": "Новости с сайта РЕН ТВ",
                "icon": "DefaultAddonArtistInfo.png",
            },
            {
                "title": "Новые выпуски",
                "router": "new",
                "plot": "Свежие выпуски в проектах",
                "icon": "DefaultAddonsUpdates.png"
            },
            {
                "title": "Категории проектов",
                "router": "category",
                "plot": "Категории проектов согласно сайту",
                "icon": "DefaultPlaylist.png",
            },
        ]
        if self._view.get_setting_bool("history_realise") and self._view.get_setting_str("history_realise_item"):
            model.append({
                "title": "Последний просмотр",
                "router": "last_realise",
                "data": self._view.get_setting_str("history_realise_item"),
                "plot": "Открывает последний просмотренный проект/сериал/фильм",
                "icon": "DefaultInProgressShows.png",
            })
        model.append({
            "title": "Меню поиска",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        })
        return {
            "category": "Меню",
            "list": tuple(model)
        }
