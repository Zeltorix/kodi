# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserRenTv
    from .view import View
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.release.ren_tv.resources.lib.parser import ParserRenTv


class ModelRenTv:
    __slots__ = []
    _parser = ParserRenTv()
    _view = View()

    @staticmethod
    def _cleanhtml(raw_html):
        import re
        return " ".join(re.sub(re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});'), '', raw_html).split())

    def _season(self, data: dict) -> tuple:
        model_list: list = []

        def no_video_content():
            model["title"]: str = f"-----Нет потока для видео----- {str(item['title'])}"
            model["player"]: str = ""
            model["router"]: str = ""

        for item in data["data"]:
            model: dict = {
                "title": str(item["title"]),
                "premiered": str(item["published_at"].split("T")[0]),
                "plot": str(self._cleanhtml(item["description"])),
            }
            if item.get("image"):
                model["posters"] = str(item["image"]["url"])
            else:
                model["posters"] = str()
            if item["config"]["provider"] == "platformcraft":
                if item["config"]["platformcraft"] and item["config"]["platformcraft"]["list"]:
                    model["player"]: str = "http://" + item["config"]["platformcraft"]["list"][0]["cdn_url"]
                    model["router"]: str = "platformcraft"
                else:
                    no_video_content()
            elif item["config"]["provider"] == "rutube" and item["config"]["rutube"]:
                model["player"]: str = item["config"]["rutube"]["id"]
                model["router"]: str = "rutube"
            elif item["config"]["provider"] == "ok" and item["config"]["ok"]:
                model["player"]: str = "https://ok.ru/video/" + item["config"]["ok"]["id"]
                model["router"]: str = "ok_vk"
            elif item["config"]["provider"] == "vk" and item["config"]["vk"]:
                model["player"]: str = "https://vk.com/video" + item["config"]["vk"]["id"]
                model["router"]: str = "ok_vk"
            elif item["config"]["provider"] == "youtube" and item["config"]["youtube"]:
                if item["config"]["youtube"]["id"].startswith("http"):
                    model["player"]: str = item["config"]["youtube"]["id"]
                else:
                    model["player"]: str = "https://www.youtube.com/watch?v=" + item["config"]["youtube"]["id"]
                model["router"]: str = "youtube"
            elif not item["config"]["provider"]:
                no_video_content()
            else:
                msg: str = f"Неизвестный поставщик видео: {json.dumps(item['config'], indent=2, ensure_ascii=False)} - {item['title']}"
                raise Exception(msg)
            model_list.append(model)
        return tuple(model_list)

    def project(self, url_project: str) -> dict:
        data: dict = self._parser.api(url_project)["data"]

        # TODO Перелопатить в асинхронку
        # import asyncio
        #
        # async def client(link):
        #     import aiohttp
        #     async with aiohttp.ClientSession() as session:
        #         async with session.get("0/ipa/vt.ner//:sptth"[::-1] + link) as response:
        #             return await response
        #
        #
        # listing = []
        #
        # async def get_new_data(season) -> dict:
        #     response = await client(f"/episode/list/{data['id']}/{season['id']}")
        #     data_new = await response.json()
        #     return data_new
        #
        # async def asyncio_run() -> None:
        #     coroutines = [get_new_data(season) for season in data['seasons']]
        #     new_data = asyncio.gather(*coroutines)
        #     listing.extend(new_data)
        #
        # asyncio.run(asyncio_run())

        listing = []
        for season in data['seasons']:
            listing.extend(self._season(self._parser.api(f"/episode/list/{data['id']}/{season['id']}")))

        # from itertools import chain
        # listing = list(chain.from_iterable(self._season(self._parser.api(f"/episode/list/{data['id']}/{season['id']}")) for season in data['seasons']))

        return {
            "category": data["title"],
            "players": tuple(listing)
        }

    def rutube(self, id_: str) -> str:
        return self._parser.rutube(id_)["video_balancer"]["m3u8"]

    def ok_vk_youtube(self, link: str) -> str:
        import yt_dlp
        ydl = yt_dlp.YoutubeDL({})
        try:
            for i in ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"]:
                if i.get("manifest_url"):
                    return i["manifest_url"]
                if i.get("fps") and i["fps"] and i.get("audio_channels") and i["audio_channels"] \
                        and i["format_note"] == "720p":
                    return i["url"]
        except yt_dlp.DownloadError:
            from sys import exc_info
            msg_error = str(exc_info()[1])
            self._view.error(heading="Ошибка потока", message=msg_error, type_message="error")
        except Exception as error:
            import xbmc
            xbmc.log(msg=f'\n\n\nok_vk_youtube ERROR: {error}\n\n\n', level=xbmc.LOGERROR)

    def online(self) -> dict:
        tv_program: dict = self._parser.api("/tv-program")["data"]
        current_time: str = self._parser.current_time()
        img: str = ""
        current: str = tv_program["current"]["title"]

        def msk_to_local_datetime(date_time):
            from datetime import datetime
            import time
            # С начало в UTC c с обрезкой временной зоны, разделяем по значениям относительно шаблону, преобразуем в
            # секунды и отнимаем мск время
            utc = datetime.strptime(date_time.split("+")[0], "%Y-%m-%dT%H:%M:%S").timestamp() - 10800
            # Далее разделяем дату и время на составляющие, делаем срез с года до секунд, распаковываем по значениям
            utc_datetime = datetime(*time.localtime(utc)[:6])
            # Далее вычисляем отклонения времени от начало эпохи
            delta = utc_datetime - datetime(1970, 1, 1)
            # Далее секунды за день умножаем на количество дней отклонения и прибавляем секунды отклонения
            utc_epoch = 24 * 60 * 60 * delta.days + delta.seconds
            # Далее полученные секунды разделяем на год, месяц, день, час, минута и секунда
            time_struct = time.localtime(utc_epoch)
            # Далее делаем срез с года до секунд и прибавляем отклонения микросекунд
            dt_args = time_struct[:6] + (delta.microseconds,)
            # Вновь распаковываем полученные значения и преобразуем в нужный формат вывода
            return datetime(*dt_args).strftime('%H:%M')

        if current == "":
            for project in tv_program["current"]["projects"]:
                current: str = project["title"]
        if tv_program["current"].get("image") and tv_program["current"]["image"].get("previews") and \
                tv_program["current"]["image"]["previews"].get("thumb"):
            img: str = tv_program["current"]["image"]["previews"]["thumb"]

        plot: str = "Далее:"
        num: int = 0
        for program in tv_program["list"]:
            if program["started_at"] > current_time:
                tv_pro: str = program["title"]
                if program["title"] == "":
                    for project in program["projects"]:
                        tv_pro: str = project["title"]
                from datetime import datetime
                plot += f"\n{msk_to_local_datetime(program['started_at'])} - {tv_pro}"
                num += 1
                if num == 10:
                    break

        model: list = []
        num: int = 1
        for stream in self._parser.online()["hls"]:
            model.append(
                {
                    "title": f"Источник - {num}. В эфире - {current}",
                    "router": "online_play",
                    "data": stream,
                    "plot": plot,
                    "genres": [],
                    "posters": img,
                }
            )
            num += 1
        return {
            "category": "Прямой Эфир",
            "list": tuple(model)
        }

    def new(self) -> tuple:
        return self._parser.api("/project?page=1")["data"]["items"], "Обновления в проектах"

    def search(self, find_item: str) -> dict:
        # TODO перелопатить в более быстрый
        listing = self.check_projects(self._parser.api("/project?page=1")["data"]["items"], sort_title=True)["list"]
        return {
            "category": "Найдено",
            "list": tuple(filter(lambda dictionary: find_item.lower() in dictionary['title'].lower(), listing))
        }

    def check_projects(self, listing: list, category: str = "Проекты", sort_title: bool = False) -> dict:
        model: list = []
        # Проекты без видео, как сделать проверку без лишних запросов, за что зацепится не нашёл
        no_video_projects: list = [308, 713, 65914, 73618, 127221, 141631, 145900, 151234, 238476, 411519, 445808,
                                   446472, 446551, 446589, 446596, 446662, 446663, 446665]
        # Отсутствует жанр сериалов, ставлю на свое усмотрение
        no_genres_serialy_projects: list = [446593, 446594, 446595]
        # Отсутствует жанр передач, ставлю на свое усмотрение
        no_genres_peredachi_projects: list = [108180, 238483]
        for project in listing:
            if project["id"] in no_video_projects:
                continue
            model_dict: dict = {
                "title": project["title"],
                "router": "project",
                "data": project["url"],
                "plot": str(self._cleanhtml(project["description"]))
            }
            if project["genres"]:
                if len(project["categories"]) > 1:
                    model_dict["genres"] = [*[category["title"] for category in project["categories"]],
                                            str(project["genres"][0]["title"])]
                else:
                    model_dict["genres"] = [str(project["categories"][0]["title"]),
                                            str(project["genres"][0]["title"])]
            else:
                if project["id"] in no_genres_serialy_projects:
                    model_dict["genres"] = ["Сериалы", "Развлекательные"]
                elif project["id"] in no_genres_peredachi_projects:
                    model_dict["genres"] = ["Передачи", "Документальные"]
                else:
                    model_dict["genres"] = []
            if project.get("image"):
                model_dict["posters"] = str(project["image"]["url"])
            else:
                model_dict["posters"] = str(project["poster"]["url"])
            model.append(model_dict)
        if sort_title:
            model.sort(key=lambda dictionary: dictionary['title'])
        return {
            "category": category,
            "list": tuple(model)
        }

    def categories(self) -> dict:
        model_list: list = []
        for category in self._parser.api("/category")["data"]["items"]:
            if category.get("description"):
                plot = category["description"]
            else:
                plot = ""
            model_list.append({
                "title": category["title"],
                "router": "category",
                "data": category["id"],
                "plot": plot,
                "genres": [],
                "posters": "",
            })
        return {
            "category": "Категории проектов",
            "list": tuple(model_list)
        }

    def category(self, category: str) -> (list, ValueError):
        if category == "69":
            name_category: str = "Передачи"
        elif category == "70":
            name_category: str = "Сериалы"
        elif category == "99":
            name_category: str = "Спецпроекты"
        else:
            return ValueError("Неизвестная категория проекта")
        return [self._parser.api(f"/project?page=1&limit=0&category={category}")["data"]["items"], name_category]

    def all_projects(self) -> tuple:
        return self._parser.api("/project?page=1&limit=0")["data"]["items"], "Все проекты"

    def main(self) -> dict:
        model_list: list = [
            {
                "title": "Прямой эфир",
                "router": "online",
                "data": "",
                "plot": "Прямой эфир канала",
                "genres": [],
                "posters": "",
            },
            {
                "title": "Новые",
                "router": "new",
                "data": "",
                "plot": "Свежие видео в проектах",
                "genres": [],
                "posters": "",
            },
            {
                "title": "Категории проектов",
                "router": "categories",
                "data": "",
                "plot": "Категории проектов согласно сайту",
                "genres": [],
                "posters": "",
            },
            {
                "title": "Все проекты",
                "router": "all_projects",
                "data": "",
                "plot": "Все проекты доступные для просмотра через сайт",
                "genres": [],
                "posters": "",
            },
            {
                "title": "Поиск",
                "router": "search",
                "data": "",
                "plot": "Примитивный поиск по проектам",
                "genres": [],
                "posters": "",
            },
        ]
        # model_list: list = []
        # online: dict = {
        #     "title": "Прямой эфир",
        #     "router": "online",
        #     "data": "",
        #     "plot": "Прямой эфир канала",
        #     "genres": [],
        #     "posters": "",
        # }
        # model_list.append(online)
        # new: dict = {
        #     "title": "Новые",
        #     "router": "new",
        #     "data": "",
        #     "plot": "Свежие видео в проектах",
        #     "genres": [],
        #     "posters": "",
        # }
        # model_list.append(new)
        # all_projects: dict = {
        #     "title": "Все проекты",
        #     "router": "all_projects",
        #     "data": "",
        #     "plot": "Все проекты РЕН ТВ доступные для просмотра через сайт",
        #     "genres": [],
        #     "posters": "",
        # }
        # model_list.append(all_projects)
        # search: dict = {
        #     "title": "Поиск",
        #     "router": "search",
        #     "data": "",
        #     "plot": "Примитивный поиск по проектам",
        #     "genres": [],
        #     "posters": "",
        # }
        # model_list.append(search)
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
