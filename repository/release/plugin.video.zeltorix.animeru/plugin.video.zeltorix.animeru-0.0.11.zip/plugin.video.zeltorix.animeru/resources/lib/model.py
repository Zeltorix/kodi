# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json
import sys

from bs4 import BeautifulSoup

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserAnimeru
    from .view import View
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.develop.animeru.resources.lib.parser import ParserAnimeru
    from source.develop.animeru.resources.lib.view import View


class ModelAnimeru:
    __slots__ = []
    _parser = ParserAnimeru()
    _view = View()

    def play(self, link: str) -> str:
        data_1 = self._parser.request(link)
        link_player = None
        from re import search, findall
        try:
            link_player = search(r"https://.*?db\..*?/player/\d+", data_1)[0]
        except TypeError:
            import xbmc
            xbmc.log(msg=f'play: {data_1}', level=xbmc.LOGINFO)
        except Exception:
            raise TypeError(f"Что здесь {data_1}")
        if link_player:
            data_2 = self._parser.request(link_player)
            hls = findall(r'".*="', data_2)[5]
        else:
            hls = findall(r'".*="', data_1)[5]
        from base64 import standard_b64decode
        return findall(r"https://.*?m3u8", standard_b64decode(hls).decode("utf-8"))[-1]

    @staticmethod
    def youtube(link: str) -> str:
        import yt_dlp
        with yt_dlp.YoutubeDL({}) as ydl:
            for i in ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"]:
                if i.get("fps") and i["fps"] and i.get("audio_channels") and i["audio_channels"] \
                        and i["format_note"] == "720p":
                    import xbmc
                    xbmc.log(msg=f'youtube: {i["url"]}', level=xbmc.LOGINFO)
                    return i["url"]

    def _list_item(self, page_link: str) -> tuple:
        model = []
        data_site = self._parser.request(page_link)
        soup_site = BeautifulSoup(data_site, "html.parser")
        content_list = soup_site.find("div", id="dle-content")
        if len(content_list.find_all("article")) > 0:
            for i in content_list.find_all("article"):
                link: str = i.find("a", href=True)["href"]
                if link.startswith("https://"):
                    data = link
                else:
                    data = "https://animeru.org" + link
                img: str = i.find("img", src=True)["src"]
                if img.startswith("https://"):
                    posters = img
                else:
                    posters = "https://animeru.org" + img
                title = i.find("h3").text.strip()
                model.append({
                    "Title": title,
                    "data": data,
                    "Posters": posters,
                    "router": "realise",
                })
        else:
            for i in content_list.find_all("a"):
                link: str = i["href"]
                if link.startswith("https://"):
                    data = link
                else:
                    data = "https://animeru.org" + link
                img: str = i.find("img", src=True)["src"]
                if img.startswith("https://"):
                    posters = img
                else:
                    posters = "https://animeru.org" + img
                if i.find("span"):
                    title = i.find("span").text.strip()
                    router = "listing"
                else:
                    # Для вкладки Топ
                    title = i.find("h3").text.strip()
                    router = "realise"
                model.append({
                    "Title": title,
                    "data": data,
                    "Posters": posters,
                    "router": router,
                })
        return tuple(model)

    def realise(self, url: str) -> dict:
        model = []
        request = self._parser.request(url)
        soup = BeautifulSoup(request, "html.parser")
        category = soup.find("ol", itemtype="https://schema.org/BreadcrumbList").find_all("li")[2].text.replace("»", "").strip()
        img = soup.find("img", class_="xfieldimage")["src"]
        if soup.find("div", itemprop="description"):
            plot = soup.find("div", itemprop="description").text
        else:
            plot = ""
        if img.startswith("https://"):
            posters = img
        else:
            posters = "https://animeru.org" + img
        list_pages = soup.find_all("nav")[1]
        import xbmc
        xbmc.log(msg=f'====================realise: "{list_pages}"', level=xbmc.LOGINFO)
        # if list_pages.find("div", id="myTabContent") is None:
        #     model.append({
        #         "Title": "Скоро выйдет",
        #         "data": "",
        #         "Posters": posters,
        #         "Plot": plot,
        #         "router": ""
        #     })
        breadcrumbs = soup.find_all("li", itemprop="itemListElement")[1].text.strip("» ").strip()
        xbmc.log(msg=f'====================breadcrumbs: "{breadcrumbs}"', level=xbmc.LOGINFO)
        if breadcrumbs == "Видео новости из мира Аниме":
            data = soup.find("iframe")["src"]
            title = f"Видео с Youtube"
            model.append({
                "Title": title,
                "data": data,
                "Posters": posters,
                "Plot": plot,
                "router": "play"
            })
        elif list_pages.find_all("a"):
            last_page = int(list_pages.find_all("a")[-2].text)
            pages_link = list_pages.find_all("a")[-2]["href"].split(str(last_page), 1)
            import xbmc
            xbmc.log(msg=f'====================realise: "{pages_link}"', level=xbmc.LOGINFO)
            for num in range(1, last_page + 1):
                data = f"{pages_link[0]}{num}{pages_link[1]}"
                title = f"E{num}"
                model.append({
                    "Title": title,
                    "data": data,
                    "Posters": posters,
                    "Plot": plot,
                    "router": "play"
                })
        return {
            "list": tuple(model),
            "category": category,
            "sort": False
        }

    def listing(self, link: str, next_item: bool = True, sort: bool = False) -> dict:
        model = []
        model.extend(self._list_item(link))
        request = self._parser.request(link)
        soup = BeautifulSoup(request, "html.parser")
        nav_page = soup.find_all("nav")
        category = soup.find("h1").text.strip()
        if len(nav_page) == 4:
            list_pages = soup.find_all("nav")[1].find_all("a", href=True)
            link_page = list_pages[0]["href"][:-2]
            last_page = int(list_pages[-2].text)
            if next_item:
                for a in range(1, last_page + 1):
                    model.extend(self._list_item(f"{link_page}{a}/"))
        if sort:
            category = "Все аниме"
        return {
            "category": category,
            "list": model,
            "sort": sort,
        }

    def search(self, search_item):
        history: str = self._view.get_setting("history_dict")
        if history:
            history_dict: dict =  json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            new_item: dict = {search_item: f"search_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            self._view.set_setting("history_dict", json.dumps(history_dict))

    def main(self) -> dict:
        model = []
        request = self._parser.request("https://animeru.org/anime-geroi/")
        soup = BeautifulSoup(request, "html.parser")
        menu = soup.find("nav", itemtype=True).find_all("li")
        for i in menu:
            title = i.find("a", href=True)
            if not title:
                continue
            title = title.text.strip()
            link: str = i.find("a", href=True)["href"]
            if link == "/":
                link = "https://animeru.org/video-novosti-iz-mira-anime/"
            if link.startswith("https://"):
                data = link
            else:
                data = "https://animeru.org" + link
            if title == "Новинки":
                router = "new"
            else:
                router = "listing"
            model.append({
                "Title": title,
                "data": data,
                "router": router,
            })
        model.append({
            "Title": "Все аниме",
            "data": "https://animeru.org/novinki/",
            "router": "all_anime",
        })
        return {
            "list": tuple(model),
            "category": "Меню",
            "sort": False
        }
