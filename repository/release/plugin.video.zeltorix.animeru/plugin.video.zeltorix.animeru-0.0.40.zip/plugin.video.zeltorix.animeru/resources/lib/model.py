# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import loads
from re import findall
from base64 import b64decode

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from view import View, ViewDialogProgressBG
from history import History
from get_video_link import VideoLink
from errors import Errors


class Model:
    __slots__ = []
    _web = WebApiRequest()
    _view = View()
    _view_dialog_progress_bg = ViewDialogProgressBG()
    _history = History()
    _video_link = VideoLink()
    _errors = Errors()
    _base_url = "gro.uremina//:sptth"[::-1]

    def play(self, link: str) -> str:
        response = self._web.request_get(link)
        if response and type(response) is not dict:
            if "/player/" in link:
                # hls = findall(r'atob\(".*?"\),', response.text)[0].split('"')[1]
                # return findall(r"https://.*?m3u8", b64decode(hls).decode("utf-8"))[-1]
                pass
            else:
                link_player = findall(r"https://.*?/player/\d+", response.text)[0]
                if link_player:
                    response = self._web.request_get(link_player)
                    if response and type(response) is not dict:
                        response = response
                # hls = findall(r'atob\(".*?"\),', response.text)[0].split('"')[1]
                # return findall(r"https://.*?m3u8", b64decode(hls).decode("utf-8"))[-1]

            jd = loads(findall(r'sources = \[\{.*?}]', response.text)[0].strip("sources = "))
            for item in jd:
                if item["label"] == self._view.get_setting_str("size_video"):
                    return item["file"] + "|verifypeer=false"
            return jd[-1]["file"] + "|verifypeer=false"
        else:
            self._errors.log_web_error(response)

    def youtube(self, link: str) -> str:
        return self._video_link.youtube_link(link)

    def _list_item(self, page_link: str) -> tuple:
        model = []
        response = self._web.request_get(https_checking(page_link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            content_list = soup.find("div", id="dle-content")
            if len(content_list.find_all("article")) > 0:
                for i in content_list.find_all("article"):
                    data: str = https_checking(i.find("a", href=True)["href"], self._base_url)
                    posters: str = https_checking(i.find("img", src=True)["src"], self._base_url)
                    title = i.find("h3").text.strip()
                    model.append({
                        "title": title,
                        "data": data,
                        "images": posters,
                        "router": "realise",
                    })
            else:
                for i in content_list.find_all("a"):
                    data: str = https_checking(i["href"], self._base_url)
                    posters: str = https_checking(i.find("img", src=True)["src"], self._base_url)
                    if i.find("span"):
                        title = i.find("span").text.strip()
                        router = "listing"
                    else:
                        # Для вкладки Топ
                        title = i.find("h3").text.strip()
                        router = "realise"
                    model.append({
                        "title": title,
                        "data": data,
                        "images": posters,
                        "router": router,
                    })
        else:
            self._errors.log_web_error(response)
        return tuple(model)

    def realise(self, url: str) -> dict:
        category = ""
        model = []
        response = self._web.request_get(https_checking(url, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            category = soup.find("ol", itemtype="https://schema.org/BreadcrumbList").find_all("li")[2].text.replace("»",
                                                                                                                    "").strip()
            img = soup.find("img", class_="xfieldimage")["src"]
            if soup.find("div", itemprop="description"):
                plot = soup.find("div", itemprop="description").text
            else:
                plot = ""
            if img.startswith("https://"):
                posters = img
            else:
                posters = https_checking(img, self._base_url)
            list_pages = soup.find_all("nav")[1]

            breadcrumbs = soup.find_all("li", itemprop="itemListElement")[1].text.strip("» ").strip()
            if breadcrumbs == "Видео новости из мира Аниме":
                model.append({
                    "title": f"Видео с Youtube",
                    "data": https_checking(soup.find_all("iframe")[1]["src"]),
                    "images": posters,
                    "plot": plot,
                    "router": "play",
                    "play": True,

                })
            elif soup.find(id="tab12") and "Скоро" in soup.find(id="tab12").text:
                model.append({
                    "title": "Скоро выйдет",
                    "data": "",
                    "images": posters,
                    "plot": plot,
                    "router": ""
                })
            elif soup.find(id="tab22") and "Анонс" in soup.find(id="tab22").text:
                model.append({
                    "title": f"{soup.find(class_='tab-pane-').text.strip()}",
                    "data": https_checking(soup.find_all("iframe")[1]["src"]),
                    "images": posters,
                    "plot": plot,
                    "router": "play",
                    "play": True,
                })
            elif list_pages.find_all("option"):
                last_page = int(list_pages.find_all("a")[-2].text)
                pages_link = list_pages.find_all("a")[-2]["href"].split(str(last_page), 1)
                for num in range(1, last_page + 1):
                    model.append({
                        "title": list_pages.find_all("option")[num].text,
                        "data": https_checking(f"{pages_link[0]}{num}{pages_link[1]}", self._base_url),
                        "images": posters,
                        "plot": plot,
                        "episode": num,
                        "router": "play",
                        "play": True,
                    })
            else:
                model.append({
                    "title": "Контент отсутствует",
                    "data": "",
                    "images": posters,
                    "plot": plot,
                    "router": "",
                })
        else:
            self._errors.log_web_error(response)

        return {
            "list": tuple(model),
            "category": category,
        }

    def listing(self, link: str, next_item: bool = True, sort: bool = True) -> dict:
        model = []
        category = ""
        link = https_checking(link, self._base_url)
        model.extend(self._list_item(link))
        response = self._web.request_get(link)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            nav_page = soup.find_all("nav")
            category: str = soup.find("h1").text.strip()
            point = link.split("/")[3]
            if len(nav_page) == 4:
                list_pages = soup.find_all("nav")[1].find_all("a", href=True)
                link_page = https_checking(list_pages[0]["href"][:-2], self._base_url)
                last_page = int(list_pages[-2].text)

                if next_item:
                    self._view_dialog_progress_bg.create(category, "")
                    self._view_dialog_progress_bg.update(0, "")
                    for a in range(2, last_page + 1):
                        self._view_dialog_progress_bg.update(int((a / (last_page + 1)) * 100), "")
                        model.extend(self._list_item(f"{link_page}{a}/"))
                    self._view_dialog_progress_bg.close()

                else:
                    for a in range(1, last_page + 1):
                        model.append({
                            "title": f"Страница {a}",
                            "data": f"/{point}/page/{a}/",
                            "router": "new",
                        })
        else:
            self._errors.log_web_error(response)

        if sort and "топ" not in category.lower() and "видео новости" not in category.lower():
            return {
                "category": "Все аниме",
                "list": tuple(model),
                "sort": [
                    9,  # SORT_METHOD_TITLE
                    10,  # SORT_METHOD_TITLE_IGNORE_THE
                    0,  # SORT_METHOD_NONE
                ],
            }
        else:
            return {
                "category": category,
                "list": tuple(model),
            }

    def _search_item(self, page_link: str, search_item: str) -> tuple:
        model: list = []
        response = self._web.request_get(https_checking(page_link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            for i in soup.find_all("article", class_=True)[18:30]:
                # self._view.output_logs(i)
                title: str = i.find("h3").text.strip()
                if search_item.lower() in title.lower():
                    data: str = https_checking(i.find("a", href=True)["href"], self._base_url)
                    posters: str = https_checking(i.find("img", src=True)["src"], self._base_url)
                    model.append({
                        "title": title,
                        "data": data,
                        "images": posters,
                        "router": "realise",
                        })
        else:
            self._errors.log_web_error(response)
        return tuple(model)

    def search(self, search_item):
        self._history.history_add_item(search_item)
        model: list = []
        self._view_dialog_progress_bg.create("Поиск", f"{search_item}")
        model.extend(self._search_item(self._base_url, search_item))
        self._view_dialog_progress_bg.update(0, "")
        response = self._web.request_get(self._base_url)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            nav_page = soup.find_all("nav")
            if len(nav_page) == 4:
                list_pages = soup.find_all("nav")[1].find_all("a", href=True)
                link_page = https_checking(list_pages[0]["href"][:-2], self._base_url)
                last_page = int(list_pages[-2].text)

                for a in range(2, last_page + 1):
                    self._view_dialog_progress_bg.update(int((a / (last_page + 1)) * 100), "")
                    model.extend(self._search_item(f"{link_page}{a}/", search_item))
        else:
            self._errors.log_web_error(response)

        self._view_dialog_progress_bg.close()

        return {
            "category": "Найдено",
            "list": tuple(model),
            "sort": [
                9,  # SORT_METHOD_TITLE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                0,  # SORT_METHOD_NONE
            ],
        }

    def main(self) -> dict:
        model = []
        response = self._web.request_get(https_checking("/anime-geroi/", self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, "html.parser")
            menu = soup.find("nav", itemtype=True).find_all("li")
            for i in menu:
                title = i.find("a", href=True)
                if not title:
                    continue
                title = title.text.strip()
                if title == "Аниме":
                    continue
                link: str = i.find("a", href=True)["href"]
                if link == "/":
                    link = https_checking("/video-novosti-iz-mira-anime/", self._base_url)
                if title == "Новинки":
                    router = "new"
                else:
                    router = "listing"
                model.append({
                    "title": title,
                    "data": https_checking(link, self._base_url),
                    "router": router,
                })
            model.append({
                "title": "Все аниме",
                "data": https_checking("/novinki/", self._base_url),
                "router": "all_anime",
                "plot": "[COLOR=red]ВНИМАНИЕ!\nСоздаёт избыточную нагрузку на сайт!\n[/COLOR]",
            })
            model.append({
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "[COLOR=red]ВНИМАНИЕ!\nСоздаёт избыточную нагрузку на сайт при поиске!\n[/COLOR]"
                        "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            })
        else:
            self._errors.log_web_error(response)
        return {
            "list": tuple(model),
            "category": "Меню",
        }
