# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.07.04
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""

# Не стандартный модуль импортируется в addon.xml как script.module.requests
from requests import Session

# Не стандартный модуль импортируется в addon.xml как script.module.zeltorix.utilitys
from browsers import browsers


class ParserAnimeru:
    """
    Клас для получения данных
    """
    __slots__ = []
    _session = Session()
    _headers = {
        "User-Agent": browsers,
    }

    def request(self, link: str, retry: int = 10) -> (dict, str):
        response = self._session.get(link, headers=self._headers, timeout=10)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.request(link=link, retry=retry - 1)
            elif response.status_code == 404:
                # TODO Добавить оповещение в интерфейс
                raise "Изменился API"
            elif response.ok:
                return response.text
        except ConnectionError:
            if retry:
                from time import sleep
                from random import randint
                # TODO Добавить оповещение в интерфейс
                sleep(randint(2, 10))
                return self.request(link=link, retry=retry - 1)
            else:
                raise "Что то не то с API..."
