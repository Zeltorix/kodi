# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import loads, dumps
from re import findall, sub
from base64 import b64decode

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking, Proxy
from view import View, ViewDialogProgressBG
from history import History
from get_video_link import VideoLink
from alerts import KAlert

from .cache import Cache


class Model:
    __slots__ = [
        "_proxy",
        "_web",
    ]

    _cache = Cache()
    _view = View()
    _view_dialog_progress_bg = ViewDialogProgressBG()
    _history = History()
    _video_link = VideoLink()
    _alert = KAlert()
    _base_url = "gro.uremina//:sptth"[::-1]

    def __init__(self):
        if self._view.get_setting_bool("blocking_bool"):
            if not self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility"):
                Proxy().proxy_provider_reload()
            self._proxy = self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility")
            self._web = WebApiRequest(proxy=self._proxy)
        else:
            self._web = WebApiRequest()

    def play(self, link: str) -> str:
        response = self._web.request_get(link)
        if response and type(response) is not dict:
            link_player = findall(r"https://.*?/player/\d+", response.text)[0]
            if link_player:
                response = self._web.request_get(link_player)
                if response and type(response) is not dict:
                    response = response
            jd = loads(findall(r"sources = \[\{.*?}]", response.text)[0].strip("sources = "))
            resolution_480p = ""
            resolution_720p = ""
            resolution_1080p = ""

            for item in jd:
                if item["label"] == "480p":
                    resolution_480p = item["file"]
                if item["label"] == "720p":
                    resolution_720p = item["file"]
                if item["label"] == "1080p":
                    resolution_1080p = item["file"]

            video_size: int = self._view.get_setting_int("video_resolution", "script.module.zeltorix.utility")

            if video_size:
                height = int(video_size)
            else:
                height: int = int(self._view.get_windows_width_height()["height"])

            if height < 720:
                if resolution_480p:
                    return resolution_480p
                elif resolution_720p:
                    return resolution_720p
                elif resolution_1080p:
                    return resolution_1080p
            elif 720 <= height < 1080:
                if resolution_720p:
                    return resolution_720p
                elif resolution_480p:
                    return resolution_480p
                elif resolution_1080p:
                    return resolution_1080p
            elif height >= 1080:
                if resolution_1080p:
                    return resolution_1080p
                elif resolution_720p:
                    return resolution_720p
                elif resolution_480p:
                    return resolution_480p
            else:
                raise ValueError(f"Отсутствует ссылка на плеер\n{dumps(jd, indent=2)}", 3)
        else:
            self._alert.error(
                heading="Ошибка доступа",
                message="Проблема доступа ссылки на видео",
                data=response
            )

    def youtube(self, link: str) -> str:
        return self._video_link.youtube_link(link)

    def _list_item(self, page_link: str) -> tuple:
        model: list = []
        response: str = self._cache.web(
            https_checking(page_link, self._base_url),
            time_expires=self._cache.time_limits("default")
        )
        if response:
            soup = BeautifulSoup(response, "html.parser")
            content_list = soup.find("div", id="dle-content")
            if len(content_list.find_all("article")) > 0:
                for i in content_list.find_all("article"):
                    model.append({
                        "title": i.find("h3").text.strip(),
                        "data": https_checking(i.find("a", href=True)["href"], self._base_url),
                        "images": https_checking(i.find("img", src=True)["src"], self._base_url),
                        "router": "realise",
                    })
            else:
                for i in content_list.find_all("a"):
                    if i.find("span"):
                        title: str = i.find("span").text.strip()
                        router: str = "listing"
                    else:
                        # Для вкладки Топ
                        title: str = i.find("h3").text.strip()
                        router: str = "realise"
                    model.append({
                        "title": title,
                        "data": https_checking(i["href"], self._base_url),
                        "images": https_checking(i.find("img", src=True)["src"], self._base_url),
                        "router": router,
                    })
        else:
            self._view.output_logs(
                f"{page_link}\n"
                f"{dumps(model, indent=2)}",
                3
            )
            self._alert.error(
                heading="Ошибка доступа",
                message="Проблема доступа ссылки на списки",
                data=response
            )
        return tuple(model)

    def realise(self, url: str) -> dict:
        category: str = ""
        model: list = []
        response: str = self._cache.web(
            https_checking(url, self._base_url),
            time_expires=self._cache.time_limits("release")
        )
        if response:
            soup = BeautifulSoup(response, "html.parser")
            category: str = soup.find(
                "ol",
                itemtype="https://schema.org/BreadcrumbList"
            ).find_all("li")[2].text.replace("»", "").strip()
            img: str = soup.find("img", class_="xfieldimage")["src"]
            if soup.find("div", itemprop="description"):
                plot: str = soup.find("div", itemprop="description").text
            else:
                plot: str = ""

            if img.startswith("https://"):
                posters: str = img
            else:
                posters: str = https_checking(img, self._base_url)

            list_pages = soup.find_all("nav")[1]
            breadcrumbs: str = soup.find_all("li", itemprop="itemListElement")[1].text.strip("» ").strip()

            if breadcrumbs == "Видео новости из мира Аниме":
                model.append({
                    "title": f"Видео с Youtube",
                    "data": https_checking(soup.find_all("iframe")[1]["src"]),
                    "images": posters,
                    "plot": plot,
                    "router": "play",
                    "play": True,

                })
            elif soup.find(id="tab12") and "Скоро" in soup.find(id="tab12").text:
                model.append({
                    "title": "Скоро выйдет",
                    "data": "",
                    "images": posters,
                    "plot": plot,
                    "router": ""
                })
            elif soup.find(id="tab22") and "Анонс" in soup.find(id="tab22").text:
                model.append({
                    "title": f"{soup.find(class_='tab-pane-').text.strip()}",
                    "data": https_checking(soup.find_all("iframe")[1]["src"]),
                    "images": posters,
                    "plot": plot,
                    "router": "play",
                    "play": True,
                })
            elif list_pages.find_all("option"):
                # last_page: int = int(list_pages.find_all("a")[-2].text)
                # pages_link = list_pages.find_all("a")[-2]["href"].split(str(last_page), 1)
                # for num in range(1, last_page + 1):
                #     model.append({
                #         "title": list_pages.find_all("option")[num].text,
                #         "data": https_checking(f"{pages_link[0]}{num}{pages_link[1]}", self._base_url),
                #         "images": posters,
                #         "plot": plot,
                #         "episode": num,
                #         "router": "play",
                #         "play": True,
                #     })
                for i in list_pages.find_all("option"):
                    if i["value"]:
                        if findall(r"\d+", i.text)[0] == "1":
                            data = https_checking(i["value"].replace("page-1-", ""), self._base_url)
                        else:
                            data = https_checking(i["value"], self._base_url)
                        model.append({
                            "title": i.text,
                            "data": data,
                            "images": posters,
                            "plot": plot,
                            "episode": int(findall(r"\d+", i.text)[0]),
                            "router": "play",
                            "play": True,
                        })
            else:
                model.append({
                    "title": "Контент отсутствует",
                    "data": "",
                    "images": posters,
                    "plot": plot,
                    "router": "",
                })
        else:
            self._alert.error(
                heading="Ошибка доступа",
                message="Проблема доступа ссылки на реализ",
                data=response
            )

        return {
            "list": tuple(model),
            "category": category,
        }

    def listing(self, link: str, next_item: bool = True, sort: bool = True) -> dict:
        model: list = []
        category: str = ""
        link: str = https_checking(link, self._base_url)
        model.extend(self._list_item(link))
        response: str = self._cache.web(
            link,
            time_expires=self._cache.time_limits("default")
        )

        if response:
            soup = BeautifulSoup(response, "html.parser")
            nav_page = soup.find_all("nav")
            point = link.split("/")[3]
            category: str = soup.find("h1").text.strip()
            if soup.find("ol", class_="wsbcl"):
                page_num = soup.find("ol", class_="wsbcl").find_all("li")
                if len(page_num) == 3:
                    category += page_num[-1].text

            if len(nav_page) == 4:
                list_pages = soup.find_all("nav")[1].find_all("a", href=True)
                link_page: str = https_checking(list_pages[0]["href"][:-2], self._base_url)
                last_page: int = int(list_pages[-2].text)
                if next_item:
                    self._view_dialog_progress_bg.create(category, "")
                    self._view_dialog_progress_bg.update(0, "")
                    for a in range(2, last_page + 1):
                        self._view_dialog_progress_bg.update(int((a / (last_page + 1)) * 100), "")
                        model.extend(self._list_item(f"{link_page}{a}/"))
                    self._view_dialog_progress_bg.close()
                else:
                    for a in range(1, last_page + 1):
                        model.append({
                            "title": f"Страница {a}",
                            "data": f"/{point}/page/{a}/",
                            "router": "new",
                        })
        else:
            self._alert.error(
                heading="Ошибка доступа",
                message="Проблема доступа ссылки на списки",
                data=response
            )

        if sort and "топ" not in category.lower() and "видео новости" not in category.lower():
            return {
                "category": "Все аниме",
                "list": tuple(model),
                "sort": [
                    9,  # SORT_METHOD_TITLE
                    10,  # SORT_METHOD_TITLE_IGNORE_THE
                    0,  # SORT_METHOD_NONE
                ],
            }
        else:
            return {
                "category": category,
                "list": tuple(model),
            }

    def _search_item(self, page_link: str, search_item: str) -> tuple:
        model: list = []
        response: str = self._cache.web(
            https_checking(page_link, self._base_url),
            time_expires=self._cache.time_limits("default")
        )

        if response:
            soup = BeautifulSoup(response, "html.parser")
            for i in soup.find_all("article", class_=True)[18:30]:
                title: str = i.find("h3").text.strip()
                if search_item.lower() in title.lower():
                    data: str = https_checking(i.find("a", href=True)["href"], self._base_url)
                    posters: str = https_checking(i.find("img", src=True)["src"], self._base_url)
                    model.append({
                        "title": title,
                        "data": data,
                        "images": posters,
                        "router": "realise",
                    })
        else:
            self._alert.error(
                heading="Ошибка доступа",
                message="Проблема доступа ссылки на списки",
                data=response
            )
        return tuple(model)

    def search(self, search_item):
        self._history.history_add_item(search_item)
        model: list = []
        self._view_dialog_progress_bg.create("Поиск", f"{search_item}")
        model.extend(self._search_item(self._base_url, search_item))
        self._view_dialog_progress_bg.update(0, "")
        response: str = self._cache.web(
            self._base_url,
            time_expires=self._cache.time_limits("default")
        )
        if response:
            soup = BeautifulSoup(response, "html.parser")
            nav_page = soup.find_all("nav")
            if len(nav_page) == 4:
                list_pages = soup.find_all("nav")[1].find_all("a", href=True)
                link_page: str = https_checking(list_pages[0]["href"][:-2], self._base_url)
                last_page: int = int(list_pages[-2].text)
                for a in range(2, last_page + 1):
                    self._view_dialog_progress_bg.update(int((a / (last_page + 1)) * 100), "")
                    model.extend(self._search_item(f"{link_page}{a}/", search_item))
        else:
            self._alert.error(
                heading="Ошибка доступа",
                message="Проблема доступа ссылки на списки",
                data=response
            )

        self._view_dialog_progress_bg.close()

        return {
            "category": "Найдено",
            "list": tuple(model),
            "sort": [
                9,  # SORT_METHOD_TITLE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                0,  # SORT_METHOD_NONE
            ],
        }

    def main(self) -> dict:
        model: list = []
        response: str = self._cache.web(
            https_checking("/anime-geroi/", self._base_url),
            time_expires=self._cache.time_limits("default")
        )
        if response:
            soup = BeautifulSoup(response, "html.parser")
            menu = soup.find("nav", itemtype=True).find_all("li")
            for i in menu:
                title = i.find("a", href=True)
                if not title:
                    continue
                title = title.text.strip()

                if title == "Аниме":
                    continue
                link: str = i.find("a", href=True)["href"]

                if link == "/":
                    link: str = https_checking("/video-novosti-iz-mira-anime/", self._base_url)

                if title == "Новинки":
                    router: str = "new"
                    data = "/novinki-anime/"
                else:
                    router: str = "listing"
                    data = link

                model.append({
                    "title": title,
                    "data": data,
                    "router": router,
                })
            model.append({
                "title": "Все аниме",
                "data": "/novinki-anime/",
                "router": "all_anime",
                "plot": "[COLOR=red]ВНИМАНИЕ!\nСоздаёт избыточную нагрузку на сайт!\n[/COLOR]",
            })
            model.append({
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "[COLOR=red]ВНИМАНИЕ!\nСоздаёт избыточную нагрузку на сайт при поиске!\n[/COLOR]"
                        "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            })
        else:
            self._alert.error(
                heading="Ошибка доступа",
                message="Проблема доступа к главной странице",
                data=response
            )

        return {
            "list": tuple(model),
            "category": "Меню",
        }
