# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

# Импорт модуля плагина для создания модели
from .model import Model


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _history = History()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict["router"] == "search_history":
            _view.output(_model.search(params_dict["data"]))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict["data"]):
                _view.output(_history.search_menu())

        elif params_dict["router"] == "realise":
            _view.output(_model.realise(params_dict["data"]))
        elif params_dict["router"] == "listing":
            _view.output(_model.listing(params_dict["data"]))
        elif params_dict["router"] == "new":
            _view.output(_model.listing(params_dict["data"], next_item=False, sort=False))
        elif params_dict["router"] == "all_anime":
            _view.output(_model.listing(params_dict["data"]))
        elif params_dict["router"] == "search_video_history":
            _view.output(_model.search(search_item=params_dict["data"]))

        elif params_dict["router"] == "play":
            if "youtube" in params_dict["data"]:
                _view.play(_model.youtube(link=params_dict["data"]))
            else:
                link_play = _model.play(link=params_dict["data"])
                if ".mp4" in link_play:
                    _view.play(link_play, False)
                else:
                    _view.play(link_play, "hls")
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
