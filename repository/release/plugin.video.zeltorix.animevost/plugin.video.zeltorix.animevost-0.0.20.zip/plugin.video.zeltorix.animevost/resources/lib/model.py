# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.02.07
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from re import findall, sub
from json import loads, dumps
from random import random, choice

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking, Proxy
from history import History
from view import View
from text_job import date_to_time_stamp, ras, shy


class Model:
    __slots__ = [
        "_web",
        "_base_url",
    ]
    _view = View()
    _history = History()

    def __init__(self):
        self._base_url = "https://animevost.org"
        if self._view.get_setting_bool("blocking_bool"):
            # Автоматическое обновления зеркала
            if self._view.get_setting_int("blocking_target") == 1:
                url = self._view.get_setting_str("blocking_manual")
                if url != "localhost":
                    self._base_url = url
                    headers["Referer"] = self._base_url + "/"
                    self._web = WebApiRequest(headers)
                else:
                    if self.find_mirror():
                        self._view.dialog_ok("Зеркало", "Зеркало получено, перезапустите плагин")
                    raise
            # Ручной ввод адреса
            elif self._view.get_setting_int("blocking_target") == 2:
                url = self._view.get_setting_str("blocking_manual")
                if url != "localhost":
                    self._base_url = url
                    headers["Referer"] = self._base_url + "/"
                    self._web = WebApiRequest(headers)
                else:
                    raise
            # Прокси AnimeVost
            elif self._view.get_setting_int("blocking_target") == 3:
                headers["Referer"] = self._base_url + "/"
                self._web = WebApiRequest(headers, proxy=self.__get_local_proxy())
            # Прокси из набора инструментов
            elif self._view.get_setting_int("blocking_target") == 4:
                _proxy = self.__proxy_utility()
                headers["Referer"] = self._base_url + "/"
                self._web = WebApiRequest(headers, proxy=_proxy)
        else:
            headers["Referer"] = self._base_url + "/"
            self._web = WebApiRequest(headers)

    def __anti_block(self):
        response = WebApiRequest().request_get(f"https://{ras('vR3czV2YjFmL0V2Z')}.site/vost.pac")
        if response and type(response) is not dict:
            proxy: str = "SOCKS5://" + findall(r"\d+\.\d+\.\d+\.\d+:\d+", response.text)[2]
            self._view.set_setting("local_proxy_animevost", proxy)
            return proxy
        else:
            raise

    def __get_local_proxy(self):
        proxy: str = self._view.get_setting_str("local_proxy_animevost")
        if proxy != "localhost":
            return proxy
        else:
            return self.__anti_block()

    def __proxy_utility(self):
        if not self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility"):
            Proxy().proxy_provider_reload()
        return self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility")

    def find_mirror(self):
        response = WebApiRequest(headers, proxy=self.__get_local_proxy()).request_get(self._base_url)
        if response and type(response) is not dict:
            url: str = findall(r"https://\w+.vost.pw", response.text)[0]
            self._view.set_setting("blocking_manual", url)
            return True
        else:
            raise

    def update_local_proxy(self):
        self._view.dialog_ok("Локальный прокси", "Попытка обновить локальный прокси")
        return self.__anti_block()

    def _access_verification(self):
        if self._view.get_setting_bool("blocking_bool"):
            # Автоматическое обновления зеркала
            if self._view.get_setting_int("blocking_target") == 1:
                if self.find_mirror():
                    self._view.dialog_ok("Зеркало", "Зеркало обновлено, перезапустите плагин")
                else:
                    self._view.dialog_ok("Зеркало", "Проблемы с обновлением зеркала")
                raise
            # Ручной ввод адреса
            elif self._view.get_setting_int("blocking_target") == 2:
                self._view.dialog_ok("Зеркало", "Текущие зеркало не доступно")
                raise
            # Прокси AnimeVost
            elif self._view.get_setting_int("blocking_target") == 3:
                if self.__anti_block():
                    self._view.dialog_ok("Локальный прокси", "Локальный прокси обновлён")
                else:
                    self._view.dialog_ok("Локальный прокси", "Проблемы с обновлением локального прокси")
            # Прокси из набора инструментов
            elif self._view.get_setting_int("blocking_target") == 4:
                self._view.dialog_ok("Прокси с набора инструментов", "Если проблема не пропала, требуется обновить прокси в Наборе Инструментов")
        else:
            self._view.dialog_ok("Основной сайт", "Основной сайт не доступен")
            raise

    def set_votes(self, go_rate: str, news_id: str) -> None:
        headers["X-Requested-With"] = "XMLHttpRequest"
        self._web.__init__(headers)
        params = {
            "go_rate": go_rate,
            "news_i d": news_id,
            "skin": "AnimeVostNext5",
        }
        response = self._web.request_get(https_checking("/engine/ajax/rating.php", self._base_url), params=params)
        if response and type(response) is not dict:
            self._view.dialog_ok("Голос учтён", f"Всего голосов: {response.json()['votenum']}")

    def play(self, link: str) -> str:
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            # find_data = findall(r'\(480p\).*"', response.text)
            # if not find_data:
            #     if not self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility"):
            #         Proxy().proxy_provider_reload()
            #     self._web.__init__(proxy=self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility"))
            #     response = self._web.request_get(https_checking(link, self._base_url))
            #     if type(response) is dict:
            #         raise TypeError(response)
            find_data = findall(r'\(480p\).*"', response.text)
            find_links: list = [*findall(r"https://\S+?time=\d+\b", find_data[0])]
            fhd_1080: list = [i for i in find_links if "/std." not in i and "/1080/" in i]
            hd_720: list = [i for i in find_links if "/std." not in i and "/720/" in i]
            sd_480: list = [i for i in find_links if "/std." not in i and "/720/" not in i and "/1080/" not in i]
            self._web.request_get(https_checking(findall(r"/stat\.php\?id=\d+", response.text)[0], self._base_url))
            video_size: int = self._view.get_setting_int("video_size")
            if video_size:
                if video_size == 480:
                    return choice(list(set(sd_480)))
                elif video_size == 720:
                    return choice(list(set(hd_720)))
                elif video_size == 1080:
                    if fhd_1080:
                        return choice(list(set(fhd_1080)))
                    else:
                        return choice(list(set(hd_720)))
                else:
                    raise
            else:
                height: int = self._view.get_windows_width_height()["height"]
                if height < 720:
                    return choice(list(set(sd_480)))
                elif 720 < height < 1080:
                    return choice(list(set(hd_720)))
                elif 1080 <= height:
                    if fhd_1080:
                        return choice(list(set(fhd_1080)))
                    else:
                        return choice(list(set(hd_720)))
                else:
                    return choice(list(set(hd_720)))
        else:
            raise

    def random(self) -> dict:
        model: list = []
        category: str = ""
        response_base = self._web.request_get(self._base_url)
        if response_base and type(response_base) is not dict:
            url = findall(r"https://v\d+\.vost\.pw", response_base.text)[0]
        else:
            url = self._base_url
        response = self._web.request_get(https_checking("/get_random_post.php", self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find(class_="imgOngoingVie").text.strip()
            model.append({
                "title": soup.find("span").text.strip(),
                "data": soup.find("a")["href"].replace(self._base_url, ""),
                "router": "realise",
                "icon": https_checking(soup.find("img")["src"], url),
            })
        else:
            self._access_verification()
        return {
            "category": category,
            "list": tuple(model),
        }

    def realise(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find("h1").text.strip()

            for key, values in loads(
                    findall(r"data = \{.*?};", response.text)[0].split("= ")[1][:-1].replace(",}", "}")).items():
                data: str = f"/frame5.php?play={values}&old=1"
                model.append({
                    "title": key,
                    "data": data,
                    "images": f"https://media.animetop.info/img/{values}.jpg",
                    "duration": int(findall(r"\d+ мин.", response.text)[0].split(" мин.")[0]) * 60,
                    "router": "play",
                    "context_menu": [(
                        f"Загрузить эпизод",
                        f"RunPlugin({self._view.convert_to_url(router='download_episode_anime_fail', data=data, category=category, fail_name=key)})"
                    )],
                    "play": True,
                })
        else:
            self._access_verification()
        return {
            "category": category,
            "list": tuple(model),
        }

    @staticmethod
    def select_sort() -> tuple:
        return (
            "Выбор типа сортировки",
            [
                "По дате",
                "По популярности",
                "По посещаемости",
                "По комментариям",
                "По алфавиту"
            ]
        )

    def search(self, search_item: str, search_start: str = "1") -> dict:
        self._history.history_add_item(search_item)
        model: list = []
        category: str = ""
        params: dict = {
            "do": "search",
        }
        post: dict = {
            "do": "search",
            "subaction": "search",
            "search_start": search_start,
            "full_search": "0",
            "result_from": int(search_start) * 10 - 9,
            "story": search_item,
        }
        response = self._web.request_post(self._base_url + "/index.php", params=params, data=post)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category: str = f"{soup.find(class_='userinfoHead').text.strip()} - {search_item} - страница №{search_start}"

            for item in soup.find(id="dle-content").find_all(class_="shortstory"):
                context_menu: list = []
                year: int = 0
                genres: list = []
                plot: str = ""

                for p in item.find_all("p"):
                    if p.find("strong").text.strip() == "Год выхода:":
                        year: int = int(p.text.replace("Год выхода: ", "").strip())
                    if p.find("strong").text.strip() == "Жанр:":
                        genres.extend(p.text.replace("Жанр: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Тип:":
                        genres.extend(p.text.replace("Тип: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Описание:":
                        plot: str = p.text.replace("Описание: ", "").strip().replace("\n\n", " ")
                    if p.find("strong").text.strip() == "Режиссёр:":
                        context_menu.append((
                            f'{p.find("strong").text.strip()} {p.find("a").text}',
                            f"Container.Update({self._view.convert_to_url(router='catalog', data=p.find('a')['href'])})"
                        ))

                for a in item.find("i").find_all("a"):
                    context_menu.append((
                        f'Категории: {a.text}',
                        f"Container.Update({self._view.convert_to_url(router='catalog', data=a['href'])})"
                    ))

                try:
                    date_realise = date_to_time_stamp(
                        data_input=item.find(class_="staticInfoLeftData").text.strip(),
                        format_input="%d %B %Y",
                    )
                except:
                    date_realise = ""

                # context_menu.append((
                #     f"Загрузить целиком",
                #     f"RunPlugin({self._view.convert_to_url(router='download_full_anime', data=item.find('h2').find('a')['href'].replace(self._base_url, ''))})"
                # ))

                model.append({
                    "title": item.find("h2").text.strip(),
                    "data": item.find("h2").find("a")["href"].replace(self._base_url, ""),
                    "genres": genres,
                    "year": year,
                    "premiered": date_realise,
                    "dateadded": date_realise,
                    "router": "realise",
                    "plot": plot,
                    "icon": https_checking(item.find("img")["src"], self._base_url),
                    "context_menu": context_menu,
                })

            if soup.find(class_="block_4"):
                last_page: int = int(soup.find(class_="block_4").find_all("a")[-1].text)

                for a in range(1, last_page + 1):
                    model.append({
                        "title": f"Страница {a}",
                        "data": {
                            "search_item": search_item,
                            "search_start": a,
                        },
                        "router": "search",
                    })
        else:
            self._access_verification()
        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, link: str, sort: int = 0) -> dict:
        link: str = https_checking(link, self._base_url)
        point: str = link.split(self._base_url)[-1]
        if findall(r"page/\d+/", point):
            point: str = point.replace(findall(r"page/\d+/", point)[0], "")
        model: list = []
        category: str = ""
        title_sort = "[COLOR=yellow]Отсортировано по[/COLOR] "
        dledirection = "desc"
        set_new_sort = "dle_sort_cat",
        set_direction_sort = "dle_direction_cat"
        if link[:-1] == self._base_url:
            set_new_sort = "dle_sort_main",
            set_direction_sort = "dle_direction_main"
        if int(sort) == 0:
            title_sort += "[COLOR=green]дате[/COLOR]"
            dlenewssortby = "date"
        elif int(sort) == 1:
            title_sort += "[COLOR=green]популярности[/COLOR]"
            dlenewssortby = "rating"
        elif int(sort) == 2:
            title_sort += "[COLOR=green]посещаемости[/COLOR]"
            dlenewssortby = "news_read"
        elif int(sort) == 3:
            title_sort += "[COLOR=green]комментариям[/COLOR]"
            dlenewssortby = "comm_num"
        elif int(sort) == 4:
            title_sort += "[COLOR=green]алфавиту[/COLOR]"
            dlenewssortby = "title"
            dledirection = "asc"
        else:
            raise TypeError("Метод выбора сортировки вышел за рамки")
        model.append({
            "title": title_sort,
            "data": link,
            "router": "select_sort",
            "not_folder": True,
            "icon": "DefaultTVShowTitle.png",
        })

        post: dict = {
            "dlenewssortby": dlenewssortby,
            "dledirection": dledirection,
            "set_new_sort": set_new_sort,
            "set_direction_sort": set_direction_sort,
        }

        response = self._web.request_post(link, data=post)
        if response and type(response) is not dict:

            soup = BeautifulSoup(response.text, features="html.parser")

            url = findall(r"https://v\d+\.vost\.pw", response.text)[0]

            if soup.find("h1"):
                category: str = f"{soup.find('h1').text.strip()}"
            if link.split("/")[-2].isdigit() and link.split("/")[-3] != "god":
                category += f" - страница №{link.split('/')[-2]}"

            for item in soup.find(id="dle-content").find_all(class_="shortstory"):
                context_menu: list = []
                year: int = 0
                genres: list = []
                plot: str = ""

                for p in item.find_all("p"):
                    if p.find("strong").text.strip() == "Год выхода:":
                        year: int = int(p.text.replace("Год выхода: ", "").strip())
                    if p.find("strong").text.strip() == "Жанр:":
                        genres.extend(p.text.replace("Жанр: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Тип:":
                        genres.extend(p.text.replace("Тип: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Описание:":
                        plot: str = p.text.replace("Описание: ", "").strip().replace("\n\n", " ")
                    if p.find("strong").text.strip() == "Режиссёр:":
                        context_menu.append((
                            f'{p.find("strong").text.strip()} {p.find("a").text}',
                            f"Container.Update({self._view.convert_to_url(router='catalog', data=p.find('a')['href'], sort=sort)})"
                        ))

                for a in item.find("i").find_all("a"):
                    context_menu.append((
                        f'Категории: {a.text}',
                        f"Container.Update({self._view.convert_to_url(router='catalog', data=a['href'], sort=sort)})"
                    ))

                if item.find(class_="unit-rating"):
                    for a in item.find(class_="unit-rating").find_all("a"):
                        on_click: list = findall(r"\d+", a.get("onclick"))
                        context_menu.append((
                            f"Рейтинг: {a.get('title')} ({a.text} из 5)",
                            f"RunPlugin({self._view.convert_to_url(router='set_votes', go_rate=on_click[0], news_id=on_click[1])})"
                        ))

                try:
                    date_realise = date_to_time_stamp(
                        data_input=item.find(class_="staticInfoLeftData").text.strip(),
                        format_input="%d %B %Y",
                    )
                except:
                    date_realise = ""

                context_menu.append((
                    f"Загрузить целиком",
                    f"RunPlugin({self._view.convert_to_url(router='download_full_anime', data=item.find('h2').find('a')['href'].replace(self._base_url, ''))})"
                ))

                if "[Анонс]" in item.find("h2").text:
                    title: str = item.find("h2").text.strip().replace("[Анонс]", "[COLOR=red][Анонс][/COLOR]")
                    data: str = ""
                    router: str = ""
                    plot = "[COLOR=red][Анонс][/COLOR]\n" + plot
                else:
                    title: str = item.find("h2").text.strip()
                    data: str = item.find("h2").find("a")["href"].replace(self._base_url, "")
                    router: str = "realise"

                model_realise: dict = {
                    "title": title,
                    "data": data,
                    "genres": genres,
                    "year": year,
                    "premiered": date_realise,
                    "dateadded": date_realise,
                    "router": router,
                    "plot": plot,
                    "icon": https_checking(item.find("img")["src"], url),
                    "context_menu": context_menu,
                }
                if item.find("span", id=True):
                    model_realise["votes"]: int = int(item.find("span", id=True).text)

                model.append(model_realise)

            if soup.find(class_="block_4"):
                last_page: int = int(soup.find(class_="block_4").find_all("a")[-1].text)

                for a in range(1, last_page + 1):
                    model.append({
                        "title": f"Страница {a}",
                        "data": {
                            "data": https_checking(f"{point}page/{a}/", self._base_url),
                            "sort": sort,
                        },
                        "router": "catalog",
                        "icon": "DefaultAddonVfs.png",
                    })
        else:
            self._access_verification()
        return {
            "category": category,
            "list": tuple(model),
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(self._base_url)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            for item_menu in soup.find(id="topnav").find_all("li"):
                if item_menu.find("a")["href"] in [
                    "/preview/",
                    "/index.php?do=feedback",
                    "/dlya-pravoobladateley.html",
                    "/index.php?action=mobile",
                ]:
                    continue
                if item_menu.find(class_="sar"):
                    model.append({
                        "title": f"[COLOR=grey]{item_menu.find('a').text.strip()}[/COLOR]",
                        "icon": "DefaultSets.png",
                    })
                    for item_sub_menu in item_menu.find(class_="sar").find_all("a"):
                        model.append({
                            "title": f"[COLOR=grey]{item_menu.find('a').text.strip()} =>[/COLOR] {item_sub_menu.text.strip()}",
                            "data": item_sub_menu["href"],
                            "router": "catalog",
                        })
                else:
                    if item_menu.find("a")["href"] == "/":
                        data = self._base_url + "/"
                    else:
                        data = item_menu.find("a")["href"]
                    model.append({
                        "title": item_menu.find("a").text.strip(),
                        "data": data,
                        "router": "catalog",
                    })

            model.append({
                "title": "Случайное аниме",
                "router": "random",
            })
            model.append({
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            })
        else:
            self._access_verification()
        return {
            "category": "Меню",
            "list": tuple(model),
        }
