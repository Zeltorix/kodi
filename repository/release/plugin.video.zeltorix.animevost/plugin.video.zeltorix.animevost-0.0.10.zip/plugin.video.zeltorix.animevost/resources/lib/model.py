# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.02.07
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from re import findall
from json import loads, dumps
from random import random, choice

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking, Proxy
from history import History
from view import *
from text_job import *


class Model:
    __slots__ = ["url", "_web"]
    _view = View()
    _history = History()
    _base_url = "3BnLy92Zh9yL6MHc0RHa"

    def __init__(self):
        url = self._view.get_setting_str("url")
        if url:
            self.url = ras(url)
        else:
            self._web = WebApiRequest()
            self.url_update()
            self.__init__()
        headers["Referer"] = self.url + "/"
        self._web = WebApiRequest(headers)

    def url_update(self):
        response = self._web.request_get(ras(self._base_url))
        if response and type(response) is not dict:
            self._view.set_setting("url", shy(findall(r"https://\S+\w+", response.text)[1]))

    def set_votes(self, go_rate: str, news_id: str) -> None:
        headers["X-Requested-With"] = "XMLHttpRequest"
        self._web.__init__(headers)
        params = {
            "go_rate": go_rate,
            "news_id": news_id,
            "skin": "AnimeVostNext5",
        }
        response = self._web.request_get(https_checking("/engine/ajax/rating.php", self.url), params=params)
        if response and type(response) is not dict:
            self._view.dialog_ok("Голос учтён", f"Всего голосов: {response.json()['votenum']}")

    def play(self, link: str) -> str:
        response = self._web.request_get(https_checking(link, self.url))
        if response and type(response) is not dict:
            find_data = findall(r'\(480p\).*"', response.text)
            if not find_data:
                if not self._view.get_setting_str("proxy_query", "script.module.zeltorix.utilitys"):
                    Proxy().proxy_provider_reload()
                self._web.__init__(proxy=self._view.get_setting_str("proxy_query", "script.module.zeltorix.utilitys"))
                response = self._web.request_get(https_checking(link, self.url))
                if type(response) is dict:
                    raise TypeError(response)
            find_data = findall(r'\(480p\).*"', response.text)
            find_links: list = [*findall(r"https://\S+?time=\d+\b", find_data[0])]
            fhd_1080: list = [i for i in find_links if "/std." not in i and "/1080/" in i]
            hd_720: list = [i for i in find_links if "/std." not in i and "/720/" in i]
            sd_480: list = [i for i in find_links if "/std." not in i and "/720/" not in i and "/1080/" not in i]
            self._web.request_get(https_checking(findall(r"/stat\.php\?id=\d+", response.text)[0], self.url))
            video_size: int = self._view.get_setting_int("video_size")
            if video_size:
                if video_size == 480:
                    return choice(list(set(sd_480)))
                elif video_size == 720:
                    return choice(list(set(hd_720)))
                elif video_size == 1080:
                    if fhd_1080:
                        return choice(list(set(fhd_1080)))
                    else:
                        return choice(list(set(hd_720)))
            else:
                height: int = self._view.get_windows_width_height()["height"]
                if height < 720:
                    return choice(list(set(sd_480)))
                elif 720 < height < 1080:
                    return choice(list(set(hd_720)))
                elif 1080 <= height:
                    if fhd_1080:
                        return choice(list(set(fhd_1080)))
                    else:
                        return choice(list(set(hd_720)))
                else:
                    return choice(list(set(hd_720)))

    def random(self) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(https_checking("/get_random_post.php", self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find(class_="imgOngoingVie").text.strip()
            model.append({
                "title": soup.find("span").text.strip(),
                "data": soup.find("a")["href"].replace(self.url, ""),
                "router": "realise",
                "icon": https_checking(soup.find("img")["src"], self.url),
            })
        return {
            "category": category,
            "list": tuple(model),
        }

    def realise(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(https_checking(link, self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find("h1").text.strip()
            for key, values in loads(
                    findall(r"data = \{.*?};", response.text)[0].split("= ")[1][:-1].replace(",}", "}")).items():
                data: str = f"/frame5.php?play={values}&old=1"
                model.append({
                    "title": key,
                    "data": data,
                    "images": f"https://media.animegost.org/img/{values}.jpg",
                    "duration": int(findall(r"\d+ мин.", response.text)[0].split(" мин.")[0]) * 60,
                    "router": "play",
                    "context_menu": [(
                        f"Загрузить эпизод",
                        f"RunPlugin({self._view.convert_to_url(router='download_episode_anime_fail', data=data, category=category, fail_name=key)})"
                    )],
                    "play": True,
                })

        return {
            "category": category,
            "list": tuple(model),
        }

    @staticmethod
    def select_sort() -> tuple:
        return (
            "Выбор типа сортировки",
            [
                "По дате",
                "По популярности",
                "По посещаемости",
                "По комментариям",
                "По алфавиту"
            ]
        )

    def search(self, search_item: str, search_start: str = "1") -> dict:
        self._history.history_add_item(search_item)
        model: list = []
        category: str = ""
        params: dict = {
            "do": "search",
        }
        post: dict = {
            "do": "search",
            "subaction": "search",
            "search_start": search_start,
            "full_search": "0",
            "result_from": int(search_start) * 10 - 9,
            "story": search_item,
        }
        response = self._web.request_post(self.url + "/index.php", params=params, data=post)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category: str = f"{soup.find(class_='userinfoHead').text.strip()} - {search_item} - страница №{search_start}"

            for item in soup.find(id="dle-content").find_all(class_="shortstory"):
                context_menu: list = []
                year: int = 0
                genres: list = []
                plot: str = ""

                for p in item.find_all("p"):
                    if p.find("strong").text.strip() == "Год выхода:":
                        year: int = int(p.text.replace("Год выхода: ", "").strip())
                    if p.find("strong").text.strip() == "Жанр:":
                        genres.extend(p.text.replace("Жанр: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Тип:":
                        genres.extend(p.text.replace("Тип: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Описание:":
                        plot: str = p.text.replace("Описание: ", "").strip().replace("\n\n", " ")
                    if p.find("strong").text.strip() == "Режиссёр:":
                        context_menu.append((
                            f'{p.find("strong").text.strip()} {p.find("a").text}',
                            f"Container.Update({self._view.convert_to_url(router='catalog', data=p.find('a')['href'])})"
                        ))

                for a in item.find("i").find_all("a"):
                    context_menu.append((
                        f'Категории: {a.text}',
                        f"Container.Update({self._view.convert_to_url(router='catalog', data=a['href'])})"
                    ))

                try:
                    date_realise = date_to_time_stamp(
                        data_input=item.find(class_="staticInfoLeftData").text.strip(),
                        format_input="%d %B %Y",
                    )
                except:
                    date_realise = ""

                # context_menu.append((
                #     f"Загрузить целиком",
                #     f"RunPlugin({self._view.convert_to_url(router='download_full_anime', data=item.find('h2').find('a')['href'].replace(self.url, ''))})"
                # ))

                model.append({
                    "title": item.find("h2").text.strip(),
                    "data": item.find("h2").find("a")["href"].replace(self.url, ""),
                    "genres": genres,
                    "year": year,
                    "premiered": date_realise,
                    "dateadded": date_realise,
                    "router": "realise",
                    "plot": plot,
                    "icon": https_checking(item.find("img")["src"], self.url),
                    "context_menu": context_menu,
                })

            if soup.find(class_="block_4"):
                last_page: int = int(soup.find(class_="block_4").find_all("a")[-1].text)

                for a in range(1, last_page + 1):
                    model.append({
                        "title": f"Страница {a}",
                        "data": {
                            "search_item": search_item,
                            "search_start": a,
                        },
                        "router": "search",
                    })

        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, link: str, sort: int = 0) -> dict:
        link: str = https_checking(link, self.url)
        point: str = link.split(self.url)[-1]
        if findall(r"page/\d+/", point):
            point: str = point.replace(findall(r"page/\d+/", point)[0], "")
        model: list = []
        category: str = ""
        title_sort = "[COLOR=yellow]Отсортировано по[/COLOR] "
        dledirection = "desc"
        set_new_sort = "dle_sort_cat",
        set_direction_sort = "dle_direction_cat"
        if link[:-1] == self.url:
            set_new_sort = "dle_sort_main",
            set_direction_sort = "dle_direction_main"
        if int(sort) == 0:
            title_sort += "[COLOR=green]дате[/COLOR]"
            dlenewssortby = "date"
        elif int(sort) == 1:
            title_sort += "[COLOR=green]популярности[/COLOR]"
            dlenewssortby = "rating"
        elif int(sort) == 2:
            title_sort += "[COLOR=green]посещаемости[/COLOR]"
            dlenewssortby = "news_read"
        elif int(sort) == 3:
            title_sort += "[COLOR=green]комментариям[/COLOR]"
            dlenewssortby = "comm_num"
        elif int(sort) == 4:
            title_sort += "[COLOR=green]алфавиту[/COLOR]"
            dlenewssortby = "title"
            dledirection = "asc"
        else:
            raise TypeError("Метод выбора сортировки вышел за рамки")
        model.append({
            "title": title_sort,
            "data": link,
            "router": "select_sort",
            "not_folder": True,
            "icon": "DefaultTVShowTitle.png",
        })

        post: dict = {
            "dlenewssortby": dlenewssortby,
            "dledirection": dledirection,
            "set_new_sort": set_new_sort,
            "set_direction_sort": set_direction_sort,
        }

        response = self._web.request_post(link, data=post)
        if response and type(response) is not dict:

            soup = BeautifulSoup(response.text, features="html.parser")

            if soup.find("h1"):
                category: str = f"{soup.find('h1').text.strip()}"
            if link.split("/")[-2].isdigit() and link.split("/")[-3] != "god":
                category += f" - страница №{link.split('/')[-2]}"

            for item in soup.find(id="dle-content").find_all(class_="shortstory"):
                context_menu: list = []
                year: int = 0
                genres: list = []
                plot: str = ""

                for p in item.find_all("p"):
                    if p.find("strong").text.strip() == "Год выхода:":
                        year: int = int(p.text.replace("Год выхода: ", "").strip())
                    if p.find("strong").text.strip() == "Жанр:":
                        genres.extend(p.text.replace("Жанр: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Тип:":
                        genres.extend(p.text.replace("Тип: ", "").strip().split(", "))
                    if p.find("strong").text.strip() == "Описание:":
                        plot: str = p.text.replace("Описание: ", "").strip().replace("\n\n", " ")
                    if p.find("strong").text.strip() == "Режиссёр:":
                        context_menu.append((
                            f'{p.find("strong").text.strip()} {p.find("a").text}',
                            f"Container.Update({self._view.convert_to_url(router='catalog', data=p.find('a')['href'], sort=sort)})"
                        ))

                for a in item.find("i").find_all("a"):
                    context_menu.append((
                        f'Категории: {a.text}',
                        f"Container.Update({self._view.convert_to_url(router='catalog', data=a['href'], sort=sort)})"
                    ))

                if item.find(class_="unit-rating"):
                    for a in item.find(class_="unit-rating").find_all("a"):
                        on_click: list = findall(r"\d+", a.get("onclick"))
                        context_menu.append((
                            f"Рейтинг: {a.get('title')} ({a.text} из 5)",
                            f"RunPlugin({self._view.convert_to_url(router='set_votes', go_rate=on_click[0], news_id=on_click[1])})"
                        ))

                try:
                    date_realise = date_to_time_stamp(
                        data_input=item.find(class_="staticInfoLeftData").text.strip(),
                        format_input="%d %B %Y",
                    )
                except:
                    date_realise = ""

                context_menu.append((
                    f"Загрузить целиком",
                    f"RunPlugin({self._view.convert_to_url(router='download_full_anime', data=item.find('h2').find('a')['href'].replace(self.url, ''))})"
                ))

                if "[Анонс]" in item.find("h2").text:
                    title: str = item.find("h2").text.strip().replace("[Анонс]", "[COLOR=red][Анонс][/COLOR]")
                    data: str = ""
                    router: str = ""
                    plot = "[COLOR=red][Анонс][/COLOR]\n" + plot
                else:
                    title: str = item.find("h2").text.strip()
                    data: str = item.find("h2").find("a")["href"].replace(self.url, "")
                    router: str = "realise"

                model_realise: dict = {
                    "title": title,
                    "data": data,
                    "genres": genres,
                    "year": year,
                    "premiered": date_realise,
                    "dateadded": date_realise,
                    "router": router,
                    "plot": plot,
                    "icon": https_checking(item.find("img")["src"], self.url),
                    "context_menu": context_menu,
                }
                if item.find("span", id=True):
                    model_realise["votes"]: int = int(item.find("span", id=True).text)

                model.append(model_realise)

            if soup.find(class_="block_4"):
                last_page: int = int(soup.find(class_="block_4").find_all("a")[-1].text)

                for a in range(1, last_page + 1):
                    model.append({
                        "title": f"Страница {a}",
                        "data": {
                            "data": https_checking(f"{point}page/{a}/", self.url),
                            "sort": sort,
                        },
                        "router": "catalog",
                        "icon": "DefaultAddonVfs.png",
                    })

        return {
            "category": category,
            "list": tuple(model),
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(self.url)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            for item_menu in soup.find(id="topnav").find_all("li"):
                if item_menu.find("a")["href"] in [
                    "/preview/",
                    "/index.php?do=feedback",
                    "/dlya-pravoobladateley.html",
                    "/index.php?action=mobile",
                ]:
                    continue
                if item_menu.find(class_="sar"):
                    model.append({
                        "title": f"[COLOR=grey]{item_menu.find('a').text.strip()}[/COLOR]",
                        "icon": "DefaultSets.png",
                    })
                    for item_sub_menu in item_menu.find(class_="sar").find_all("a"):
                        model.append({
                            "title": f"[COLOR=grey]{item_menu.find('a').text.strip()} =>[/COLOR] {item_sub_menu.text.strip()}",
                            "data": item_sub_menu["href"],
                            "router": "catalog",
                        })
                else:
                    if item_menu.find("a")["href"] == "/":
                        data = self.url + "/"
                    else:
                        data = item_menu.find("a")["href"]
                    model.append({
                        "title": item_menu.find("a").text.strip(),
                        "data": data,
                        "router": "catalog",
                    })

            model.append({
                "title": "Случайное аниме",
                "router": "random",
            })

        model.append({
            "title": "Меню поиска",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        })
        return {
            "category": "Меню",
            "list": tuple(model),
        }
