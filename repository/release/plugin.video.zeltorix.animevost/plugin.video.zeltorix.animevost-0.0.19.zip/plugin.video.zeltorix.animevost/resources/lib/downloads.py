# -*- coding: utf-8 -*-
# Module: downloads
# Author: Zeltorix
# Created on: 2023.02.07
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from json import loads
from re import findall

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from view import *
from text_job import *
from download import Download

from .model import Model


class Downloads:
    __slots__ = ["_web", "_download"]

    _view = View()
    _model = Model()
    _progress = ViewDialogProgress()

    def __init__(self):
        headers["Referer"] = self._model.url + "/"
        self._web = WebApiRequest(headers)
        path_folder = self._view.get_setting_str("download_path")
        if not path_folder:
            if self._view.dialog_ok(
                    "Отсутствует путь сохранения",
                    "Требуется выбрать папку для сохранения в меню настройках \"Загрузки\" плагина"
            ):
                self._view.open_settings()
                self.__init__()
            else:
                self._view.dialog_ok(
                    "Т.к. не внесён путь сохранения",
                    "Загрузка не будет произведена"
                )
                raise
        self._download = Download(path_folder=path_folder, heads=headers)

    def download_full_anime(self, link: str):
        response = self._web.request_get(https_checking(link, self._model.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = sanitize(soup.find("h1").text.strip())

            self._progress.create("Загрузка", f"Начат процесс загрузки {category}")

            json_data = loads(findall(r"data = \{.*?};", response.text)[0].split("= ")[1][:-1].replace(",}", "}"))
            for key, values in json_data.items():
                num_episode = findall(r"\d+", key)

                if not num_episode:
                    num_output = 0
                else:
                    num_output = int(num_episode[0])
                self._progress.update(int(num_output/len(json_data)*100), f"Начат процесс загрузки {key}")
                if self._progress.is_canceled():
                    return

                if num_episode:
                    fail_name: str = key.replace(num_episode[0], num_episode[0].zfill(3))
                else:
                    fail_name = key

                self._download.download(
                    link=self._model.play(f"/frame5.php?play={values}&old=1") + "&d=1",
                    fail_name=f"{fail_name}.mp4",
                    path_anime=category
                )

            self._progress.close()

    def download_episode_anime_fail(self, link: str, category: str, fail_name: str):
        fail_name_num = findall(r"\d+", fail_name)[0]
        fail_name: str = fail_name.replace(fail_name_num, fail_name_num.zfill(3))
        self._progress.create("Загрузка", f"Начат процесс загрузки {fail_name}")
        self._download.download(
            link=self._model.play(link),
            fail_name=f"{sanitize(fail_name)}.mp4",
            path_anime=sanitize(category)
        )
        self._progress.close()
