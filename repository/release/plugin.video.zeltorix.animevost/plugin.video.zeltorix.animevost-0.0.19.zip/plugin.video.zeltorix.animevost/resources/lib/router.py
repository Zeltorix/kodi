# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

from .model import Model
from .downloads import Downloads


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _history = History()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            elif params_dict.get("search_start"):
                _view.output(_model.search(params_dict["search_item"], params_dict["search_start"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict["router"] == "search_history":
            _view.output(_model.search(params_dict["data"]))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict["data"]):
                _view.output(_history.search_menu())
        elif params_dict["router"] == "history_realise":
            _view.output(_model.realise(_view.get_setting_str("history_realise")))

        # Блок воспроизведения
        elif params_dict["router"] == "play":
            _view.play(_model.play(params_dict["data"]))

        # Блок списка серий
        elif params_dict["router"] == "realise":
            _view.output(_model.realise(params_dict["data"]))

        # Блок списка select_sort
        elif params_dict["router"] == "select_sort":
            select_sort: int = _view.dialog_select(_model.select_sort()[0], _model.select_sort()[1])
            if select_sort >= 0:
                # _view.output(_model.catalog(params_dict['data'], select_sort))
                _view.reload(router="catalog", data=params_dict["data"], sort=select_sort)

        # Блок каталогов
        elif params_dict["router"] == "catalog":
            if params_dict.get("sort"):
                _view.output(_model.catalog(params_dict["data"], params_dict["sort"]))
            else:
                _view.output(_model.catalog(params_dict["data"]))

        # Блок случайного аниме
        elif params_dict["router"] == "random":
            _view.output(_model.random())

        # блок голосования
        elif params_dict["router"] == "set_votes":
            _model.set_votes(go_rate=params_dict["go_rate"], news_id=params_dict["news_id"])

        # Блок загрузки
        elif params_dict["router"] == "download_full_anime":
            Downloads().download_full_anime(params_dict["data"])
        elif params_dict["router"] == "download_episode_anime_fail":
            Downloads().download_episode_anime_fail(
                params_dict["data"],
                category=params_dict["category"],
                fail_name=params_dict["fail_name"]
            )

        # Блок исключения
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
