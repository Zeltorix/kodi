# -*- coding: utf-8 -*-
# Module: downloads
# Author: Zeltorix
# Created on: 2023.02.07
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from json import loads
from re import findall

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from view import *
from text_job import *
from download import Download

from .model import Model


class Downloads:
    __slots__ = ["_web", "_download"]

    _view = View()
    _model = Model()
    _progress = ViewDialogProgress()

    def __init__(self):
        headers["Referer"] = self._model.url + "/"
        self._web = WebApiRequest(headers)
        path_folder = self._view.get_setting_str("download_path")
        if not path_folder:
            if self._view.dialog_ok(
                    "Отсутствует путь сохранения",
                    "Требуется выбрать папку для сохранения в меню настройках \"Загрузки\" плагина"
            ):
                self._view.open_settings()
                self.__init__()
            else:
                self._view.dialog_ok(
                    "Т.к. не внесён путь сохранения",
                    "Загрузка не будет произведена"
                )
                raise
        self._download = Download(path_folder=path_folder, heads=headers)

    def download_full_anime(self, link: str):
        response = self._web.request_get(https_checking(link, self._model.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = sanitize(soup.find("h1").text.strip())

            self._progress.create("Загрузка", f"Начат процесс загрузки {category}")

            json_data = loads(findall(r"data = \{.*?};", response.text)[0].split("= ")[1][:-1].replace(",}", "}"))
            for key, values in json_data.items():
                num_episode = findall(r"\d+", key)

                self._progress.update(int(int(num_episode[0])/len(json_data)*100), f"Начат процесс загрузки {key}")
                if self._progress.is_canceled():
                    return

                if num_episode:
                    if int(num_episode[0]) == 1:
                        fail_name: str = key.replace(num_episode[0], f"000{num_episode[0]}")
                    elif int(num_episode[0]) == 2:
                        fail_name: str = key.replace(num_episode[0], f"00{num_episode[0]}")
                    elif int(num_episode[0]) == 3:
                        fail_name: str = key.replace(num_episode[0], f"0{num_episode[0]}")
                    else:
                        fail_name = key
                else:
                    fail_name = key

                self._download.download(
                    link=self._model.play(f"/frame5.php?play={values}&old=1") + "&d=1",
                    fail_name=f"{fail_name}.mp4",
                    path_anime=category
                )

            self._progress.close()

