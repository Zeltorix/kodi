# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from datetime import datetime, timedelta
from pathlib import Path
from time import time
from json import load, dump, dumps, loads
from re import findall
from random import choice
from base64 import standard_b64decode

from web_api_request import WebApiRequest, https_checking, headers
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from get_video_link import VideoLink
from view import View, ViewDialogProgressBG
from history import History

from .auth import Auth
from .cache import Cache


class Model:
    __slots__ = [
        "api",
        "cdn",
        "_plugin_folder",
        "_plugin_cache",
        "_file_favorites",
        "_view",
        "_cache",
    ]

    _web = WebApiRequest()
    _view_dialog_progress_bg = ViewDialogProgressBG()
    _history = History()
    _video_link = VideoLink()
    _auth = Auth()
    list_players: list = ["[COLOR=blue]Telegram[/COLOR] - разрешение не настраивается",
                          "[COLOR=navy]SibNet[/COLOR] - разрешение не настраивается",
                          "[COLOR=grey]Kodik[/COLOR] - выбор разрешения в настройках"]

    def __init__(self):
        self._cache = Cache()
        self._view = View()
        self.cdn: str = "https://a.anibaza.com"
        self.api: str = self.cdn + "/api/"
        self._plugin_folder = Path(self._view.plugin_folder)

    def player_target(self):
        return self._view.dialog_select(
            "Выбор плеера поставщика",
            self.list_players
        )

    def release(self, id_anime: str, player_target=None) -> dict:
        params: dict = {
            "populate": "torrents,"
                        "screenshots,"
                        "roleList,"
                        "roleList.komanda,"
                        "preview,"
                        "zhanries,"
                        "episodes.episode,"
                        "studiyas,"
                        "episodes.episode.preview,"
                        "stuffs,"
                        "stuffs.roles,"
                        "stuffs.hide",
        }
        model: list = []
        data = None
        category: str = "Проблемы с получением реализа"
        # response = self._cache.web_cache(self.url + link, params, time_expires=self._cache.cache_limits("release"))
        response = self._web.request_get(f"{self.api}animes/{id_anime}", params)
        if response and type(response) is not dict:
            data = response.json()

        if data:
            if player_target is None:
                # player_target = self._view.get_setting_int("player_target")
                player_target = 0
            model.append({
                "title": f"[COLOR=coral]Выбор поставщика видео:[/COLOR] {self.list_players[player_target]}",
                "data": id_anime,
                "router": "player_target",
                "not_folder": True,
            })
            attributes = data["data"]["attributes"]
            category: str = attributes["titleRu"]
            if attributes["seasonAnime"]:
                season = findall(r"\d+", attributes["seasonAnime"])[0]
            else:
                season = 1
            images: str = https_checking(
                self.cdn + attributes["preview"]["data"]["attributes"]["url"]
            )
            plot: str = " ".join([children["children"][0]["text"] for children in attributes["desc"]])
            if attributes["episodes"]["episode"]:
                for episode in attributes["episodes"]["episode"]:
                    if episode["preview"]["data"]:
                        images: str = https_checking(
                            episode["preview"]["data"]["attributes"]["url"],
                            self.cdn
                        )
                    if player_target == 0:
                        data_link = https_checking(episode["videoUrl"])
                        router = "play"
                    elif player_target == 1:
                        data_link = https_checking(episode["videoSibnet"])
                        router = "sibnet"
                    elif player_target == 2:
                        data_link = https_checking(episode["videoKodik"])
                        router = "kodik"
                    else:
                        raise
                    model.append({
                        "title": f'[COLOR=red]{attributes["type"]}[/COLOR].'
                                 f'[COLOR=yellow]S{season}[/COLOR].'
                                 f'[COLOR=green]E{episode["number"]}[/COLOR]',
                        "images": images,
                        "plot": plot,
                        "duration": int(findall(r"\d+", attributes["epidoseLength"])[0]) * 60,
                        "data": data_link,
                        "router": router,
                        "play": True,
                    })

        return {
            "list": tuple(model),
            "category": category,
        }

    def _listing_item(self, item: dict):
        context_menu: list = []
        genres: list = []
        attributes: dict = item["attributes"]
        id_title = item["id"]
        if attributes["zhanries"]:
            genres.extend([i["attributes"]["shortName"] for i in attributes["zhanries"]["data"]])

        # if item["team"]:
        #     if item["team"]["voice"]:
        #         genres.extend(item["team"]["voice"])
        #         for voice in item["team"]["voice"]:
        #             context_menu.append((
        #                 f"Озвучка: {voice}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=voice)})"
        #             ))
        #
        #     if item["team"]["translator"]:
        #         genres.extend(item["team"]["translator"])
        #         for translator in item["team"]["translator"]:
        #             context_menu.append((
        #                 f"Переводчик: {translator}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=translator)})"
        #             ))
        #
        #     if item["team"]["editing"]:
        #         genres.extend(item["team"]["editing"])
        #         for editing in item["team"]["editing"]:
        #             context_menu.append((
        #                 f"Субтитры: {editing}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=editing)})"
        #             ))
        #
        #     if item["team"]["decor"]:
        #         genres.extend(item["team"]["decor"])
        #         for decor in item["team"]["decor"]:
        #             context_menu.append((
        #                 f"Оформитель: {decor}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=decor)})"
        #             ))
        #
        #     if item["team"]["timing"]:
        #         genres.extend(item["team"]["timing"])
        #         for timing in item["team"]["timing"]:
        #             context_menu.append((
        #                 f"Тайминг: {timing}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=timing)})"
        #             ))
        #
        # if self._auth.get_session_id():
        #     if not favorites_online:
        #         context_menu.append((
        #             f"Добавить в онлайн избранное",
        #             f"Container.Update({self._view.convert_to_url(router='favorites_online_add', attributes=item['id'])})"
        #         ))
        #
        #     if favorites_online:
        #         context_menu.append((
        #             f"Удалить из онлайн избранного",
        #             f"Container.Update({self._view.convert_to_url(router='favorites_online_del', attributes=item['id'])})"
        #         ))
        #
        # if self._view.get_setting_bool("download_bool"):
        #     context_menu.append((
        #         f"Загрузить целиком с сервера",
        #         f"RunPlugin({self._view.convert_to_url(router='download_full_anime', attributes=item['code'])})"
        #     ))
        #     context_menu.append((
        #         f"Загрузить торрент",
        #         f"Container.Update({self._view.convert_to_url(router='torrents', attributes=item['code'])})"
        #     ))

        premiered = attributes["updatedAt"]

        return {
            "attributes": id_title,
            "title": attributes["titleRu"],
            "images": https_checking(self.cdn + attributes["preview"]["data"]["attributes"]["url"]),
            "premiered": premiered,
            "dateadded": premiered,
            "genres": genres,
            "plot": " ".join([children["children"][0]["text"] for children in attributes["desc"]]),
            "context_menu": context_menu,
            "data": id_title,
            "router": "release",
        }

    def _listing(self,
                 params: dict,
                 time_expires: int = 0,
                 category: str = "",
                 random=False,
                 ) -> dict:
        model: list = []
        params: dict = {
            "populate": "preview,"
                        "zhanries",
            "pagination[start]": "0",
            **params
        }
        data = None
        # response = self._cache.web_cache(self.api + link, params, time_expires=time_expires)
        response = self._web.request_get(self.api + "animes", params)
        if response and type(response) is not dict:
            data = response.json()

        if data:
            data_list = data["data"]
            if random:
                model.append(
                    self._listing_item(
                        choice(data_list),
                    )
                )
            else:
                self._view_dialog_progress_bg.create(category, "")
                self._view_dialog_progress_bg.update(0, "")
                num = 1
                sum_data = len(data_list)
                for item in data_list:
                    self._view_dialog_progress_bg.update(int((num / (sum_data + 1)) * 100), "")
                    model.append(
                        self._listing_item(
                            item,
                        )
                    )
                    num += 1
                self._view_dialog_progress_bg.close()

        return {
            "list": tuple(model),
            "category": category,
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    @staticmethod
    def telegram(link: str) -> dict:
        return {
            "type": False,
            "link_play": link,
        }

    def youtube_id(self, youtube_id: str) -> dict:
        return {
            "type": False,
            "link_play": self._video_link.youtube_link("https://www.youtube.com/watch?v=" + youtube_id),
        }

    def sibnet(self, link: str) -> dict:
        return {
            "type": False,
            "link_play": self._video_link.sibnet_link(link),
        }

    def kodik(self, link: str) -> dict:
        link_chunk: str = ""
        del headers["Referer"]
        headers["Sec-Fetch-Dest"] = "iframe"
        headers["Sec-Fetch-Site"] = "cross-site"
        headers["Upgrade-Insecure-Requests"] = "1"
        self._web.__init__(headers)
        response = self._web.request_get(link)
        if response and type(response) is not dict:
            response_text = response.text
            url_params = loads(findall(r"urlParams.*?}';", response_text)[0].split("'")[1])
            data_type = findall(r"videoInfo\.type.*?;", response_text)[0].split("'")[1]
            data_hash = findall(r"videoInfo\.hash.*?;", response_text)[0].split("'")[1]
            data_id = findall(r"videoInfo\.id.*?;", response_text)[0].split("'")[1]
            domain: str = "https://" + url_params["pd"]
            post: dict = {
                "d": url_params["d"],
                "d_sign": url_params["d_sign"],
                "pd": url_params["pd"],
                "pd_sign": url_params["pd_sign"],
                "ref": url_params["ref"],
                "ref_sign": url_params["ref_sign"],
                "bad_user": "false",
                "cdn_is_working": "true",
                "type": data_type,
                "hash": data_hash,
                "id": data_id,
                "info": "{}"
            }
            link_js = findall(r"/assets/js/app.*?\.js", response_text)[0]
            headers["Priority"] = "u=1"
            headers["Referer"] = link
            headers["Sec-Fetch-Dest"] = "script"
            headers["Sec-Fetch-Mode"] = "no-cors"
            headers["Sec-Fetch-Site"] = "same-origin"
            headers["Accept"] = "*/*"
            self._web.__init__(headers)
            response_js = self._web.request_get(domain + link_js)
            if response_js and type(response_js) is not dict:
                link_chunk: str = standard_b64decode(
                    findall(r'url:atob\("\S+"\),', response_js.text)[0].split('"')[1]).decode("utf-8")

            if link_chunk:
                headers["Referer"] = https_checking(url_params["pd"])
                self._web.__init__(headers)
                self._web.request_get("https://cloud.kodik-storage.com/test/t")
                headers["Accept"] = "application/json, text/javascript, */*; q=0.01"
                headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
                headers["Priority"] = "u=1, i"
                headers["Referer"] = link
                headers["Sec-Fetch-Dest"] = "empty"
                headers["Sec-Fetch-Mode"] = "cors"
                headers["Sec-Fetch-Site"] = "same-origin"
                headers["X-Requested-With"] = "XMLHttpRequest"
                headers["Origin"] = https_checking(url_params["pd"])
                self._web.__init__(headers)
                response_json = self._web.request_post(domain + link_chunk, data=post)
                if response_json and type(response_json) is not dict:
                    data_json = response_json.json()

                    video_size: int = self._view.get_setting_int("video_size")
                    if video_size:
                        height = video_size
                    else:
                        height: int = self._view.get_windows_width_height()["height"]

                    if height <= 360:
                        if data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                    elif 360 < height <= 480:
                        if data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                    elif 480 < height <= 720:
                        if data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                    elif 720 < height <= 1080:
                        if data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                    else:
                        raise ValueError("Отсутствия потоков на видео")

                    def decoding_url(data_url: str) -> str:
                        old: str = "9876543210zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA"[::-1]
                        new: str = "9876543210mlkjihgfedcbazyxwvutsrqponMLKJIHGFEDCBAZYXWVUTSRQPON"[::-1]
                        return standard_b64decode("".join(new[old.index(char)] for char in data_url) + "===").decode(
                            "utf-8")

                    return {
                        "type": "hls",
                        "link_play": https_checking(decoding_url(link_play)),
                    }

    def favorites_online_add(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params_favorites: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "filter": "id",
                **self._limits("all"),
            }
            response_favorites = self._web.request_get(https_checking(self.url + "user/favorites"),
                                                       params=params_favorites)

            if response_favorites and type(response_favorites) is not dict:
                for i in response_favorites.json()["list"]:
                    if i["id"] == int(id_):
                        self._view.dialog_ok("Онлайн избранно", "Данное аниме уж есть в списке!")
                        return False

            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            post: dict = {}
            response = self._web.request_put(https_checking(self.url + "user/favorites"), params=params, data=post)

            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites_online_del(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            response = self._web.request_delete(https_checking(self.url + "user/favorites"), params=params)

            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites(self) -> dict:
        model: list = []
        if self._auth.get_session_id() and self._auth.get_session_id()["expires"] > time():
            model.append({
                "title": f"[COLOR=red]Онлайн избранное расконектится через: "
                         f"{str(timedelta(seconds=self._auth.get_session_id()['expires'] - time()))}[/COLOR]",
                "dateadded": datetime.fromtimestamp(self._auth.get_session_id()["expires"]).strftime(
                    "%Y-%m-%d %H:%M:%S"),
            })
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                **self._limits("all"),
            }
            model.extend(self._listing(
                link="user/favorites",
                params=params,
                time_expires=0,
                category=f"Избранное",
                title_color="blue",
                favorites_online=True)["list"])

        if self._file_favorites.exists():
            with open(self._file_favorites, "r") as file:
                data_json = load(file)

            if data_json["favorites_list"]:
                params: dict = {
                    "code_list": ",".join(data_json["favorites_list"]),
                }
                model.extend(self._listing(
                    link="title/list",
                    params=params,
                    time_expires=0,
                    category=f"Избранное",
                    title_color="green",
                    favorites_offline=True)["list"])

        return {
            "list": tuple(model),
            "category": "Избранное",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def new(self) -> dict:
        params: dict = {
            "sort": "updatedAt:DESC",
            "pagination[limit]": 50,
        }
        return self._listing(
            params=params,
            time_expires=self._cache.cache_limits("new"),
            category="Новые серии",
        )

    def random(self) -> dict:
        params: dict = {
            "pagination[limit]": 500,
        }
        return self._listing(
            params=params,
            time_expires=0,
            category="Случайное аниме",
            random=True,
        )

    def search_advanced(self,
                        genres=None,
                        years=None,
                        season_code=None,
                        order_by=None,
                        status=None):
        params: dict = {
            "sort_direction": "0",
        }
        query_list: list = []

        if genres:
            for i in genres.split(","):
                query_list.append("{genres} == " + i)

        if years:
            for i in years.split(","):
                query_list.append("{season.year} == " + i)

        if season_code:
            for i in season_code.split(","):
                query_list.append("{season.code} == " + i)

        if order_by:
            params["order_by"] = order_by

        if status:
            for i in status.split(","):
                query_list.append("{status.code} == " + i)
        return self._listing(link="title/search/advanced",
                             params=params,
                             category=f"Найдено по запросу",
                             time_expires=self._cache.cache_limits("default"))

    def all(self) -> dict:
        params: dict = {
            "sort[0]": "titleRu:ASC",
            "pagination[limit]": 500,
        }
        return self._listing(
            params=params,
            time_expires=self._cache.cache_limits("all"),
            category=f"Все аниме",
        )

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)
        params: dict = {
            "filters[titleRu][$containsi]": search_item,
            "pagination[limit]": 500,
            # "pagination[withCount]": True
        }
        return self._listing(
            params=params,
            time_expires=self._cache.cache_limits("all"),
            category=f"Найдено => {search_item}",
        )

    def main(self) -> dict:
        model: list = []

        if self._view.get_setting_bool("auth_bool"):
            if not self._auth.token() or self._auth.token()["expires"] < time():
                model.append({
                    "title": "[COLOR=blue]Авторизация[/COLOR]",
                    "router": "auth",
                    "plot": "[COLOR=red]В данный момент не работает[/COLOR]\n"
                            "Нужно для удаленного управления избранным.\n"
                            "Можно отключить этот пункт в настройках.",
                    "not_folder": True,
                    "icon": "DefaultAddonsRepo.png",

                })
        # model.extend([
        #     {
        #         "title": "Мои списки",
        #         "router": "favorites",
        #         "plot": "Онлайн списки",
        #         "icon": "DefaultAddonVfs.png",
        #     },
        #     {
        #         "title": "Смотрю",
        #         "router": "favorites",
        #         "plot": "Онлайн списки",
        #         "icon": "DefaultAddonVfs.png",
        #     },
        #     {
        #         "title": "Запланировано",
        #         "router": "favorites",
        #         "plot": "Онлайн списки",
        #         "icon": "DefaultAddonVfs.png",
        #     },
        #     {
        #         "title": "Пересматриваю",
        #         "router": "favorites",
        #         "plot": "Онлайн списки",
        #         "icon": "DefaultAddonVfs.png",
        #     },
        #     {
        #         "title": "Просмотрено",
        #         "router": "favorites",
        #         "plot": "Онлайн списки",
        #         "icon": "DefaultAddonVfs.png",
        #     },
        #     {
        #         "title": "Отложено",
        #         "router": "favorites",
        #         "plot": "Онлайн списки",
        #         "icon": "DefaultAddonVfs.png",
        #     },
        #     {
        #         "title": "Брошено",
        #         "router": "favorites",
        #         "plot": "Онлайн списки",
        #         "icon": "DefaultAddonVfs.png",
        #     },
        # ])
        model.extend([
            {
                "title": "Новые серии",
                "router": "new",
                "plot": "От недавно вышедших к более старым",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
                "icon": "DefaultAddonInfoLibrary.png",
            },
            {
                "title": "Все аниме",
                "router": "all",
                "icon": "DefaultMovieTitle.png",
            },
            # {
            #     "title": "Поиск по тегам",
            #     "router": "search_menu_advanced",
            #     "plot": "Поиск по тегам с историей",
            #     "icon": "DefaultAddonsSearch.png",
            # },
            {
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ])

        return {
            "list": tuple(model),
            "category": "Меню",
        }
