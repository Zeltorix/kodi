# -*- coding: utf-8 -*-
# Module: cache
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
from view import View
from web_api_request import WebCache


class Cache(WebCache):
    def time_limits(self, item: str, time_expires=None) -> int:
        if item == "release":
            if time_expires:
                return time_expires
            else:
                return self._view.get_setting_int("cache_time_release") * 60
        elif item == "new":
            return self._view.get_setting_int("cache_time_new") * 60
        elif item == "default":
            return self._view.get_setting_int("cache_time_default") * 60
        elif item == "all":
            return self._view.get_setting_int("cache_time_all") * 60
        else:
            raise ValueError(f"Такого значения нет: {item}")
