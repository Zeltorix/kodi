# -*- coding: utf-8 -*-
# Module: auth
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from json import dumps, loads, load, dump
from pathlib import Path
from re import findall
from time import time, gmtime
from datetime import timedelta

from web_api_request import WebApiRequest, https_checking, headers, Proxy
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from view import View


class Auth:
    __slots__ = [
        "_web",
        "_plugin_folder",
        "_plugin_token",
    ]

    _view = View()

    def __init__(self, headers_=headers, proxy=None):
        self._web = WebApiRequest(headers_, proxy=proxy)
        self._plugin_folder = Path(self._view.plugin_folder)
        self._plugin_token = Path(self._view.plugin_folder, "token.json")

    def register(self):
        post: dict = {
            "email": self._view.dialog_input(label="Почта"),
            "password": self._view.dialog_input(label="Пароль"),
            "username": self._view.dialog_input(label="Логин")
        }

        token = None
        error = None

        response = self._web.request_post("https://a.anibaza.com/api/auth/local/register", data=post)
        if response and type(response) is not dict:
            json_data = response.json()
            if json_data.get("jwt"):
                token = json_data["jwt"]
            elif json_data.get("error"):
                error = json_data["error"]["message"]
        else:
            self._view.output_logs(response)

        if token:
            if not self._plugin_folder.exists():
                self._plugin_folder.mkdir(parents=True)
            with open(self._plugin_token, "w+") as file:
                dump({
                    "token": token,
                    "expires": 604800 * 2 + time()
                }, file, indent=2)

            self._view.dialog_ok(
                "Регистрация",
                f"Регистрация выполнена.\n"
            )
        elif error:
            self._view.dialog_ok(
                "Регистрация",
                f"Ошибка регистрации.\n"
                f"{error}"
            )
        else:
            raise

    def auth(self):
        post: dict = {
            "identifier": self._view.dialog_input(label="Логин или почта"),
            "password": self._view.dialog_input(label="Пароль"),
        }

        token = None
        error = None

        response = self._web.request_post("https://a.anibaza.com/api/auth/local", data=post)
        if response and type(response) is not dict:
            json_data = response.json()
            if json_data.get("jwt"):
                token = f'Bearer {json_data["jwt"]}'
            elif json_data.get("error"):
                error = json_data["error"]["message"]
            else:
                raise ValueError(f"Не известное значение:\n{dumps(json_data, indent=2)}")
        else:
            self._view.output_logs(response)

        if token:
            if not self._plugin_folder.exists():
                self._plugin_folder.mkdir(parents=True)
            with open(self._plugin_token, "w+") as file:
                dump({
                    "token": token,
                    "expires": 604800 * 2 + time()
                }, file, indent=2)

            self._view.dialog_ok(
                "Авторизация",
                f"Авторизация выполнена.\n"
            )
        elif error:
            self._view.dialog_ok(
                "Авторизация",
                f"Ошибка авторизации.\n"
                f"{error}"
            )
        else:
            raise

    def token(self) -> dict:
        if self._plugin_token.exists():
            with open(self._plugin_token, "r") as file:
                return load(file)

    def auth_del(self):
        if self._plugin_token.exists():
            self._plugin_token.unlink()
            self._view.dialog_ok("Авторизация", "Авторизация удалена")
