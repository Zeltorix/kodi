# -*- coding: utf-8 -*-
# Module: history_advanced
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль истории работы с поиском.
"""
# Стандартные модули
from itertools import islice
from pathlib import Path
from json import load, dump

from view import View
from history import History


class HistoryAdvanced(History):
    __slots__ = []

    _view = View()
    history_advanced_file = Path(_view.plugin_folder, "history_advanced.json")
#
#     def history_advanced_clearing(self) -> bool:
#         with open(self.history_advanced_file, "w") as file:
#             dump({}, file)
#             return True
#
#     def history_advanced_del_item(self, item: str) -> bool:
#         if self.history_advanced_file.exists():
#             with open(self.history_advanced_file, "r", encoding='utf-8') as file:
#                 history_dict: dict = load(file)
#                 if history_dict.pop(item, None):
#                     with open(self.history_advanced_file, "w") as new_file:
#                         dump(history_dict, new_file, indent=2)
#                         return True
#
#     def history_advanced_add_item(self, item: str) -> bool:
#         history_limit: int = int(self._view.get_setting_int("history_limit"))
#         if self.history_advanced_file.exists():
#             with open(self.history_advanced_file, "r", encoding='utf-8') as file:
#                 history_dict: dict = load(file)
#             new_item: dict = {item: f"search_history"}
#             history_dict, new_item = new_item, history_dict
#             history_dict.update(new_item)
#             history_dict: dict = dict(islice(history_dict.items(), history_limit))
#             with open(self.history_advanced_file, "w") as new_file:
#                 dump(history_dict, new_file, indent=2)
#                 return True
#         else:
#             with open(self.history_advanced_file, "w") as new_file:
#                 dump({item: f"search_history"}, new_file, indent=2)
#                 return True
#
#     def search_menu_advanced(self,
#                              genres=None,
#                              years=None,
#                              season_code=None,
#                              order_by=None,
#                              status=None) -> dict:
#         model: list = []
#         model_genres: dict = {
#             "title": "[COLOR=green]Жанр:[/COLOR]",
#             "router": "genres",
#             "icon": "DefaultAddonsSearch.png",
#             "data": {
#                 "genres": genres,
#                 "years": years,
#                 "season_code": season_code,
#                 "order_by": order_by,
#                 "status": status,
#             },
#         }
#         model_years: dict = {
#             "title": "[COLOR=green]Год:[/COLOR]",
#             "router": "years",
#             "icon": "DefaultAddonsSearch.png",
#             "data": {
#                 "genres": genres,
#                 "years": years,
#                 "season_code": season_code,
#                 "order_by": order_by,
#                 "status": status,
#             },
#         }
#         model_season_code: dict = {
#             "title": "[COLOR=green]Сезон:[/COLOR]",
#             "router": "season_code",
#             "icon": "DefaultAddonsSearch.png",
#             "data": {
#                 "genres": genres,
#                 "years": years,
#                 "season_code": season_code,
#                 "order_by": order_by,
#                 "status": status,
#             },
#         }
#         model_order_by: dict = {
#             "title": "[COLOR=green]Сортировать по:[/COLOR]",
#             "router": "order_by",
#             "icon": "DefaultAddonsSearch.png",
#             "data": {
#                 "genres": genres,
#                 "years": years,
#                 "season_code": season_code,
#                 "order_by": order_by,
#                 "status": status,
#             },
#         }
#         model_status: dict = {
#             "title": "[COLOR=green]Релиз завершен:[/COLOR]",
#             "router": "status",
#             "icon": "DefaultAddonsSearch.png",
#             "data": {
#                 "genres": genres,
#                 "years": years,
#                 "season_code": season_code,
#                 "order_by": order_by,
#                 "status": status,
#             },
#         }
#         model_search: dict = {
#             "title": "Показать",
#             "router": "search_advanced",
#             "icon": "DefaultAddonsSearch.png",
#             "data": {
#                 "genres": genres,
#                 "years": years,
#                 "season_code": season_code,
#                 "order_by": order_by,
#                 "status": status,
#             },
#         }
#         if genres:
#             model_search["data"]["genres"] = genres
#             model_genres["title"] = f"[COLOR=yellow]Выбрать жанры[/COLOR]: {genres}"
#         if years:
#             model_search["data"]["years"] = years
#             model_years["title"] = f"[COLOR=yellow]Год[/COLOR]: {years}"
#         if season_code:
#             model_search["data"]["season_code"] = season_code
#             model_season_code["title"] = f"[COLOR=yellow]Сезон[/COLOR]: {season_code}"
#         if order_by:
#             model_search["data"]["order_by"] = order_by
#             model_order_by["title"] = f"[COLOR=yellow]Сезон[/COLOR]: {order_by}"
#         if status:
#             model_search["data"]["status"] = status
#             model_status["title"] = f"[COLOR=yellow]Сезон[/COLOR]: {status}"
#         model.append(model_genres)
#         model.append(model_years)
#         model.append(model_season_code)
#         model.append(model_order_by)
#         model.append(model_status)
#         model.append(model_search)
#
#         if self.history_advanced_file.exists():
#             with open(self.history_advanced_file, "r", encoding='utf-8') as file:
#                 history_dict: dict = load(file)
#                 for key, value in history_dict.items():
#                     model.append({
#                         "title": f"[COLOR grey]{key}[/COLOR]",
#                         "router": "search_advanced",
#                         "data": value["data"],
#                         "plot": value["plot"],
#                         "context_menu": [
#                             (
#                                 "Удалить из истории",
#                                 f"Container.Update({self._view.convert_to_url(router='history_advanced_del_item', data=key)})"
#                             ),
#                         ],
#                     })
#         return {
#             "category": "Меню поиска",
#             "list": tuple(model)
#         }
