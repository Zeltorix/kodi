# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from web_api_request import WebCache

from .model import Model
from .auth import Auth
# from .downloads import Downloads
from .history_advanced import HistoryAdvanced


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _auth = Auth()
    _history = HistoryAdvanced()
    _web_cache = WebCache()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            elif params_dict.get("search_start"):
                _view.output(_model.search(params_dict["search_item"]))
            else:
                input_text = _view.dialog_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        elif params_dict["router"] == "search_menu_advanced":
            _view.output(_history.search_menu_advanced())
        # elif params_dict["router"] == "genres":
        #     genres = _model.list_for_a("genres"),
        #     _view.output(
        #         _history.search_menu_advanced(
        #             genres=genres,
        #             years=params_dict["years"],
        #             season_code=params_dict["season_code"],
        #             order_by=params_dict["order_by"],
        #             status=params_dict["status"],
        #         )
        #     )

        # Блок работы с историей
        elif params_dict["router"] == "search_history":
            _view.output(_model.search(params_dict["data"]))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict["data"]):
                _view.output(_history.search_menu())
        elif params_dict["router"] == "history_realise":
            _view.output(_model.release(_view.get_setting_str("history_realise")))

        # Блок воспроизведения
        elif params_dict["router"] == "play":
            _view.play(params_dict["data"])
        elif params_dict["router"] == "telegram":
            _view.play(_model.telegram(params_dict["data"]))
        elif params_dict["router"] == "sibnet":
            _view.play(_model.sibnet(params_dict["data"]))
        elif params_dict["router"] == "kodik":
            _view.play(_model.kodik(params_dict["data"]))

        elif params_dict["router"] == "youtube_id":
            _view.output(_model.trailer(params_dict["data"]))

        # Блок списка серий
        elif params_dict["router"] == "release":
            player_target = None
            if params_dict.get("player_target"):
                player_target = int(params_dict["player_target"])
            _view.output(_model.release(params_dict["data"], player_target=player_target))
        elif params_dict["router"] == "random":
            _view.output(_model.random())

        # Блок выбора плеера
        elif params_dict["router"] == "player_target":
            player_target: int = _model.player_target()
            if player_target >= 0:
                _view.reload(router="release", data=params_dict["data"], player_target=player_target)

        # Блок списков аниме
        elif params_dict["router"] == "new":
            _view.output(_model.new())
        elif params_dict["router"] == "all":
            _view.output(_model.all())

        # Блок авторизации
        elif params_dict["router"] == "auth":
            _auth.auth()
            _view.output(_model.main())
        elif params_dict["router"] == "auth_del":
            _auth.auth_del()

        # Блок избранное
        elif params_dict["router"] == "anime_list":
            _view.output(_model.anime_list())
        elif params_dict["router"] == "favorites_online_add":
            if _model.favorites_online_add(params_dict["data"]):
                _view.output(_model.favorites())
            else:
                _view.output(_model.main())
        elif params_dict["router"] == "favorites_online_del":
            if _model.favorites_online_del(params_dict["data"]):
                _view.output(_model.favorites())
            else:
                _view.output(_model.main())

        # Блок обций
        elif params_dict["router"] == "cache_clearing":
            _web_cache.cache_clearing()

        # # Блок загрузки
        # elif params_dict["router"] == "download_full_anime":
        #     Downloads().download_full_anime(params_dict["data"])
        # elif params_dict["router"] == "download_torrents":
        #     Downloads().download_torrent(params_dict["data"])
        #
        # elif params_dict["router"] == "torrents":
        #     _view.output(_model.torrents(params_dict["data"]))

        # Блок исключения
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
