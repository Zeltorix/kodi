# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from datetime import datetime, timedelta
from pathlib import Path
from time import time
from json import load, dump, dumps, loads
from re import findall
from random import choice
from base64 import standard_b64decode

from web_api_request import WebApiRequest, https_checking, headers
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from get_video_link import VideoLink
from view import View, ViewDialogProgressBG
from history import History

from .auth import Auth
from .cache import Cache


class Model:
    __slots__ = [
        "_cache",
        "_view",
        "cdn",
        "api",
        "_plugin_folder",
    ]

    _web = WebApiRequest()
    _view_dialog_progress_bg = ViewDialogProgressBG()
    _history = History()
    _video_link = VideoLink()
    _auth = Auth()
    list_players: list = ["[COLOR=blue]AniBaza[/COLOR] - разрешение не настраивается (проблемный плеер)",
                          "[COLOR=navy]SibNet[/COLOR] - разрешение не настраивается",
                          "[COLOR=grey]Kodik[/COLOR] - выбор разрешения в настройках адона"]

    def __init__(self):
        self._cache = Cache()
        self._view = View()
        self.cdn: str = "https://a.anibaza.com"
        self.api: str = self.cdn + "/api/"
        self._plugin_folder = Path(self._view.plugin_folder)

    def player_target(self):
        return self._view.dialog_select(
            "Выбор плеера",
            self.list_players
        )

    def release(self, id_anime: str, player_target=None) -> dict:
        params: dict = {
            "populate":
            # "torrents,"
            #     "screenshots,"
                "roleList,"
                "roleList.komanda,"
                "preview,"
                "zhanries,"
                "episodes.episode,"
                "studiyas,"
                "episodes.episode.preview,"
            # "stuffs,"
            # "stuffs.roles,"
            # "stuffs.hide",
        }
        model: list = []
        data = None
        plot: str = ""
        category: str = "Проблемы с получением реализа"
        response = self._cache.web(f"{self.api}animes/{id_anime}", params=params,
                                   time_expires=self._cache.time_limits("release"))
        if response:
            data = loads(response)

        if data:
            if player_target is None:
                player_target_setting: int = self._view.get_setting_int("player_target")
                if player_target_setting:
                    player_target = player_target_setting - 1
                else:
                    player_target = 0
            model.append({
                "title": f"[COLOR=coral]Выбор поставщика видео:[/COLOR] {self.list_players[player_target]}",
                "data": id_anime,
                "router": "player_target",
                "not_folder": True,
            })
            attributes = data["data"]["attributes"]
            category: str = attributes["titleRu"]
            if attributes["seasonAnime"]:
                season = findall(r"\d+", attributes["seasonAnime"])[0]
            else:
                season = 1
            images: str = https_checking(
                self.cdn + attributes["preview"]["data"]["attributes"]["url"]
            )

            if attributes["desc"]:
                plot: str = " ".join([children["children"][0]["text"] for children in attributes["desc"]])

            if attributes["episodes"] and attributes["episodes"]["episode"]:
                for episode in attributes["episodes"]["episode"]:
                    if episode["preview"]["data"]:
                        images: str = https_checking(
                            episode["preview"]["data"]["attributes"]["url"],
                            self.cdn
                        )
                    if player_target == 0:
                        if episode["videoUrl"]:
                            data_link = https_checking(episode["videoUrl"])
                            router = "telegram"
                        else:
                            continue
                    elif player_target == 1:
                        if episode["videoSibnet"]:
                            data_link = https_checking(episode["videoSibnet"])
                            router = "sibnet"
                        else:
                            continue
                    elif player_target == 2:
                        if episode["videoKodik"]:
                            data_link = https_checking(episode["videoKodik"])
                            router = "kodik"
                        else:
                            continue
                    else:
                        self._view.output_logs(episode, 3)
                        raise
                    model.append({
                        "title": f'[COLOR=red]{attributes["type"]}[/COLOR].'
                                 f'[COLOR=yellow]S{season}[/COLOR].'
                                 f'[COLOR=green]E{episode["number"]}[/COLOR]',
                        "images": images,
                        "plot": plot,
                        "duration": int(findall(r"\d+", attributes["epidoseLength"])[0]) * 60,
                        "data": data_link,
                        "router": router,
                        "play": True,
                    })
            else:
                model.append({
                    "title": f'[COLOR=red]Серии отсутствуют[/COLOR].',
                    "images": images,
                    "plot": plot,
                })
        return {
            "list": tuple(model),
            "category": category,
        }

    def _listing_item(self, item: dict):
        context_menu: list = []
        genres: list = []
        plot = ""
        attributes: dict = item["attributes"]
        id_title = item["id"]
        if attributes["zhanries"]:
            genres.extend([i["attributes"]["shortName"] for i in attributes["zhanries"]["data"]])

        if attributes["category"]:
            genres.append(attributes["category"])

        if attributes["country"]:
            genres.append(attributes["country"])

        if attributes["epidoseLength"]:
            genres.append(attributes["epidoseLength"])

        if attributes["original"]:
            genres.append(attributes["original"])

        if attributes["rating"]:
            genres.append(attributes["rating"])

        if attributes["season"]:
            genres.append(attributes["season"])

        if attributes["status"]:
            genres.append(attributes["status"])

        if attributes["type"]:
            genres.append(attributes["type"])

        if attributes["workProgress"]:
            genres.append(attributes["workProgress"])

        if attributes.get("trailer") and attributes["trailer"]:
            context_menu.append((
                f"Трейлер",
                # f"RunPlugin({self._view.convert_to_url(router='youtube_id', data=attributes['trailer'], play=True)})"
                f"Container.Update(plugin://plugin.video.zeltorix.anibaza//?router=youtube_id&data={attributes['trailer']}&play=True)"
            ))
            # RunScript RunAddon Container.Update
        #
        # if self._auth.get_session_id():
        #     if not favorites_online:
        #         context_menu.append((
        #             f"Добавить в онлайн избранное",
        #             f"Container.Update({self._view.convert_to_url(router='favorites_online_add', data=item['id'])})"
        #         ))
        #
        # if self._view.get_setting_bool("download_bool"):
        #     context_menu.append((
        #         f"Загрузить целиком с сервера",
        #         f"RunPlugin({self._view.convert_to_url(router='download_full_anime', data=item['code'])})"
        #     ))
        #     context_menu.append((
        #         f"Загрузить торрент",
        #         f"Container.Update({self._view.convert_to_url(router='torrents', data=item['code'])})"
        #     ))

        premiered: str = attributes["updatedAt"]

        if attributes["desc"]:
            plot: str = " ".join([children["children"][0]["text"] for children in attributes["desc"]])

        return {
            "attributes": id_title,
            "title": attributes["titleRu"],
            "images": https_checking(self.cdn + attributes["preview"]["data"]["attributes"]["url"]),
            "premiered": premiered,
            "dateadded": premiered,
            "genres": genres,
            "plot": plot,
            "context_menu": context_menu,
            "data": id_title,
            "router": "release",
        }

    def _listing(self,
                 params: dict,
                 time_expires: int = 0,
                 category: str = "",
                 random=False,
                 search=False,
                 ) -> (dict, list):
        model: list = []
        params: dict = {
            "populate": "preview,"
                        "zhanries",
            "pagination[start]": "0",
            **params
        }
        data = None
        response = self._cache.web(self.api + "animes", params=params, time_expires=time_expires)
        if response:
            data = loads(response)

        if data:
            data_list = data["data"]
            if random:
                model.append(
                    self._listing_item(
                        choice(data_list),
                    )
                )
            else:
                self._view_dialog_progress_bg.create(category, "")
                self._view_dialog_progress_bg.update(0, "")
                num = 1
                sum_data = len(data_list)
                for item in data_list:
                    self._view_dialog_progress_bg.update(int((num / (sum_data + 1)) * 100), "")
                    model.append(
                        self._listing_item(
                            item,
                        )
                    )
                    num += 1
                self._view_dialog_progress_bg.close()

        if search:
            return model
        else:
            return {
                "list": tuple(model),
                "category": category,
                "sort": [
                    0,  # SORT_METHOD_NONE
                    10,  # SORT_METHOD_TITLE_IGNORE_THE
                    21,  # SORT_METHOD_DATEADDED
                ]
            }

    @staticmethod
    def telegram(link: str) -> dict:
        return {
            "type": False,
            "link_play": link,
        }

    def sibnet(self, link: str) -> dict:
        return {
            "type": False,
            "link_play": self._video_link.sibnet_link(link),
        }

    def kodik(self, link: str) -> dict:
        return self._video_link.kodik_play_one(link)

    def trailer(self, youtube_id: str) -> dict:
        data = self._video_link.youtube_link("https://www.youtube.com/watch?v=" + youtube_id)
        return {
            "list": [
                {
                    "title": "Трейлер",
                    "data": data,
                    "router": "play",
                    "play": True,
                }
            ],
            "category": "Трейлер",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    # def favorites_online_add(self, id_: str) -> bool:
    #     if self._auth.get_session_id():
    #         params_favorites: dict = {
    #             "session": self._auth.get_session_id()["session_id"],
    #             "filter": "id",
    #         }
    #         response_favorites = self._web.request_get(https_checking(self.url + "user/favorites"),
    #                                                    params=params_favorites)
    #
    #         if response_favorites and type(response_favorites) is not dict:
    #             for i in response_favorites.json()["list"]:
    #                 if i["id"] == int(id_):
    #                     self._view.dialog_ok("Онлайн избранно", "Данное аниме уж есть в списке!")
    #                     return False
    #
    #         params: dict = {
    #             "session": self._auth.get_session_id()["session_id"],
    #             "title_id": id_,
    #         }
    #         post: dict = {}
    #         response = self._web.request_put(https_checking(self.url + "user/favorites"), params=params, data=post)
    #
    #         if response and type(response) is not dict:
    #             if response.json()["success"]:
    #                 return True
    #
    # def favorites_online_del(self, id_: str) -> bool:
    #     if self._auth.get_session_id():
    #         params: dict = {
    #             "session": self._auth.get_session_id()["session_id"],
    #             "title_id": id_,
    #         }
    #         response = self._web.request_delete(https_checking(self.url + "user/favorites"), params=params)
    #
    #         if response and type(response) is not dict:
    #             if response.json()["success"]:
    #                 return True
    #
    # def favorites(self) -> dict:
    #     model: list = []
    #     if self._auth.get_session_id() and self._auth.get_session_id()["expires"] > time():
    #         model.append({
    #             "title": f"[COLOR=red]Онлайн избранное расконектится через: "
    #                      f"{str(timedelta(seconds=self._auth.get_session_id()['expires'] - time()))}[/COLOR]",
    #             "dateadded": datetime.fromtimestamp(self._auth.get_session_id()["expires"]).strftime(
    #                 "%Y-%m-%d %H:%M:%S"),
    #         })
    #         params: dict = {
    #             "session": self._auth.get_session_id()["session_id"],
    #             **self._limits("all"),
    #         }
    #         model.extend(self._listing(
    #             link="user/favorites",
    #             params=params,
    #             time_expires=0,
    #             category=f"Избранное",
    #             title_color="blue",
    #             favorites_online=True)["list"])
    #
    #     if self._file_favorites.exists():
    #         with open(self._file_favorites, "r") as file:
    #             data_json = load(file)
    #
    #         if data_json["favorites_list"]:
    #             params: dict = {
    #                 "code_list": ",".join(data_json["favorites_list"]),
    #             }
    #             model.extend(self._listing(
    #                 link="title/list",
    #                 params=params,
    #                 time_expires=0,
    #                 category=f"Избранное",
    #                 title_color="green",
    #                 favorites_offline=True)["list"])
    #
    #     return {
    #         "list": tuple(model),
    #         "category": "Избранное",
    #         "sort": [
    #             0,  # SORT_METHOD_NONE
    #             10,  # SORT_METHOD_TITLE_IGNORE_THE
    #             21,  # SORT_METHOD_DATEADDED
    #         ]
    #     }

    def new(self) -> dict:
        params: dict = {
            "sort": "updatedAt:DESC",
            "pagination[limit]": 50,
        }
        return self._listing(
            params=params,
            time_expires=self._cache.time_limits("new"),
            category="Новые серии",
        )

    def random(self) -> dict:
        params: dict = {
            "pagination[limit]": 500,
        }
        return self._listing(
            params=params,
            time_expires=0,
            category="Случайное аниме",
            random=True,
        )

    def search_advanced(self,
                        genres=None,
                        years=None,
                        season_code=None,
                        order_by=None,
                        status=None):
        params: dict = {
            "sort_direction": "0",
        }
        query_list: list = []

        if genres:
            for i in genres.split(","):
                query_list.append("{genres} == " + i)

        if years:
            for i in years.split(","):
                query_list.append("{season.year} == " + i)

        if season_code:
            for i in season_code.split(","):
                query_list.append("{season.code} == " + i)

        if order_by:
            params["order_by"] = order_by

        if status:
            for i in status.split(","):
                query_list.append("{status.code} == " + i)
        return self._listing(link="title/search/advanced",
                             params=params,
                             category=f"Найдено по запросу",
                             time_expires=self._cache.time_limits("default"))

    def all(self) -> dict:
        params: dict = {
            "sort[0]": "titleRu:ASC",
            "pagination[limit]": 500,
        }
        return self._listing(
            params=params,
            time_expires=self._cache.time_limits("all"),
            category=f"Все аниме",
        )

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)
        search_item: str = search_item.lower()
        params_title_ru: dict = {
            "filters[titleRu][$containsi]": search_item,
            "pagination[limit]": 500,
        }
        # params_title_eng: dict = {
        #     "filters[titleEng][$containsi]": search_item,
        #     "pagination[limit]": 500,
        # }
        params_shikimori: dict = {
            "filters[shikimori][$containsi]": search_item,
            "pagination[limit]": 500,
        }
        model_title_ru = self._listing(
            params=params_title_ru,
            time_expires=self._cache.time_limits("all"),
            search=True
        )
        # model_title_eng = self._listing(
        #     params=params_title_eng,
        #     time_expires=self._cache.time_limits("all"),
        #     search=True
        # )
        model_shikimori = self._listing(
            params=params_shikimori,
            time_expires=self._cache.time_limits("all"),
            search=True
        )
        return {
            "list": tuple(model_title_ru + model_shikimori),
            "category": f"Найдено => {search_item}",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def anime_list(self) -> dict:
        num_1: int = 0
        num_2: int = 0
        num_3: int = 0
        num_4: int = 0
        num_5: int = 0
        num_6: int = 0
        headers["Authorization"] = self._auth.token()["token"]
        self._web.__init__(headers)
        response = self._web.request_get(self.api + "users/me")
        if response and type(response) is not dict:
            for item in response.json()["animeList"]:
                if item["type"] == "Смотрю":
                    num_1 += num_1 + 1
                elif item["type"] == "Запланировано":
                    num_2 += num_2 + 1
                elif item["type"] == "Пересматриваю":
                    num_3 += num_3 + 1
                elif item["type"] == "Просмотрено":
                    num_4 += num_4 + 1
                elif item["type"] == "Отложено":
                    num_5 += num_5 + 1
                elif item["type"] == "Брошено":
                    num_6 += num_6 + 1
                else:
                    raise
        model: list = [
            {
                "title": f"Смотрю({num_1})",
                "router": "favorites",
                "plot": "Онлайн списки",
                "icon": "DefaultAddonVfs.png",
            },
            {
                "title": f"Запланировано({num_2})",
                "router": "favorites",
                "plot": "Онлайн списки",
                "icon": "DefaultAddonVfs.png",
            },
            {
                "title": f"Пересматриваю({num_3})",
                "router": "favorites",
                "plot": "Онлайн списки",
                "icon": "DefaultAddonVfs.png",
            },
            {
                "title": f"Просмотрено({num_4})",
                "router": "favorites",
                "plot": "Онлайн списки",
                "icon": "DefaultAddonVfs.png",
            },
            {
                "title": f"Отложено({num_5})",
                "router": "favorites",
                "plot": "Онлайн списки",
                "icon": "DefaultAddonVfs.png",
            },
            {
                "title": f"Брошено({num_6})",
                "router": "favorites",
                "plot": "Онлайн списки",
                "icon": "DefaultAddonVfs.png",
            },
        ]

        return {
            "list": tuple(model),
            "category": "Меню",
        }

    def main(self) -> dict:
        model: list = []

        if self._view.get_setting_bool("auth_bool"):
            if not self._auth.token() or self._auth.token()["expires"] < time():
                model.extend([
                    {
                        "title": "[COLOR=blue]Авторизация[/COLOR]",
                        "router": "auth",
                        "plot": "[COLOR=red]В данный момент не работает[/COLOR]\n"
                                "Нужно для удаленного управления избранным.\n"
                                "Можно отключить этот пункт в настройках.",
                        "not_folder": True,
                        "icon": "DefaultAddonsRepo.png",
                    },
                    {
                        "title": "[COLOR=blue]Регистрация[/COLOR]",
                        "router": "register",
                        "plot": "[COLOR=red]В данный момент не работает[/COLOR]\n"
                                "Нужно для удаленного управления избранным.\n"
                                "Можно отключить этот пункт в настройках.",
                        "not_folder": True,
                        "icon": "DefaultAddonsRepo.png",
                    }
                ])

            if self._auth.token() and self._auth.token()["expires"] > time():
                model.append(
                    {
                        "title": "Мои списки",
                        "router": "anime_list",
                        "plot": "Онлайн списки",
                        "icon": "DefaultAddonVfs.png",
                    }
                )

        model.extend([
            {
                "title": "Новые серии",
                "router": "new",
                "plot": "От недавно вышедших к более старым",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
                "icon": "DefaultAddonInfoLibrary.png",
            },
            {
                "title": "Все аниме",
                "router": "all",
                "icon": "DefaultMovieTitle.png",
            },
            # {
            #     "title": "Поиск по тегам",
            #     "router": "search_menu_advanced",
            #     "plot": "Поиск по тегам с историей",
            #     "icon": "DefaultAddonsSearch.png",
            # },
            {
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ])

        return {
            "list": tuple(model),
            "category": "Меню",
        }
