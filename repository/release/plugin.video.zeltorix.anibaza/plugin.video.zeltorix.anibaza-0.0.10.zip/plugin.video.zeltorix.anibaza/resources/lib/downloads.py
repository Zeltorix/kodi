# -*- coding: utf-8 -*-
# Module: downloads
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from json import loads
from pathlib import Path
from re import findall

from web_api_request import WebApiRequest, headers, https_checking
from view import View, ViewDialogProgress
from text_job import sanitize
# from download import Download

# from PyBitTorrent import TorrentClient

from .model import Model


# class Downloads:
#     __slots__ = ["_web", "_download", "path_folder"]
#
#     _view = View()
#     _model = Model()
#     _progress = ViewDialogProgress()
#
#     def __init__(self):
#         self._web = WebApiRequest()
#         self.path_folder = self._view.get_setting_str("download_path")
#         if not self.path_folder:
#             if self._view.dialog_ok(
#                     "Отсутствует путь сохранения",
#                     "Требуется выбрать папку для сохранения в меню настройках \"Загрузки\" плагина"
#             ):
#                 self._view.open_settings()
#                 self.__init__()
#             else:
#                 self._view.dialog_ok(
#                     "Т.к. не внесён путь сохранения",
#                     "Загрузка не будет произведена"
#                 )
#                 raise
#         self._download = Download(path_folder=self.path_folder, heads=headers)
#
#     def download_full_anime(self, code: str):
#         params: dict = {
#             "code": code,
#             "filter": "code,"
#                       "names.ru,"
#                       "type.string,"
#                       "player.host,"
#                       "player.list,"
#                       "player.rutube",
#         }
#         response = self._web.request_get(https_checking(self._model.url + "title", code), params=params)
#         if response and type(response) is not dict:
#             response_data = response.json()
#
#             self._progress.create("Загрузка", f"Начат процесс загрузки {response_data['names']['ru']}")
#             title_prefix: str = response_data["type"]["string"]
#
#             if response_data["player"]["list"]:
#                 host: str = response_data["player"]["host"]
#                 title = ""
#
#                 for episode in response_data["player"]["list"].values():
#                     if episode["episode"]:
#                         title: str = f"{title_prefix}.{str(episode['episode'])}"
#                         episode_num: int = episode["episode"]
#                     else:
#                         episode_num: int = 0
#                     if episode["name"]:
#                         title: str = f"{title} {episode['name']}"
#
#                     link: str = ""
#
#                     video_size: int = self._view.get_setting_int("video_size")
#                     if video_size:
#                         height = video_size
#                     else:
#                         height: int = self._view.get_windows_width_height()["height"]
#
#                     if height < 720:
#                         if episode["hls"]["sd"]:
#                             link: str = https_checking(host + episode["hls"]["sd"])
#                         elif episode["hls"]["hd"]:
#                             link: str = https_checking(host + episode["hls"]["hd"])
#                         elif episode["hls"]["fhd"]:
#                             link: str = https_checking(host + episode["hls"]["fhd"])
#                     elif 720 <= height < 1080:
#                         if episode["hls"]["hd"]:
#                             link: str = https_checking(host + episode["hls"]["hd"])
#                         elif episode["hls"]["sd"]:
#                             link: str = https_checking(host + episode["hls"]["sd"])
#                         elif episode["hls"]["fhd"]:
#                             link: str = https_checking(host + episode["hls"]["fhd"])
#                     elif 1080 <= height:
#                         if episode["hls"]["fhd"]:
#                             link: str = https_checking(host + episode["hls"]["fhd"])
#                         elif episode["hls"]["hd"]:
#                             link: str = https_checking(host + episode["hls"]["hd"])
#                         elif episode["hls"]["sd"]:
#                             link: str = https_checking(host + episode["hls"]["sd"])
#                     else:
#                         raise ValueError("Отсутствия потоков на видео")
#
#                     self._progress.update(
#                         int(episode_num / len(response_data["player"]["list"]) * 100),
#                         f"Начат процесс загрузки {title}")
#                     if self._progress.is_canceled():
#                         return
#
#                     if link:
#                         self._download.hls(
#                             link=link,
#                             fail_name=f"{title}.mp4",
#                             path_video=response_data["names"]["ru"]
#                         )
#
#             self._progress.close()
#
#     def download_torrent(self, link: str):
#         # response = self._web.request_get(link)
#         # if response and type(response) is not dict:
#         #     fail_name = response.headers["Content-Disposition"].split('"')[1]
#         #     fail_path = Path(self.path_folder, "torrents", fail_name)
#         #     with open(fail_path, 'wb') as fail:
#         #         fail.write(response.content)
#         #     client = TorrentClient(torrent=fail_path, use_progress_bar=False)
#         #     client.start()
#         raise
