# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.01.14
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
# Модули KODI
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon


class View:
    __slots__ = []
    # Получите URL-адрес плагина в формате plugin:// значение.
    _url = sys.argv[0]
    # Получить заготовка плагина в виде целого числа.
    _handle = int(sys.argv[1])
    _kodi_version_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])

    def get_setting(self, id_: str) -> str:
        id_a: str = self._url.split("//")[1].split("/")[0]
        return xbmcaddon.Addon(id_a).getSetting(id_)

    def check_modules(self) -> None:
        try:
            xbmcaddon.Addon('script.module.requests')
        except (ModuleNotFoundError, RuntimeError):
            xbmcgui.Dialog().notification(
                heading='Установка библиотеки requests',
                message='script.module.requests',
                icon=xbmcgui.NOTIFICATION_WARNING,
                time=5000)
            xbmc.executebuiltin('RunPlugin("plugin://script.module.requests")')
        try:
            xbmcaddon.Addon('inputstream.adaptive')
        except (ModuleNotFoundError, RuntimeError):
            xbmcgui.Dialog().notification(
                heading='Установка библиотеки inputstream adaptive',
                message='inputstream.adaptive',
                icon=xbmcgui.NOTIFICATION_WARNING,
                time=5000)
            xbmc.executebuiltin('RunPlugin("plugin://inputstream.adaptive")')
        if self.get_setting("youtube") == "true":
            try:
                xbmcaddon.Addon('script.module.zeltorix.utilitys')
            except (ModuleNotFoundError, RuntimeError):
                xbmcgui.Dialog().notification(
                    heading='Установка библиотеки script.module.zeltorix.utilitys',
                    message='script.module.zeltorix.utilitys',
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin('RunPlugin("plugin://script.module.zeltorix.utilitys")')

    @staticmethod
    def cdn_error() -> None:
        xbmcgui.Dialog().notification(
            heading='Сайт с картинками не доступен',
            message='Сайт с картинка не отвечает',
            icon=xbmcgui.NOTIFICATION_WARNING,
            time=5000)

    @staticmethod
    def youtube_error(msg: str) -> None:
        xbmcgui.Dialog().notification(
            heading='Проблема с видео',
            message=msg,
            icon=xbmcgui.NOTIFICATION_WARNING,
            time=5000)

    def _convert_to_url(self, **kwargs: str) -> str:
        # Преобразование кляча и значения в ссылку данных для дополнения в виде URL
        return f'{self._url}?{urlencode(kwargs)}'

    @staticmethod
    def search() -> str:
        return xbmcgui.Dialog().input(
            'Введите название аниме',
            type=xbmcgui.INPUT_ALPHANUM)

    def play(self, path: str) -> None:
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)
        # Подорожник на пропуск сцен
        if self.get_setting("inputstream_adaptive") == "true":
            # Использовать inputstream.adaptive для входящего медиапотока
            play_item.setProperty('inputstream', "inputstream.adaptive")
            # Тип манифеста медиапотока
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            # Подбор разрешения под экран
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

            # Тип запрашиваемого контента
            play_item.setMimeType('application/xml+dash')
            # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
            play_item.setContentLookup(False)

            # Обновление манифеста, возможно это убирает баг с зависанием
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            # Разрешить начинать воспроизведение LIVE-потока с начала буфера, а не с его конца.
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')

            headers: str = 'Accept-Encoding=gzip,deflate,br&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' \
                           'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
            play_item.setProperty('inputstream.adaptive.stream_headers', headers)
            # listitem.setProperty('inputstream.adaptive.stream_headers',
            #                      'headername=value&User-Agent=the_user_agent&Cookie=the_cookies')

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def play_youtube(self, path: str) -> None:
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)
        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def listing(self, data: dict) -> None:
        if data["sort"]:
            sort_item = xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE
        else:
            sort_item = xbmcplugin.SORT_METHOD_NONE
        # Установка представления содержимого плагина.
        # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
        # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
        xbmcplugin.setContent(self._handle, 'videos')
        # Путь сверху между слешей("/") с добавленным названием
        xbmcplugin.setPluginCategory(self._handle, f"{data['category']} - {len(data['titles'])}")
        # Перебор либо списка аниме, либо серий
        for item in data["titles"]:
            # Нужно для дополнения United Search, иначе не отображает название
            list_item = xbmcgui.ListItem(label=item['title'])
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item['title'])
                vinfo.setGenres(item['genres'])
                vinfo.setPlot(item['plot'])
                # video       For normal video
                # set         For a selection of video
                # musicvideo  To define it as music video
                # movie       To define it as normal movie
                # tvshow      If this is it defined as tvshow
                # season      The type is used as a series season
                # episode     The type is used as a series episode
                vinfo.setMediaType("video")
            else:
                list_item.setInfo('video', {'title': item['title']})
                list_item.setInfo('video', {'genre': item['genres']})
                list_item.setInfo('video', {'plot': item['plot']})
                list_item.setInfo('video', {'mediatype': 'videos'})
            url = self._convert_to_url(router='title', data=item['id'])

            list_item.setArt({'thumb': item['posters']})
            list_item.setArt({'icon': item['posters']})
            list_item.setArt({'fanart': item['posters']})

            # Нужно для перехода в сезон, иначе не переходит
            is_folder = True
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, sort_item)
        xbmcplugin.endOfDirectory(self._handle)

    def season(self, data: dict) -> None:
        sort_item = xbmcplugin.SORT_METHOD_NONE
        # Установка представления содержимого плагина.
        # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
        # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
        xbmcplugin.setContent(self._handle, 'episodes')
        # Путь сверху между слешей("/") с добавленным названием
        xbmcplugin.setPluginCategory(self._handle, data['label'])
        # Перебор либо списка аниме, либо серий
        for item in data['players']:
            list_item = xbmcgui.ListItem()
            last = f"[B][COLOR=red]{data['video_type']} {item['episode']}[/COLOR].[/B] {item['title']}"
            no_last = f"[B][COLOR=green]{data['video_type']}[/COLOR][COLOR=yellow] {item['episode']}[/COLOR].[/B] {item['title']}"
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                if data["total_episodes"] == item['episode']:
                    vinfo.setTitle(last)
                else:
                    vinfo.setTitle(no_last)
                vinfo.setPlot(data["plot"])
                vinfo.setEpisode(item["episode"])
                vinfo.setPremiered(item["premiered"])
                # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
                # video       For normal video
                # set         For a selection of video
                # musicvideo  To define it as music video
                # movie       To define it as normal movie
                # tvshow      If this is it defined as tvshow
                # season      The type is used as a series season
                # episode     The type is used as a series episode
                vinfo.setMediaType("episode")
            else:
                if data["total_episodes"] == item['episode']:
                    list_item.setInfo('video', {
                        'title': last})
                else:
                    list_item.setInfo('video', {
                        'title': no_last})
                list_item.setInfo('video', {'plot': data["plot"]})
                list_item.setInfo('video', {'premiered': item["premiered"]})
                list_item.setInfo('video', {'episode': item["episode"]})
                list_item.setInfo('video', {'mediatype': 'videos'})

            list_item.setArt({'thumb': item['posters']})
            list_item.setArt({'icon': item['posters']})
            list_item.setArt({'fanart': item['posters']})

            list_item.setProperty('IsPlayable', 'true')

            url = self._convert_to_url(router='play', data=item['player'])
            # Переход внутрь не требуется, можно отключить
            is_folder = False
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, sort_item)
        xbmcplugin.endOfDirectory(self._handle)

    def main(self, data: dict) -> None:
        xbmcplugin.setContent(self._handle, 'videos')
        xbmcplugin.setPluginCategory(self._handle, data["category"])
        for item in data["list"]:
            list_item = xbmcgui.ListItem()
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item['title'])
                vinfo.setPlot(item['plot'])
                vinfo.setMediaType("video")
            else:
                list_item.setInfo('video', {'title': item['title']})
                list_item.setInfo('video', {'plot': item['plot']})
                list_item.setInfo('video', {'mediatype': 'videos'})
            url = self._convert_to_url(router=item["router"], data="")
            list_item.setArt({'thumb': item['posters']})
            list_item.setArt({'icon': item['posters']})
            list_item.setArt({'fanart': item['posters']})
            is_folder = True
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self._handle)
