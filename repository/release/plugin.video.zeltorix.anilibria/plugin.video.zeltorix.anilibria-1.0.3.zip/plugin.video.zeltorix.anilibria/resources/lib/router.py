# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

from .model import Model
from .auth import Auth


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _auth = Auth()
    _history = History()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.releases_search(params_dict["keyword"]))
            elif params_dict.get("search_start"):
                _view.output(_model.releases_search(params_dict["search_item"]))
            else:
                input_text = _view.dialog_input()
                if input_text:
                    _view.output(_model.releases_search(input_text))
                _view.output(_history.search_menu())
        # Меню поиска
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей поиска
        elif params_dict["router"] == "search_history":
            _view.output(_model.releases_search(params_dict["data"]))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict["data"]):
                _view.output(_history.search_menu())
        elif params_dict["router"] == "history_realise":
            _view.output(_model.release(_view.get_setting_str("history_realise")))

        # Блок воспроизведения
        elif params_dict["router"] == "play":
            _view.play(_model.play(params_dict["data"]))
        elif params_dict["router"] == "rutube":
            _view.play(_model.rutube(params_dict["data"]))
        elif params_dict["router"] == "youtube_id":
            _view.play(_model.youtube(params_dict["data"]))

        # Блок списка серий
        elif params_dict["router"] == "release":
            _view.output(_model.release(params_dict["data"]))
        elif params_dict["router"] == "random":
            _view.output(_model.releases_random())

        # Блок списков аниме
        elif params_dict["router"] == "new":
            _view.output(_model.releases_last())
        elif params_dict["router"] == "franchises":
            _view.output(_model.franchises())
        elif params_dict["router"] == "all":
            _view.output(_model.catalog_releases())

        # Блок авторизации
        elif params_dict["router"] == "auth_menu":
            _view.output(_auth.auth_menu())
        elif params_dict["router"] == "auth_login":
            _auth.auth_login()
            _view.output(_model.main())
        elif params_dict["router"] == "auth_del":
            _auth.auth_del()

        # Блок избранное
        elif params_dict["router"] == "collections":
            _view.output(_model.collections())
        elif params_dict["router"] == "collections_target":
            _view.output(_model.collections_target(params_dict["data"]))
        elif params_dict["router"] == "collections_add":
            _model.collections_add(params_dict["data"], params_dict["collection"])
            _view.output(_model.collections_target(params_dict["collection"]))
        elif params_dict["router"] == "collections_del":
            _model.collections_del(params_dict["data"])
            _view.output(_model.collections())
        elif params_dict["router"] == "favorites":
            _view.output(_model.favorites())
        elif params_dict["router"] == "favorites_add":
            if _model.favorites_add(params_dict["data"]):
                _view.output(_model.favorites())
            else:
                _view.output(_model.main())
        elif params_dict["router"] == "favorites_del":
            if _model.favorites_del(params_dict["data"]):
                _view.output(_model.favorites())
            else:
                _view.output(_model.main())

        # # Блок опций
        # elif params_dict["router"] == "cache_clearing":
        #     _model.cache_clearing()

        # # Блок загрузки
        # elif params_dict["router"] == "download_full_anime":
        #     Downloads().download_full_anime(params_dict["data"])
        # elif params_dict["router"] == "download_torrents":
        #     Downloads().download_torrent(params_dict["data"])
        #
        # elif params_dict["router"] == "torrents":
        #     _view.output(_model.torrents(params_dict["data"]))

        # Блок исключения
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
