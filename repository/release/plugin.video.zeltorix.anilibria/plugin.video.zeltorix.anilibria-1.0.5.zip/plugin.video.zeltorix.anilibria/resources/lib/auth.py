# -*- coding: utf-8 -*-
# Module: auth
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import dumps, loads, load, dump
from pathlib import Path
from re import findall
from time import time, gmtime
from datetime import timedelta

from web_api_request import WebApiRequest, https_checking, headers, Proxy
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from view import View


class Auth:
    __slots__ = [
        "_web",
        "_plugin_folder",
        "_token",
    ]

    _view = View()

    def __init__(self, headers_=headers, proxy=None):
        self._web = WebApiRequest(headers_, proxy=proxy)
        self._plugin_folder = Path(self._view.plugin_folder)
        self._token = Path(self._view.plugin_folder, "token.json")

    def auth_login(self):
        post: dict = {
            "login": self._view.dialog_input(label="Логин"),
            "password": self._view.dialog_input(label="Пароль от аккаунта"),
        }

        response = self._web.request_post("https://api.anilibria.app/api/v1/accounts/users/auth/login", data=post)
        if response and type(response) is not dict:
            expires = findall(r"expires=.*?;", response.headers["set-cookie"])[0][8:-1]
            session_id = response.json()["token"]
            time_expires = date_time_to_local(expires, format_input="%a, %d-%b-%Y %H:%M:%S %Z", second_output=True)
        else:
            self._view.output_logs(response)
            raise

        if session_id and time_expires:
            if not self._plugin_folder.exists():
                self._plugin_folder.mkdir(parents=True)
            with open(self._token, "w+") as file:
                dump({
                    "token": session_id,
                    "expires": time_expires,
                }, file, indent=2)

            self._view.dialog_ok("Авторизация", f"Авторизация выполнена.\n"
                                                f"До повторной авторизации осталось:\n"
                                                f"{str(timedelta(seconds=time_expires-time()))}")

    def get_token(self) -> dict:
        if self._token.exists():
            with open(self._token, "r") as file:
                return load(file)
        else:
            return {
                "token": "",
                "expires": 0,
            }

    def auth_del(self):
        if self._token.exists():
            self._token.unlink()
            self._view.dialog_ok("Авторизация", "Авторизация удалена")

    def auth_menu(self) -> dict:
        model: list = [
            {
                "title": "Авторизация по логину и паролю",
                "router": "auth_login",
            },
        ]
        return {
            "list": tuple(model),
            "category": "Меню Авторизации",
        }
