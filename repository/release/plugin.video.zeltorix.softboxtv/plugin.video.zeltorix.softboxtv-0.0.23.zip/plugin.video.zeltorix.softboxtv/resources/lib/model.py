# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.08.25
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from re import findall
from json import loads, dumps
from urllib.parse import parse_qsl
from base64 import standard_b64decode

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from history import History
from view import *
from text_job import *


class Model:
    __slots__ = []
    _base_url: str = ras("v02bj5CZoZHd49mY0Z2bz9yL6MHc0RHa")
    headers["Referer"] = _base_url + "/"
    _web = WebApiRequest(headers)
    _view = View()
    _history = History()

    def play(self, link_input: str) -> str:
        clear_link, data_link = link_input.split("?")
        data_link = dict(parse_qsl(data_link))
        post = {
            "d": data_link["d"],
            "d_sign": data_link["d_sign"],
            "pd": data_link["pd"],
            "pd_sign": data_link["pd_sign"],
            "ref": data_link["ref"],
            "ref_sign": data_link["ref_sign"],
            "bad_user": "false",
            "type": data_link["type"],
            "hash": data_link["hash"],
            "id": data_link["id"],
            "info": "{}"
        }
        headers["Referer"] = clear_link
        web = WebApiRequest(headers)
        response = web.request_post("https://" + clear_link.split("/")[2] + "/vdu", data=post)
        if response and type(response) is not dict:
            data_json = loads(response.text)

            default = self._view.get_setting_str("video_size")
            data_2: str = data_json["links"][default][0]["src"]

            def decoding_url(data_url: str) -> str:
                old: str = "9876543210zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA"[::-1]
                new: str = "9876543210mlkjihgfedcbazyxwvutsrqponMLKJIHGFEDCBAZYXWVUTSRQPON"[::-1]
                return standard_b64decode("".join(new[old.index(char)] for char in data_url) + "===").decode("utf-8")

            self._view.output_logs(https_checking(decoding_url(data_2)))

            return https_checking(decoding_url(data_2))

    def realise(self, link: str, translate_num: int = 0) -> dict:
        model: list = []
        category: str = ""
        translate_data: dict = {}
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            duration: int = int(findall(r"\d+", soup.find(class_="page__subcol-side2").find("li").text)[0]) * 60
            posters: str = soup.find(class_="pmovie__poster").find("img")["data-src"]
            plot: str = soup.find(class_="page__text").text
            link_seasons: str = "https:" + soup.find("meta", property="ya:ovs:content_url")["content"]
            category: str = soup.find(class_="speedbar").text.split("»")[-1].strip()

            response_movie = self._web.request_get(link_seasons)
            if response_movie and type(response_movie) is not dict:
                type_video: str = findall(r"videoInfo.type = '.*?'", response_movie.text)[0].split("'")[1]
                soup_seasons = BeautifulSoup(response_movie.text, features="html.parser")
                json_data: dict = loads(findall(r'\{.*?}', response_movie.text)[0])

                model_translate: list = []

                if type_video == "seria":
                    if translate_num:
                        data_media_id: str = soup_seasons.find(
                            class_="serial-translations-box").find_all("option")[translate_num]['data-media-id']
                        data_media_hash: str = soup_seasons.find(
                            class_="serial-translations-box").find_all("option")[translate_num]['data-media-hash']
                        new_link: str = (
                            f"https://"
                            f"kodik.info/"
                            f"serial/"
                            f"{data_media_id}/"
                            f"{data_media_hash}/"
                            f"720p"
                        )
                        response_season = self._web.request_get(new_link)
                        if response_season and type(response) is not dict:
                            type_video: str = findall(r"videoInfo.type = '.*?'", response_season.text)[0].split("'")[1]
                            soup_seasons = BeautifulSoup(response_season.text, features="html.parser")
                            json_data: dict = loads(findall(r'\{.*?}', response_season.text)[0])

                    self._view.output_logs(response_movie.text)
                    if soup_seasons.find(class_="serial-translations-box"):
                        for translate in soup_seasons.find(class_="serial-translations-box").find_all("option"):
                            if translate['data-translation-type'] == "subtitles":
                                title: str = f"Субтитры: [COLOR=yellow]{translate.text}[/COLOR]"
                            elif translate['data-translation-type'] == "voice":
                                title: str = f"Озвучка: [COLOR=green]{translate.text}[/COLOR]"
                            else:
                                title: str = f"Озвучка/Субтитры: [COLOR=yellowgreen]{translate.text}[/COLOR]"
                            model_translate.append(title)
                        data_media_id: str = soup_seasons.find(
                            class_="serial-translations-box").find_all("option")[translate_num]['data-media-id']
                        data_media_hash: str = soup_seasons.find(
                            class_="serial-translations-box").find_all("option")[translate_num]['data-media-hash']

                        for season in soup_seasons.find(class_="series-options").find_all("div"):
                            season_num: str = findall(r"\d+", season['class'][0])[0]
                            for episode in season.find_all("option"):
                                data: str = (
                                    f"https://"
                                    f"kodik.info/"
                                    f"serial/"
                                    f"{data_media_id}/"
                                    f"{data_media_hash}/"
                                    f"720p?"
                                    f"d={json_data['d']}&"
                                    f"d_sign={json_data['d_sign']}&"
                                    f"pd={json_data['pd']}&"
                                    f"pd_sign={json_data['pd_sign']}&"
                                    f"ref={json_data['ref']}&"
                                    f"ref_sign={json_data['ref_sign']}&"
                                    f"advert_debug={json_data['advert_debug']}&"
                                    f"min_age={json_data['min_age']}&"
                                    f"first_url={json_data['first_url']}&"
                                    f"season={season_num}&"
                                    f"episode={episode['value']}&"
                                    f"link={link}&"
                                    f"type={type_video}&"
                                    f"hash={episode['data-hash']}&"
                                    f"id={episode['data-id']}"
                                )
                                model.append({
                                    "title": f"[B][COLOR=blue]S{season_num}[/COLOR][COLOR=yellow]E{episode['value']}[/COLOR][/B]",
                                    "data": data,
                                    "router": "play",
                                    "plot": plot,
                                    "duration": duration,
                                    "images": https_checking(posters, self._base_url),
                                    "play": True,
                                })
                        translate_data: dict = {
                            "title": f"[COLOR=yellowgreen]{model_translate[translate_num]}[/COLOR]",
                            "data": link,
                            "router": "translate",
                            "list": model_translate
                        }

                    elif soup_seasons.find(class_="serial-series-box"):
                        data_media_id = findall(r"videoInfo.id = '.*?';", response_movie.text)[0].split("'")[1]
                        data_media_hash = findall(r"videoInfo.hash = '.*?';", response_movie.text)[0].split("'")[1]
                        type_media = findall(r"videoInfo.type = '.*?';", response_movie.text)[0].split("'")[1]
                        for season in soup_seasons.find(class_="series-options").find_all("div"):
                            season_num: str = findall(r"\d+", season['class'][0])[0]
                            for episode in season.find_all("option"):
                                data: str = (
                                    f"https://"
                                    f"kodik.info/"
                                    f"serial/"
                                    f"{data_media_id}/"
                                    f"{data_media_hash}/"
                                    f"720p?"
                                    f"d={json_data['d']}&"
                                    f"d_sign={json_data['d_sign']}&"
                                    f"pd={json_data['pd']}&"
                                    f"pd_sign={json_data['pd_sign']}&"
                                    f"ref={json_data['ref'][:-1]}&"
                                    f"ref_sign={json_data['ref_sign']}&"
                                    f"advert_debug={json_data['advert_debug']}&"
                                    f"min_age={json_data['min_age']}&"
                                    f"first_url={json_data['first_url']}&"
                                    f"season={season_num}&"
                                    f"episode={episode['value']}&"
                                    f"link={link}&"
                                    f"type={type_video}&"
                                    f"hash={episode['data-hash']}&"
                                    f"id={episode['data-id']}"
                                )
                                model.append({
                                    "title": f"[B][COLOR=blue]S{season_num}[/COLOR][COLOR=yellow]E{episode['value']}[/COLOR][/B]",
                                    "data": data,
                                    "router": "play",
                                    "plot": plot,
                                    "duration": duration,
                                    "images": https_checking(posters, self._base_url),
                                    "play": True,
                                })
                elif type_video == "video":
                    for translate in soup_seasons.find(class_="movie-translations-box").find_all("option"):
                        data: str = (
                            f"https://"
                            f"kodik.info/"
                            f"video/"
                            f"{translate['data-media-id']}/"
                            f"{translate['data-media-hash']}/"
                            f"720p?"
                            f"d={json_data['d']}&"
                            f"d_sign={json_data['d_sign']}&"
                            f"pd={json_data['pd']}&"
                            f"pd_sign={json_data['pd_sign']}&"
                            f"ref={json_data['ref']}&"
                            f"ref_sign={json_data['ref_sign']}&"
                            f"advert_debug={json_data['advert_debug']}&"
                            f"first_url={json_data['first_url']}&"
                            f"link={link}&"
                            f"type={type_video}&"
                            f"hash={translate['data-media-hash']}&"
                            f"id={translate['data-media-id']}"
                        )

                        if translate['data-translation-type'] == "subtitles":
                            title: str = f"{category} (Субтитры: [COLOR=yellow]{translate['data-title']}[/COLOR])"
                        elif translate['data-translation-type'] == "voice":
                            title: str = f"{category} (Озвучка: [COLOR=green]{translate['data-title']}[/COLOR])"
                        else:
                            title: str = f"{category} (Озвучка/Субтитры: [COLOR=yellowgreen]{translate['data-title']}[/COLOR])"

                        model.append({
                            "title": title,
                            "data": data,
                            "router": "play",
                            "plot": plot,
                            "duration": duration,
                            "images": https_checking(posters, self._base_url),
                            "play": True,
                        })
                else:
                    raise TypeError("Неизвестный тип для воспроизведения")

        return {
            "category": category,
            "list": tuple(model),
            "translate": translate_data,
        }

    def catalog(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            if soup.find(class_="sect__title"):
                category: str = soup.find(class_="sect__title").text
            else:
                category: str = soup.find("h1").text
            list_items: list = soup.find_all("article", class_="card d-flex")
            if list_items:
                for item in list_items:
                    if item:
                        context_menu: list = []
                        img: str = item.find("img")["data-src"]
                        plot: str = item.find("div", class_="card__desc").find("p", class_="card__text").text

                        if item.find(lass="ws-nowrap"):
                            genres: list = [genre.text for genre in item.find("li", lass="ws-nowrap").find_all("a")]
                        else:
                            genres: list = []

                        for dis in item.find(class_="card__list").find_all("li"):
                            if dis.find("span"):
                                for a in dis.find_all("a"):
                                    context_menu.append((
                                        f'{dis.find("span").text} {a.text}',
                                        f"Container.Update({self._view.convert_to_url(router='catalog', data=a['href'])})"
                                    ))

                        model.append({
                            "title": item.find("h2").text,
                            "data": item.find("a")["href"],
                            "images": https_checking(img, self._base_url),
                            "plot": plot,
                            "genres": genres,
                            "context_menu": context_menu,
                            "router": "realise",
                        })
            if soup.find(class_="pagination__btn-loader") and soup.find(class_="pagination__btn-loader").find("a"):
                model.append({
                    "title": ">>> Следующая страница >>>",
                    "data": soup.find(class_="pagination__btn-loader").find("a")["href"],
                    "router": "catalog",
                })

        return {
            "category": category,
            "list": tuple(model),
        }

    def menu_sub(self, input_data: str) -> dict:
        model: list = []
        response = self._web.request_get(https_checking(input_data, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            for item in soup.find(class_="side-block__content d-flex jc-space-between").find_all(class_="nav-col"):
                nav_title = item.find_all(class_="nav-title")
                nav_menu = item.find_all(class_="nav-menu")
                num_title: int = len(nav_title)
                for i in range(0, num_title):
                    model.append({
                        "title": f'[B][COLOR=#f8d268]{nav_title[i].text}[/COLOR][/B]',
                        "data": "",
                        "router": "",
                    })
                    all_li = nav_menu[i].find_all("li")
                    for li in all_li:
                        model.append({
                            "title": li.text,
                            "data": li.find("a")["href"],
                            "router": "catalog",
                        })
            model.append({
                "title": f'[B][COLOR=#f8d268]По алфавиту[/COLOR][/B]',
                "data": "",
                "router": "",
            })
            for item in soup.find(class_="ac-catalog").find_all("a"):
                model.append({
                    "title": item.text,
                    "data": item["href"],
                    "router": "catalog",
                })

        return {
            "category": "Главная",
            "list": tuple(model),
        }

    def _collections_items(self, response) -> list:
        model: list = []
        soup = BeautifulSoup(response.text, features="html.parser")
        for item in soup.find(id="dle-content").find_all(class_="collection__item"):
            model.append({
                "title": f'{item.find(class_="collection__title").text} ({item.find(class_="collection__label").text})',
                "data": item["href"],
                "plot": "Обновлено: " + item.find(class_="collection__date").text,
                "icon": https_checking(item.find("img")["data-src"], self._base_url),
                "router": "catalog",
                "premiered": date_time_to_local(item.find(class_="collection__date").text, format_input="%d-%m-%Y, %H:%M"),
            })
        return model

    def collections(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category: str = soup.find(class_="sect__title").text
            model.extend(self._collections_items(response))
            if soup.find(class_="pagination__pages"):
                if soup.find(class_="pagination__pages").find_all("a"):
                    for page in range(2, int(soup.find(class_="pagination__pages").find_all("a")[-1].text) + 1):
                        response_page = self._web.request_get(https_checking(f"{link}/page/{page}", self._base_url))
                        if response_page and type(response_page) is not dict:
                            model.extend(self._collections_items(response_page))

        return {
            "category": category,
            "list": tuple(model),
            "sort": [
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def search(self, item: str) -> dict:
        self._history.history_add_item(item)
        return self.catalog(f"/search/{item}/")

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(self._base_url)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            menu: list = soup.find("nav").find_all("a")
            for item in menu:
                menu_link: str = item["href"]
                if menu_link == "/":
                    model.append({
                        "title": item.text,
                        "data": self._base_url,
                        "router": "menu_sub",
                    })
                elif menu_link == "/collections/":
                    model.append({
                        "title": item.text,
                        "data": menu_link,
                        "router": "collections",
                    })
                elif menu_link == "/ongoings.html":
                    continue
                else:
                    model.append({
                        "title": item.text,
                        "data": menu_link,
                        "router": "catalog",
                    })
        model.append({
            "title": "Последняя просмотренная Дорама",
            "data": "",
            "router": "history_realise",
        })
        model.append({
            "title": "Поиск",
            "data": "",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        })
        return {
            "category": "Меню",
            "list": tuple(model),
        }
