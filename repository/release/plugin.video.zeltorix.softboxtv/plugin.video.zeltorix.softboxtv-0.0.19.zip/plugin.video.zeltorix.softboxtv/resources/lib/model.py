# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.08.25
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json
import re
from urllib.parse import parse_qsl
from base64 import standard_b64decode

# Импорт подключённых модулей из официальных репозиторий
from bs4 import BeautifulSoup

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserSoftboxtv
    from .view import View
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.release.softboxtv.resources.lib.parser import ParserSoftboxtv


class ModelSoftboxtv:
    __slots__ = []
    _parser = ParserSoftboxtv()
    _view = View()
    _base_url = "moc.vtxobtfos//:sptth"[::-1]

    def https_checking(self, url_check: str) -> str:
        if url_check.startswith("http"):
            return url_check
        elif url_check.startswith("//"):
            return "https:" + url_check
        elif self._base_url in url_check:
            return url_check
        elif url_check.startswith("/"):
            return self._base_url + url_check
        else:
            self._view.logs(url_check)
            raise ValueError("Неизвестный тип ссылки")

    def history_clearing(self) -> None:
        self._view.set_setting("history_dict", json.dumps({}))

    def history_realise(self, link) -> None:


        self._view.get_setting("history_realise")


    def play(self, link_input: str) -> str:
        clear_link, data_link = link_input.split("?")
        data_link = dict(parse_qsl(data_link))
        post = {
            "d": data_link["d"],
            "d_sign": data_link["d_sign"],
            "pd": data_link["pd"],
            "pd_sign": data_link["pd_sign"],
            "ref": data_link["ref"],
            "ref_sign": data_link["ref_sign"],
            "bad_user": "false",
            "type": data_link["type"],
            "hash": data_link["hash"],
            "id": data_link["id"],
            "info": "{}"
        }
        self._parser.headers["Referer"] = clear_link
        response = json.loads(self._parser.response_post("https://" + clear_link.split("/")[2] + "/gvi", post).text)

        default = self._view.get_setting("video_size")
        data_2: str = response["links"][default][0]["src"]

        def decoding_url(data_url: str) -> str:
            old: str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
            new: str = "NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm0123456789"
            return standard_b64decode("".join(new[old.index(char)] for char in data_url) + "===").decode("utf-8")

        return self.https_checking(decoding_url(data_2))

    def realise(self, link: str, translate_num: int = 0) -> dict:
        model: list = []
        soup = BeautifulSoup(self._parser.response_get(link).text, features="html.parser")
        duration = int(re.search(r"\d+", soup.find(class_="page__subcol-side2").find("li").text)[0]) * 60
        posters = self.https_checking(soup.find(class_="pmovie__poster").find("img")["data-src"])
        plot = soup.find(class_="page__text").text
        link_seasons: str = "https:" + soup.find("meta", property="ya:ovs:content_url")["content"]
        category = soup.find(class_="speedbar").text.split("»")[-1].strip()

        self._parser.headers["Referer"] = self._base_url + "/"
        response_season = self._parser.response_get(link_seasons).text
        type_video = re.search(r"videoInfo.type = '.*?'", response_season)[0].split("'")[1]
        soup_seasons = BeautifulSoup(response_season, features="html.parser")
        json_data = json.loads(re.search(r'\{.*?}', response_season)[0])

        model_translate: list = []

        if type_video == "seria":
            if translate_num:
                data_media_id = soup_seasons.find(
                    class_="serial-translations-box").find_all("option")[translate_num]['data-media-id']
                data_media_hash = soup_seasons.find(
                    class_="serial-translations-box").find_all("option")[translate_num]['data-media-hash']
                new_link = (
                    f"https://"
                    f"kodik.info/"
                    f"serial/"
                    f"{data_media_id}/"
                    f"{data_media_hash}/"
                    f"720p"
                )
                self._parser.headers["Referer"] = self._base_url + "/"
                response_season = self._parser.response_get(new_link).text
                type_video = re.search(r"videoInfo.type = '.*?'", response_season)[0].split("'")[1]
                soup_seasons = BeautifulSoup(response_season, features="html.parser")
                json_data = json.loads(re.search(r'\{.*?}', response_season)[0])

            for translate in soup_seasons.find(class_="serial-translations-box").find_all("option"):
                if  translate['data-translation-type'] == "subtitles":
                    title = f"Субтитры: [COLOR=yellow]{translate.text}[/COLOR]"
                elif translate['data-translation-type'] == "voice":
                    title = f"Озвучка: [COLOR=green]{translate.text}[/COLOR]"
                else:
                    title = f"Озвучка/Субтитры: [COLOR=yellowgreen]{translate.text}[/COLOR]"
                model_translate.append(title)
            data_media_id = soup_seasons.find(
                class_="serial-translations-box").find_all("option")[translate_num]['data-media-id']
            data_media_hash = soup_seasons.find(
                class_="serial-translations-box").find_all("option")[translate_num]['data-media-hash']

            for season in soup_seasons.find(class_="series-options").find_all("div"):
                season_num = re.search(r"\d+", season['class'][0])[0]
                for episode in season.find_all("option"):
                    data = (
                        f"https://"
                        f"kodik.info/"
                        f"serial/"
                        f"{data_media_id}/"
                        f"{data_media_hash}/"
                        f"720p?"
                        f"d={json_data['d']}&"
                        f"d_sign={json_data['d_sign']}&"
                        f"pd={json_data['pd']}&"
                        f"pd_sign={json_data['pd_sign']}&"
                        f"ref={json_data['ref']}&"
                        f"ref_sign={json_data['ref_sign']}&"
                        f"advert_debug={json_data['advert_debug']}&"
                        f"min_age={json_data['min_age']}&"
                        f"first_url={json_data['first_url']}&"
                        f"season={season_num}&"
                        f"episode={episode['value']}&"
                        f"link={link}&"
                        f"type={type_video}&"
                        f"hash={episode['data-hash']}&"
                        f"id={episode['data-id']}"
                    )
                    model.append({
                        "Title": f"[B][COLOR=blue]S{season_num}[/COLOR][COLOR=yellow]E{episode['value']}[/COLOR][/B]",
                        "data": data,
                        "router": "play",
                        "Plot": plot,
                        "Duration": duration,
                        "Posters": posters,
                    })
            translate_data = {
                "title": f"[COLOR=yellowgreen]{model_translate[translate_num]}[/COLOR]",
                "data": link,
                "router": "translate",
                "list": model_translate
            }
        elif type_video == "video":
            for translate in soup_seasons.find(class_="movie-translations-box").find_all("option"):
                data = (
                    f"https://"
                    f"kodik.info/"
                    f"video/"
                    f"{translate['data-media-id']}/"
                    f"{translate['data-media-hash']}/"
                    f"720p?"
                    f"d={json_data['d']}&"
                    f"d_sign={json_data['d_sign']}&"
                    f"pd={json_data['pd']}&"
                    f"pd_sign={json_data['pd_sign']}&"
                    f"ref={json_data['ref']}&"
                    f"ref_sign={json_data['ref_sign']}&"
                    f"advert_debug={json_data['advert_debug']}&"
                    f"first_url={json_data['first_url']}&"
                    f"link={link}&"
                    f"type={type_video}&"
                    f"hash={translate['data-media-hash']}&"
                    f"id={translate['data-media-id']}"
                )

                if  translate['data-translation-type'] == "subtitles":
                    title = f"{category} (Субтитры: [COLOR=yellow]{translate['data-title']}[/COLOR])"
                elif translate['data-translation-type'] == "voice":
                    title = f"{category} (Озвучка: [COLOR=green]{translate['data-title']}[/COLOR])"
                else:
                    title = f"{category} (Озвучка/Субтитры: [COLOR=yellowgreen]{translate['data-title']}[/COLOR])"

                model.append({
                    "Title": title,
                    "data": data,
                    "router": "play",
                    "Plot": plot,
                    "Duration": duration,
                    "Posters": posters,
                })
            translate_data = False
        else:
            raise TypeError("Неизвестный тип для воспроизведения")
        return {
            "category": category,
            "list": model,
            "translate": translate_data,
        }

    def catalog(self, link: str) -> dict:
        model: list = []
        response = self._parser.response_get(link)
        soup = BeautifulSoup(response.text, features="html.parser")
        if soup.find(class_="sect__title"):
            category = soup.find(class_="sect__title").text
        else:
            category = soup.find("h1").text
        list_items: list = soup.find_all("article", class_="card d-flex")
        if list_items:
            for item in list_items:
                if item:
                    img = self.https_checking(item.find("img")["data-src"])
                    card_desc = item.find("div", class_="card__desc")
                    plot = card_desc.find("p", class_="card__text").text

                    if item.find(lass="ws-nowrap"):
                        genres = [genre.text for genre in item.find("li", lass="ws-nowrap").find_all("a")]
                    else:
                        genres = []

                    model.append({
                        "Title": item.find("h2").text,
                        "data": self.https_checking(item.find("a")["href"]),
                        "Posters": img,
                        "Plot": plot,
                        "Genres": genres,
                        "router": "realise",
                    })
        if soup.find(class_="pagination__btn-loader") and soup.find(class_="pagination__btn-loader").find("a"):
            model.append({
                "Title": ">>> Следующая страница >>>",
                "data": self.https_checking(soup.find(class_="pagination__btn-loader").find("a")["href"]),
                "router": "catalog",
            })
        return {
            "category": category,
            "list": model,
        }

    def menu_sub(self, input_data: str) -> dict:
        model: list = []
        response = self._parser.response_get(input_data)
        soup = BeautifulSoup(response.text, features="html.parser")
        for item in soup.find(class_="side-block__content d-flex jc-space-between").find_all(class_="nav-col"):
            nav_title = item.find_all(class_="nav-title")
            nav_menu = item.find_all(class_="nav-menu")
            num_title = len(nav_title)
            for i in range(0, num_title):
                model.append({
                    "Title": f'[B][COLOR=#f8d268]{nav_title[i].text}[/COLOR][/B]',
                    "data": "",
                    "router": "",
                })
                all_li = nav_menu[i].find_all("li")
                for li in all_li:
                    model.append({
                        "Title": li.text,
                        "data": self.https_checking(li.find("a")["href"]),
                        "router": "catalog",
                    })
        model.append({
            "Title": f'[B][COLOR=#f8d268]По алфавиту[/COLOR][/B]',
            "data": "",
            "router": "",
        })
        for item in soup.find(class_="ac-catalog").find_all("a"):
            model.append({
                "Title": item.text,
                "data": self.https_checking(item["href"]),
                "router": "catalog",
            })
        return {
            "category": "Главная",
            "list": model,
        }

    def collections(self, link: str) -> dict:
        model: list = []
        response = self._parser.response_get(link)
        soup = BeautifulSoup(response.text, features="html.parser")
        category = soup.find(class_="sect__title").text
        for item in soup.find_all(class_="collection__item"):
            print(item)
            model.append({
                "Title": f'{item.find(class_="collection__title").text} ({item.find(class_="collection__label").text})',
                "data": self.https_checking(item["href"]),
                "Plot": "Обновлено: " + item.find(class_="collection__date").text,
                "router": "catalog",
            })
        return {
            "category": category,
            "list": model,
        }

    def search(self, item: str) -> dict:
        history_limit: int = int(self._view.get_setting("history_limit"))
        history: str = self._view.get_setting("history_dict")
        history_dict: dict = json.loads(history)
        new_item: dict = {item: f"search_history"}
        history_dict, new_item = new_item, history_dict
        history_dict.update(new_item)
        from itertools import islice
        history_dict = dict(islice(history_dict.items(), history_limit))
        self._view.set_setting("history_dict", json.dumps(history_dict))
        return self.catalog(self.https_checking(f"/search/{item}/"))

    def search_menu(self) -> dict:
        model: list = []
        history = self._view.get_setting("history_dict")
        model.append({
            "Title": "Поиск дорамы",
            "data": "",
            "router": "search",
        })
        if history:
            history_dict: dict = json.loads(history)
            for key, value in history_dict.items():
                model.append({
                    "Title": f"[COLOR grey]{key}[/COLOR]",
                    "router": value,
                    "data": key,
                })
        return {
            "category": "Меню поиска",
            "list": tuple(model)
        }

    def main(self) -> dict:
        model: list = []
        response = self._parser.response_get(self._base_url)
        soup = BeautifulSoup(response.text, features="html.parser")
        menu: list = soup.find("nav").find_all("a")
        for item in menu:
            menu_link: str = item["href"]
            if menu_link == "/":
                model.append({
                    "Title": item.text,
                    "data": self._base_url,
                    "router": "menu_sub",
                })
            elif menu_link == "/collections/":
                model.append({
                    "Title": item.text,
                    "data": self.https_checking(menu_link),
                    "router": "collections",
                })
            elif menu_link == "/ongoings.html":
                continue
            else:
                model.append({
                    "Title": item.text,
                    "data": self.https_checking(menu_link),
                    "router": "catalog",
                })
        model.append({
            "Title": "Последняя просмотренная Дорама",
            "data": "",
            "router": "history_realise",
        })
        model.append({
            "Title": "Поиск",
            "data": "",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        })
        return {
            "category": "Меню",
            "list": model,
        }
