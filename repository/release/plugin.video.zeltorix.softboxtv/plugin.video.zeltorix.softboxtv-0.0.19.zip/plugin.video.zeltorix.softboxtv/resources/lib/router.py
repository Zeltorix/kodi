# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

# Импорт модуля плагина для создания модели
from .model import ModelSoftboxtv
from .view import View
from .parser import ParserSoftboxtv


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    view = View()
    model = ModelSoftboxtv()
    parser = ParserSoftboxtv()
    if params_dict:

        # Блок поиска
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                if params_dict.get('data'):
                    search = params_dict['data']
                else:
                    search = params_dict['keyword']
                view.main(model.search(search))
            else:
                if params_dict.get('data'):
                    search = params_dict['data']
                    view.main(model.search(search))
                else:
                    search = view.search()
                    view.main(model.search(search))

        elif params_dict['router'] == "search_menu":
            view.main(model.search_menu())

        # Блок работы с историей
        elif params_dict['router'] == "search_history":
            view.main(model.search(params_dict['data']))
        elif params_dict['router'] == "history_clearing":
            model.history_clearing()
        elif params_dict['router'] == "history_realise":
            history_realise = view.get_setting("history_realise")
            link = history_realise.split(",")[0]
            translate_num = int(history_realise.split(",")[1])
            view.main(model.realise(link, translate_num))

        # Блок воспроизведения
        elif params_dict['router'] == 'play':
            url_video = model.play(params_dict['data'])
            parser.response_get(url_video)
            view.play(url_video)

        # Блок списка серий
        elif params_dict['router'] == 'realise':
            if "," in params_dict['data']:
                view.set_setting("history_realise", params_dict['data'])
                link = params_dict['data'].split(",")[0]
                translate_num = int(params_dict['data'].split(",")[1])
            else:
                history_realise = view.get_setting("history_realise")
                if params_dict['data'] in history_realise:
                    link = history_realise.split(",")[0]
                    translate_num = int(history_realise.split(",")[1])
                else:
                    link = params_dict['data']
                    translate_num = 0
            view.main(model.realise(link, translate_num))

        # Блок списка translate
        elif params_dict['router'] == 'translate':
            link = params_dict['data'].split(",")[0]
            translate_num: int = view.dialog_select("Выбор озвучки, перевода", params_dict['data'].split(",")[1].split("|"))
            if translate_num >= 0:
                view.reload(router="realise", data=f"{link},{translate_num}")

        # Блок навигации
        elif params_dict['router'] == "menu_sub":
            view.main(model.menu_sub(params_dict['data']))

        # Блок коллекции
        elif params_dict['router'] == "collections":
            view.main(model.collections(params_dict['data']))

        # Блок каталогов
        elif params_dict['router'] == "catalog":
            view.main(model.catalog(params_dict['data']))

        # Блок исключения
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        view.main(model.main())
