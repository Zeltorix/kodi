# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

from .model import Model


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _history = History()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict["router"] == "search_history":
            _view.output(_model.search(params_dict['data']))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict['data']):
                _view.output(_history.search_menu())
        elif params_dict["router"] == "history_realise":
            history_realise = _view.get_setting_str("history_realise")
            link = history_realise.split(",")[0]
            translate_num = int(history_realise.split(",")[1])
            _view.output(_model.realise(link, translate_num))

        # Блок воспроизведения
        elif params_dict["router"] == "kodik_play":
            _view.play(_model.kodik_play(
                link=params_dict["data"],
                season_num=params_dict["season_num"],
                episode=params_dict["episode"],
                translate=params_dict["translate_num"],
            ))

        # Блок списка серий
        elif params_dict["router"] == "realise":
            if params_dict.get("translate_num"):
                _view.output(_model.realise(params_dict["data"], params_dict["translate_num"]))
            else:
                _view.output(_model.realise(params_dict["data"]))
        elif params_dict["router"] == "random":
            _view.output(_model.random())

        # Блок списка translate
        elif params_dict["router"] == "translate":
            link = params_dict["data"].split(",")[0]
            translate_num: int = _view.dialog_select("Выбор озвучки, перевода",
                                                     params_dict["data"].split(",")[1].split("|"))

            if translate_num >= 0:
                _view.reload(
                    router="realise",
                    data=link,
                    translate_num=translate_num
                )

        # Блок коллекции
        elif params_dict["router"] == "collections":
            _view.output(_model.collections(params_dict["data"]))

        # Блок каталогов
        elif params_dict["router"] == "catalog":
            _view.output(_model.catalog(params_dict["data"]))

        # Блок исключения
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
