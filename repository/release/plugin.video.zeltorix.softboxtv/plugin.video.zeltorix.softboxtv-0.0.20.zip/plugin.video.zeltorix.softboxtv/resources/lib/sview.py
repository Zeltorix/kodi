# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.08.25
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import json
import sys
from urllib.parse import urlencode

# Модули KODI
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon


class View:
    __slots__ = []
    # Получите URL-адрес плагина в формате plugin:// значение.
    _url = sys.argv[0]
    # ID плагина
    _id_plugin = _url.split('/')[2]
    # Получить заготовка плагина в виде целого числа.
    _handle = int(sys.argv[1])
    _kodi_version_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])

    def logs(self, message) -> None:
        xbmc.log(msg=f"{self._id_plugin} ===> {message}", level=xbmc.LOGINFO)

    def reload(self, **kwargs):
        pp = self._convert_to_url(**kwargs)
        self.logs(pp)
        xbmc.executebuiltin(f'Container.Update({pp})')

    @staticmethod
    def get_setting(api_key: str) -> str:
        return xbmcaddon.Addon().getSetting(api_key)

    @staticmethod
    def set_setting(id_: str, value: str) -> str:
        return xbmcaddon.Addon().setSetting(id_, value)

    @staticmethod
    def check_modules() -> None:
        def target_module(check_module: str) -> None:
            try:
                xbmcaddon.Addon(check_module)
            except (ModuleNotFoundError, RuntimeError):
                xbmcgui.Dialog().notification(
                    heading=f'Установка библиотеки {check_module}',
                    message=f'{check_module}',
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin(f'RunPlugin("plugin://{check_module}")')
        target_module('script.module.requests')
        target_module('inputstream.adaptive')
        target_module("script.module.beautifulsoup4")
        target_module('script.module.zeltorix.utilitys')

    @staticmethod
    def error(heading: str, message: str, type_message: str = "info") -> None:
        if type_message == "warning":
            notification = xbmcgui.NOTIFICATION_WARNING
        elif type_message == "error":
            notification = xbmcgui.NOTIFICATION_ERROR
        elif type_message == "info":
            notification = xbmcgui.NOTIFICATION_INFO
        else:
            notification = xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification(
            heading=heading,
            message=message,
            icon=notification,
            time=5000,
            sound=True
        )

    @staticmethod
    def dialog_ok(heading: str, message: str) -> bool:
        return xbmcgui.Dialog().ok(heading=heading, message=message)

    @staticmethod
    def dialog_select(header: str, data: list) -> int:
        return xbmcgui.Dialog().select(header, data, useDetails=True)


    def _convert_to_url(self, **kwargs) -> str:
        # Преобразование кляча и значения в ссылку данных для дополнения в виде URL
        return f'{self._url}?{urlencode(kwargs)}'

    def play(self, path: str) -> None:
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)

        if self.get_setting("inputstream_adaptive") == "true":
            # Использовать inputstream.adaptive для входящего медиапотока
            play_item.setProperty('inputstream', "inputstream.adaptive")
            # Тип манифеста медиапотока
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            # Подбор разрешения под экран
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
            # Выбор разрешения в меню
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'manual-osd')
            # Тип запрашиваемого контента
            play_item.setMimeType('application/x-mpegURL')
            # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
            play_item.setContentLookup(True)
            # Обновление манифеста, возможно это убирает баг с зависанием
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    @staticmethod
    def search() -> str:
        return xbmcgui.Dialog().input(
            'Введите название проекта',
            type=xbmcgui.INPUT_ALPHANUM)

    def main(self, data: dict) -> None:
        xbmcplugin.setContent(self._handle, 'videos')
        xbmcplugin.setPluginCategory(self._handle, data["category"])

        if data.get("translate") and data["translate"]:
            list_item = xbmcgui.ListItem(label=data["translate"]["title"])
            vinfo = list_item.getVideoInfoTag()
            vinfo.setTitle(data["translate"]["title"])
            is_folder = False
            data_translate = f'{data["translate"]["data"]},{"|".join(data["translate"]["list"])}'
            url = self._convert_to_url(router=data["translate"]["router"], data=data_translate)
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)

        for item in data["list"]:
            list_item = xbmcgui.ListItem(label=item['Title'])

            # if item.get('ContextMenuItems') or True:
            #     list_item.addContextMenuItems(
            #         [
            #             (
            #                 'Тестирование контекстного меню',
            #                 f'RunPlugin(plugin.video.zeltorix.vk.video, 99)'
            #                 # f'RunScript(plugin.video.zeltorix.vk.video, 0, ?)'
            #         ]
            #     )

            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item['Title'])
                if item.get('Plot'):
                    vinfo.setPlot(item['Plot'])
                if item.get('Genres'):
                    vinfo.setGenres(item['Genres'])
                if item.get('Premiered'):
                    vinfo.setPremiered(item['Premiered'])
                if item.get("Duration"):
                    vinfo.setDuration(item['Duration'])

                # if item.get('DateAdded'):
                #     vinfo.setDateAdded(item['DateAdded'])

                vinfo.setMediaType("video")
            else:
                list_item.setInfo('video', {'title': item['Title']})
                if item.get('Plot'):
                    list_item.setInfo('video', {'plot': item['Plot']})
                if item.get('Genres'):
                    list_item.setInfo('video', {'genre': item['Genres']})
                if item.get('Premiered'):
                    list_item.setInfo('video', {'premiered': item['Premiered']})
                list_item.setInfo('video', {'mediatype': 'video'})
            if item.get('Posters'):
                list_item.setArt({'thumb': item['Posters']})
                list_item.setArt({'icon': item['Posters']})
                list_item.setArt({'fanart': item['Posters']})

            # Внутренний переход есть
            if item.get("data"):
                data = item["data"]
            else:
                data = ""
            if item.get("data_2"):
                data_2 = item["data_2"]
            else:
                data_2 = ""
            if item['router'] == "play":
                list_item.setProperty('IsPlayable', 'true')
                # Переход внутрь не требуется, можно отключить
                is_folder = False
            # elif item("router") == "":
            #     is_folder = False
            else:
                is_folder = True
            url = self._convert_to_url(router=item["router"], data=data, data_2=data_2)
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self._handle)
