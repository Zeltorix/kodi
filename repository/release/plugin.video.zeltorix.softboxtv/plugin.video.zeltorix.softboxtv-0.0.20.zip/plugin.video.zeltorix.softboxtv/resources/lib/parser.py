# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.08.25
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
# Стандартные
from random import randint, choice
from time import sleep

# Не стандартный модуль импортируется в addon.xml как script.module.requests
from requests import Session

# Не стандартный модуль импортируется в addon.xml как script.module.zeltorix.utilitys
from web_api_request import user_agents

from .view import View

class ParserSoftboxtv:
    __slots__ = []
    _view = View()
    # headers = {
    #     "User-Agent": UserAgent().random,
    # }
    headers = {
        "User-Agent": choice(user_agents),
    }

    # _session = httpx.Client(
    #     headers=headers,
    #     follow_redirects=True,
    #     timeout=10,
    #     http2=True,
    # )

    _session = Session()

    def response_get(self, link: str, retry: int = 10):
        response = self._session.get(link, headers=self.headers, timeout=10)
        self._view.logs(f"GET {response.status_code}")
        if response.ok:
            return response
        elif response.status_code == 404:
            self._view.dialog_ok(
                "Ошибка 404",
                f"Данная страница отсутствует: {link}"
            )
        elif retry:
            sleep(3)
            self.response_get(link=link, retry=retry - 1)
        else:
            raise TypeError(f"\n\n\n{link}\n\n\n{response.text}")

    def response_post(self, link: str, data: dict, retry: int = 10):
        response = self._session.post(link, data=data, headers=self.headers, timeout=10)
        self._view.logs(f"POST {response.status_code}")
        if response.ok:
            return response
        elif 500 <= response.status_code <= 599:
            self._view.dialog_ok(
                "Ошибка 500-599",
                "Возможно видео не доступно.\n"
                "Проверти на сайте доступно ли видео.\n"
                "Если оно доступно сообщите на форум в раздел плагина для исправления этой ошибки."
            )
        elif retry:
            sleep(3)
            self.response_get(link=link, retry=retry - 1)
        else:
            raise TypeError(f"\n\n\n{link}\n\n\n{response.text}")

    # def response_get(self, link: str, retry: int = 10) -> httpx.Response:
    #     try:
    #         result: httpx.Response = self._session.get(link)
    #         if result.status_code != 200:
    #             return self.response_get(link=link, retry=retry - 1)
    #         elif result.status_code == 200:
    #             if result:
    #                 return result
    #         else:
    #             raise TypeError("ghjdthrf")
    #     except Exception as e:
    #         if retry:
    #             return self.response_get(link=link, retry=retry - 1)

    # def response_post(self, link: str, data: dict, retry: int = 10) -> httpx.Response:
    #     try:
    #         result: httpx.Response = self._session.post(link, data=data)
    #         if result.status_code != 200:
    #             return self.response_post(link=link, data=data, retry=retry - 1)
    #         return result
    #     except Exception as e:
    #         if retry:
    #             return self.response_post(link=link, data=data, retry=retry - 1)
