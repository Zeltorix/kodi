# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.08.25
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
from pathlib import Path
# Стандартные модули
from re import findall
from json import loads, dumps, dump, load
from urllib.parse import parse_qsl
from base64 import standard_b64decode

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from history import History
from view import View
from text_job import date_time_to_local, ras
from kodik import Kodik

from .cache import Cache


class Model:
    __slots__ = [
        "_base_url",
        "_web",
        "_view",
        "_history",
        "_kodik",
        "_cache",
        "_cache_translate_file",
    ]

    def __init__(self):
        self._base_url: str = "https://russ.softboxtv.tv"
        headers["Referer"] = self._base_url + "/"
        self._web = WebApiRequest(headers)
        self._view = View()
        self._history = History()
        self._kodik = Kodik()
        self._cache = Cache()

    def kodik_play(
            self,
            link: str,
            season_num: str,
            episode: str,
            translate: str = None,
    ):
        return {
            "type": "hls",
            "link_play": self._kodik.kodik_play(
                link,
                season_num,
                episode,
                translate=translate,
            ),
        }

    def realise(self,
                link: str,
                translate_num: int = None,) -> dict:
        response = self._cache.web(https_checking(link, self._base_url), time_expires=self._cache.time_limits("all"))
        return self.__realise(response, link=link, translate_num=translate_num)

    def __realise(self,
                response: str,
                link: str,
                translate_num: int = None,) -> dict:
        duration: int = 0
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            if soup.find(class_="page__subcol-side2"):
                li = findall(r"\d+", soup.find(class_="page__subcol-side2").find_all("li")[0].text)
                if li:
                    duration: int = int(li[0]) * 60

            if soup.find(class_="pmovie__poster"):
                images: str = https_checking(soup.find(class_="pmovie__poster").find("img")["data-src"], self._base_url)
            else:
                images: str = ""

            if soup.find(class_="page__text"):
                plot: str = soup.find(class_="page__text").text
            else:
                plot: str = ""

            link_seasons: str = "https:" + soup.find("meta", property="ya:ovs:content_url")["content"]
            category: str = soup.find(class_="speedbar").text.split("»")[-1].strip()
            return self._kodik.kodik_list(
                link=link_seasons,
                translate_num=translate_num,
                link_site=link,
                plot=plot,
                duration=duration,
                images=images,
                category=category
            )

    def catalog(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._cache.web(https_checking(link, self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            if soup.find(class_="sect__title"):
                category: str = soup.find(class_="sect__title").text
            else:
                category: str = soup.find("h1").text

            if findall(r"\d+", link.split("/")[-2]):
                category = f"{category} => Страница №{link.split('/')[-2]}"

            list_items = soup.find(id="dle-content")

            if list_items:
                for item in list_items.find_all("div", class_="poster"):
                    if item:
                        img: str = item.find("img")["data-src"]
                        genres = [item.find("div",{"class": "poster__subtitle"}).text.split("•")[1].strip()]
                        genres.extend(i.strip() for i in
                            item.find(
                                "div",
                                {"class": "poster__subtitle"}
                            ).text.split("•")[2].split(",")
                                      )
                        model.append({
                            "title": item.find("div", class_="poster__title").text,
                            "data": item.find("a")["href"],
                            "images": https_checking(img, self._base_url),
                            "genres": genres,
                            "router": "realise",
                        })
            if soup.find(class_="pagination__pages") and soup.find(class_="pagination__pages").find_all("a"):
                link_pages = link.split("page/")
                if link_pages:
                    link: str = link_pages[0]
                for page in range(1, int(soup.find(class_="pagination__pages").find_all("a")[-1].text)):
                    model.append({
                        "title": f"Страница №{page}",
                        "data": https_checking(f"{link}page/{page}/", self._base_url),
                        "router": "catalog",
                    })

        return {
            "category": category,
            "list": tuple(model),
        }

    def _collections_items(self, response) -> list:
        model: list = []
        soup = BeautifulSoup(response, features="html.parser")
        for item in soup.find(id="dle-content").find_all(class_="podborki-item"):
            model.append({
                "title": f'{item.find(class_="podborki-item__title").text} ({item.find(class_="poster__episode").text})',
                "data": item.find("a")["href"],
                "icon": https_checking(item.find("img")["data-src"], self._base_url),
                "router": "catalog",
            })
        return model

    def collections(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._cache.web(https_checking(link, self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            category: str = soup.find(class_="sect__title").text
            model.extend(self._collections_items(response))
            if soup.find(class_="pagination__pages"):
                if soup.find(class_="pagination__pages").find_all("a"):
                    for page in range(2, int(soup.find(class_="pagination__pages").find_all("a")[-1].text) + 1):
                        response_page = self._cache.web(https_checking(f"{link}page/{page}", self._base_url),
                                                        time_expires=self._cache.time_limits("all"))
                        if response_page and type(response_page) is not dict:
                            model.extend(self._collections_items(response_page))

        return {
            "category": category,
            "list": tuple(model),
            "sort": [
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def random(self) -> dict:
        response = self._cache.web(https_checking("/?do=rand_url", self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            return self.__realise(response, self._base_url)

    def search(self, item: str) -> dict:
        self._history.history_add_item(item)
        return self.catalog(f"/search/{item}/")

    def main(self) -> dict:
        model: list = []
        response = self._cache.web(https_checking(self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            menu: list = soup.find("div", class_="nav").find_all("a")

            # self._view.output_logs(menu, 1)

            for item in menu:
                menu_link: str = item["href"]
                if menu_link in [
                    "/",
                    "/marvel-00622/",
                    "/multfilmi-00622/",
                    "/films-00622/",
                    "/top-100/",
                    "/calendar/",
                    "/person/",
                ]:
                    continue
                elif menu_link == "/collections/":
                    model.append({
                        "title": item.text,
                        "data": menu_link,
                        "router": "collections",
                    })
                elif menu_link == "/?do=rand_url":
                    model.append({
                        "title": item.text,
                        "data": menu_link,
                        "router": "random",
                    })
                else:
                    model.append({
                        "title": item.text,
                        "data": menu_link,
                        "router": "catalog",
                    })
        model.append({
            "title": "Поиск",
            "data": "",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        })
        return {
            "category": "Меню",
            "list": tuple(model),
        }
