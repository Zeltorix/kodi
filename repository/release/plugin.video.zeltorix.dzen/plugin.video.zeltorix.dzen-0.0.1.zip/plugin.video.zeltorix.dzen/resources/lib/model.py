# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2025.04.13
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import load, dump, loads, dumps
from re import findall
from time import strftime, localtime, time

from web_api_request import WebApiRequest, https_checking, headers
from get_video_link import VideoLink
from view import View, ViewDialogProgressBG
from history import History
from text_job import clear_html_tags


class Model:
    __slots__ = [
        "_view",
        "_history",
        "host",
        "api",
        "_web",
        "_video_link",
    ]

    def __init__(self):
        self._view = View()
        self._history = History()
        self.host: str = "https://dzen.ru/"
        self.api: str = f"{self.host}api/web/v1/"
        self._web = WebApiRequest()
        self._video_link = VideoLink()

    @staticmethod
    def play(link: str) -> dict:
        return {
            "type": "hls",
            "link_play": link,
        }

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)
        return self.topic(f"https://dzen.ru/api/web/v1/zen-search?query={search_item}&type_filter=video%2Cshort")

    def topic(self, topic_id: str = None) -> dict:
        model: list = []
        category: str = ""
        topic_identity = ""

        if topic_id.startswith("http"):
            response = self._web.request_get(topic_id)
        else:
            response_html = self._web.request_get(
                f"{self.host}topic/{topic_id}",
            )
            if response_html and type(response_html) is not dict:
                response_json = loads(findall(r"\{\"ssrData\":.*}", response_html.text)[0])
                topic_identity = response_json["ssrData"]["exportResponse"]["topicChannel"]["source"]["id"]

            if topic_identity:
                _params = {
                    "topic_identity": topic_identity,
                    "content_type": "long_video"
                }
                response = self._web.request_get(
                    f"{self.api}topic-channel",
                    params=_params,
                )
        if response and type(response) is not dict:
            response_data = loads(response.text)

            # self._view.output_logs(dumps(response_data, indent=2, ensure_ascii=False), 1)



            # for item in response_data["widgets"]["cardNewsTopicChannel"]["payload"]["data"]["rubrics"][0]["stories"]:
            #     time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(int(item["annot"]["title"]["doc"]["pub_date"])))
            #     model.append({
            #         "title": clear_html_tags(item["annot"]["title"]["text"]),
            #         "plot": clear_html_tags(item["annot"]["snippets"][0]["text"]),
            #         "premiered": time_stamp,
            #         "dateadded": time_stamp,
            #         "data": item["annot"]["api_story_url"],
            #         "images": item["pictures"]["pictures"][0]["url"],
            #         "router": "story",
            #     })
            if response_data.get("feedData"):
                data_interation = response_data["feedData"]
            elif response_data.get("items"):
                data_interation = response_data
            else:
                raise
            for item in data_interation["items"]:
                time_stamp = ""
                images = ""
                if item.get("publicationDate"):
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(int(item["publicationDate"])))
                if item.get("image"):
                    images = item["image"]["urlTemplate"].format(
                        namespace=item["image"]["namespace"],
                        size=item["image"]["sizeName"],
                    )
                model.append({
                    "title": clear_html_tags(item["title"]),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "data": item["video"]["id"],
                    "duration": item["video"]["duration"],
                    "images": images,
                    "router": "play",
                    "play": True,
                })

            if data_interation.get("more"):
                model.append({
                    "title": "===>",
                    "data": data_interation["more"]["link"],
                    "router": "topic",
                })
        return {
            "list": tuple(model),
            "category": category,
        }

    def menu(self, parent_id: str) -> dict:
        model: list = []
        category: str = ""
        _params = {
            "parent-id": parent_id,
            "level": "0"
        }
        response = self._web.request_get(
            f"{self.api}get-nested-thematics-catalog",
            params=_params,
        )
        if response and type(response) is not dict:
            response_data = loads(response.text)
            category: str = response_data["items"][0]["title"]
            for item in response_data["items"][0]["items"]:
                model.append({
                    "title": item["title"],
                    "icon": item["imageLink"],
                    "data": item["id"],
                    "router": "topic",
                })
        return {
            "list": tuple(model),
            "category": category,
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(
            f"{self.api}get-nested-thematics-catalog",
        )
        if response and type(response) is not dict:
            response_data = loads(response.text)
            for i in response_data["items"]:
                model.append({
                    "title": i["title"],
                    "icon": i["imageLink"],
                    "data": i["id"],
                    "router": "menu",
                })
        model.append(
            {
                "title": "Поиск",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        )
        return {
            "list": tuple(model),
            "category": "Меню",
        }
