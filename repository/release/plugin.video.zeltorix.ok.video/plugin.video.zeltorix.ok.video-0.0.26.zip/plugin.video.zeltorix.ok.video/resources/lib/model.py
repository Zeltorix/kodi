# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json
from re import findall

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from view import View

from text_job import clear_html_tags


class Model:
    __slots__ = []
    headers["X-Requested-With"] = "XMLHttpRequest"
    _web = WebApiRequest(headers)
    _view = View()

    def play(self, link) -> str:
        if "video/" in link:
            id_: str = link.split("video/")[1]
        else:
            id_ = link
        post: dict = {"st.vpl.id": id_, "st.vpl.bu": link}
        req: str = self._web.request_post(link="https://ok.ru/dk?cmd=PopLayerVideo", data=post).text

        try:
            data_str = findall(r'data-options=".*?"', req)
            if data_str:
                data_json = json.loads(data_str[0].split('"')[1].replace("&quot;", '"'))
            else:
                soup = BeautifulSoup(req, features="html.parser")
                self._view.dialog_ok("Ответ с сайта", soup.find(class_="vp_video_stub_txt").text.strip())
        except:
            self._view.output_logs(msg=f'\n\nplay: {link}\n{req}\n')
        hls: dict = json.loads(data_json["flashvars"]["metadata"])
        if hls.get("hlsMasterPlaylistUrl"):
            video: str = hls["hlsMasterPlaylistUrl"]
        elif hls.get("hlsManifestUrl"):
            video: str = hls["hlsManifestUrl"]
        else:
            raise KeyError("Нужно сообщить на форум")
        return video

    @staticmethod
    def listing(data) -> list:
        soup = BeautifulSoup(data, features="html.parser")
        model_list: list = []
        for item in soup.find_all("div", {"class": "ugrid_i"}):
            img_link: dict = item.find("img", {"class": "video-card_img"})
            if img_link:
                img: str = img_link["src"]
            else:
                img: str = ""
            if img.startswith("//"):
                img: str = "https:" + img
            title: str = item.find("a", {"class": "video-card_n"}).text
            link: str = item.find("a", {"class": "video-card_lk"})["href"]
            if "?" in link:
                link: str = link.split("?")[0]
            if not link.startswith("http"):
                link = "https://ok.ru" + link
            video_info = item.find("div", {"class": "video-card_info"})
            if len(video_info.find_all("span")) == 3:
                video_info = video_info.find_all("span")[2].text
                if int(findall(r'\d+', video_info)[0]):
                    number_of_videos = f"({video_info})"
                else:
                    continue
                router = "playlist"
                play = False
            else:
                number_of_videos = ""
                router = "play"
                play = True
            model_dict: dict = {
                "title": f"{title} {number_of_videos}",
                "router": router,
                "data": link,
                "images": img,
                "play": play
            }
            model_list.append(model_dict)
        return model_list

    def search(self, type_search: str, search_item: str, next_items, gwt=None) -> dict:
        if not gwt:
            gwt: str = findall(r'gwtHash:".*?"', self._web.request_post(link="https://ok.ru/",
                                                                        data={}).text)[0].split('"')[1]
        if type_search == "video":
            link = f"https://ok.ru/dk?cmd=VideoSearchResultMoviesBlock&st.v.sfd=ANY&st.v.srt=Live&st.v.sfhd=off&st.v.sq={search_item}&st.cmd=video&st.prevft=search&st.psft=top&st.m=SEARCH&st.ft=search"
        elif type_search == "channel":
            link = f"https://ok.ru/dk?cmd=VideoSearchResultAlbumsBlock&st.v.srt=Compilation&st.v.sq={search_item}&st.cmd=video&st.psft=top&st.m=SEARCH&st.ft=search"
        else:
            raise ValueError("Неизвестный тип поиска")
        if next_items == "":
            post = {}
        elif len(next_items) <= 3:
            post = {"st.page": next_items, "gwt.requested": gwt}
        elif next_items:
            post = {"st.lastelem": next_items, "gwt.requested": gwt}
        else:
            raise ValueError("Неизвестная конструкция следующей страницы")

        history: str = self._view.get_setting_str("history_dict")
        if history:
            history_dict: dict = json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            new_item: dict = {search_item: f"search_{type_search}_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            self._view.set_setting("history_dict", json.dumps(history_dict))

        data = self._web.request_post(link=link, data=post)
        list_items = self.listing(data.text)
        if data.headers.get("lastelem"):
            next_items = data.headers["lastelem"]
        else:
            if next_items == "":
                next_items = "2"
            else:
                next_items = str(int(next_items) + 1)
        if len(list_items) != 0:
            list_items.append({
                "title": "Далее",
                "router": "search",
                "data": {
                    "data": type_search,
                    "data_2": search_item,
                    "data_3": next_items,
                    "data_4": gwt,
                },
            })
        return {
            "category": "Найдено",
            "list": list_items
        }

    def playlist(self, link: str, next_items: str = "1") -> dict:
        if next_items == "":
            post = {}
        elif len(next_items) <= 3:
            post = {"st.page": next_items}
        elif next_items:
            post = {"st.lastelem": next_items}
        else:
            raise
        data = self._web.request_post(link=link, data=post)
        list_items: list = self.listing(data.text)
        if data.headers.get("lastelem"):
            next_items = data.headers["lastelem"]
        else:
            if next_items == "":
                next_items = "2"
            else:
                next_items = str(int(next_items) + 1)
        if len(list_items) != 0:
            list_items.append({
                "title": "Далее",
                "router": "playlist",
                "data": {
                    "data": link,
                    "data_2": next_items,
                },
            })
        return {
            "category": "Контент",
            "list": list_items
        }

    def menu(self, item: str) -> dict:
        if item == "serial":
            category = "Сериалы"
            model_list: list = [
                {
                    "title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Новинки",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/new?st.cmd=anonymVideo&st.ftag=new&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Драма",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/serialdrama?st.cmd=anonymVideo&st.ftag=serialdrama&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Комедии",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/serialcomedy?st.cmd=anonymVideo&st.ftag=serialcomedy&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Детективы",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/serialdetective?st.cmd=anonymVideo&st.ftag=serialdetective&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
            ]
        elif item == "tvshow":
            category = "ТВ-шоу"
            model_list: list = [
                {
                    "title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Шоу",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/show?st.cmd=anonymVideo&st.ftag=show&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Юмор",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/humor?st.cmd=anonymVideo&st.ftag=humor&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Кулинария",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/cookery?st.cmd=anonymVideo&st.ftag=cookery&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Красота",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/beauty?st.cmd=anonymVideo&st.ftag=beauty&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Авто",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/autoshows?st.cmd=anonymVideo&st.ftag=autoshows&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Познавательные",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/educational?st.cmd=anonymVideo&st.ftag=educational&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
            ]
        elif item == "bloggers":
            category = "Блоги"
            model_list: list = [
                {
                    "title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Юмор",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/bloghumor?st.cmd=anonymVideo&st.ftag=bloghumor&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Игры",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/bloggames?st.cmd=anonymVideo&st.ftag=bloggames&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Животные",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/bloganimals?st.cmd=anonymVideo&st.ftag=bloganimals&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Авто",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogauto?st.cmd=anonymVideo&st.ftag=blogauto&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Красота и здоровье",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogbeauty?st.cmd=anonymVideo&st.ftag=blogbeauty&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Рецепты",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogcookery?st.cmd=anonymVideo&st.ftag=blogcookery&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Дети",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogchildren?st.cmd=anonymVideo&st.ftag=blogchildren&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Спорт",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogsport?st.cmd=anonymVideo&st.ftag=blogsport&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Путешествия",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogtravel?st.cmd=anonymVideo&st.ftag=blogtravel&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Познавательное",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogcognitive?st.cmd=anonymVideo&st.ftag=blogcognitive&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                }
            ]
        elif item == "children":
            category = "Детям"
            model_list: list = [
                {
                    "title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/children?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=children&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "title": "Мультфильмы",
                    "router": "playlist",
                    "data": "https://ok.ru/video/children/cartoons?st.cmd=anonymVideo&st.ftag=cartoons&st.m=ALBUMS_CATALOG&st.ft=children&cmd=VideoAlbumsCatalogBlock",
                },
            ]
        elif item == "search_menu":
            category = "Поиск"
            model_list: list = [
                {
                    "title": "Поиск видео",
                    "router": "search",
                    "data": "video",
                },
                {
                    "title": "Поиск канала",
                    "router": "search",
                    "data": "channel",
                },
            ]
            history = self._view.get_setting_str("history_dict")
            if history:
                history_dict: dict = json.loads(history)
                if len(history_dict) > 10:
                    history_dict.popitem()
                for key, value in history_dict.items():
                    model_list.append({
                        "title": f"[COLOR grey]{key}[/COLOR]",
                        "router": value,
                        "data": key,
                    })
        else:
            raise
        return {
            "category": category,
            "list": tuple(model_list)
        }

    @staticmethod
    def main() -> dict:
        model_list: list = [
            {
                "title": "В топе",
                "router": "playlist",
                "data": "https://ok.ru/video/top?st.cmd=anonymVideo&st.m=CATALOG&st.ft=top&cmd=VideoCatalogBlock",
            },
            {
                "title": "Трансляции",
                "router": "playlist",
                "data": "https://ok.ru/video/live?st.cmd=anonymVideo&st.m=LIVE_SHOWCASE&st.ft=live&cmd=VideoCatalogBlock",
            },
            {
                "title": "Спорт",
                "router": "playlist",
                "data": "https://ok.ru/video/sport?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=sport&cmd=VideoAlbumsCatalogBlock",
            },
            {
                "title": "Каталог",
                "router": "playlist",
                "data": "https://ok.ru/video/channels?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=channels&cmd=VideoAlbumsCatalogBlock",
            },
            {
                "title": "Сериалы",
                "router": "menu",
                "data": "serial",
            },
            {
                "title": "ТВ-шоу",
                "router": "menu",
                "data": "tvshow",
            },
            {
                "title": "Фильмы",
                "router": "playlist",
                "data": "https://ok.ru/video/kino?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=kino&cmd=VideoAlbumsCatalogBlock",
            },
            {
                "title": "Блоги",
                "router": "menu",
                "data": "bloggers",
            },
            {
                "title": "Детям",
                "router": "menu",
                "data": "children",
            },
            {
                "title": "Поиск",
                "router": "menu",
                "data": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            },
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
