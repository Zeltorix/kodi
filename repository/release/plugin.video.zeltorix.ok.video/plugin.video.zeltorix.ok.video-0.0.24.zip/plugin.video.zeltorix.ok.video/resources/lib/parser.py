# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
from web_api_request import headers

class ParserOK:
    """
    Клас для получения данных
    """
    __slots__ = []

    def rest_api(self, link: str, post: dict, retry: int = 10) -> (dict, str):
        # Не стандартный модуль импортируется в addon.xml как script.module.requests
        import requests
        headers["X-Requested-With"] = "XMLHttpRequest"
        response = requests.post(link, headers=headers, timeout=5, data=post)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.rest_api(link=link, post=post, retry=retry - 1)
            elif response.status_code == 404:
                # TODO Добавить оповещение в интерфейс
                raise "Изменился API"
            elif response.ok:
                return response
        except ConnectionError:
            if retry:
                from time import sleep
                from random import randint
                # TODO Добавить оповещение в интерфейс
                sleep(randint(2, 10))
                return self.rest_api(link=link, post=post, retry=retry - 1)
            else:
                raise "Что то не то с API..."
