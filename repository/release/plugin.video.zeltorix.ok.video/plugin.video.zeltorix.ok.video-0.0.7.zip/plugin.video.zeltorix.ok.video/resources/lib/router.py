# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

# Импорт модуля плагина для создания модели
from .model import ModelOK
from .view import View


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    # import logging
    # logger = logging.getLogger(__name__)
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    view = View()
    model = ModelOK()
    if params_dict:
        import xbmc
        xbmc.log(msg=f'router: {params_dict}', level=xbmc.LOGINFO)
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                view.main(model.search(type_search="video", search_item=params_dict['keyword'], next_items="1"))
            else:
                # Вывод поиска, импортировано из модуля view
                if params_dict.get('data_2') and params_dict['data_2']:
                    type_search = params_dict['data']
                    search_item = params_dict['data_2']
                    next_items = params_dict['data_3']
                    gwt = params_dict['data_4']
                else:
                    type_search = params_dict['data']
                    search_item = view.search()
                    next_items = "1"
                    gwt = None
                view.main(model.search(type_search=type_search, search_item=search_item, next_items=next_items, gwt=gwt))
        elif params_dict['router'] == "play":
            view.play(model.play(link=params_dict['data']))
        elif params_dict['router'] == "menu":
            view.main(model.menu(params_dict['data']))
        elif params_dict['router'] == "playlist":
            if params_dict.get('data_2'):
                next_items = params_dict['data_2']
            else:
                next_items = ""
            view.main(model.playlist(link=params_dict['data'], next_items=next_items))
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        view.main(model.main())
