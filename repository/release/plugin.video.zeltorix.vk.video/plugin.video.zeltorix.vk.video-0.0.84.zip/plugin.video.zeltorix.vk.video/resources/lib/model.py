# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import dumps, loads, dump, load
from time import strftime, localtime

from bs4 import BeautifulSoup

# Импорт модуля плагина из текущего каталога для запроса данных
from get_video_link import VideoLink
from web_api_request import WebApiRequest, headers, https_checking
from text_job import clear_html_tags
from view import View
from history import History


class Model:
    __slots__ = [
        "_post",
        "_web",
        "_vkvideo",
        "_live_vkvideo",
        "_api_vkvideo",
        "_api_live_vkvideo",
        "_api_vk",
    ]

    _video_link = VideoLink()
    _view = View()
    _history = History()

    def __init__(self):
        self._post = {
            "al": "1",
            "silent_loading": "1"
        }
        self._vkvideo = "https://vkvideo.ru"
        self._live_vkvideo = "https://live.vkvideo.ru"
        self._api_vkvideo = "https://api.vkvideo.ru"
        self._api_live_vkvideo = "https://api.live.vkvideo.ru"
        self._api_vk = "https://api.vk.com"
        headers["x-requested-with"] = "XMLHttpRequest"
        self._web = WebApiRequest(heads=headers)

    def _get_anonym_token(self):
        return self._video_link.vk_get_anonym_token()

    def _item(self, item: (list, dict), json_data: dict = None) -> dict:

        self._view.output_logs(dumps(item, indent=2, ensure_ascii=False), 1)

        context_menu: list = []
        # Старый формат
        if type(item) is list:
            title = clear_html_tags(item[3])
            router = "play"
            time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(item[9]))
            data = f"{item[0]}_{item[1]}"
            duration = int(item[19])
            images = item[2]
            group_name = clear_html_tags(BeautifulSoup(item[8], "html.parser").find("a").text)
            link_id = item[39]
            if type(item[43]) is int:
                title = f"[COLOR=red]Скоро[/COLOR] {title}"
                router = ""
        # Новый формат?
        elif type(item) is dict:
            title = clear_html_tags(item["3"])
            router = "live_play"
            time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(item["9"]))
            # Лучше переписать!
            data = item["20"]
            duration = item["10"]
            images = item["2"]
            group_name = clear_html_tags(BeautifulSoup(item["8"], "html.parser").find("a").text)
            link_id = item["39"]
            if item.get("43"):
                if type(item["43"]) is int:
                    title = f"[COLOR=red]Скоро[/COLOR] {title}"
                    router = ""
        else:
            self._view.output_logs(dumps(item, indent=2, ensure_ascii=False), 3)
            raise
        if json_data:
            context_menu.append((
                f"{json_data['langKeys']['local']['mobile_video_showcase_form_upload_goto_video']} => {group_name}",
                f"Container.Update({self._view.convert_to_url(router='groups', data=self._vkvideo + link_id)})"
            ))
        return {
            "title": title,
            "router": router,
            "data": data,
            "premiered": time_stamp,
            "dateadded": time_stamp,
            "duration": duration,
            "images": images,
            "plot": f"[B]{group_name}[/B]\n{title}",
            "play": True,
            "context_menu": context_menu,
        }

    def play(self, url: str) -> str:
        return self._video_link.vk_link(url)

    def live_play(self, url: str) -> dict:
        link_play: str = ""
        api_url = f"https://api.live.vkvideo.ru/v1/blog/{url.split('/')[-1]}/public_video_stream?"
        response = self._web.request_get(link=https_checking(api_url, start_url=self._vkvideo))
        if type(response) is not dict:
            data = loads(response.text)["data"][0]
            for i in data["playerUrls"]:
                if i["type"] == "live_cmaf" and i["url"]:
                    return {
                        "type": "mpd",
                        "link_play": i["url"],
                    }
                elif i["type"] == "live_dash" and i["url"]:
                    return {
                        "type": "mpd",
                        "link_play": i["url"],
                    }
                elif i["type"] == "live_playback_dash" and i["url"]:
                    return {
                        "type": "mpd",
                        "link_play": i["url"],
                    }

                # if i["type"] == "live_ondemand_hls" and i["url"]:
                #     return {
                #         "type": "hls",
                #         "link_play": i["url"],
                #     }
                # elif i["type"] == "live_hls" and i["url"]:
                #     return {
                #         "type": "hls",
                #         "link_play": i["url"],
                #     }
                # elif i["type"] == "live_playback_hls" and i["url"]:
                #     return {
                #         "type": "hls",
                #         "link_play": i["url"],
                #     }
            raise

    def profiles(self, id_: str) -> dict:
        model: list = []
        category: str = ""
        _post: dict = {
            "al": "1",
            "need_albums": "1",
            "offset": "0",
            "oid": id_,
            "rowlen": "3",
            "section": "all",
            "snippet_video": "0",
        }
        _params: dict = {
            "act": "load_videos_silent",
        }
        response = self._web.request_post(
            f"{self._vkvideo}/al_video.php",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)
            for i in response_json["payload"][1][1]:
                title = clear_html_tags(f"{i[0]} ({i[1]})")
                model.append({
                    "title": title,
                    "router": "groups_albums",
                    "data": {
                        "data": i[6],
                        "owner_id": i[8],
                    },
                    "plot": title,
                    "images": i[2],
                })
            for video in response_json["payload"][1][0]["all"]["list"]:
                if video[11] == "YouTube":
                    # Убирает сторонние плеера Youtube, да прибудет с Вами РКН. Для воспроизведения нужны примочки
                    continue
                model.append(self._item(video))
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups_albums(self, id_: str, owner_id: str, offset: (str, int) = 0) -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self._get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "album_id": id_,
            "count": "200",
            "extended": "1",
            "owner_id": owner_id,
            "fields": "verified,photo_50,is_esia_verified,is_sber_verified,is_tinkoff_verified",
            "track_code": "",
            "access_token": anonym_token["access_token"],
        }
        if offset:
            _post["offset"] = offset
            _post["start_from"] = ""
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/video.get",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            for i in response_json["items"]:
                if i.get("restriction") or i["files"].get("external") and "ok.ru" in i["files"]["external"]:
                    pass
                elif i.get("restriction") or i["files"].get("external"):
                    # Убирает сторонние плеера Youtube, да прибудет с Вами РКН. Для воспроизведения нужны примочки
                    continue
                time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                if not i.get("description"):
                    self._view.output_logs(dumps(i, indent=2, ensure_ascii=False), 1)
                model.append({
                    "title": i["title"],
                    "router": "play",
                    "data": f"{i['owner_id']}_{i['id']}",
                    "images": i["image"][-1]["url"],
                    "plot": clear_html_tags(i["description"]),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "duration": i["duration"],
                    "play": True,
                })
            model.append({
                "title": "===>",
                "router": "groups_albums",
                "data": {
                    "data": id_,
                    "owner_id": owner_id,
                    "offset": int(offset) + 200,
                },
            })
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups_blocks(self, id_: str, section_id: str = "") -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self._get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "replacement_ids": id_,
            "access_token": anonym_token["access_token"],
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.replaceBlocks",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            category: str = f"{response_json['groups'][0]['name']} / {response_json['albums'][0]['title']}"
            for i in response_json["videos"]:
                time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                model.append({
                    "title": i["title"],
                    "router": "play",
                    "data": f"{i['owner_id']}_{i['id']}",
                    "images": i["image"][-1]["url"],
                    "plot": clear_html_tags(i["description"]),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "duration": i["duration"],
                    "play": True,
                })
            model.append({
                "title": "===>",
                "router": "groups_sections",
                "data": {
                    "data": section_id,
                    "next_from": response_json["replacements"]["new_next_from"],
                },
            })
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups_sections(self, id_: str, next_from: str = "") -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self._get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "section_id": id_,
            "access_token": anonym_token["access_token"],
        }
        if next_from:
            _post["start_from"] = next_from
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.getSection",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            # Дублируются блоки
            # for i in response_json["section"]["blocks"]:
            #     if i.get("actions") and i["actions"]:
            #         if i["actions"][0].get("options"):
            #             for o in i["actions"][0]["options"]:
            #                 model.append({
            #                     "title": o["text"],
            #                     "router": "groups_blocks",
            #                     "data": {
            #                         "data": o["replacement_id"],
            #                         "section_id": response_json["section"]["id"],
            #                     },
            #                 })
            #         if i["actions"][0].get("album_id"):
            #             model.append({
            #                 "title": f"{i['title']} ({i['actions'][0]['ref_items_count']})",
            #                 "router": "groups_albums",
            #                 "data": {
            #                     "data": i["actions"][0]["album_id"],
            #                     "owner_id": i["actions"][0]["owner_id"],
            #                 },
            #             })
            if response_json.get("albums"):
                for i in response_json["albums"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["updated_time"]))
                    if i.get("image"):
                        images = i["image"][-1]["url"]
                    else:
                        images = ""
                        self._view.output_logs(dumps(i, indent=2, ensure_ascii=False), 1)
                    model.append({
                        "title": f"{i['title']} ({i['count']})",
                        "router": "groups_albums",
                        "data": {
                            "data": i["id"],
                            "owner_id": i["owner_id"],
                        },
                        "images": images,
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                    })
            if response_json.get("videos"):
                for i in response_json["videos"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                    model.append({
                        "title": i["title"],
                        "router": "play",
                        "data": f"{i['owner_id']}_{i['id']}",
                        "images": i["image"][-1]["url"],
                        "plot": clear_html_tags(i["description"]),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": i["duration"],
                        "play": True,
                    })
            if response_json.get("catalog_videos"):
                for i in response_json["catalog_videos"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["video"]["date"]))
                    model.append({
                        "title": f"[COLOR=orange]Видео => [/COLOR]{i['video']['title']}",
                        "router": "play",
                        "data": f"{i['video']['owner_id']}_{i['video']['id']}",
                        "images": i["video"]["image"][-1]["url"],
                        "plot": clear_html_tags(i["video"]["description"]),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": i["video"]["duration"],
                        "genres": [
                            f"Просмотров: {i['video']['views']}",
                            f"Лайков: {i['video']['likes']['count']}",
                            f"Репостов: {i['video']['reposts']['count']}"
                        ],
                        "play": True,
                    })
            if response_json.get("placeholders"):
                model.append({
                    "title": response_json["placeholders"][0]["title"],
                    "plot": response_json["placeholders"][0]["text"],
                })
            if response_json["section"].get("next_from"):
                model.append({
                    "title": "===>",
                    "router": "groups_sections",
                    "data": {
                        "data": response_json["section"]["id"],
                        "next_from": response_json["section"]["next_from"],
                    },
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups(self, url: str) -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self._get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "need_blocks": "1",
            "owner_id": "0",
            "url": url,
            "access_token": anonym_token["access_token"],
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.getVideo",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]

            if response_json.get("catalog"):
                category: str = f"{response_json['groups'][0]['name']}"
                for i in response_json["catalog"]["sections"]:
                    model.append({
                        "title": i["title"],
                        "router": "groups_sections",
                        "data": i["id"],
                    })
        return {
            "category": category,
            "list": tuple(model),
        }

    def search(self, search_item: str) -> dict:
        model: list = []
        category: str = f"=> {search_item} <="
        self._history.history_add_item(search_item)
        anonym_token: dict = self._get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "q": search_item,
            "category": "",
            "screen_ref": "search_video_service",
            "access_token": anonym_token["access_token"],
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.getVideoSearchWeb2",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            if response_json.get("catalog"):
                pass
            if response_json.get("profiles"):
                for i in  response_json["profiles"]:
                    genres: list = []
                    if i.get("country"):
                        genres.append(i["country"]["title"])
                    if i.get("city"):
                        genres.append(i["city"]["title"])
                    if i.get("is_closed"):
                        genres.append("Профиль закрыт")
                    else:
                        genres.append("Профиль открыт")
                    if i.get("followers_count"):
                        genres.append(f"Подписчиков: {i['followers_count']}")
                    model.append({
                        "title": f"[COLOR=red]Профили => [/COLOR]{i['first_name']} {i['last_name']}",
                        "router": "profiles",
                        "data": i["id"],
                        "images": i["photo_base"],
                        "genres": genres,
                    })
            if response_json.get("groups"):
                for i in response_json["groups"]:
                    genres: list = []
                    if i.get("activity"):
                        genres.append(i["activity"])
                    if i.get("is_closed"):
                        genres.append("Закрытая")
                    else:
                        genres.append("Открытая")
                    if i.get("members_count"):
                        genres.append(f"Подписчиков: {i['members_count']}")
                    model.append({
                        "title": f"[COLOR=blue]Группы => [/COLOR]{i['name']}",
                        "router": "groups",
                        "data": f"{self._vkvideo}/@{i['screen_name']}",
                        "images": i["photo_base"],
                        "genres": genres,
                    })
            if response_json.get("videos"):
                for i in response_json["videos"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                    model.append({
                        "title": f"[COLOR=orange]Видео => [/COLOR]{i['title']}",
                        "router": "play",
                        "data": f"{i['owner_id']}_{i['id']}",
                        "images": i["image"][-1]["url"],
                        "plot": clear_html_tags(i["description"]),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": i["duration"],
                        "genres": [
                            f"Просмотров: {i['views']}",
                            f"Лайков: {i['likes']['count']}",
                            f"Репостов: {i['reposts']['count']}"
                        ],
                        "play": True,
                    })
            if response_json.get("catalog_videos"):
                for i in response_json["catalog_videos"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["video"]["date"]))
                    genres = []
                    if i["video"].get("views"):
                        genres.append(f"Просмотров: {i['video']['views']}")
                    if i["video"].get("likes"):
                        genres.append(f"Лайков: {i['video']['likes']['count']}")
                    if i["video"].get("reposts"):
                        genres.append(f"Репостов: {i['video']['reposts']['count']}")
                    model.append({
                        "title": f"[COLOR=orange]Видео => [/COLOR]{i['video']['title']}",
                        "router": "play",
                        "data": f"{i['video']['owner_id']}_{i['video']['id']}",
                        "images": i["video"]["image"][-1]["url"],
                        "plot": clear_html_tags(i["video"]["description"]),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": i["video"]["duration"],
                        "genres": genres,
                        "play": True,
                    })
            if response_json.get("albums"):
                for i in response_json["albums"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["updated_time"]))
                    model.append({
                        "title": f"[COLOR=green]Плейлисты => [/COLOR]{i['title']} ({i['count']})",
                        "router": "groups_albums",
                        "data": {
                            "data": i["id"],
                            "owner_id": i["owner_id"],
                        },
                        "images": i["image"][-1]["url"],
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "genres": [f"Подписчиков: {i['followers_count']}"],
                    })
        return {
            "category": category,
            "list": tuple(model),
        }

    def live_blocks(self, url: str) -> dict:
        model: list = []
        category: str = ""
        _params: dict = {
            "limit": "300",
        }
        response = self._web.request_get(
            https_checking(
                url,
                start_url=self._api_live_vkvideo
            ),
            params=_params,
        )
        if type(response) is not dict:
            data = loads(response.text)["data"]
            if data.get("categories"):
                for i in data["categories"]:
                    model.append({
                        "title": f"{i['title']} ({i['count']['viewers']})",
                        "images": i["coverUrl"],
                        "router": "live_blocks",
                        "data": f"/v1/catalog/public_video_streams/category/{i['id']}/stream/",
                        "genres": [i["type"]],
                    })
            if data.get("streamBlogs"):
                for i in data["streamBlogs"]:
                    if not i["stream"]["isPublic"]:
                        # Без общего доступа
                        continue
                    genres: list = []
                    time_stamp: str = strftime("%Y-%m-%d %H:%M:%S", localtime(i["stream"]["createdAt"]))
                    if i["stream"].get("category"):
                        genres.extend([
                            i["stream"]["category"]["type"],
                            i["stream"]["category"]["title"],
                        ])
                    genres.extend([
                            i["blog"]["owner"]["displayName"],
                            f"Лайков: {i['stream']['count']['likes']}",
                            f"Смотрящих: {i['stream']['count']['viewers']}",
                            f"Просмотров: {i['stream']['count']['views']}",
                        ])
                    if i["blog"]["owner"].get("streamerActivity"):
                        genres.append(f"Уровень: {i['blog']['owner']['streamerActivity']['level']}")
                    model.append({
                        "title": f"{i['stream']['title']} ({i['stream']['count']['viewers']})",
                        "router": "live_play",
                        "data": f"{self._live_vkvideo}/{i['blog']['blogUrl']}",
                        "images": i["stream"]["previewUrl"],
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "genres": genres,
                        "play": True,
                    })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def live(self) -> dict:
        model: list = []
        category: str = ""
        _params: dict = {
            "type": "main",
        }
        response = self._web.request_get(
            https_checking(
                f"{self._api_live_vkvideo}/v1/catalog/schema",
                start_url=self._api_live_vkvideo
            ),
            params=_params,
        )
        if type(response) is not dict:
            blocks = loads(response.text)["data"]["blocks"]
            for i in blocks:
                if i.get("title") and i["title"]:
                    model.append({
                        "title": i["title"],
                        "router": "live_blocks",
                        "data": i["sourceUrl"],
                        "genres": [i["type"]],
                    })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def video_live_categories(self, url) -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self._get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "need_blocks": "1",
            "owner_id": "0",
            "url": f"{self._vkvideo}{url}",
            "access_token": anonym_token["access_token"],
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            link=https_checking(
                f"{self._api_vkvideo}/method/catalog.getVideoShowcase",
                start_url=self._api_vkvideo),
            params=_params,
            data=_post,
        )
        if type(response) is not dict:
            json_data = loads(response.text)
            category: str = (
                f"{json_data['response']['vklive_categories'][0]['title']}"
                f" ({json_data['response']['vklive_categories'][0]['viewers']})"
            )
            for i in json_data["response"]["vklive_channels"]:
                time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["stream_started_at"]))
                model.append({
                    "title": f"{i['stream_title']}({i['stream_viewers']})",
                    "router": "live_play",
                    "data": f"{self._live_vkvideo}/{i['url']}",
                    "images": i["stream_preview_url"],
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "genres": [i["vklive_owner_nick"], i["status"], f"зрителей: {i['stream_viewers']}"],
                    "play": True,
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def play_list(self, link: str, next_items: str) -> dict:
        model: list = []
        group, playlist = link.split("_")
        if group.startswith("-"):
            group = group
        else:
            group = "-" + group
        post = {"al": "1", "offset": next_items, "oid": group, "section": f"playlist_{playlist}", }
        response = self._web.request_post(
            https_checking("/al_video.php?act=load_videos_silent", self._vkvideo),
            data=post
        )
        if type(response) is not dict:
            payload = loads(response.text)["payload"][1][0][f"playlist_{playlist}"]
            for i in payload["list"]:
                if int(i[19]):
                    title = clear_html_tags(str(i[3]))
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
                    model.append({
                        "title": title,
                        "router": "play",
                        "data": str(f"{i[0]}_{i[1]}"),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": int(i[19]),
                        "images": str(i[2]),
                        "plot": f"{time_stamp}\n{title}",
                        "play": True,
                    })
            if next_items is None:
                next_items = 0
            if payload['list']:
                model.append({
                    "title": "=>=>=>",
                    "router": "play_list",
                    "data": {
                        "data": str(link),
                        "data_2": str(int(next_items) + int(payload["count"] + 1)),
                    },
                })
        return {
            "category": "",
            "list": tuple(model)
        }

    def list_items(self, url: str, next_from: str = "") -> dict:
        model: list = []
        category: str = ""
        if next_from:
            self._post["next_from"] = next_from
        response = self._web.request_post(
            link=https_checking(url, start_url=self._vkvideo),
            data=self._post,
        )
        if type(response) is not dict:
            json_data = loads(response.text)
            payload = loads(json_data["payload"][1][0])
            if payload.get("catPlaylists"):
                cat = next(iter(payload["catPlaylists"].values()))
                if cat.get("title"):
                    category = next(iter(payload["catPlaylists"].values()))["title"]
            if payload.get("videos"):
                videos = payload["videos"]
                for i in videos:
                    model.append(self._item(i, json_data))
            elif payload.get("playlists"):
                play_lists = payload["playlists"]
                for i in play_lists:
                    if i[1] == 1:
                        title = clear_html_tags(str(i[0]))
                        router = "play"
                        play = True
                        data_link = i[7]
                    elif payload["context"]["ref"] == "video_live_categories":
                        watching = json_data["langKeys"]["local"]["video_live_N_watching"][1]
                        title = clear_html_tags(f"{i[0]} ({watching % i[1]})")
                        router = "video_live_categories"
                        play = False
                        data_link = i[3]
                    else:
                        title = clear_html_tags(f"{i[0]} ({i[1]})")
                        router = "play_list"
                        play = False
                        data_link = f"{i[8]}_{i[6]}"
                    model.append({
                        "title": title,
                        "router": router,
                        "data": data_link,
                        "plot": title,
                        "images": i[2],
                        "play": play,
                    })
            else:
                raise
            next_page = payload["nextFrom"]
            if next_page:
                model.append({
                    "title": "=>=>=>",
                    "router": "list_items",
                    "data": {
                        "data": url,
                        "next_from": next_page
                    }
                })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, url: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_post(link=https_checking(url, start_url=self._vkvideo), data=self._post)
        if type(response) is not dict:
            payload = loads(loads(response.text)["payload"][1][0])
            if not payload["tabList"]:
                return self.list_items(url)
            cat = next(iter(payload["catPlaylists"].values()))
            if cat.get("title"):
                category = next(iter(payload["catPlaylists"].values()))["title"]
            tab_list: list = payload["tabList"]
            for i in tab_list:
                if "interactive" in i["url"]:
                    continue
                model.append({
                    "title": i["name"],
                    "data": i["url"],
                    "router": "list_items",
                })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    @staticmethod
    def auth_menu() -> dict:
        return {
            "category": "Меню авторизации",
            "list": [
                {
                    "title": "По телефону",
                    "router": "auth_phone",
                    "plot": "Вход в «VK Видео»",
                },
                {
                    "title": "Быстрый вход по QR-коду",
                    "router": "auth_qr",
                    "plot": "Отсканируйте QR-код сканером в приложении ВКонтакте или камерой устройства",
                },
            ],
        }

    def auth_phone(self):
        anonym_token: dict = self._get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            # "phone": "",
            # "supported_ways": "push,email,passkey",
            # "supported_ways_settings": "callreset_preview_enabled",
            # "sid": "",
            # "super_app_token": "",
            # "device_id": ,
            # "external_device_id": "",
            # "service_group": "",
            # "lang": "ru",
            # "auth_token": "",
            # "allow_callreset": "1",
            # "access_token": "",
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            link=https_checking("/method/auth.validatePhone", self._api_vk),
            params=_params,
            data=_post,
        )

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(link=https_checking(self._vkvideo))
        if type(response) is not dict:
            # if True:
            #     model.append({
            #         "title": "[COLOR=blue]Авторизация[/COLOR]",
            #         "router": "auth_menu",
            #     })
            category: str = "Меню"
            soup = BeautifulSoup(response.text, "html.parser")
            find_menu_list: list = soup.find_all(class_="MenuList--redesigned")[0].find_all("a")
            for i in find_menu_list:
                # Стримы
                if "live." in i["href"]:
                    router = "live"
                # Интерактив
                elif "interactives" in i["href"]:
                    continue
                # Подписки
                elif "subscriptions" in i["href"]:
                    if False:
                        router = "subscriptions"
                    else:
                        continue
                else:
                    router = "catalog"
                if i.get("data-title"):
                    model.append({
                        "title": i["data-title"],
                        "data": {
                            "data": i["href"],
                        },
                        "router": router,
                    })
            model.append({
                "title": "Меню поиска",
                "router": "search_menu",
            })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }
