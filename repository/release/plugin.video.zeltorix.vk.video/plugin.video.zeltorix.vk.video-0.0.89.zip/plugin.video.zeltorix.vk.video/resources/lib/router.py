# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

from .model import Model


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    _view = View()
    _model = Model()
    _history = History()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict["router"] == "search_history":
            _view.output(_model.search(params_dict["data"]))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict["data"]):
                _view.output(_history.search_menu())

        # Блок воспроизведения
        elif params_dict["router"] == "play":
            _view.play(_model.play(params_dict["data"]))
        elif params_dict["router"] == "live_play":
            _view.play(_model.live_play(params_dict["data"]))

        # Блок навигации
        elif params_dict["router"] == "clip":
            if params_dict.get("data"):
                _view.output(_model.clip(params_dict["data"]))
            _view.output(_model.clip())
        elif params_dict["router"] == "catalog_get_video_showcase":
            _view.output(_model.catalog_get_video_showcase(params_dict["data"]))
        elif params_dict["router"] == "catalog_get_section":
            if params_dict.get("next_from"):
                _view.output(_model.catalog_get_section(params_dict["data"], params_dict["next_from"]))
            _view.output(_model.catalog_get_section(params_dict["data"]))
        elif params_dict["router"] == "catalog":
            _view.output(_model.catalog(params_dict["data"]))
        elif params_dict["router"] == "list_items":
            if params_dict.get("next_from"):
                _view.output(_model.list_items(params_dict["data"], params_dict["next_from"]))
            _view.output(_model.list_items(params_dict["data"]))
        elif params_dict["router"] == "live":
            _view.output(_model.live())
        elif params_dict["router"] == "live_blocks":
            _view.output(_model.live_blocks(params_dict["data"]))
        elif params_dict["router"] == "play_list":
            if params_dict.get("data_2"):
                data = params_dict["data"]
                data_2 = params_dict["data_2"]
            else:
                data = params_dict["data"]
                data_2 = "0"
            _view.output(_model.play_list(data, data_2))
        elif params_dict["router"] == "video_live_categories":
            _view.output(_model.video_live_categories(params_dict["data"]))
        elif params_dict["router"] == "groups":
            _view.output(_model.groups(params_dict["data"]))
        elif params_dict["router"] == "groups_sections":
            if params_dict.get("next_from"):
                _view.output(_model.groups_sections(params_dict["data"], next_from=params_dict["next_from"]))
            _view.output(_model.groups_sections(params_dict["data"]))
        elif params_dict["router"] == "groups_blocks":
            if params_dict.get("section_id"):
                _view.output(_model.groups_blocks(params_dict["data"], params_dict["section_id"]))
            _view.output(_model.groups_blocks(params_dict["data"]))
        elif params_dict["router"] == "groups_albums":
            if params_dict.get("offset"):
                _view.output(_model.groups_albums(params_dict["data"], params_dict["owner_id"], params_dict["offset"]))
            _view.output(_model.groups_albums(params_dict["data"], params_dict["owner_id"]))
        elif params_dict["router"] == "profiles":
            _view.output(_model.profiles(params_dict["data"]))

        # Блок исключения
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        _view.output(_model.main())
