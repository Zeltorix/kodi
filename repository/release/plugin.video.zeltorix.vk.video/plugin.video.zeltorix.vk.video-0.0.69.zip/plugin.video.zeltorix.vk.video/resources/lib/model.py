# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import dumps, loads, dump, load
from pathlib import Path
from re import findall
from time import strftime, localtime
import datetime
from itertools import islice

from bs4 import BeautifulSoup

# Импорт модуля плагина из текущего каталога для запроса данных
from get_video_link import VideoLink
from web_api_request import WebApiRequest, headers, https_checking
from text_job import clear_html_tags
from view import View
from history import History


class Model:
    __slots__ = [
        "_post",
        "_web",
        "_vkvideo",
        "_api_vkvideo",
        "_api_live_vkvideo",
    ]

    _video_link = VideoLink()
    _view = View()
    _history = History()

    def __init__(self):
        self._post = {
            "al": "1",
            "silent_loading": "1"
        }
        self._vkvideo = "https://vkvideo.ru"
        self._api_vkvideo = "https://api.vkvideo.ru"
        self._api_live_vkvideo = "https://api.live.vkvideo.ru"
        headers["x-requested-with"] = "XMLHttpRequest"
        self._web = WebApiRequest(heads=headers)

    def get_anonym_token(self) -> (True, None):
        response_html = self._web.request_get(self._vkvideo)
        if type(response_html) is not dict:
            js_link: str = findall(r"/dist/web/chunks/core_spa\.\w+?\.js", response_html.text)[0]
            response_js = self._web.request_get(f"{self._vkvideo}{js_link}")
            if type(response_js) is not dict:
                js_text: str = response_js.text
                client_secret: str = findall(r'c="\w+?"', js_text)[3].split('"')[1]
                client_id: str = findall(r"_=\d*,", js_text)[1].split("_=")[1]
                scopes: str = findall(r'scopes:".+?"', js_text)[0].split('"')[1]
                app_id: str = findall(r"u=\d+", js_text)[0].split("u=")[1]
                v: str = findall(r'r="\d+\.\d+"', js_text)[0].split('"')[1]
                params: dict = {
                    "act": "get_anonym_token"
                }
                _post: dict = {
                    "client_secret": client_secret,
                    "client_id": client_id,
                    "scopes": scopes,
                    "version": "1",
                    "app_id": app_id,
                }
                response_anonym_token = self._web.request_post("https://login.vk.com/", params=params, data=_post)
                if type(response_anonym_token) is not dict:
                    data_dict: dict = loads(response_anonym_token.text)["data"]
                    data_dict["v"] = v
                    data_dict: dict = {**data_dict, **_post}
                    # if not Path(self._view.plugin_folder).exists():
                    #     Path(self._view.plugin_folder).mkdir(parents=True)
                    # with open(self.anonym_token_file, "w") as fail:
                    #     fail.write(dumps(data_dict, indent=2))
                    # return True
                    return data_dict

    def play(self, url: str) -> str:
        return self._video_link.vk_link(url)

    def search(self, search_item: str) -> dict:
        model: list = []
        category: str = f"=> {search_item} <="
        self._history.history_add_item(search_item)
        anonym_token: dict = self.get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "q": search_item,
            "category": "",
            "screen_ref": "search_video_service",
            "access_token": anonym_token["access_token"],
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.getVideoSearchWeb2",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            if response_json.get("catalog"):
                pass
            if response_json.get("profiles"):
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                model.append({
                    "title": "Авторы",
                })
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                for i in  response_json["profiles"]:
                    plot: str = ""
                    if i.get("city"):
                        plot: str = i["city"]["title"]
                    if i.get("country"):
                        if plot:
                            plot: str = f"{plot}/{i['country']['title']}"
                        else:
                            plot: str = i["country"]["title"]
                    model.append({
                        "title": f"{i['first_name']} {i['last_name']}",
                        "router": "profiles",
                        "data": i["id"],
                        "images": i["photo_base"],
                        "plot": plot,
                    })
            if response_json.get("groups"):
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                model.append({
                    "title": "Группы",
                })
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                for i in response_json["groups"]:
                    model.append({
                        "title": i["name"],
                        "router": "groups",
                        "data": f"{self._vkvideo}/@{i['screen_name']}",
                        "images": i["photo_base"],
                        "plot": i["activity"],
                    })
            if response_json.get("videos"):
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                model.append({
                    "title": "Видео",
                })
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                for i in response_json["videos"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                    model.append({
                        "title": i["title"],
                        "router": "play",
                        "data": f"{i['owner_id']}_{i['id']}",
                        "images": i["image"][-1]["url"],
                        "plot": clear_html_tags(i["description"]),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": i["duration"],
                        "play": True,
                    })
            if response_json.get("albums"):
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                model.append({
                    "title": "Плейлисты",
                })
                model.append({
                    "title": "[COLOR=red]========[/COLOR]",
                })
                for i in response_json["albums"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["updated_time"]))
                    model.append({
                        "title": f"{i['title']} ({i['count']})",
                        "router": "",
                        "data": f"{i['owner_id']}_{i['id']}",
                        "images": i["image"][-1]["url"],
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                    })
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups_albums(self, id_: str, owner_id: str, offset: (str, int) = 0) -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self.get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "album_id": id_,
            "count": "200",
            "extended": "1",
            "owner_id": owner_id,
            "fields": "verified,photo_50,is_esia_verified,is_sber_verified,is_tinkoff_verified",
            "track_code": "",
            "access_token": anonym_token["access_token"],
        }
        if offset:
            _post["offset"] = offset
            _post["start_from"] = ""
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/video.get",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            for i in response_json["items"]:
                time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                model.append({
                    "title": i["title"],
                    "router": "play",
                    "data": f"{i['owner_id']}_{i['id']}",
                    "images": i["image"][-1]["url"],
                    "plot": clear_html_tags(i["description"]),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "duration": i["duration"],
                    "play": True,
                })
            model.append({
                "title": "===>",
                "router": "groups_albums",
                "data": {
                    "data": id_,
                    "owner_id": owner_id,
                    "offset": int(offset) + 200,
                },
            })
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups_blocks(self, id_: str, section_id: str = "") -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self.get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "replacement_ids": id_,
            "access_token": anonym_token["access_token"],
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.replaceBlocks",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            category: str = f"{response_json['groups'][0]['name']} / {response_json['albums'][0]['title']}"
            # category: str = f"{response_json['groups'][0]['name']}"

            for i in response_json["videos"]:
                time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                model.append({
                    "title": i["title"],
                    "router": "play",
                    "data": f"{i['owner_id']}_{i['id']}",
                    "images": i["image"][-1]["url"],
                    "plot": clear_html_tags(i["description"]),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "duration": i["duration"],
                    "play": True,
                })
            model.append({
                "title": "===>",
                "router": "groups_sections",
                "data": {
                    "data": section_id,
                    "next_from": response_json["replacements"]["new_next_from"],
                },
            })
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups_sections(self, id_: str, next_from: str = "") -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self.get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "section_id": id_,
            "access_token": anonym_token["access_token"],
        }
        if next_from:
            _post["start_from"] = next_from
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.getSection",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            # category: str = f"{response_json['groups'][0]['name']} / {response_json['section']['title']}"
            for i in response_json["section"]["blocks"]:
                if i.get("actions") and i["actions"]:
                    if i["actions"][0].get("options"):
                        for o in i["actions"][0]["options"]:
                            model.append({
                                "title": o["text"],
                                "router": "groups_blocks",
                                "data": {
                                    "data": o["replacement_id"],
                                    "section_id": response_json["section"]["id"],
                                },
                            })
                    if i["actions"][0].get("album_id"):
                        model.append({
                            "title": f"{i['title']} ({i['actions'][0]['ref_items_count']})",
                            "router": "groups_albums",
                            "data": {
                                "data": i["actions"][0]["album_id"],
                                "owner_id": i["actions"][0]["owner_id"],
                            },
                        })
            if response_json.get("albums"):
                for i in response_json["albums"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["updated_time"]))
                    model.append({
                        "title": f"{i['title']} ({i['count']})",
                        "router": "groups_albums",
                        "data": {
                            "data": i["id"],
                            "owner_id": i["owner_id"],
                        },
                        "images": i["image"][-1]["url"],
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                    })
            if response_json.get("videos"):
                for i in response_json["videos"]:
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["date"]))
                    model.append({
                        "title": i["title"],
                        "router": "play",
                        "data": f"{i['owner_id']}_{i['id']}",
                        "images": i["image"][-1]["url"],
                        "plot": clear_html_tags(i["description"]),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": i["duration"],
                        "play": True,
                    })
            if response_json.get("placeholders"):
                model.append({
                    "title": response_json["placeholders"][0]["title"],
                    "plot": response_json["placeholders"][0]["text"],
                })
            if response_json["section"].get("next_from"):
                model.append({
                    "title": "===>",
                    "router": "groups_sections",
                    "data": {
                        "data": response_json["section"]["id"],
                        "next_from": response_json["section"]["next_from"],
                    },
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def groups(self, url) -> dict:
        model: list = []
        category: str = ""
        anonym_token: dict = self.get_anonym_token()
        if not anonym_token:
            raise
        _post: dict = {
            "need_blocks": "1",
            "owner_id": "0",
            "url": url,
            "access_token": anonym_token["access_token"],
        }
        _params: dict = {
            "v": anonym_token["v"],
            "client_id": anonym_token["client_id"],
        }
        response = self._web.request_post(
            f"{self._api_vkvideo}/method/catalog.getVideo",
            params=_params,
            data=_post
        )
        if type(response) is not dict:
            response_json: dict = loads(response.text)["response"]
            if response_json.get("catalog"):
                category: str = f"{response_json['groups'][0]['name']}"
                for i in response_json["catalog"]["sections"]:
                    model.append({
                        "title": i["title"],
                        "router": "groups_sections",
                        "data": i["id"],
                    })
        return {
            "category": category,
            "list": tuple(model),
        }

    def live_play(self, url: str) -> str:
        api_url = f"https://api.live.vkvideo.ru/v1/blog/{url.split('/')[-1]}/public_video_stream?"
        response = self._web.request_get(link=https_checking(api_url, start_url=self._vkvideo))
        if type(response) is not dict:
            data = loads(response.text)["data"][0]
            for i in data["playerUrls"]:
                if i["type"] in ["live_ondemand_hls", "live_hls", "live_playback_hls"] and i["url"]:
                    return i["url"]
            raise

    def video_live_categories(self, url) -> dict:
        model: list = []
        category: str = ""
        _post: dict = {
            "need_blocks": "1",
            "owner_id": "0",
            "url": f"{self._vkvideo}{url}"
        }
        response = self._web.request_post(
            link=https_checking(
                f"{self._api_vkvideo}/method/catalog.getVideoShowcase",
                start_url=self._api_vkvideo),
            data=_post,
        )
        if type(response) is not dict:
            json_data = loads(response.text)

    def live(self) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(
            https_checking(f"{self._api_live_vkvideo}/v1/catalog/schema?type=main", start_url=self._api_live_vkvideo))
        if type(response) is not dict:
            blocks = loads(response.text)["data"]["blocks"]
            for i in blocks:
                if i.get("title") and i["title"]:
                    model.append({
                        "title": i["title"],
                        "router": "",
                        "data": i["sourceUrl"],
                    })

        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def play_list(self, link: str, next_items: str) -> dict:
        model: list = []
        group, playlist = link.split("_")
        if group.startswith("-"):
            group = group
        else:
            group = "-" + group
        post = {"al": "1", "offset": next_items, "oid": group, "section": f"playlist_{playlist}", }
        response = self._web.request_post(
            https_checking("/al_video.php?act=load_videos_silent", self._vkvideo),
            data=post
        )
        if type(response) is not dict:
            payload = loads(response.text)["payload"][1][0][f"playlist_{playlist}"]
            for i in payload["list"]:
                if int(i[19]):
                    title = clear_html_tags(str(i[3]))
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
                    model.append({
                        "title": title,
                        "router": "play",
                        "data": str(f"{i[0]}_{i[1]}"),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": int(i[19]),
                        "images": str(i[2]),
                        "plot": f"{time_stamp}\n{title}",
                        "play": True,
                    })
            if next_items is None:
                next_items = 0
            if payload['list']:
                model.append({
                    "title": "=>=>=>",
                    "router": "play_list",
                    "data": {
                        "data": str(link),
                        "data_2": str(int(next_items) + int(payload["count"] + 1)),
                    },
                })
        return {
            "category": "",
            "list": tuple(model)
        }

    def list(self, url: str, next_from: str = "") -> dict:
        model: list = []
        category: str = ""
        if next_from:
            self._post["next_from"] = next_from
        response = self._web.request_post(
            link=https_checking(url, start_url=self._vkvideo),
            data=self._post,
        )
        if type(response) is not dict:
            json_data = loads(response.text)
            payload = loads(json_data["payload"][1][0])
            if payload.get("catPlaylists"):
                cat = next(iter(payload["catPlaylists"].values()))
                if cat.get("title"):
                    category = next(iter(payload["catPlaylists"].values()))["title"]
            if payload.get("videos"):
                videos = payload["videos"]
                for i in videos:
                    # Старый формат
                    if type(i) is list:
                        title = clear_html_tags(i[3])
                        router = "play"
                        time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
                        data = f"{i[0]}_{i[1]}"
                        duration = int(i[19])
                        images = i[2]
                    # Новый формат?
                    elif type(i) is dict:
                        title = clear_html_tags(i["3"])
                        router = "live_play"
                        time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["9"]))
                        # Лучше переписать!
                        data = i["20"]
                        duration = 0
                        images = i["2"]
                    else:
                        raise
                    model.append({
                        "title": title,
                        "router": router,
                        "data": data,
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": duration,
                        "images": images,
                        "plot": f"{time_stamp}\n{title}",
                        "play": True,
                    })
            elif payload.get("playlists"):
                play_lists = payload["playlists"]
                for i in play_lists:
                    if i[1] == 1:
                        title = clear_html_tags(str(i[0]))
                        router = "play"
                        play = True
                        data_link = i[7]
                    elif payload["context"]["ref"] == "video_live_categories":
                        watching = json_data["langKeys"]["local"]["video_live_N_watching"][1]
                        title = clear_html_tags(f"{i[0]} ({watching % i[1]})")
                        router = "video_live_categories"
                        play = False
                        data_link = i[3]
                    else:
                        title = clear_html_tags(f"{i[0]} ({i[1]} видео)")
                        router = "play_list"
                        play = False
                        data_link = f"{i[8]}_{i[6]}"
                    model.append({
                        "title": title,
                        "router": router,
                        "data": data_link,
                        "plot": title,
                        "images": i[2],
                        "play": play,
                    })
            else:
                raise
            next_page = payload["nextFrom"]
            if next_page:
                model.append({
                    "title": "=>=>=>",
                    "router": "list",
                    "data": {
                        "data": url,
                        "next_from": next_page
                    }
                })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, url: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_post(link=https_checking(url, start_url=self._vkvideo), data=self._post)
        if type(response) is not dict:
            payload = loads(loads(response.text)["payload"][1][0])
            if not payload["tabList"]:
                return self.list(url)
            cat = next(iter(payload["catPlaylists"].values()))
            if cat.get("title"):
                category = next(iter(payload["catPlaylists"].values()))["title"]
            tab_list: list = payload["tabList"]
            for i in tab_list:
                if "interactive" in i["url"]:
                    continue
                model.append({
                    "title": i["name"],
                    "data": i["url"],
                    "router": "list",
                })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(link=https_checking(self._vkvideo))
        if type(response) is not dict:
            # if True:
            #     model.append({
            #         "title": "[COLOR=blue]Авторизация[/COLOR]",
            #         "router": "auth",
            #     })
            category: str = "Меню"
            soup = BeautifulSoup(response.text, "html.parser")
            find_menu_list: list = soup.find_all(class_="MenuList--redesigned")[0].find_all("a")
            for i in find_menu_list:
                # Стримы
                if "live." in i["href"]:
                    router = "live"
                    continue
                # Интерактив
                elif "interactives" in i["href"]:
                    continue
                # Подписки
                elif "subscriptions" in i["href"]:
                    if False:
                        router = "subscriptions"
                    else:
                        continue
                else:
                    router = "catalog"
                if i.get("data-title"):
                    model.append({
                        "title": i["data-title"],
                        "data": {
                            "data": i["href"],
                        },
                        "router": router,
                    })
            model.append({
                "title": "Меню поиска",
                "router": "search_menu",
            })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }
