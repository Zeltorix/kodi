# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

# Импорт модуля плагина для создания модели
from .model import ModelVK
from .view import View


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    # import logging
    # logger = logging.getLogger(__name__)
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    view = View()
    model = ModelVK()
    if params_dict:
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                if params_dict.get('data'):
                    search = params_dict['data']
                    next_items = params_dict['data_2']
                else:
                    search = params_dict['keyword']
                    next_items = None
                view.main(model.search(search, next_items))
            else:
                # Вывод поиска, импортировано из модуля view
                if params_dict.get('data'):
                    search = params_dict['data']
                    next_items = params_dict['data_2']
                else:
                    search = view.search()
                    next_items = None
                view.main(model.search(search, next_items))
        elif params_dict['router'] == 'play':
            view.play(model.url(params_dict['data']))
        elif params_dict['router'] == "menu":
            view.main(model.menu(params_dict['data']))
        elif params_dict['router'] == "video_items":
            if params_dict.get('data_2'):
                view.main(model.video_items(params_dict['data'], params_dict['data_2']))
            else:
                view.main(model.video_items(params_dict['data']))
        elif params_dict['router'] == "playlist":
            view.main(model.playlist(params_dict['data']))
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        view.main(model.main())
