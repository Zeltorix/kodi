# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
# Стандартные
from random import randint

# Не стандартный модуль импортируется в addon.xml как script.module.requests
from requests import Session

# Не стандартный модуль импортируется в addon.xml как script.module.zeltorix.utilitys
from browsers import browsers


class ParserVK:
    """
    Клас для получения данных
    """
    __slots__ = []
    _api: str = "https://vk.com"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
        "Dnt": "1",
        "Origin": _api,
        "Referer": "https://yandex.com",
        "User-Agent": browsers,
        "x-requested-with": "XMLHttpRequest",
    }
    _session = Session()

    def api(self, path: str, post: dict, retry: int = 10) -> (dict, str):

        link = self._api + path
        response = self._session.post(link, headers=self.headers, timeout=randint(5, 10), data=post)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.api(path=path, post=post, retry=retry - 1)
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            if retry:
                from time import sleep
                # TODO Добавить оповещение в интерфейс
                sleep(randint(2, 10))
                return self.api(path=path, post=post, retry=retry - 1)
            else:
                return "Что то не то с API..."
