# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
# Модули KODI
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon


class View:
    __slots__ = [
        # 'logger'
    ]
    # Получите URL-адрес плагина в формате plugin:// значение.
    _url = sys.argv[0]
    # Получить заготовка плагина в виде целого числа.
    _handle = int(sys.argv[1])
    _kodi_version_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])

    # def __init__(self):
        # import logging
        # self.logger = logging.getLogger(__name__)

    def get_setting(self, id_: str) -> str:
        id_a: str = self._url.split("//")[1].split("/")[0]
        return xbmcaddon.Addon(id_a).getSetting(id_)

    @staticmethod
    def check_modules() -> None:
        def target_module(check_module: str) -> None:
            try:
                xbmcaddon.Addon(check_module)
            except (ModuleNotFoundError, RuntimeError):
                xbmcgui.Dialog().notification(
                    heading=f'Установка библиотеки {check_module}',
                    message=f'{check_module}',
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin(f'RunPlugin("plugin://{check_module}")')
        target_module('script.module.requests')
        target_module('inputstream.adaptive')
        target_module("script.module.beautifulsoup4")
        target_module('script.module.zeltorix.utilitys')


    @staticmethod
    def error(heading: str, message: str, type_message: str = "info") -> None:
        if type_message == "warning":
            notification = xbmcgui.NOTIFICATION_WARNING
        elif type_message == "error":
            notification = xbmcgui.NOTIFICATION_ERROR
        elif type_message == "info":
            notification = xbmcgui.NOTIFICATION_INFO
        else:
            notification = xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification(
            heading=heading,
            message=message,
            icon=notification,
            time=5000,
            sound=True
        )

    def _convert_to_url(self, **kwargs: str) -> str:
        # Преобразование кляча и значения в ссылку данных для дополнения в виде URL
        return f'{self._url}?{urlencode(kwargs)}'

    def play(self, path: str, adaptive: bool = True) -> None:
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)

        if self.get_setting("inputstream_adaptive") == "true" and adaptive:
            # Использовать inputstream.adaptive для входящего медиапотока
            play_item.setProperty('inputstream', "inputstream.adaptive")
            # Тип манифеста медиапотока
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            # Подбор разрешения под экран
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

            play_item.setProperty('inputstream.adaptive.live_delay', '120')

            # Тип запрашиваемого контента
            play_item.setMimeType('application/x-mpegURL')

            # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
            play_item.setContentLookup(True)
            # Обновление манифеста, возможно это убирает баг с зависанием
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            # Разрешить начинать воспроизведение LIVE-потока с начала буфера, а не с его конца.
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
            # listitem.setProperty('inputstream.adaptive.stream_headers',
            #                      f'User-Agent={user_agent}')
            # listitem.setProperty('inputstream.adaptive.stream_headers',
            #                      'headername=value&User-Agent=the_user_agent&Cookie=the_cookies')

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    @staticmethod
    def search() -> str:
        return xbmcgui.Dialog().input(
            'Введите название проекта',
            type=xbmcgui.INPUT_ALPHANUM)

    def main(self, data: dict) -> None:
        xbmcplugin.setContent(self._handle, 'videos')
        xbmcplugin.setPluginCategory(self._handle, data["category"])
        for item in data["list"]:
            list_item = xbmcgui.ListItem(label=item['Title'])
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item['Title'])
                if item.get('Plot'):
                    vinfo.setPlot(item['Plot'])
                if item.get('Genres'):
                    vinfo.setGenres(item['Genres'])
                if item.get('Premiered'):
                    vinfo.setPremiered(item['Premiered'])
                if item.get("Duration"):
                    vinfo.setDuration(item['Duration'])

                # if item.get('DateAdded'):
                #     vinfo.setDateAdded(item['DateAdded'])
                # if item.get('posters'):
                #     vinfo.addAvailableArtwork(url=item['posters'], arttype='thumb', isgz=True)
                #     vinfo.addAvailableArtwork(url=item['posters'], arttype='icon', isgz=True)
                #     vinfo.addAvailableArtwork(url=item['posters'], arttype='fanart', isgz=True)

                vinfo.setMediaType("video")
            else:
                list_item.setInfo('video', {'title': item['Title']})
                if item.get('plot'):
                    list_item.setInfo('video', {'plot': item['Plot']})
                if item.get('genres'):
                    list_item.setInfo('video', {'genre': item['Genres']})
                if item.get('premiered'):
                    list_item.setInfo('video', {'premiered': item['Premiered']})
                list_item.setInfo('video', {'mediatype': 'videos'})
            if item.get('posters'):
                list_item.setArt({'thumb': item['posters']})
                list_item.setArt({'icon': item['posters']})
                list_item.setArt({'fanart': item['posters']})

            # Внутренний переход есть
            if item.get("data"):
                data = item["data"]
            else:
                data = ""
            if item.get("data_2"):
                data_2 = item["data_2"]
            else:
                data_2 = ""
            if item['router'] == "play":
                list_item.setProperty('IsPlayable', 'true')
                # Переход внутрь не требуется, можно отключить
                is_folder = False
            else:
                is_folder = True
            url = self._convert_to_url(router=item["router"], data=data, data_2=data_2)
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self._handle)
