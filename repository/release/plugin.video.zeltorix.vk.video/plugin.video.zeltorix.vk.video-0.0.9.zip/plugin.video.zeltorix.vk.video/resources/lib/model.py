# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserVK
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.release.vk_video.resources.lib.parser import ParserVK


class ModelVK:
    __slots__ = []
    _parser = ParserVK()

    @staticmethod
    def _cleanhtml(raw_html):
        import re
        return " ".join(re.sub(re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});'), '', raw_html).split())

    @staticmethod
    def time_to_second(time_string: str):
        import datetime
        if len(time_string.split(":")) == 3:
            time_stamp = "%H:%M:%S"
        else:
            time_stamp = "%M:%S"
        date_time = datetime.datetime.strptime(time_string, time_stamp)
        a_timedelta = date_time - datetime.datetime(1900, 1, 1)
        seconds = a_timedelta.total_seconds()
        return seconds

    def search(self, item: str, next_items: (str, None) = None) -> dict:
        import xbmc
        xbmc.log(msg=f'search: {item} - {next_items}', level=xbmc.LOGINFO)
        import time
        if next_items:
            post = {"al": "1", "from": "0", "offset": next_items, "q": item}
        else:
            post = {"al": "1", "from": "0", "offset": "0", "q": item}
        data_text = self._parser.api(path="/al_video.php?act=search_video", post=post)
        js = data_text.split('<!--')[1]
        payload = json.loads(js)["payload"][1][2]
        model_list: list = []
        for i in payload['list']:
            import xbmc
            xbmc.log(msg=f'search: {i}', level=xbmc.LOGINFO)
            model_dict: dict = {
                "Title": str(i[3]),
                "router": "play",
                "data": "https://vk.com" + str(i[20]),
                "Plot": str(),
                "Genres": [],
                "Premiered": time.strftime("%Y-%M-%d", time.localtime(i[9])),
                "Duration": int(i[19]),
                "posters": str(i[2]),
            }
            model_list.append(model_dict)
        if not next_items:
            next_items = 0
        if payload['list']:
            model_dict: dict = {
                "Title": "Следующая страница",
                "router": "search",
                "data": str(item),
                "data_2": str(int(next_items) + int(payload["count"]) + 1),
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            }
            model_list.append(model_dict)
        return {
            "category": "Найдено",
            "list": tuple(model_list)
        }

    @staticmethod
    def url(link: str) -> str:
        import yt_dlp
        ydl = yt_dlp.YoutubeDL({})
        for i in ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"]:
            if i.get("manifest_url"):
                return i["manifest_url"]

    def video_items(self, link: str, next_items: (str, None) = None) -> dict:
        import xbmc
        xbmc.log(msg=f'video_items: {link} - {next_items}', level=xbmc.LOGINFO)
        if next_items:
            post = {"al": "1", "next_from": next_items, "silent_loading": "1"}
        else:
            post = {"al": "1", "silent_loading": "1"}
        data_text = self._parser.api(path=link, post=post)
        js = data_text.split('<!--')[1]
        payload = json.loads(json.loads(js)["payload"][1][0])
        model_list: list = []
        import time
        if payload['videos']:
            for i in payload['videos']:
                model_dict: dict = {
                    "Title": str(i[3]),
                    "router": "play",
                    "data": "https://vk.com" + str(i[20]),
                    "Plot": str(),
                    "Genres": [],
                    "Premiered": time.strftime("%Y-%M-%d", time.localtime(i[9])),
                    "Duration": int(i[19]),
                    "posters": str(i[2]),
                }
                model_list.append(model_dict)
        elif payload['playlists']:
            for i in payload['playlists']:
                model_dict: dict = {
                    "Title": str(i[0]),
                    "router": "play",
                    "data": "https://vk.com/video" + str(i[7]),
                    "time": str(i[4]), # "1 час 6 минут"
                    "Plot": str(),
                    "Genres": [],
                    "posters": str(i[2]),
                }
                model_list.append(model_dict)
        if payload["nextFrom"]:
            model_dict: dict = {
                "Title": "Следующая страница",
                "router": "video_items",
                "data": str(link),
                "data_2": str(payload["nextFrom"]),
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            }
            model_list.append(model_dict)
        return {
            "category": "Список видео",
            "list": tuple(model_list)
        }


    def menu(self, link: str) -> dict:
        import xbmc
        xbmc.log(msg=f'menu: {link}', level=xbmc.LOGINFO)
        video = {
            "/video": "Все",
            "/video/interview": "Интервью и шоу",
            "/video/tourisme": "Тревел",
            "/video/technology": "Технологии",
            "/video/music": "Музыка",
            "/video/culture": "Культура",
            "/video/cooking": "Еда",
            "/video/fitness": "Здоровье",
            "/video/education": "Образование",
            "/video/automotive": "Авто",
            "/video/lifestyle": "Мода и красота",
        }
        lives = {
            "/video/lives": "Популярное",
            "/video/lives/games": "Видеоигры",
            "/video/lives/sport": "Спорт",
            "/video/lives/news": "Новости",
            "/video/lives/music": "Музыка",
        }
        sport = {
            "/video/sport": "Все",
            "/video/sport/football": "Футбол",
            "/video/sport/basketball": "Баскетбол",
            "/video/sport/hockey": "Хоккей",
            "/video/sport/mma": "ММА",
            "/video/sport/tennis": "Теннис",
            "/video/sport/volleyball": "Волейбол",
            "/video/sport/other_sport": "Другое",
        }
        cybersport = {
            "/video/cybersport": "Киберспорт и игры",
        }
        movies = {
            "/video/movies": "Все",
            "/video/movies/comedy": "Комедия",
            "/video/movies/adventure": "Приключения",
            "/video/movies/fantastic": "Фантастика",
            "/video/movies/action": "Боевик",
            "/video/movies/family": "Семейный",
            "/video/movies/melodrama": "Мелодрама",
            "/video/movies/drama": "Драма",
            "/video/movies/biography": "Биография",
            "/video/movies/anime": "Аниме",
            "/video/movies/detective": "Детектив",
            "/video/movies/thriller": "Триллер",
            "/video/movies/horror": "Ужасы",
            "/video/movies/soviet": "Советское",
            "/video/movies/documentary": "Документальный",
            "/video/movies/short": "Короткий метр",
        }
        serials = {
            "/video/serials": "Сериалы",
        }
        tvshow = {
            "/video/tvshow": "Все",
            "/video/tvshow/comedy": "Комедийные",
            "/video/tvshow/family": "Семейные",
            "/video/tvshow/reality": "Реалити - шоу",
        }
        for_kids = {
            "/video/for_kids": "Фильмы",
            "/video/for_kids/cartoons": "Мультфильмы",
        }
        menu = {}
        if link in video.keys():
            menu = video
        elif link in lives.keys():
            menu = lives
        elif link in sport.keys():
            menu = sport
        elif link in cybersport.keys():
            menu = cybersport
        elif link in movies.keys():
            menu = movies
        elif link in serials.keys():
            menu = serials
        elif link in tvshow.keys():
            menu = tvshow
        elif link in for_kids.keys():
            menu = for_kids
        model_list: list = []
        for key, value in menu.items():
            model_dict: dict = {
                "Title": value,
                "router": "video_items",
                "data": key,
                "data_2": str(),
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            }
            model_list.append(model_dict)
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }

    def main(self) -> dict:
        model_list: list = [
            {
                "Title": "Для вас",
                "router": "menu",
                "data": "/video",
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
            # {
            #     "Title": "Трансляции",
            #     "router": "menu",
            #     "data": "/video/lives",
            #     "Plot": str(),
            #     "Genres": [],
            #     "posters": str(),
            # },
            {
                "Title": "Спорт",
                "router": "menu",
                "data": "/video/sport",
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
            {
                "Title": "Киберспорт и игры",
                "router": "menu",
                "data": "/video/cybersport",
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
            {
                "Title": "Фильмы",
                "router": "menu",
                "data": "/video/movies",
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
            {
                "Title": "Сериалы",
                "router": "menu",
                "data": "/video/serials",
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
            {
                "Title": "Шоу",
                "router": "menu",
                "data": "/video/tvshow",
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
            {
                "Title": "Детям",
                "router": "menu",
                "data": "/video/for_kids",
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
            {
                "Title": "Поиск",
                "router": "search",
                "data": str(),
                "Plot": str(),
                "Genres": [],
                "posters": str(),
            },
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
