# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""


class ParserVK:
    """
    Клас для получения данных
    """
    __slots__ = []

    _api: str = "https://vk.com"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0",
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "Accept-Language": "ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3",
        "Host":	"vk.com",
        "Origin": "https://vk.com"
    }

    def api(self, path: str, post: dict, retry: int = 10) -> (dict, str):
        from random import randint
        # Не стандартный модуль импортируется в addon.xml как script.module.requests
        import requests
        link = self._api + path
        response = requests.post(link, headers=self.headers, timeout=randint(5, 10), data=post)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.api(path=path, post=post, retry=retry - 1)
            elif response.status_code == 200:
                return response.text
        except ConnectionError:
            if retry:
                from time import sleep
                # TODO Добавить оповещение в интерфейс
                sleep(randint(2, 10))
                return self.api(path=path, post=post, retry=retry - 1)
            else:
                return "Что то не то с API..."
