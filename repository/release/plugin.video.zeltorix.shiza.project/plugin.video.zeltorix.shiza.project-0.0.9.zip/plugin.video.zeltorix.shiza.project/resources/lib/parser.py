# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.29
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
import json

from requests import Session


class ParserShizaProject:
    """
    Клас для получения данных
    """
    __slots__ = []

    _session = Session()
    _main_url = "https://shiza-project.com/"
    _api: str = _main_url + "graphql"
    _ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0"
    _headers = {
        "User-Agent": _ua,
        "content-type": "application/json",
    }

    def link_get(self, link: str) -> str:
        response = self._session.get(
            link,
            headers={"User-Agent": self._ua, "Referer": self._main_url},
            timeout=8,
        )
        if response.ok:
            return response.text
        else:
            raise ValueError("Что то не то с адресом или запросом: " + link)

    def link_post(self, link: str, data: dict) -> dict:
        response = self._session.post(
            link,
            headers={"User-Agent": self._ua, "Referer": self._main_url},
            data=data,
            timeout=8,
        )
        if response.ok:
            return response.json()
        else:
            raise ValueError("Что то не то с адресом или запросом: " + link)

    def vk(self, path: str, post: dict, retry: int = 10) -> (dict, str):
        headers = {
            "Referer": "https://yandex.com",
            "User-Agent": self._ua,
            "x-requested-with": "XMLHttpRequest",
        }
        link = "https://vk.com" + path
        response = self._session.post(link, headers=headers, data=post)
        if response.ok:
            return response.json()
        else:
            self.vk(path=path, post=post, retry=retry-1)


    def api(self, data: str, retry: int = 10) -> (dict, str):
        # Не стандартный модуль импортируется в addon.xml как script.module.requests
        response = self._session.post(self._api, headers=self._headers, data=data, timeout=8)
        try:
            if response.ok:
                return response.json()
            elif response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.api(data, retry - 1)
            elif response.status_code == 404:
                raise ValueError("Ошибка API")
            print(response.status_code)
            print(response.text)
        except ConnectionError:
            if retry:
                from time import sleep
                # TODO Добавить оповещение в интерфейс
                from random import randint
                sleep(randint(2, 10))
                return self.api(data, retry - 1)
            else:
                raise ValueError("Требуется пересмотреть API")
