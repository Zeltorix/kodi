# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.29
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserShizaProject
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.release.shiza_project.resources.lib.parser import ParserShizaProject


class ModelShizaProject:
    __slots__ = []
    _parser = ParserShizaProject()

    def sibnet(self, link: str) -> str:
        data: str = self._parser.link_get(link)
        from re import search
        return "https://video.sibnet.ru" + search(r"/v/.*/\d*.mp4", data)[0] + "|Referer=https://video.sibnet.ru/"

    def kodik(self, link: str) -> str:
        link = link + "?translations=false"
        data: str = self._parser.link_get(link)
        from re import search
        post = {
            "d": search(r'domain = ".*?"', data)[0].split('"')[1],
            "d_sign": search(r'd_sign = ".*?"', data)[0].split('"')[1],
            "pd": search(r'pd = ".*?"', data)[0].split('"')[1],
            "pd_sign": search(r'pd_sign = ".*?"', data)[0].split('"')[1],
            "ref": search(r'ref = ".*?"', data)[0].split('"')[1],
            "ref_sign": search(r'ref_sign = ".*?"', data)[0].split('"')[1],
            "bad_user": "false",
            "type": search(r"videoInfo.type = '.*?'", data)[0].split("'")[1],
            "hash": search(r"videoInfo.hash = '.*?'", data)[0].split("'")[1],
            "id": search(r"videoInfo.id = '.*?'", data)[0].split("'")[1],
            "info": "{}"
        }
        data_2 = self._parser.link_post("https://" + link.split("/")[2] + "/gvi", post)["links"]["720"][0]["src"]
        old: str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        new: str = "NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm0123456789"
        from base64 import standard_b64decode
        link_out: str = standard_b64decode("".join(new[old.index(char)] for char in data_2) + "===").decode("utf-8")
        if link_out.startswith("http"):
            return link_out
        else:
            return "https://" + link_out

    def vk(self, link: str) -> str:
        from re import findall
        rex = findall(r'\d{5,}', link)
        link = f"-{rex[0]}_{rex[1]}"
        post = {"al": "1", "video": link}
        data = self._parser.vk(path="/al_video.php?act=show", post=post)["payload"][1][4]["player"]["params"][0]
        if data.get("hls"):
            return data["hls"]
        elif data.get("hls_ondemand"):
            return data["hls_ondemand"]
        else:
            raise KeyError(f"Нету потока {json.dumps(data, indent=2)}")

    def myvi(self, link: str) -> str:
        data = self._parser.link_get(link)
        from urllib.parse import unquote
        from re import search
        return self._parser.link_get(
            unquote(search(r"https.*?\\", data)[0][:-1])) + "Cookie=UniversalUserID=6da8a191eb5f4643811620da1e21cfe8"

    def release(self, data: str) -> dict:
        post = {
            "operationName": "fetchRelease",
            "variables": {"slug": data},
            "query": "query fetchRelease($slug: String!){"
                     "release(slug: $slug){"
                     "name "
                     "description "
                     "seasonNumber "
                     "episodesCount "
                     "episodesAired "
                     "type "
                     "viewCount "
                     "score "
                     "airedOn "
                     "posters{...ReleasePosterCommon}"
                     "genres{name}"
                     "episodes{...ReleaseEpisodeCommon}"
                     "}"
                     "}"
                     "fragment ReleaseVideoCommon on VideoFile{embedSource embedUrl}"
                     "fragment ReleaseEpisodeCommon on ReleaseEpisode{"
                     "name "
                     "number "
                     "duration "
                     "videos{...ReleaseVideoCommon}"
                     "}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
        }
        data = self._parser.api(json.dumps(post))
        title = data["data"]["release"]["name"]
        premiered = data["data"]["release"]["airedOn"]
        posters = data["data"]["release"]["posters"][0]["original"]["url"]
        season_number = data["data"]["release"]["seasonNumber"]
        episodes_count = data["data"]["release"]["episodesCount"]
        episodes_aired = data["data"]["release"]["episodesAired"]
        type_ = data["data"]["release"]["type"]
        plot = data["data"]["release"]["description"]
        model_list: list = []
        for item in data["data"]["release"]["episodes"]:
            if not item["videos"]:
                break
            item_title = item["name"]
            number = item["number"]
            duration = int(item["duration"]) * 60
            # embedSource_1 = item["videos"][0]["embedSource"]
            # embedSource_2 = item["videos"][1]["embedSource"]
            # video_1 = item["videos"][0]["embedUrl"]
            # video_2 = item["videos"][1]["embedUrl"]
            model_list.append({
                "Title": f"[B][COLOR=green]{type_}[/COLOR][COLOR=blue]S{season_number or '0'}[/COLOR][COLOR=yellow]E{number or '0'}[/COLOR][/B] {item_title or ''}",
                "router": item["videos"][0]["embedSource"],
                "data": item["videos"][0]["embedUrl"],
                "Posters": posters,
                "Premiered": premiered,
                "Duration": duration,
                "Plot": plot,
            })
        return {
            "category": f"({episodes_aired} из {episodes_count}) {title} {season_number or ' '}",
            "list": tuple(model_list)
        }

    @staticmethod
    def _listing_releases(data: dict) -> tuple:
        model_list: list = []
        for release in data:
            model_list.append({
                "Title": f'{release["node"]["name"]}',
                "router": "release",
                "data": release["node"]["slug"],
                "Premiered": release["node"]["publishedAt"],
                "Posters": release["node"]["posters"][0]["original"]["url"],
                "Genres": [i["name"] for i in release["node"]["genres"]],
                "viewCount": release["node"]["viewCount"],
                "score": release["node"]["score"],
                "Plot": release["node"]["description"],
            })
        return tuple(model_list)

    def search(self, find_item: str) -> dict:
        post = {
            "operationName": "search",
            "variables": {"query": find_item, "type": "RELEASE"},
            "query": "query search($query: String!, $type: SearchType!){"
                     "search(query: $query, type: $type, first: 5000){edges{node{... on Release{...ReleaseCard}}}}}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{slug name publishedAt description seasonNumber viewCount score posters{"
                     "...ReleasePosterCommon}genres{name}}"
        }
        return {
            "category": "Найдено",
            "list": tuple(self._listing_releases(self._parser.api(data=json.dumps(post))["data"]["search"]["edges"]))
        }

    def _releases(self, category: str, sort_items: (str, bool) = True, total: int = 5000) -> dict:
        post = {
            "operationName": "fetchReleases",
            "variables": {"first": total, "activity": {"include": [], "exclude": ["WISH"]}, },
            "query": "query fetchReleases($first: Int, $activity: ReleaseActivityFilter,){"
                     "releases(first: $first activity: $activity ){"
                     "totalCount edges{node{...ReleaseCard viewerWatchlist{id}}}}}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{"
                     "slug "
                     "name "
                     "publishedAt "
                     "description "
                     "seasonNumber "
                     "viewCount "
                     "score "
                     "posters{...ReleasePosterCommon}"
                     "genres{name}"
                     "}"
        }
        return {
            "category": category,
            "sort_items": sort_items,
            "list": tuple(self._listing_releases(self._parser.api(data=json.dumps(post))["data"]["releases"]["edges"]))
        }

    def new(self) -> dict:
        return self._releases("Новые реализы", False, 50)

    def random(self) -> dict:
        post = {
            "operationName": "fetchReleases",
            "variables": {"first": 5000, "activity": {"include": [], "exclude": ["WISH"]}, },
            "query": "query fetchReleases($first: Int, $activity: ReleaseActivityFilter,){"
                     "releases(first: $first activity: $activity){"
                     "totalCount edges{node{...ReleaseCard viewerWatchlist{id}}}}}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{slug name publishedAt description viewCount score posters{"
                     "...ReleasePosterCommon}genres{name}}"
        }
        from random import choice
        data = choice(self._parser.api(data=json.dumps(post))["data"]["releases"]["edges"])
        return {
            "category": "Случайное аниме",
            # "sort_items": sort_items,
            "list": [
                {
                    "Title": data["node"]["name"],
                    "data": data["node"]["slug"],
                    "router": "release",
                    "Premiered": data["node"]["publishedAt"],
                    "Posters": data["node"]["posters"][0]["original"]["url"],
                    "Genres": [i["name"] for i in data["node"]["genres"]],
                    "viewCount": data["node"]["viewCount"],
                    "score": data["node"]["score"],
                    "Plot": data["node"]["description"],
                }
            ]
        }

    def all(self) -> dict:
        return self._releases("Все аниме", True, 5000)

    def collections(self, collect: str = None) -> dict:
        post = {
            "operationName": "fetchCollections",
            "variables": {"first": 5000, "query": ""},
            "query": "query fetchCollections($first: Int, $query: String, $orderBy: CollectionOrder){"
                     "collections(first: $first, query: $query, orderBy: $orderBy){"
                     "totalCount edges{node{...CollectionCommon previewItems{...CollectionItemCommon}}}}}"
                     "fragment CollectionItemCommon on CollectionItem{collectionable{... on Release{...ReleaseCard}}}"
                     "fragment CollectionCommon on Collection{slug name content viewCount publishedAt}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{slug name publishedAt description viewCount score posters{...ReleasePosterCommon}genres{name}}"
        }
        data = self._parser.api(data=json.dumps(post))["data"]["collections"]["edges"]
        model_list: list = []
        category = "Подборки"
        if collect:
            for collection in data:
                if collection["node"]["slug"] == collect:
                    category = collection["node"]["name"]
                    for release in collection["node"]["previewItems"]:
                        model_list.append({
                            "Title": release["collectionable"]["name"],
                            "data": release["collectionable"]["slug"],
                            "router": "release",
                            "Premiered": release["collectionable"]["publishedAt"],
                            "viewCount": release["collectionable"]["viewCount"],
                            "Plot": release["collectionable"]["description"],
                            "Posters": release["collectionable"]["posters"][0]["original"]["url"],
                            "Genres": [k["name"] for k in release["collectionable"]["genres"]],
                        })
        else:
            for collection in data:
                model_list.append({
                    "Title": collection["node"]["name"],
                    "data": collection["node"]["slug"],
                    "router": "collections",
                    "Premiered": collection["node"]["publishedAt"],
                    "viewCount": collection["node"]["viewCount"],
                    "Plot": collection["node"]["content"],
                })
        return {
            "category": category,
            "list": tuple(model_list)
        }

    @staticmethod
    def main() -> dict:
        model_list: list = [
            {
                "Title": "Новые реализы",
                "router": "new",
            },
            {
                "Title": "Случайное аниме",
                "router": "random",
            },
            {
                "Title": "Подборки",
                "router": "collections",
            },
            {
                "Title": "Каталог",
                "router": "all",
            },
            {
                "Title": "Поиск",
                "router": "search",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            },
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
