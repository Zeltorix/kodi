# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.29
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

# Импорт модуля плагина для создания модели
from .model import ModelShizaProject
from .view import View


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    # import logging
    # logger = logging.getLogger(__name__)
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    view = View()
    model = ModelShizaProject()
    if params_dict:
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                view.main(model.search(params_dict['keyword']))
            else:
                # Вывод поиска, импортировано из модуля view
                view.main(model.search(view.search()))
        elif params_dict['router'] == "new":
            view.main(model.new())
        elif params_dict['router'] == "random":
            view.main(model.random())
        elif params_dict['router'] == "collections":
            if params_dict.get('data'):
                view.main(model.collections(params_dict['data']))
            else:
                view.main(model.collections())
        elif params_dict['router'] == "all":
            view.main(model.all())
        elif params_dict['router'] == "release":
            view.main(model.release(params_dict['data']))
        elif params_dict['router'] == "SIBNET":
            view.play(model.sibnet(params_dict['data']))
        elif params_dict['router'] == "KODIK":
            view.play(model.kodik(params_dict['data']))
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        view.main(model.main())
