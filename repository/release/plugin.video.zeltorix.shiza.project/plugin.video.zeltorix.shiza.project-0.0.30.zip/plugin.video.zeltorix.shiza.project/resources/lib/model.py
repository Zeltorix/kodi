# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.29
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import loads, dumps
from re import findall
from base64 import standard_b64decode
from urllib.parse import unquote
from random import choice

from web_api_request import WebApiRequest, https_checking
from get_video_link import VideoLink
from view import View
from text_job import ras
from headers import headers
from history import History
from errors import Errors


class ModelShizaProject:
    __slots__ = []

    _main_url = "https://shizaproject.com/"
    _api: str = _main_url + "graphql"
    headers["Referer"] = _main_url
    headers["Content-Type"] = "application/json"
    _view = View()
    _web = WebApiRequest(headers)
    _video_link = VideoLink()
    _history = History()
    _errors = Errors()

    def sibnet(self, link: str) -> str:
        return self._video_link.sibnet_link(link)

    def kodik(self, link: str) -> str:
        return self._video_link.kodik_play_one(link)

    def vk(self, link: str) -> str:
        return self._video_link.vk_link(link)

    def myvi(self, link: str) -> str:
        # TODO Нужно полностью переписать
        data = self._web.request_get(link).text
        return self._web.request_get(
            unquote(findall(r"https.*?\\", data)[0][:-1])) + "Cookie=UniversalUserID=6da8a191eb5f4643811620da1e21cfe8"

    def release(self, data: str) -> dict:
        post = {
            "operationName": "fetchRelease",
            "variables": {"slug": data},
            "query": "query fetchRelease($slug: String!){"
                     "release(slug: $slug){"
                     "name "
                     "description "
                     "seasonNumber "
                     "episodesCount "
                     "episodesAired "
                     "type "
                     "viewCount "
                     "score "
                     "airedOn "
                     "posters{...ReleasePosterCommon}"
                     "genres{name}"
                     "episodes{...ReleaseEpisodeCommon}"
                     "}"
                     "}"
                     "fragment ReleaseVideoCommon on VideoFile{embedSource embedUrl}"
                     "fragment ReleaseEpisodeCommon on ReleaseEpisode{"
                     "name "
                     "number "
                     "duration "
                     "videos{...ReleaseVideoCommon}"
                     "}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
        }
        data = self._web.request_post(self._api, data=dumps(post)).json()
        title = data["data"]["release"]["name"]
        premiered = data["data"]["release"]["airedOn"]
        posters = data["data"]["release"]["posters"][0]["original"]["url"]
        season_number = data["data"]["release"]["seasonNumber"]
        episodes_count = data["data"]["release"]["episodesCount"]
        episodes_aired = data["data"]["release"]["episodesAired"]
        type_ = data["data"]["release"]["type"]
        plot = data["data"]["release"]["description"]
        model_list: list = []
        for item in data["data"]["release"]["episodes"]:
            if not item["videos"]:
                break
            item_title = item["name"]
            number = item["number"]
            duration = int(item["duration"]) * 60
            # embedSource_1 = item["videos"][0]["embedSource"]
            # embedSource_2 = item["videos"][1]["embedSource"]
            # video_1 = item["videos"][0]["embedUrl"]
            # video_2 = item["videos"][1]["embedUrl"]
            model_list.append({
                "title": f"[B][COLOR=green]{type_}[/COLOR][COLOR=blue]S{season_number or '0'}[/COLOR][COLOR=yellow]E{number or '0'}[/COLOR][/B] {item_title or ''}",
                "router": item["videos"][0]["embedSource"],
                "data": item["videos"][0]["embedUrl"],
                "images": posters,
                "premiered": premiered,
                "duration": duration,
                "plot": plot,
                "play": True,
            })
        return {
            "category": f"({episodes_aired} из {episodes_count}) {title} {season_number or ' '}",
            "list": tuple(model_list)
        }

    @staticmethod
    def _listing_releases(data: dict) -> tuple:
        model_list: list = []
        for release in data:
            model_list.append({
                "title": f'{release["node"]["name"]}',
                "router": "release",
                "data": release["node"]["slug"],
                "premiered": release["node"]["publishedAt"],
                "images": release["node"]["posters"][0]["original"]["url"],
                "genres": [i["name"] for i in release["node"]["genres"]],
                "viewCount": release["node"]["viewCount"],
                "score": release["node"]["score"],
                "plot": release["node"]["description"],
            })
        return tuple(model_list)

    def search(self, find_item: str) -> dict:
        self._history.history_add_item(find_item)

        post = {
            "operationName": "search",
            "variables": {"query": find_item, "type": "RELEASE"},
            "query": "query search($query: String!, $type: SearchType!){"
                     "search(query: $query, type: $type, first: 5000){edges{node{... on Release{...ReleaseCard}}}}}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{slug name publishedAt description seasonNumber viewCount score posters{"
                     "...ReleasePosterCommon}genres{name}}"
        }
        return {
            "category": "Найдено",
            "list": tuple(self._listing_releases(self._web.request_post(self._api, data=dumps(post)).json()["data"]["search"]["edges"]))
        }

    def _releases(self, category: str, sort_items: (str, bool) = True, total: int = 5000) -> dict:
        post = {
            "operationName": "fetchReleases",
            "variables": {"first": total, "activity": {"include": [], "exclude": ["WISH"]}, },
            "query": "query fetchReleases($first: Int, $activity: ReleaseActivityFilter,){"
                     "releases(first: $first activity: $activity ){"
                     "totalCount edges{node{...ReleaseCard viewerWatchlist{id}}}}}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{"
                     "slug "
                     "name "
                     "publishedAt "
                     "description "
                     "seasonNumber "
                     "viewCount "
                     "score "
                     "posters{...ReleasePosterCommon}"
                     "genres{name}"
                     "}"
        }
        if sort_items:
            sort = [
                10,  # SORT_METHOD_TITLE_IGNORE_THE
            ]
        else:
            sort = [
                0,  # SORT_METHOD_NONE
            ]

        response = self._web.request_post(self._api, data=dumps(post))
        if response and type(response) is not dict:
            return {
                "category": category,
                "sort": sort,
                "list": tuple(self._listing_releases(response.json()["data"]["releases"]["edges"]))
            }

        else:
            self._errors.log_web_error(response)

    def new(self) -> dict:
        return self._releases("Новые реализы", False, 50)

    def random(self) -> dict:
        post = {
            "operationName": "fetchReleases",
            "variables": {"first": 5000, "activity": {"include": [], "exclude": ["WISH"]}, },
            "query": "query fetchReleases($first: Int, $activity: ReleaseActivityFilter,){"
                     "releases(first: $first activity: $activity){"
                     "totalCount edges{node{...ReleaseCard viewerWatchlist{id}}}}}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{slug name publishedAt description viewCount score posters{"
                     "...ReleasePosterCommon}genres{name}}"
        }
        data = choice(self._web.request_post(self._api, data=dumps(post)).json()["data"]["releases"]["edges"])
        return {
            "category": "Случайное аниме",
            # "sort_items": sort_items,
            "list": [
                {
                    "title": data["node"]["name"],
                    "data": data["node"]["slug"],
                    "router": "release",
                    "premiered": data["node"]["publishedAt"],
                    "images": data["node"]["posters"][0]["original"]["url"],
                    "genres": [i["name"] for i in data["node"]["genres"]],
                    "viewCount": data["node"]["viewCount"],
                    "score": data["node"]["score"],
                    "plot": data["node"]["description"],
                }
            ]
        }

    def all(self) -> dict:
        return self._releases("Все аниме", True, 5000)

    def collections(self, collect: str = None) -> dict:
        post = {
            "operationName": "fetchCollections",
            "variables": {"first": 5000, "query": ""},
            "query": "query fetchCollections($first: Int, $query: String, $orderBy: CollectionOrder){"
                     "collections(first: $first, query: $query, orderBy: $orderBy){"
                     "totalCount edges{node{...CollectionCommon previewItems{...CollectionItemCommon}}}}}"
                     "fragment CollectionItemCommon on CollectionItem{collectionable{... on Release{...ReleaseCard}}}"
                     "fragment CollectionCommon on Collection{slug name content viewCount publishedAt}"
                     "fragment ReleasePosterCommon on ImageFile{original{url}}"
                     "fragment ReleaseCard on Release{slug name publishedAt description viewCount score posters{...ReleasePosterCommon}genres{name}}"
        }
        data = self._web.request_post(self._api, data=dumps(post)).json()["data"]["collections"]["edges"]
        model_list: list = []
        category = "Подборки"
        if collect:
            for collection in data:
                if collection["node"]["slug"] == collect:
                    category = collection["node"]["name"]
                    for release in collection["node"]["previewItems"]:
                        model_list.append({
                            "title": release["collectionable"]["name"],
                            "data": release["collectionable"]["slug"],
                            "router": "release",
                            "premiered": release["collectionable"]["publishedAt"],
                            "viewCount": release["collectionable"]["viewCount"],
                            "plot": release["collectionable"]["description"],
                            "images": release["collectionable"]["posters"][0]["original"]["url"],
                            "genres": [k["name"] for k in release["collectionable"]["genres"]],
                        })
        else:
            for collection in data:
                model_list.append({
                    "title": collection["node"]["name"],
                    "data": collection["node"]["slug"],
                    "router": "collections",
                    "premiered": collection["node"]["publishedAt"],
                    "viewCount": collection["node"]["viewCount"],
                    "plot": collection["node"]["content"],
                })
        return {
            "category": category,
            "list": tuple(model_list)
        }

    @staticmethod
    def main() -> dict:
        model_list: list = [
            {
                "title": "Новые реализы",
                "router": "new",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
            },
            {
                "title": "Подборки",
                "router": "collections",
            },
            {
                "title": "Каталог",
                "router": "all",
            },
            {
                "title": "Меню поиска",
                "data": "",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            },
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
