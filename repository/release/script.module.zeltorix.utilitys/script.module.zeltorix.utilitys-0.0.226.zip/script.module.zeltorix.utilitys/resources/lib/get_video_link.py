# -*- coding: utf-8 -*-
# Module: get_video_link
# Author: Zeltorix
# Created on: 2023.10.04
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from json import loads, dumps
from re import findall
from random import choice
from base64 import standard_b64decode
from urllib.parse import parse_qsl, urlencode

try:
    from web_api_request import WebApiRequest, headers, https_checking
    from view import View
except ImportError:
    try:
        from source.release.utilitys.resources.lib.web_api_request import WebApiRequest, headers, https_checking


        class View:
            @staticmethod
            def output_logs(item):
                print(item)


    except ImportError:
        from .web_api_request import WebApiRequest, headers, https_checking
        from .view import View


class VideoLink:
    __slots__ = [
        "_view"
    ]

    def __init__(self):
        self._view = View()

    def definition_links(self, link: str) -> (str, dict):
        if "vk.com" in link or findall(r"\d{5,}_\d{5,}", link) or (len(findall(r"\d{5,}", link)) == 2):
            return self.vk_link(link)
        elif "ok.ru" in link or findall(r"\d{12,}", link):
            return self.ok_link(link)
        elif "rutube.ru" in link or findall(r"(\d,\w){28,}", link):
            return self.rutube_link(link)
        elif "youtube" in link or "embed" in link or findall(r"(\d,-,\w){11}", link):
            return self.youtube_link(link)
        elif "mediavitrina" in link:
            return self.mediavitrina_links(link)
        elif "video.sibnet.ru" in link:
            return self.sibnet_link(link)
        else:
            raise ValueError(f"Неизвестная ссылка - {link}")

    @staticmethod
    def sibnet_link(link: str) -> str:
        response = WebApiRequest().request_get(link)
        if response and type(response) is not dict:
            return "https://video.sibnet.ru" + findall(r"/v/.*/\d*.mp4", response.text)[
                0] + "|Referer=https://video.sibnet.ru/"

    @staticmethod
    def _vk_get_id(link: str) -> str:
        rex = findall(r'\d{5,}', link)
        if rex:
            return f"-{rex[0]}_{rex[1]}"
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def vk_link(self, link: str) -> str:
        id_: str = self._vk_get_id(link)
        if id_:
            post = {"al": "1", "video": id_}

            headers["x-requested-with"] = "XMLHttpRequest"
            headers["Content-Type"] = "application/x-www-form-urlencoded"
            response = WebApiRequest(headers).request_post("php.oediv_la/moc.kv//:sptth"[::-1], params={"act": "show"},
                                                           data=post)
            if response and type(response) is not dict:
                data = loads(response.text)["payload"][1][4]["player"]["params"][0]
                if data.get("hls"):
                    return data["hls"]
                elif data.get("hls_ondemand"):
                    return data["hls_ondemand"]
                else:
                    raise KeyError(f"Нету нудных ключей {dumps(data, indent=2)}")
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def _ok_get_id(link: str) -> str:
        if "video/" in link:
            return link.split("video/")[1]
        elif findall(r"\d{10,}", link):
            return findall(r"\d{10,}", link)[0]
        elif "/" not in link:
            return link
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def ok_link(self, link: str) -> (str, dict):
        id_: str = self._ok_get_id(link)
        if id_:
            post: dict = {"st.vpl.id": id_, "st.vpl.bu": link}
            response = WebApiRequest().request_post("oediVreyaLpoP=dmc?kd/ur.ko//:sptth"[::-1], post)
            if response and response is not int:
                data_options: str = findall(
                    r'data-options=".*?"',
                    response.text
                )[0].split('"')[1].replace("&quot;", '"')
                hls: dict = loads(loads(data_options)["flashvars"]["metadata"])
                if hls.get("hlsMasterPlaylistUrl"):
                    video: str = hls["hlsMasterPlaylistUrl"]
                elif hls.get("hlsManifestUrl"):
                    video: str = hls["hlsManifestUrl"]
                else:
                    raise KeyError(f"Нужного ключа не найдено {link}")
                return video
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def _rutube_get_id(link: str) -> str:
        if "/" in link:
            if "?" in link:
                return link.split("?")[0].split("/")[-2]
            elif link.endswith("/"):
                return link.split("/")[-2]
            elif "rutube.ru/play/embed/" in link:
                return link.split("/")[-1]
        elif "/" not in link:
            return link
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def rutube_link(self, link: str) -> (str, dict):
        id_: (str, int, dict, None) = self._rutube_get_id(link)
        if id_:
            params = {
                "no_404": True,
                "referer": "https://rutube.ru",
                "pver": "v2",
            }
            response = WebApiRequest().request_get(f"https://rutube.ru/api/play/options/{id_}/", params=params)
            if response and type(response) is not dict:
                vido_dict: dict = response.json()

                # Если видео на портале
                if vido_dict["has_video"]:
                    # Используется ли плеер портала
                    if vido_dict["player"] == "rutube":
                        # Обычное видео
                        if vido_dict["video_balancer"]:
                            return vido_dict["video_balancer"]["m3u8"]
                        # Прямой эфир
                        elif vido_dict["live_streams"] and vido_dict["live_streams"].get("hls"):
                            return vido_dict["live_streams"]["hls"][0]["url"]

                        # При отсутствии потока проверить детали
                        elif vido_dict.get("detail"):
                            # Заглушка для стрима
                            if vido_dict["detail"]["name"] == "stream_access_fail":
                                return {
                                    "title": vido_dict["detail"]["languages"][0]["title"],
                                    "description": vido_dict["detail"]["languages"][0]["description"],
                                    "router": "message",
                                }
                        else:
                            raise ValueError(f"Видео вроде как есть на портале, но логики на вынимания потока нет - "
                                             f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
                    else:
                        raise ValueError(f"Видео вроде как есть, но логики на вынимания потока нет - "
                                         f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
                # Отсутствие видео на портале
                else:
                    # Проверяет использоваться ли сторонний плеер
                    if vido_dict["player"] == "iframe":
                        if "mediavitrina" in vido_dict["iframe_url"]:
                            self.mediavitrina_links(vido_dict["iframe_url"], one_link=True)
                        else:
                            return {
                                "title": "Сторонний плеер",
                                "data": "https:" + vido_dict["iframe_url"],
                                "referer": vido_dict["referer"],
                                "router": "iframe",
                            }

                    else:
                        raise ValueError(f"Не понятно от куда брать поток, требуется исследование - "
                                         f"{'/snoitpo/yalp/ipa/ur.ebutur//:sptth'[::-1] + id_}")
        else:
            raise ValueError("Отсутствует данные")

    @staticmethod
    def mediavitrina_links(link: str, one_link=False) -> dict:
        response = WebApiRequest().request_get(link)
        if response and response is not int:
            link_site = loads(findall(r"allowedDomains: .*?]", response.text)[0].split("allowedDomains: ")[1])
            refer_host_name: str = list(filter(lambda item: item if "*" not in item else False, link_site[::-1][:2]))[0]

            url_players: str = findall(r"url:.*'", response.text)[0].split("'")[1]

            link_players: str = url_players \
                .replace("{{APPLICATION_ID}}", "") \
                .replace("{{PLAYER_REFERER_HOSTNAME}}", refer_host_name) \
                .replace("{{CONFIG_CHECKSUM_SHA256}}", "")

            link_epg: str = findall(r"epg_url:.*'", response.text)[0].split("'")[1]

            headers["Referer"] = "/ur.anirtivaidem.reyalp//:sptth"[::-1]
            headers["Sec-Fetch-Dest"] = "empty"
            headers["Sec-Fetch-Mode"] = "cors"
            headers["Sec-Fetch-Site"] = "same-site"
            session = WebApiRequest(headers)
            players: dict = session.request_get(link_players).json()
            if one_link:
                return choice(players["hls"])
            else:
                epg: dict = session.request_get(link_epg).json()
                return {**players, **epg}

    @staticmethod
    def _youtube_get_id(link: str) -> str:
        if "/embed/" in link:
            link = link.split("/")[-1]
            if "?" in link:
                return link.split("?")[0]
            else:
                return link
        elif "watch?v" in link:
            link = link.split("=")[-1]
            if "?" in link:
                return link.split("?")[0]
            else:
                return link
        elif "/" not in link and "?" not in link and "=" not in link:
            return link
        else:
            raise ValueError(f"Неизвестная ссылка {link}")

    def youtube_link(self, link: str) -> str:
        # id_: str = self._youtube_get_id(link)
        # response = WebApiRequest().request_get("https://www.youtube.com/watch?v=" + id_)
        # if response and type(response) is not dict:
        #     find_json: dict = loads(findall(r'\{"response.*}}}}', response.text)[0])
        #     return [i["url"] for i in find_json["streamingData"]["formats"] if i["height"] == 720][0]

        import yt_dlp
        with yt_dlp.YoutubeDL({}) as ydl:
            for i in ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"]:
                if i.get("fps") and i["fps"] and i.get("audio_channels") and i["audio_channels"] \
                        and i["format_note"] == "720p":
                    View().output_logs(i["url"])
                    return i["url"]

    def kodik_play_one(self, link: str) -> dict:
        def decoding_url(data_url: str) -> str:
            old: str = "9876543210zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA"[::-1]
            new: str = "9876543210mlkjihgfedcbazyxwvutsrqponMLKJIHGFEDCBAZYXWVUTSRQPON"[::-1]
            return standard_b64decode("".join(new[old.index(char)] for char in data_url) + "===").decode("utf-8")

        link_play = ""
        link_chunk: str = ""
        del headers["Referer"]
        headers["Sec-Fetch-Dest"] = "iframe"
        headers["Sec-Fetch-Site"] = "cross-site"
        headers["Upgrade-Insecure-Requests"] = "1"
        WebApiRequest().__init__(headers)
        response = WebApiRequest().request_get(link)
        if response and type(response) is not dict:
            response_text = response.text
            url_params = loads(findall(r"urlParams.*?}';", response_text)[0].split("'")[1])
            data_type = findall(r"videoInfo\.type.*?;", response_text)[0].split("'")[1]
            data_hash = findall(r"videoInfo\.hash.*?;", response_text)[0].split("'")[1]
            data_id = findall(r"videoInfo\.id.*?;", response_text)[0].split("'")[1]
            domain: str = "https://" + url_params["pd"]
            post: dict = {
                "d": url_params["d"],
                "d_sign": url_params["d_sign"],
                "pd": url_params["pd"],
                "pd_sign": url_params["pd_sign"],
                "ref": url_params["ref"],
                "ref_sign": url_params["ref_sign"],
                "bad_user": "false",
                "cdn_is_working": "true",
                "type": data_type,
                "hash": data_hash,
                "id": data_id,
                "info": "{}"
            }
            link_js = findall(r"/assets/js/app.*?\.js", response_text)[0]
            headers["Priority"] = "u=1"
            headers["Referer"] = link
            headers["Sec-Fetch-Dest"] = "script"
            headers["Sec-Fetch-Mode"] = "no-cors"
            headers["Sec-Fetch-Site"] = "same-origin"
            headers["Accept"] = "*/*"
            WebApiRequest().__init__(headers)
            response_js = WebApiRequest().request_get(domain + link_js)
            if response_js and type(response_js) is not dict:
                link_chunk: str = standard_b64decode(
                    findall(r'url:atob\("\S+"\),', response_js.text)[0].split('"')[1]).decode("utf-8")

            if link_chunk:
                headers["Referer"] = https_checking(url_params["pd"])
                WebApiRequest().__init__(headers)
                WebApiRequest().request_get("https://cloud.kodik-storage.com/test/t")
                headers["Accept"] = "application/json, text/javascript, */*; q=0.01"
                headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
                headers["Priority"] = "u=1, i"
                headers["Referer"] = link
                headers["Sec-Fetch-Dest"] = "empty"
                headers["Sec-Fetch-Mode"] = "cors"
                headers["Sec-Fetch-Site"] = "same-origin"
                headers["X-Requested-With"] = "XMLHttpRequest"
                headers["Origin"] = https_checking(url_params["pd"])
                WebApiRequest().__init__(headers)
                response_json = WebApiRequest().request_post(domain + link_chunk, data=post)
                if response_json and type(response_json) is not dict:
                    data_json = response_json.json()

                    video_size: int = self._view.get_setting_int("video_size")
                    if video_size:
                        height = video_size
                    else:
                        height: int = self._view.get_windows_width_height()["height"]

                    if height <= 360:
                        if data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                    elif 360 < height <= 480:
                        if data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                    elif 480 < height <= 720:
                        if data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                    elif 720 < height <= 1080:
                        if data_json["links"].get("1080"):
                            link_play: str = data_json["links"]["1080"][0]["src"]
                        elif data_json["links"].get("720"):
                            link_play: str = data_json["links"]["720"][0]["src"]
                        elif data_json["links"].get("480"):
                            link_play: str = data_json["links"]["480"][0]["src"]
                        elif data_json["links"].get("360"):
                            link_play: str = data_json["links"]["360"][0]["src"]

        if link_play:
            return {
                "type": "hls",
                "link_play": https_checking(decoding_url(link_play)),
            }
        else:
            raise ValueError("Отсутствия потоков на видео")
