try:
    from view import View
except ImportError:
    try:
        from source.release.utilitys.resources.lib.view import View
    except ImportError:
        from .view import View


class Errors:
    _view = View()

    def log_web_error(self, response) -> None:
        self._view.output_logs(response)
        if response.get("response"):
            self._view.output_logs(response["response"].text)
        self._view.dialog_ok(
            "Возникла ошибка доступа к ресурсу",
            f"Рекомендуется сообщить в соответсвующий раздел на форум\n"
            f"https://kodi.moy.su/forum/2 и приложить лог файл для устранения ошибки.\n"
            f"{response}"
        )
        raise
