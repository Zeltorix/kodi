# -*- coding: utf-8 -*-
# Module: web_api_request
# Author: Zeltorix
# Created on: 2023.09.28
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from pathlib import Path


try:
    from web_api_request import WebApiRequest, headers
except ImportError:
    try:
        from source.release.utilitys.resources.lib.web_api_request import WebApiRequest, headers
    except ImportError:
        from .web_api_request import WebApiRequest, headers


class Download:
    __slots__ = ["_web", "_path_folder"]

    def __init__(self, path_folder: str, heads: dict = None):
        if heads is None:
            heads = headers
        self._web = WebApiRequest(heads)
        self._path_folder = path_folder
        if not Path(path_folder).exists():
            Path(path_folder).mkdir(parents=True)

    def download(self, link: str, fail_name: str, path_anime: str, params: dict = None):
        if not Path(self._path_folder, path_anime).exists():
            Path(self._path_folder, path_anime).mkdir(parents=True)
        with open(Path(self._path_folder, path_anime, fail_name), 'wb') as fail:
            for chunk in self._web.download(link=link, params=params):
                fail.write(chunk)
        return True
