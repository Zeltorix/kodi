# -*- coding: utf-8 -*-
# Module: web_api_request
# Author: Zeltorix
# Created on: 2023.09.28
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль запросов
"""

# Стандартные библиотеки
import asyncio
import time
from re import findall

# Не стандартные библиотеки
from httpx import Client, AsyncClient, TimeoutException, Response, ConnectError

try:
    from view import View
    from headers import headers, headers_download
except ImportError:
    try:
        from source.release.utilitys.resources.lib.headers import headers, headers_download


        class View:
            @staticmethod
            def get_setting_str(data, data_2):
                if data == "request_timeout":
                    return 8
                elif data == "request_retry":
                    return 5
                elif data == "request_time_sleep":
                    return 5
                elif data == "proxy_query":
                    return Proxy().censortracker()

            @staticmethod
            def get_setting_bool(data, data_2):
                if data == "request_verify":
                    return True

            @staticmethod
            def get_setting_int(data, data_2):
                if data == "proxy_type":
                    return 2

            @staticmethod
            def set_setting(data, data_2, data_3):
                if data == "proxy_query":
                    print(data_2)

            @staticmethod
            def output_logs(data):
                print(data)
    except ImportError:
        from .headers import headers, headers_download
        from .view import View


def https_checking(url_check: str, start_url: (str, bool) = False) -> str:
    if url_check.startswith("https"):
        return url_check
    elif url_check.startswith("http"):
        return url_check.replace("http", "https")
    elif url_check.startswith("//"):
        return "https:" + url_check
    elif "." in url_check.split("/")[0]:
        return "https://" + url_check
    elif start_url:
        if start_url in url_check:
            return url_check
        elif url_check.startswith("/"):
            return start_url + url_check
        elif "/" in url_check:
            return f"{start_url}/{url_check}"
    else:
        raise ValueError(f"Неизвестный тип ссылки - {url_check}")


class Proxy:
    __slots__ = []
    _view = View()

    def __init__(self):
        pass

    def proxy_provider_reload(self):
        if self._view.get_setting_int("proxy_type", "script.module.zeltorix.utilitys") == 1:
            proxy_address = self.antizapret()
        elif self._view.get_setting_int("proxy_type", "script.module.zeltorix.utilitys") == 2:
            proxy_address = self.censortracker()
        else:
            raise
        self._view.set_setting("proxy_query", proxy_address, "script.module.zeltorix.utilitys")
        return True

    @staticmethod
    def antizapret(proxies: bool = False) -> (str, list):
        headers["Accept"] = "application/x-ns-proxy-autoconfig"
        response = WebApiRequest(headers).request_get("cap.yxorp/3448:lol.enoweneht.p//:sptth"[::-1])
        if response and type(response) is not dict:
            find_data = findall(r"\w+\.\w+\.lol:\d+", response.text)
            if proxies:
                return {"https://": "https://" + find_data[-2], "http://": "http://" + find_data[-1], }
            else:
                return "https://" + find_data[-2]

    @staticmethod
    def censortracker() -> str:
        headers["Sec-Fetch-Site"] = "none"
        headers["Sec-Ch-Ua-Mobile"] = "?0"
        headers["Sec-Ch-Ua-Platform"] = '"Windows"'
        response = WebApiRequest(headers).request_get("/gifnoc-yxorp/ipa/goog.etalsnart.gro-rekcartrosnec-ppa//:sptth"[::-1])
        if response and type(response) is not dict:
            data = response.json()
            return f"https://{data['server']}:{data['port']}"


class WebApiRequest:
    __slots__ = ["_session", "_session_async", "heads"]
    _view = View()
    retry = int(_view.get_setting_str("request_retry", "script.module.zeltorix.utilitys"))
    time_sleep = int(_view.get_setting_str("request_time_sleep", "script.module.zeltorix.utilitys"))

    def __init__(self,
                 heads: dict = None,
                 proxies: dict = None,
                 proxy: str = None,
                 redirects=True,
                 verify=None,
                 timeout=None):
        if verify:
            verify = verify
        else:
            verify = self._view.get_setting_bool("request_verify", "script.module.zeltorix.utilitys")

        if not timeout:
            timeout = float(self._view.get_setting_str("request_timeout", "script.module.zeltorix.utilitys"))

        self.heads = heads
        if heads is None:
            self.heads = headers

        self._session = Client(
            headers=self.heads,
            follow_redirects=redirects,
            timeout=timeout,
            http2=True,
            verify=verify,
            proxies=proxies,
            proxy=proxy,
        )

    def request_get(self, link: str, params: dict = None, retry: int = retry) -> (Response, dict):
        if params is None:
            params: dict = {}
        try:
            response: Response = self._session.get(link, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_get(link=link, params=params, retry=retry - 1)
            elif response.status_code != 200:
                if retry:
                    time.sleep(self.time_sleep)
                    return self.request_get(link, params=params, retry=retry - 1)
                else:
                    raise ValueError(
                        f"Неизвестный код ответа\n"
                        f"{response.status_code}\n"
                        f"{link}\n"
                        f"{params}\n"
                        f"{self.heads}")
        except TimeoutException:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def request_post(self, link: str, params: dict = None, data: dict = None, retry: int = retry) -> (Response, dict):
        if params is None:
            params = {}
        if data is None:
            data = {}
        try:
            response: Response = self._session.post(link, data=data, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            elif response.status_code != 200:
                time.sleep(self.time_sleep)
                if retry:
                    return self.request_post(link, params=params, data=data, retry=retry - 1)
                else:
                    raise ValueError(
                        f"Неизвестный код ответа\n"
                        f"{response.status_code}\n"
                        f"{link}\n"
                        f"{params}\n"
                        f"{data}\n"
                        f"{self.heads}")
        except TimeoutException:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def request_put(self, link: str, params: dict = None, data: dict = None, retry: int = retry) -> (Response, dict):
        if params is None:
            params = {}
        if data is None:
            data = {}
        try:
            response: Response = self._session.put(link, data=data, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_put(link, params=params, data=data, retry=retry - 1)
            elif response.status_code != 200:
                time.sleep(self.time_sleep)
                if retry:
                    return self.request_put(link, params=params, data=data, retry=retry - 1)
                else:
                    raise ValueError(
                        f"Неизвестный код ответа\n"
                        f"{response.status_code}\n"
                        f"{link}\n"
                        f"{params}\n"
                        f"{data}\n"
                        f"{self.heads}")
        except TimeoutException:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_put(link, params=params, data=data, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_put(link, params=params, data=data, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_put(link, params=params, data=data, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def request_delete(self, link: str, params: dict = None, retry: int = retry) -> (Response, dict):
        if params is None:
            params = {}
        try:
            response: Response = self._session.delete(link, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            elif response.status_code != 200:
                time.sleep(self.time_sleep)
                if retry:
                    return self.request_delete(link, params=params, retry=retry - 1)
                else:
                    raise ValueError(
                        f"Неизвестный код ответа\n"
                        f"{response.status_code}\n"
                        f"{link}\n"
                        f"{params}\n"
                        f"{self.heads}")
        except TimeoutException:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "TimeoutException",
                }
        except ConnectError:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                time.sleep(self.time_sleep)
                return self.request_delete(link, params=params, retry=retry - 1)
            else:
                self._view.output_logs(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def download(self, link: str, params: dict = None):
        if params is None:
            params: dict = {}
        with Client().stream(method="GET", url=link, params=params) as response:
            for data in response.iter_bytes():
                yield data


class WebApiRequestAsync:
    __slots__ = ["_session", "_session_async", ]
    _view = View()

    def __init__(self, heads: dict = None, proxies: dict = None, proxy: str = None, redirects=True):

        timeout = float(self._view.get_setting_str("request_timeout", "script.module.zeltorix.utilitys"))

        if heads is None:
            heads = headers
        self._session_async = AsyncClient(
            headers=heads,
            follow_redirects=redirects,
            timeout=timeout,
            http2=True,
        )

        if proxies:
            self._session_async = AsyncClient(
                headers=heads,
                follow_redirects=redirects,
                timeout=timeout,
                http2=True,
                proxies=proxies,
            )

        if proxy:
            self._session_async = AsyncClient(
                headers=heads,
                follow_redirects=redirects,
                timeout=timeout,
                http2=True,
                proxy=proxy,
            )

    def request_get(self, link: str, params: dict = None, retry: int = 5) -> (Response, int, None):
        if params is None:
            params: dict = {}
        try:
            response: Response = self._session.get(link, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                raise ValueError(f"Неизвестный код ответа {response.status_code} {link}")
        except TimeoutException:
            if retry:
                time.sleep(5)
                return self.request_get(link, params=params, retry=retry - 1)
        except ConnectError:
            if retry:
                time.sleep(5)
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                return self.request_get(link, params=params, retry=retry - 1)
            else:
                raise ValueError(f"Проблемы с получением данных с ссылки {link}\n{e}")

    def request_post(self, link: str, params: dict = None, data: dict = None, retry: int = 10) -> (Response, int, None):
        if params is None:
            params = {}
        if data is None:
            data = {}
        try:
            response: Response = self._session.post(link, data=data, params=params)
            if response.status_code in [200, 302, ]:
                if response:
                    return response
            elif response.status_code in [403, 404, ]:
                return {
                    "status": "status_code",
                    "status_code": response.status_code,
                    "response": response,
                }
            elif response.status_code in [429, 503, ]:
                if response.headers.get("Retry-after"):
                    time_sleep = int(response.headers["Retry-after"])
                else:
                    time_sleep = 30
                time.sleep(time_sleep)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            elif response.status_code != 200:
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                raise ValueError(f"Неизвестный код ответа {response.status_code} {link}")
        except TimeoutException:
            if retry:
                time.sleep(5)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
        except ConnectError:
            if retry:
                time.sleep(5)
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                return {
                    "status": "error",
                    "error": "ConnectError",
                }
        except Exception as e:
            if retry:
                return self.request_post(link, params=params, data=data, retry=retry - 1)
            else:
                raise ValueError(f"Проблемы с получением данных с ссылки {link}\n{e}")
