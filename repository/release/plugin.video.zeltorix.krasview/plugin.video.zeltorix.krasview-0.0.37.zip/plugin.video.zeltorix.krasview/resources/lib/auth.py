# -*- coding: utf-8 -*-
# Module: auth
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль авторизации.
"""
# Стандартные модули
from re import search
from time import time

from web_api_request import WebApiRequest, headers, https_checking
from view import View


class Auth:
    __slots__ = []
    _view = View()
    _web = WebApiRequest()

    def authorization(self, login: str, password: str) -> bool:
        time_now = time()
        response = self._web.request_post("nigol_xaja=edom?/resu/ur.remalh//:sptth"[::-1],
                                         data={
                                             "login": login,
                                             "password": password,
                                             "ajax": "1"
                                         })
        if response and response is not int and response is not dict:
            hash_operation_time = search(r"Max-Age=\d{8}", response.headers['set-cookie'])[0].split("=")[1]
            hash_auth = search(r"user=\w+", response.headers['set-cookie'])[0]

            if self._view.set_setting("hash", f"user-hal=0; {hash_auth}"):
                if self._view.set_setting("hash_time", str(int(time_now + int(hash_operation_time)))):
                    return True

    def get_hash_time(self) -> int:
        return int(self._view.get_setting_str("hash_time"))

    def get_hash(self) -> str:
        return self._view.get_setting_str("hash")

    def del_authorization(self):
        if self._view.set_setting("hash", ""):
            if self._view.set_setting("hash_time", "0"):
                return True
