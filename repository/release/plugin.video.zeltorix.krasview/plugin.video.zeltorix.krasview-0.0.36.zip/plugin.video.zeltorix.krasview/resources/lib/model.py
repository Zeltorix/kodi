# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import loads, dumps
import re
from base64 import standard_b64decode
from time import time

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking, Proxy
from view import View
from history import History

from .auth import Auth


class Model:
    __slots__ = []

    _view = View()
    _web = WebApiRequest()
    _history = History()
    _auth = Auth()
    if _view.get_setting_bool("proxy_bool"):
        if not _view.get_setting_str("proxy_query", "script.module.zeltorix.utility"):
            Proxy().proxy_provider_reload()
        _web.__init__(
            proxy=_view.get_setting_str("proxy_query", "script.module.zeltorix.utility")
        )
    _response = _web.request_get("https://hlamer.ru/")
    if _response and type(_response) is not dict:
        _base_url = re.findall(r"https://\w+\.\w+", _response.text)[5]
    else:
        _view.output_logs(_response, 3)

    def play(self, link: str):
        link_video = re.search(
            r"/embed/\d+",
            self._web.request_get(
                https_checking(
                    link,
                    self._base_url
                )
            ).text)[0]

        if int(self._view.get_setting_str("hash_time")) > int(time()):
            headers["Cookie"] = self._auth.get_hash()
            response = WebApiRequest(headers).request_get(https_checking(link_video, self._base_url))

        else:
            response = self._web.request_get(https_checking(link_video, self._base_url))
        if re.search(r"video_Init.*?,", response.text):
            data_b64decode = re.search(r"video_Init.*?,", response.text)[0].split("'")[1]
            return {
                "type": "mpd",
                "link_play": loads(standard_b64decode(data_b64decode).decode("utf-8"))["url"],
                "add_headers": {
                    **headers,
                    "Referer": self._base_url + "/",
                    "Origin": self._base_url,
                    "Sec-Fetch-Dest": "empty",
                    "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Site": "cross-site",
                    "Accept-Encoding": "identity",
                }
            }
        else:
            soup = BeautifulSoup(response.text, features="html.parser")
            msg = soup.find("h3").text
            self._view.dialog_ok("Внимание", msg)

    def realise(self, link: str) -> dict:
        model: list = []
        category = ""
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.title.text
            list_items = soup.find(class_="video-gallery")
            if list_items:
                list_items = list_items.find_all("li")
            if list_items:
                for item in list_items:
                    if item:

                        duration_stamp = item.find(class_="ic").text.split(":")
                        if len(duration_stamp) == 3:
                            duration = int(duration_stamp[0]) * 3600 + int(duration_stamp[1]) * 60 + int(
                                duration_stamp[2])
                        elif len(duration_stamp) == 2:
                            duration = int(duration_stamp[0]) * 60 + int(duration_stamp[1])
                        else:
                            duration = 0

                        model.append({
                            "title": item.find("a")["title"],
                            "data": item.find("a")["href"],
                            "images": item.find("img")["srcset"].split(" ")[0],
                            "duration": duration,
                            "router": "play",
                            "play": True,
                        })
            next_page = soup.find(id="thread_next")
            if next_page:
                model.append({
                    "title": ">>> Следующая страница >>>",
                    "data": next_page["href"],
                    "router": "realise",
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def categories(self, link: str) -> dict:
        model: list = []
        category = ""
        response = self._web.request_get(https_checking(link + "/?category=-1", self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find(id="block-main-l").a.text
            list_items: list = soup.find(id="channel-category-line").find_all("a")
            if list_items:
                for item in list_items:
                    model.append({
                        "title": item.text,
                        "data": item["href"],
                        "router": "realise",
                    })
            next_page = soup.find(id="thread_next")
            if next_page:
                model.append({
                    "title": ">>> Следующая страница >>>",
                    "data": next_page["href"],
                    "router": "categories",
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, link: str) -> dict:
        model: list = []
        category = ""
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find("h1").text
            list_items: list = soup.find(id="channels-content").find_all("li")
            if list_items:
                for item in list_items:
                    if item:
                        if len(item.find("img")["srcset"].split(" ")) > 1:
                            images = item.find("img")["srcset"].split(" ")[0]
                        else:
                            images = ""

                        title = item.find("a")["title"]
                        if item.find(class_="channel-badge-blocked"):
                            title = f"[COLOR=red]Удалено[/COLOR] {item.find('a')['title']}"

                        model.append({
                            "title": title,
                            "data": item.find("a")["href"],
                            "images": images,
                            "router": "categories",
                        })
            next_page = soup.find(id="thread_next")
            if next_page:
                model.append({
                    "title": ">>> Следующая страница >>>",
                    "data": next_page["href"],
                    "router": "catalog",
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def menu_sub(self, link: str) -> dict:
        model: list = []
        category = ""
        response = self._web.request_get(https_checking(link, self._base_url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category: str = soup.find(id="channels-l").text
            nav_sub: list = soup.find(id="nav-sub").find_all("a")[1:]
            for item in nav_sub:
                model.append({
                    "title": item.text,
                    "data": item["href"],
                    "router": "catalog",
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def search(self, search_item: str) -> dict:
        # Наследуемый метод истории
        self._history.history_add_item(search_item)
        model: list = []
        category = ""
        response = self._web.request_post(https_checking("/kino?mode=search&ajax", self._base_url),
                                     data={"query": search_item})
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find("h1").text
            list_items: list = soup.find(id="block-main-content").find_all("li")
            if list_items:
                for item in list_items:
                    if item:

                        title = item.find("a")["title"]
                        if item.find(class_="channel-badge-blocked"):
                            title = f"[COLOR=red]Удалено[/COLOR] {item.find('a')['title']}"

                        if item.find("img"):
                            images = item.find("img")["srcset"].split(" ")[0]
                        else:
                            images = ""

                        model.append({
                            "title": title,
                            "data": item.find("a")["href"],
                            "images": images,
                            "router": "categories",
                        })
            next_page = soup.find(id="thread_next")
            if next_page:
                model.append({
                    "title": ">>> Следующая страница >>>",
                    "data": next_page["href"],
                    "router": "catalog",
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(self._base_url)
        if response and type(response) is not dict:
            if int(self._view.get_setting_str("hash_time")) < int(time()):
                model.append({
                    "title": "[COLOR=blue]Авторизация[/COLOR] ([COLOR=red]Требуется для некоторых видео[/COLOR])",
                    "router": "authorization",
                })
            soup = BeautifulSoup(response.text, features="html.parser")
            menu: list = soup.find(id='nav').find_all("a")
            for item in menu:
                data: str = item["href"]
                # if data.startswith("/help") or \
                #     data.startswith("https://hlamer.ru/people") or \
                #     data.startswith("https://hlamer.ru/thread/forum") or \
                #     data == "https://hlamer.ru/":
                #     continue
                if data.startswith("/help") or \
                        data.startswith("https://"):
                    continue
                model.append({
                    "title": item.text,
                    "data": data,
                    "router": "menu_sub",
                })
            model.append({
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            })

        else:
            self._view.output_logs(response.text, 3)
            model.append({
                "title": "Требуются выложить логи на форум, для исправления этой ошибки",
                "plot": response.text,
            })

        return {
            "category": "Меню",
            "list": tuple(model),
        }
