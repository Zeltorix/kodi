# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.09.13
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from history import History
from view import View

# Импорт модуля плагина из текущего каталога
from .model import Model
from .library import Library


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    _view = View()
    _model = Model()
    _history = History()
    _library = Library()
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    if params_dict:

        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_next":
            _view.output(_model.search(params_dict["item"], params_dict["search_start"]))
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict['router'] == "search_history":
            _view.output(_model.search(params_dict['data']))
        elif params_dict['router'] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict['router'] == "history_del_item":
            if _history.history_del_item(params_dict['data']):
                _view.output(_history.search_menu())

        # Блок работы с библиотекой
        elif params_dict['router'] == "library_folder_default":
            if _library.folder_default():
                _view.dialog_ok(
                    "Сброс папки по умолчанию",
                    "Папка возращена на домашнею папку, согласно Ваше ОС"
                )
        elif params_dict['router'] == "add_to_library":
            if _library.add_to_library(params_dict['data']):
                _view.dialog_ok(
                    "Сериал добавлен в библиотеку-источник",
                    f"Сохранено по пути {_view.get_setting_str('library_folder')}, согласно настройкам"
                )

        # elif params_dict['router'] == "library_folder_del":
        #     if _view.dialog_yesno(
        #         "Удаление папки библиотеки-источника",
        #         f"Удалить папку библиотеки-источника: {_view.get_setting_str('library_folder')} ?"
        #     ):
        #         if _view.folder_remove(path=_library.path_default, force=True):
        #             _view.dialog_ok(
        #                 "Папка библиотеки-источника удалена",
        #                 f"Папка библиотеки-источника удалена:\n{_view.get_setting_str('library_folder')}"
        #             )

        # Блок воспроизведения
        elif params_dict['router'] in ["mpd", "hls"]:
            _view.play(params_dict['data'], params_dict['router'])

        # Блок списка серий
        elif params_dict['router'] == 'realise':
            _view.output(_model.realise(params_dict['data']))

        # Блок навигации
        elif params_dict['router'] == "menu_sub":
            _view.output(_model.menu_sub(params_dict['data']))

        # Блок новое
        elif params_dict['router'] == "new":
            _view.output(_model.catalog(params_dict['data'], all_s=False))

        # Блок популярное
        elif params_dict['router'] == "popular":
            _view.output(_model.popular(params_dict['data']))

        # Блок рекомендуемое
        elif params_dict['router'] == "recommend":
            _view.output(_model.recommend(params_dict['data']))

        # Блок топ
        elif params_dict['router'] == "top":
            _view.output(_model.top(params_dict['data']))

        # Блок каталогов
        elif params_dict['router'] == "catalog":
            _view.output(_model.catalog(params_dict['data']))

        # Блок исключения
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')

    # Блок стартовый
    else:
        _view.output(_model.main())
