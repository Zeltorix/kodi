# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.09.13
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import loads
from re import findall, compile

# Импорт подключённых модулей из официальных репозиторий
from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking, Proxy
from view import View
from history import History
from text_job import ras


class Model:
    __slots__ = ["url", ]
    _web = WebApiRequest()
    _history = History()
    _view = View()
    _base_url: str = "https://allserials.cool"

    def __init__(self):
        if self._view.get_setting_str("mirror") != "":
            self.url: str = self._view.get_setting_str("mirror")
        else:
            if not self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility"):
                Proxy().proxy_provider_reload()
            # self._web.__init__(
            #     proxy=self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility")
            # )
            __response = self._web.request_get(self._base_url)
            if __response and type(__response) is not dict:
                try:
                    self.url: str = findall(r'https://.*?/', __response.text)[0]
                except:
                    self._view.output_logs(__response.text)
                    raise ValueError()
                self._view.set_setting("mirror", self.url)

    def _url_clear(self):
        self._view.set_setting("mirror", "")
        self.__init__()

    def _serials_listing(self, serials) -> list:
        model: list = []
        for serial in serials:
            plot: str = ""
            context_menu: list = []
            for dis in serial.find(class_='short-list').find_all('li'):
                if dis.find("span"):
                    for a in dis.find_all("a"):
                        context_menu.append((
                            f'{dis.find("span").text} {a.text}',
                            f"Container.Update({self._view.convert_to_url(router='catalog', data=a['href'])})"
                        ))
                else:
                    plot: str = dis.text.strip()

            # Пункт добавить в библиотеку
            context_library = self.context_to_library(serial.find(class_="short-title")["href"])
            if context_library:
                context_menu.append(context_library)

            model.append({
                "title": serial.find(class_="short-title").text.strip(),
                "data": serial.find(class_="short-title")["href"],
                "router": "realise",
                "images": https_checking(serial.find("img")["data-src"], self.url[:-1]),
                "plot": f"{plot}",
                "context_menu": tuple(context_menu),
            })

        return model

    def context_to_library(self, link: str):
        if self._view.get_setting_bool("library"):
            return (
                f"Добавить в библиотеку",
                f"RunPlugin({self._view.convert_to_url(router='add_to_library', data=link)})"
            )

    def realise_player_1(self, link: str, posters: str) -> list:
        link = "https://api.kinogram.best" + findall(r"/\w+/\w+/\d+\?\w+=.*", link)[0]
        model: list = []
        response = self._web.request_get(https_checking(link))
        if response and type(response) is not dict:
            seasons: dict = loads(
                findall(r"seasons:\[.*]", response.text)[0]
                .split("seasons:")[1])
            for season in seasons:
                for episode in season["episodes"]:
                    plot_list: list = episode["audio"]["names"]
                    plot: str = "Выбор озвучки во время воспроизведения, через настройки:\n"
                    if episode.get("dash") and self._view.get_setting_bool("mpd"):
                        data = episode["dash"]
                        num: int = 0
                        for i in plot_list:
                            plot: str = plot + f"{num + 1}. - {i}\n"
                            num += 1
                        router = "mpd"
                    else:
                        data = episode["hls"]
                        num: int = 0
                        for i in plot_list:
                            plot: str = plot + f"{num + 1}. - {i}\n"
                            num += 1
                            plot: str = plot + f"{num + 1}. - {i}\n"
                            num += 1
                        router = "hls"

                    if episode.get("duration"):
                        duration = episode["duration"]
                    else:
                        duration = 0

                    episode_model: dict = {
                        "title": episode["title"],
                        "data": data,
                        "router": router,
                        # "images": episode["poster"],
                        "images": posters,
                        "plot": plot,
                        "season": int(season["season"]),
                        "episode": int(findall(r"\d+", episode["episode"])[0]),
                        "duration": duration,
                        "play": True,
                    }

                    model.append(episode_model)

        return model

    def realise_player_2(self, link: str, posters: str) -> list:
        model: list = []
        # Наследуемый метод запроса
        response = self._web.request_get(https_checking(link))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")

        return model

    def realise(self, link: str) -> dict:
        category = ""
        model: list = []
        response = self._web.request_get(https_checking(link, self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category: str = soup.find(class_="speedbar").text.split("»")[-1].strip()
            posters: str = https_checking(soup.find(class_="fcols").find("img")["src"], self.url[:-1])
            iframe = soup.find_all("iframe", src=True)
            if iframe:
                for f in iframe:
                    if findall(r"//.*/\w+/\w+/\d+\?\w+=.*", f["src"]):
                        player_1: list = self.realise_player_1(link=https_checking(f["src"]), posters=posters)
                        if player_1:
                            model.extend(player_1)
                            break
                    elif findall(r"https?://.*:\d+/\?\w+=\d+&\w+=\w+", f["src"]):
                        player_2: list = self.realise_player_2(link=https_checking(f["src"]), posters=posters)
                        if player_2:
                            model.extend(player_2)
                            break
        else:
            self._url_clear()
            return self.realise(link)

        return {
            "category": category,
            "list": tuple(model),
            "sort": [
                24,  # SORT_METHOD_EPISODE
            ]
        }

    def popular(self, link: str) -> dict:
        model: list = []
        response = self._web.request_get(https_checking(link, self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            popular_1 = soup.find(id="owl-popular").find_all(class_="popular-item-img")
            if popular_1:
                for item in popular_1:
                    model.append({
                        "title": item.find(class_="popular-item-title").text.strip(),
                        "data": item["href"],
                        "router": "realise",
                        "images": https_checking(item.find("img")["src"], self.url[:-1]),
                    })
        else:
            self._url_clear()
            return self.popular(link)

        return {
            "category": "Популярные сериалы",
            "list": tuple(model),
        }

    def recommend(self, link: str) -> dict:
        model: list = []
        response = self._web.request_get(https_checking(link, self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            recommend = soup.find_all(class_="side-recommend-item anim")
            if recommend:
                for item in recommend:

                    context_menu: list = []
                    # Пункт добавить в библиотеку
                    context_library = self.context_to_library(item["href"])
                    if context_library:
                        context_menu.append(context_library)

                    model.append({
                        "title": item.find("img")["alt"].strip(),
                        "data": item["href"],
                        "router": "realise",
                        "images": https_checking(item.find("img")["data-src"], self.url[:-1]),
                        "context_menu": tuple(context_menu),
                    })
        else:
            self._url_clear()
            return  self.recommend(link)

        return {
            "category": "Рекомендуем посмотреть",
            "list": tuple(model),
        }

    def top(self, link: str) -> dict:
        category = ""
        model: list = []
        response = self._web.request_get(https_checking(link, self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category: str = soup.find('h2').text
            top = soup.find(class_="section-top100").find_all("a")
            if top:
                for item in top:

                    context_menu: list = []
                    # Пункт добавить в библиотеку
                    context_library = self.context_to_library(item["href"])
                    if context_library:
                        context_menu.append(context_library)

                    model.append({
                        "title": item.find(class_="side-popular-item-title").text.strip(),
                        "data": item["href"],
                        "router": "realise",
                        "images": https_checking(item.find("img")["data-src"], self.url[:-1]),
                        "plot": "\n".join([i.text.strip() for i in item.find_all(class_="side-popular-item-info")]),
                        "context_menu": context_menu,
                    })
        else:
            self._url_clear()
            return self.top(link)

        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, link: str, all_s: bool = True) -> dict:
        category = ""
        model = []
        response = self._web.request_get(https_checking(link, self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")

            check_num_page: str = link.split("/")[-2]
            if check_num_page.isalnum():
                num_page = f" -> страница №{check_num_page}"
            else:
                num_page = ""
            title = soup.find(class_="sect-title")
            if title:
                category = title.text.strip() + num_page
            else:
                category = soup.find(class_="speedbar").text.strip() + num_page

            serials = soup.find(id="dle-content").find_all(class_="short-item")
            model: list = []
            if serials:
                model.extend(self._serials_listing(serials))

            next_pages = soup.find(class_="navigation")
            if next_pages and all_s:
                last_pages = next_pages.find_all(string=compile(r"\d+"))
                start_link = next_pages.find_all("a")[1]["href"].split("page")[0]
                for page in range(1, int(last_pages[-1].text) + 1):
                    model.append({
                        "title": f"Страница ===> {page}",
                        "data": f"{start_link}/page/{page}/",
                        "router": "catalog",
                    })
                # for page in next_pages.find_all("a"):
                #     model.append({
                #         "title": f"Страница ===> {page.text.strip()}",
                #         "data": page["href"],
                #         "router": "catalog",
                #     })
        else:
            self._url_clear()
            return self.catalog(link, all_s)

        return {
            "category": category,
            "list": tuple(model),
        }

    def search(self, item, search_start: str = "1") -> dict:
        category = ""
        model = []

        if search_start == "1":
            result_from = 0
        else:
            result_from: int = int(search_start) * 12 + 1

        # Наследуемый метод истории
        self._history.history_add_item(item)

        post: dict = {
            "do": "search",
            "subaction": "search",
            "search_start": search_start,
            "full_search": "0",
            "result_from": result_from,
            "story": item,
        }
        response = self._web.request_post(https_checking("/index.php?do=search", self.url), data=post)
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")

            title = soup.find(class_="sect-title")
            if title:
                category: str = title.text.strip()
            else:
                category: str = soup.find(class_="speedbar").text.split("»")[1].strip() + f" страница №{search_start}"

            serials = soup.find(id="dle-content").find_all(class_="short-item")
            model: list = []
            if serials:
                model.extend(self._serials_listing(serials))

            next_pages = soup.find(class_="navigation")
            if next_pages:
                last_pages = next_pages.find_all(string=compile(r"\d+"))
                # start_link = next_pages.find_all("a")[1]["href"].split("page")[0]
                for page in range(1, int(last_pages[-1].text) + 1):
                    model.append({
                        "title": f"Страница ===> {page}",
                        "data": {
                            "item": item,
                            "search_start": page,
                        },
                        "router": "search_next",
                    })
                # for page in next_pages.find_all("a"):
                #     model.append({
                #         "title": f"Страница ===> {page.text.strip()}",
                #         "data": f"{item},{page.text.strip()}",
                #         "router": "search",
                #     })
        else:
            self._url_clear()
            return  self.search(item, search_start)

        return {
            "category": f"{category} => {item}",
            "list": tuple(model)
        }

    def menu_sub(self, input_data: str) -> dict:
        model: list = []
        response = self._web.request_get(https_checking(input_data, self.url))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            for item in soup.find(class_="side-box side-nav to-mob").find_all(class_="nav-col"):
                nav_title = item.find_all(class_="nav-title")
                nav_menu = item.find_all(class_="nav-menu")
                num_title: int = len(nav_title)
                for i in range(0, num_title):
                    model.append({
                        "title": f'[B][COLOR=#f8d268]{nav_title[i].text}[/COLOR][/B]',
                        "data": "",
                        "router": "",
                    })
                    all_li = nav_menu[i].find_all("li")
                    for li in all_li:
                        if li.find("a")["href"] == "/serialy-po-prosmotram-top-100.html":
                            router: str = "top"
                        else:
                            router: str = "catalog"
                        model.append({
                            "title": li.text,
                            "data": li.find("a")["href"],
                            "router": router,
                        })
        else:
            self._url_clear()
            return self.menu_sub(input_data)

        return {
            "category": "Главная",
            "list": tuple(model),
        }

    def main(self) -> dict:
        return {
            "category": "Миню навигации",
            "list": [
                {
                    "title": "Меню",
                    "data": self.url,
                    "router": "menu_sub",
                },
                {
                    "title": "Последние новинки",
                    "data": self.url,
                    "router": "new",
                },
                {
                    "title": "Популярные сериалы",
                    "data": self.url,
                    "router": "popular",
                },
                {
                    "title": "Рекомендуем посмотреть",
                    "data": self.url,
                    "router": "recommend",
                },
                {
                    "title": "Все сериалы",
                    "data": self.url,
                    "router": "catalog",
                },
                {
                    "title": "Меню поиска",
                    "data": "",
                    "router": "search_menu",
                    "plot": "Меню поиска с историей",
                    "icon": "DefaultAddonsSearch.png",
                },
            ],
        }
