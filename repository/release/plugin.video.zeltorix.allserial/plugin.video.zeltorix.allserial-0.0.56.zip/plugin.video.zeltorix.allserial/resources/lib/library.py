# -*- coding: utf-8 -*-
# Module: library
# Author: Zeltorix
# Created on: 2023.09.13
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль истории работы с поиском.
"""
# Стандартные модули
import json
from pathlib import Path
import re

# Импорт подключённых модулей из официальных репозиторий
from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from view import View

from sanitize_filename import sanitize

# Импорт модуля плагина из текущего каталога
from .model import Model


class Library:
    __slots__ = []
    web = WebApiRequest()
    view = View()
    model = Model()
    path_default: str = str(Path.joinpath(view.library_folder, "all_serial"))

    def default(self) -> bool:
        # Наследуемый метод интерфейса
        if self.view.get_setting_str("library_folder"):
            pass
        else:
            # Наследуемый метод интерфейса
            self.view.set_setting("library_folder", self.path_default)
            return True

    def folder_default(self) -> bool:
        # Наследуемый метод интерфейса
        self.view.set_setting("library_folder", self.path_default)
        return True

    def add_to_library(self, link: str) -> bool:
        # Наследуемый метод интерфейса
        path_lib: str = self.view.get_setting_str("library_folder")
        # Наследуемый метод запроса
        response = self.web.request_get(link)
        soup = BeautifulSoup(response.text, features="html.parser")
        category_source: str = soup.find(style="display: block;width: -webkit-fill-available;").text.strip()
        category_s: str = category_source.split(":")[0]
        category: str = sanitize(category_source)
        path_lib_serial = Path(
            path_lib.encode('utf-8').decode('utf-8'),
            "serials".encode('utf-8').decode('utf-8'),
            category.encode('utf-8').decode('utf-8')
        )
        iframe = soup.find_all("iframe", src=True)
        if iframe:
            for f in iframe:
                if f["src"].startswith("//api.fra"):
                    # Наследуемый метод запроса и модели
                    player_data = self.web.request_get(https_checking(f["src"]))
                    seasons: list = json.loads(re.findall(r"seasons:\[.*]", player_data.text)[0].split("seasons:")[1])
                    for season in seasons:
                        if season["season"] >= 2 and not Path.is_dir(path_lib_serial):
                            path_lib_serial = Path(
                                path_lib.encode('utf-8').decode('utf-8'),
                                "serials".encode('utf-8').decode('utf-8'),
                                category_s.encode('utf-8').decode('utf-8')
                            )
                        for episode in season["episodes"]:
                            if Path.is_dir(path_lib_serial):
                                pass
                            else:
                                Path(path_lib_serial).mkdir(parents=True, exist_ok=True)

                            season_num: str = str(season["season"])
                            if len(season_num) == 1:
                                season_num: str = "00" + season_num
                            elif len(season_num) == 2:
                                season_num: str = "0" + season_num

                            episode_num: str = str(episode["episode"])
                            if len(episode_num) == 1:
                                episode_num: str = "00" + episode_num
                            elif len(episode_num) == 2:
                                episode_num: str = "0" + episode_num

                            path_file = Path(
                                path_lib_serial,
                                f's{season_num}e{episode_num}.strm'.encode('utf-8').decode('utf-8')
                            )
                            with open(path_file, "w+") as strm:
                                # Наследуемый метод интерфейса
                                strm.write(
                                    self.view.convert_to_url(
                                        {
                                            "router": "play",
                                            "data": episode["hls"],
                                        }
                                    )
                                )

            return True
