# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""

import json
from json import dumps
from pickle import FALSE
from re import findall

from web_api_request import WebApiRequest
from view import View
from get_video_link import VideoLink


class ModelRutube:
    __slots__ = []
    _web = WebApiRequest()
    _view = View()
    _video_link = VideoLink()

    def url(self, id_: str) -> str:
        params: dict = {
            "no_404": True,
            "referer": "https://rutube.ru",
            "pver": "v2",
        }

        response = self._web.request_get("https://rutube.ru/api/play/options/" + id_, params=params)
        if response and type(response) is not dict:
            vido_dict: dict = response.json()

            # Скорее всего опустить вниз
            if vido_dict.get("detail"):
                if vido_dict["detail"]["name"] == "stream_access_fail":
                    title: str = vido_dict["detail"]["languages"][0]["title"]
                    description: str = vido_dict["detail"]["languages"][0]["description"]
                    self._view.dialog_ok(title, description)

            elif vido_dict["iframe_url"]:
                return self._video_link.mediavitrina_links("https:" + vido_dict["iframe_url"], one_link=True)
            elif vido_dict["video_balancer"]:
                return vido_dict["video_balancer"]["m3u8"]
            elif vido_dict["live_streams"] and vido_dict["live_streams"].get("hls"):
                return vido_dict["live_streams"]["hls"][0]["url"]
            elif not vido_dict["has_video"]:
                self._view.dialog_ok("Сторонний источник", vido_dict["iframe_url"])
            else:
                raise ValueError("Что то не то с ссылкой на видео")
        else:
            raise TypeError(response)

    @staticmethod
    def check_link_limit(link):
        if "limit" in link:
            if "limit=100" in link:
                link: str = link
            else:
                import re
                link: str = link.replace(re.search(r"limit=\d+", link)[0], "limit=100")
        elif "?" in link:
            link: str = link + "&limit=100"
        else:
            link: str = link + "?limit=100&sort=series_d"

        return link

    def feeds_childs(self, link: str, childs: int):
        link: str = self.check_link_limit(link)
        feeds_dict: dict = self._web.request_get(link).json()
        model_list: list = []
        for item in feeds_dict["results"]:
            if item["id"] == int(childs):
                for i in item["childs"]:
                    if i["is_paid"]:
                        continue
                    model: dict = {
                        "title": str(i["title"]),
                        "images": str(i["thumbnail_url"]),
                        "data": str(i["id"]),
                        'router': str("play"),
                        "play": True,
                    }
                    model_list.append(model)
        return {
            "category": "Контент",
            "list": tuple(model_list)
        }

    def feeds_4(self, link: str) -> dict:
        feeds_dict: dict = self._web.request_get(link).json()
        model_list: list = []
        for item in feeds_dict["results"]:
            model: dict = {
                "title": str(item["name"]),
                "data": {
                    "data": str(link),
                    "data_2": str(item["id"]),
                },
                'router': str("feeds_childs")
            }
            model_list.append(model)
        return {
            "category": feeds_dict["name"],
            "list": tuple(model_list)
        }

    def feeds_3(self, link: str) -> dict:
        feeds_dict: dict = self._web.request_get(link).json()
        model_list: list = []
        for item in feeds_dict["results"]:
            model: dict = {
                "title": str(item["title"]),
                "premiered": str(item["created_ts"].split("T")[0]),

                # Нужно проверить на всех типах
                "images": str(item["picture"]),

                "data": str(item["target"]),
                'router': str("feeds")
            }
            model_list.append(model)
        return {
            "category": "Контент",
            "list": tuple(model_list)
        }

    def feeds_2(self, link: str) -> dict:
        feeds_dict: dict = self._web.request_get(link).json()
        model_list: list = []
        for item in feeds_dict["results"]:
            model: dict = {
                "title": str(item["object"]["name"]),
                "data": str(item["object"]["content"]),
                'router': str("tags_video")
            }
            model_list.append(model)
        if feeds_dict["next"]:
            model_list.append({
                "title": f"===> Далее страница {feeds_dict['page'] + 1} ===>",
                "data": str(feeds_dict["next"]),
                'router': "tags_video"
            })
        return {
            "category": "Контент",
            "list": tuple(model_list)
        }

    def feeds(self, link: str) -> dict:
        if link.startswith("https://rutube.ru/pangolin/api/web/"):
            link: str = self.check_link_limit(link)
        elif link.startswith("/feeds/"):
            new: str = link.split("/")[2]
            link: str = f"https://rutube.ru/pangolin/api/web/feed/{new}/?limit=100"
        elif link.startswith("https://rutube.ru/api/v1/feeds/promogroup/"):
            link: str = self.check_link_limit(link)
            return self.feeds_3(link)
        elif link.startswith("/tags/video/") or link.startswith("/video/person/"):
            return self.tags_video(link, "Контент")
        elif link.startswith("https://rutube.ru/api/feeds/autowidget/"):
            return self.feeds_4(link)
        elif link.startswith("https://rutube.ru/api/feeds/"):
            link: str = self.check_link_limit(link)
            return self.feeds_2(link)
        else:
            raise ValueError(f"Что же здесь: {link} ?")
        feeds_dict: dict = self._web.request_get(link).json()
        model_list: list = []
        for item in feeds_dict["result"]["feed"]["tabs"]:
            # Платный контент
            if item["id"] in [19911, ]:
                continue
            model: dict = {
                "title": str(item["name"]),
                "data": {
                    "data": str(item["slug"]),
                    "data_2": str(link),
                },
                'router': str("feed_tabs")
            }
            model_list.append(model)
        if feeds_dict.get("next") and feeds_dict["next"]:
            model_list.append({
                "title": f"===> Далее страница {feeds_dict['page'] + 1} ===>",
                "data": str(feeds_dict["next"]),
                'router': "feed_tabs"
            })
        return {
            "category": feeds_dict["result"]["feed"]["name"],
            "list": tuple(model_list)
        }

    def feed_tabs(self, route: str, link: str) -> dict:
        model_list: list = []
        link: str = self.check_link_limit(link)
        feeds_dict: dict = self._web.request_get(link).json()
        for items in feeds_dict["result"]["feed"]["tabs"]:
            if items["slug"] == route:
                for item in items["resources"]:


                    # if item["url"].startswith("http"):
                    #     continue


                    # 54414 "Вы смотрели" нужна авторизация
                    # 54680 "Новое из подписок" нужна авторизация
                    # 53074 "RUTUBE НОВОСТИ" сторонний сайт
                    if item["id"] in [54414, 53074, 54680]:
                        continue
                    if "feeds" in item["url"]:
                        router: str = "feeds"
                    else:
                        router: str = "tags_video"
                    model: dict = {
                        "title": str(item["name"]),
                        "plot": str(item["description"]),
                        "premiered": str(item["created_ts"].split("T")[0]),
                        "data": str(item["url"]),
                        'router': router
                    }
                    model_list.append(model)
        return {
            "category": feeds_dict["result"]["feed"]["name"],
            "list": tuple(model_list)
        }

    def tags_video(self, link: str, name: str) -> dict:
        if link.startswith("https://rutube.ru/api/tags/video/") \
                or link.startswith("https://rutube.ru/api/v3/search/video") \
                or link.startswith("https://rutube.ru/api/metainfo/tv/") \
                or link.startswith("https://rutube.ru/api/metainfo/person/") \
                or link.startswith("https://rutube.ru/api/video/person/") \
                or link.startswith("https://rutube.ru/api/video/category/") \
                or link.startswith("https://rutube.ru/api/video/topic/") \
                or link.startswith("https://rutube.ru/api/video/list/public/") \
                or link.startswith("https://rutube.ru/api/playlist/custom/"):

            link: str = self.check_link_limit(link)
        elif link.startswith("/tags/video/") or link.startswith("/video/person/"):
            link: str = f"https://rutube.ru/api{link}?limit=100&sort=series_d"
        else:
            raise ValueError(f"Что же здесь: {link} ?")
        model_list: list = []
        videos_dict: dict = self._web.request_get(link).json()
        for item in videos_dict["results"]:
            # Убирает платные выдачи
            if item["is_paid"]:
                continue
            if item.get("track_id") and item["track_id"] in [13212012, ]:
                continue
            model: dict = {
                "title": str(item["title"]).replace("\n", ""),
                "plot": f'[B]{item["author"]["name"]}[/B]\n\n{item["description"]}',
                "premiered": str(item["publication_ts"].split("T")[0]),
                'genres': [str(item["category"]["name"])],
                "images": str(item["thumbnail_url"]),
                "data": str(item["id"]),
                "duration": int(item["duration"]),
                'router': "play",
                "play": True,
                "context_menu": [
                    (
                        f'Канал: {item["author"]["name"]}',
                        f"Container.Update({self._view.convert_to_url(router='channel_menu', data=str(item['author']['id']))})"
                    ),
                    (
                        f'Каталог: {item["category"]["name"]}',
                        f"Container.Update({self._view.convert_to_url(router='channel_menu', data='https://rutube.ru/api/video/category/' + str(item['category']['id']))})"
                    ),
                ],
            }
            model_list.append(model)
        if videos_dict["next"]:
            model: dict = {
                "title": f"===> Далее страница {videos_dict['page'] + 1} ===>",
                "data": str(videos_dict["next"]),
                'router': "tags_video"
            }
            model_list.append(model)
        return {
            "category": name,
            "list": tuple(model_list)
        }

    def channel_menu(self, id_channel) -> dict:
        model_list: list = [
            {
                "title": "Все видео",
                "data": f"https://rutube.ru/api/video/person/{id_channel}/?limit=100&sort=series_d",
                "router": "tags_video",
            },
            {
                "title": "Плейлисты",
                "data": f"https://rutube.ru/api/playlist/user/{id_channel}/?limit=100&sort=series_d",
                "router": "playlist_user",
            }
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }

    def playlist_user(self, link):
        videos_dict: dict = self._web.request_get(link).json()
        model_list: list = []
        if videos_dict["results"]:
            for item in videos_dict["results"]:
                # Убирает платные выдачи
                model_list.append({
                    "title": str(item["title"]).replace("\n", ""),
                    "posters": str(item["thumbnail_url"]),
                    "data": f"https://rutube.ru/api/playlist/custom/{item['id']}/videos/?limit=100&sort=series_d",
                    'router': "tags_video"
                })
            if videos_dict["next"]:
                model_list.append({
                    "title": f"===> Далее страница {videos_dict['page'] + 1} ===>",
                    "data": str(videos_dict["next"]),
                    'router': "playlist_user"
                })
        return {
            "category": "Плейлисты",
            "list": tuple(model_list)
        }

    def search(self, find_item: str) -> (list, None):
        if not find_item:
            return
        history: str = self._view.get_setting_str("history_dict")
        if history:
            history_dict: dict = json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            new_item: dict = {find_item: "search_video_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            self._view.set_setting("history_dict", json.dumps(history_dict))
        return [f"https://rutube.ru/api/v3/search/video?query={find_item}&limit=100&sort=series_d", "Найденые видео"]

    def channel_listing(self, link: str) -> dict:
        model_list: list = []
        data_dict: dict = self._web.request_get(link).json()
        for item in data_dict["results"]:
            model_list.append({
                "title": item["name"],
                "data": str(item["id"]),
                "plot": item["description"],
                "router": "channel_menu",
                "posters": item["picture"],
            })
        return {
            "category": "Найденные каналы",
            "list": tuple(model_list)
        }

    def search_channel(self, find_item: str) -> (list, None):
        if not find_item:
            return
        history: str = self._view.get_setting_str("history_dict")
        if history:
            history_dict: dict = json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            new_item: dict = {find_item: "search_channel_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            self._view.set_setting("history_dict", json.dumps(history_dict))
        return f"https://rutube.ru/api/v3/search/authors?query={find_item}&limit=100&sort=series_d"

    def search_menu(self) -> dict:
        model_list: list = [
            {
                "title": "Поиск по названию",
                "router": "search",
            },
            {
                "title": "Поиск канала",
                "router": "search_channel",
            }
        ]
        history = self._view.get_setting_str("history_dict")
        if history:
            history_dict: dict = json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            for key, value in history_dict.items():
                model_list.append({
                    "title": f"[COLOR grey]{key}[/COLOR]",
                    "router": value,
                    "data": key,
                })
        return {
            "category": "Меню поиска",
            "list": tuple(model_list)
        }

    def main(self) -> dict:
        model_list: list = []
        response = self._web.request_get("https://rutube.ru/")
        if response and response is not int and response is not dict:
            data_dict = json.loads(findall(r'\{"appSettings".*};', response.text)[0][:-1].replace("\=", "=").replace("\\x26", "&").replace("\\x60", "`").replace("\\x3c", "<").replace("\\x3e", ">").replace("\\x3d", "="))
            try:
                # data_dict = data_dict["api"]["queries"]["getLinks([\"main\",\"categories\",\"apps\",\"guide\",\"social\",\"faq\",\"info\",\"tv_channels\",\"my_group\",\"mobile_main\",\"mobile_categories\",\"mobile_apps\",\"mobile_guide\",\"mobile_social\",\"mobile_faq\",\"mobile_info\",\"mobile_tv_channels\",\"mobile_web_menu\",\"mobile_web_safe_menu\"])"]["data"]["main"]["links"]
                for k in data_dict["api"]["queries"].keys():
                    if k.startswith("getLinks"):
                        data_dict = data_dict["api"]["queries"][k]["data"]["main"]["links"]
            except:
                self._view.output_logs(f"\n\n\nВот эти данные:\n{json.dumps(data_dict, indent=2, ensure_ascii=False)}\n\n", 3)
                raise
            for item in data_dict:
                data_2: str = ""
                if item["title"] in ["Подписки", "Моё"]:
                    continue
                if item["url"].startswith("http"):
                    continue
                if item["url"].startswith("/tags/video/"):
                    data: str = (item["url"])
                    router: str = "tags_video"
                elif item["url"].startswith("/feeds/"):
                    data: str = (item["url"])
                    router: str = "feeds"
                else:
                    # Протестирую такой подход
                    data: str = f"/feeds{item['url']}"
                    router: str = "feeds"
                if item["title"] == "Каталог":
                    data: str = str("https://rutube.ru/api/v1/feeds/promogroup/382?limit=100&sort=series_d")
                    router: str = "feeds"
                if item["title"] == "Главная":
                    data = "all"
                    data_2: str = str("https://rutube.ru/pangolin/api/web/feed/new_main_page/?limit=100&sort=series_d")
                    router: str = "feed_tabs"
                model_item: dict = {
                    "title": item["title"],
                    "data": {
                        "data": str(data),
                        "data_2": data_2,
                    },
                    "router": router,
                }
                model_list.append(model_item)
        search: dict = {
            "title": "Поиск",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        }
        model_list.append(search)
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
