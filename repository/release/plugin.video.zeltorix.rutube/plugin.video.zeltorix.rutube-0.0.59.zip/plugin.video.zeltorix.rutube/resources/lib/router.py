# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View

# Импорт модуля плагина для создания модели
from .model import ModelRutube


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    view = View()
    model = ModelRutube()
    if params_dict:
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                search: list = model.search(params_dict['keyword'])
                view.output(model.tags_video(search[0], search[1]))
            else:
                # Вывод поиска, импортировано из модуля view
                find = view.dialog_text_input()
                if find:
                    search: list = model.search(find)
                    view.output(model.tags_video(search[0] , search[1]))
                else:
                    view.output(model.search_menu())

        elif params_dict['router'] == 'search_channel':
            find = view.dialog_text_input()
            if find:
                view.output(model.channel_listing(model.search_channel(find)))
            else:
                view.output(model.search_menu())

        elif params_dict['router'] == "channel_menu":
            view.output(model.channel_menu(params_dict['data']))

        elif params_dict['router'] == 'playlist_user':
            view.output(model.playlist_user(params_dict['data']))

        elif params_dict['router'] == 'search_video_history':
            search: list = model.search(params_dict['data'])
            view.output(model.tags_video(search[0], search[1]))

        elif params_dict['router'] == 'search_channel_history':
            view.output(model.channel_listing(model.search_channel(params_dict['data'])))

        elif params_dict['router'] == 'search_menu':
            view.output(model.search_menu())
        elif params_dict['router'] == "feeds":
            view.output(model.feeds(params_dict['data']))
        elif params_dict['router'] == "feed_tabs":
            view.output(model.feed_tabs(params_dict['data'], params_dict['data_2']))
        elif params_dict['router'] == "feeds_childs":
            view.output(model.feeds_childs(params_dict['data'], params_dict['data_2']))
        elif params_dict['router'] == "tags_video":
            if params_dict.get('name'):
                name = params_dict['name']
            else:
                name = "Контент"
            view.output(model.tags_video(params_dict['data'], name))
        elif params_dict['router'] == "play":
            view.play(model.url(params_dict['data']), "hls")
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        view.output(model.main())
