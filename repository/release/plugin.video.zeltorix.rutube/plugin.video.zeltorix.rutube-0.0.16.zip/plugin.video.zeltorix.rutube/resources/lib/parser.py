# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""


class ParserRuTube:
    """
    Клас для получения данных
    """
    __slots__ = []

    # _api: str = "/snoitpo/yalp/ipa/ur.ebutur//:sptth"[::-1]

    _headers = {
        "User-Agent": "plugin for KODI",
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
    }

    def rest_api(self, link: str, retry: int = 10) -> (dict, str):
        import xbmc
        xbmc.log(msg=f'Сейчас адрес: {link}', level=xbmc.LOGINFO)
        # Не стандартный модуль импортируется в addon.xml как script.module.requests
        import requests
        response = requests.get(link, headers=self._headers, timeout=5)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.rest_api(link, retry - 1)
            elif response.status_code == 404:
                detail = response.json()
                if detail["detail"]:
                    # TODO Добавить оповещение в интерфейс
                    return detail
                # TODO Добавить оповещение в интерфейс
                return "Изменился API"
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            if retry:
                # TODO Добавить оповещение в интерфейс
                from time import sleep
                from random import randint
                sleep(randint(2, 10))
                return self.rest_api(link, retry - 1)
            else:
                return "Что то не то с API..."
