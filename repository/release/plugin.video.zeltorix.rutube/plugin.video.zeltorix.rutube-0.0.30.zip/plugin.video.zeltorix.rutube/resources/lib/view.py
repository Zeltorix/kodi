# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.05.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
# Модули KODI
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon


class View:
    __slots__ = []
    # Получите URL-адрес плагина в формате plugin:// значение.
    _url = sys.argv[0]
    # Получить заготовка плагина в виде целого числа.
    _handle = int(sys.argv[1])
    _kodi_version_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    id_plugin: str = _url.split("//")[1].split("/")[0]

    def get_setting(self, id_: str) -> str:
        # return xbmcaddon.Addon(self.id_plugin).getSetting(id_)
        return xbmcaddon.Addon().getSetting(id_)

    def set_setting(self, id_: str, value: str) -> str:
        # return xbmcaddon.Addon(self.id_plugin).setSetting(id_, value)
        return xbmcaddon.Addon().setSetting(id_, value)

    @staticmethod
    def check_modules() -> None:
        def target_module(check_module: str) -> None:
            try:
                xbmcaddon.Addon(check_module)
            except (ModuleNotFoundError, RuntimeError):
                xbmcgui.Dialog().notification(
                    heading=f'Установка библиотеки {check_module}',
                    message=f'{check_module}',
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin(f'RunPlugin("plugin://{check_module}")')
        target_module('script.module.requests')
        target_module('inputstream.adaptive')
        target_module('script.module.zeltorix.utilitys')

    @staticmethod
    def error(heading: str, message: str, type_message: str = "info") -> None:
        if type_message == "warning":
            notification = xbmcgui.NOTIFICATION_WARNING
        elif type_message == "error":
            notification = xbmcgui.NOTIFICATION_ERROR
        elif type_message == "info":
            notification = xbmcgui.NOTIFICATION_INFO
        else:
            notification = xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification(
            heading=heading,
            message=message,
            icon=notification,
            time=5000,
        )

    def _convert_to_url(self, **kwargs: str) -> str:
        # Преобразование кляча и значения в ссылку данных для дополнения в виде URL
        return f'{self._url}?{urlencode(kwargs)}'

    def play(self, path: str, adaptive: bool = True) -> None:
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)

        if self.get_setting("inputstream_adaptive") == "true" and adaptive:
            # Использовать inputstream.adaptive для входящего медиапотока
            play_item.setProperty('inputstream', "inputstream.adaptive")
            # Тип манифеста медиапотока
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            # Подбор разрешения под экран
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

            play_item.setProperty('inputstream.adaptive.live_delay', '120')

            # Тип запрашиваемого контента
            play_item.setMimeType('application/x-mpegURL')

            # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
            play_item.setContentLookup(True)
            # Обновление манифеста, возможно это убирает баг с зависанием
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            # Разрешить начинать воспроизведение LIVE-потока с начала буфера, а не с его конца.
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
            # listitem.setProperty('inputstream.adaptive.stream_headers',
            #                      f'User-Agent={user_agent}')
            # listitem.setProperty('inputstream.adaptive.stream_headers',
            #                      'headername=value&User-Agent=the_user_agent&Cookie=the_cookies')

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def main(self, data: dict) -> None:
        sort_item = xbmcplugin.SORT_METHOD_NONE
        # Установка представления содержимого плагина.
        # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
        # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
        xbmcplugin.setContent(self._handle, "episodes")
        # Путь сверху между слешей("/") с добавленным названием
        xbmcplugin.setPluginCategory(self._handle, data["category"])
        # Перебор либо списка аниме, либо серий
        for item in data["list"]:
            list_item = xbmcgui.ListItem(item["title"])
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item["title"])
                if item.get("plot"):
                    vinfo.setPlot(item["plot"])
                if item.get("premiered"):
                    vinfo.setPremiered(item["premiered"])
                if item.get("genres"):
                    vinfo.setGenres(item["genres"])
                if item.get("Duration"):
                    vinfo.setDuration(item["Duration"])
                # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
                # video       For normal video
                # set         For a selection of video
                # musicvideo  To define it as music video
                # movie       To define it as normal movie
                # tvshow      If this is it defined as tvshow
                # season      The type is used as a series season
                # episode     The type is used as a series episode
                vinfo.setMediaType("video")
            else:
                list_item.setInfo('video', {'title': item["title"]})
                if item.get("plot"):
                    list_item.setInfo('video', {'plot': item["plot"]})
                if item.get("premiered"):
                    list_item.setInfo('video', {'premiered': item["premiered"]})
                if item.get("genres"):
                    list_item.setInfo('video', {'genre': item['genres']})
                if item.get("Duration"):
                    list_item.setInfo('video', {'duration': item['Duration']})
                list_item.setInfo('video', {'mediatype': 'video'})
            if item.get('posters'):
                list_item.setArt({'thumb': item['posters']})
                list_item.setArt({'icon': item['posters']})
                list_item.setArt({'fanart': item['posters']})
            if not item.get("data"):
                data = ""
            else:
                data = item['data']
            if item["router"] in ["tags_video", "feed_tabs", "feeds", "feeds_childs", "search", "search_menu", "search_video_history", "search_channel", "channel_menu", "playlist_user", "search_channel_history"]:
                if item.get('data_2'):
                    data_2 = item['data_2']
                else:
                    data_2 = ""
                url = self._convert_to_url(router=item['router'], data=data, name=item["title"], data_2=data_2)
                # Переход внутрь есть
                is_folder = True
            else:
                # Воспроизводится
                list_item.setProperty('IsPlayable', 'true')
                url = self._convert_to_url(router=item['router'], data=data)
                # Без перехода
                is_folder = False
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, sort_item)
        xbmcplugin.endOfDirectory(self._handle)

    @staticmethod
    def search() -> str:
        return xbmcgui.Dialog().input(
            'Введите название',
            type=xbmcgui.INPUT_ALPHANUM)


class ViewFakeForTest:
    __slots__ = []

    @staticmethod
    def get_setting(id_: str) -> None:
        print(f"Получение ID настройки {id_}")

    @staticmethod
    def set_setting(id_: str, value: str) -> None:
        print(f"Изменение ID настройки {id_} на значение {value}")

    @staticmethod
    def check_modules() -> None:
        def target_module(check_module: str) -> None:
            print(f"Модуль установлен: {check_module}")
        target_module('script.module.requests')
        target_module('inputstream.adaptive')
        target_module('script.module.zeltorix.utilitys')

    @staticmethod
    def error(heading: str, message: str, type_message: str = "info") -> None:
        if type_message == "warning":
            print(f"Внимание: {heading} - {message}")
        elif type_message == "error":
            print(f"Ошибка: {heading} - {message}")
        elif type_message == "info":
            print(f"Информация: {heading} - {message}")
        else:
            print(f"Информация: {heading} - {message}")
