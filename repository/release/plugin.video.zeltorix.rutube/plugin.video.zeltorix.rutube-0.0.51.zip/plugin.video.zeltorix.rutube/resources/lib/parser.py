# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""

from requests import Session


class ParserRuTube:
    """
    Клас для получения данных
    """
    __slots__ = []

    _session = Session()
    _headers = {
        "User-Agent": "plugin for KODI",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    }
    _headers_online = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.68",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Referer": "/ur.anirtivaidem.reyalp//:sptth"[::-1]
    }

    def online(self, link: str) -> dict:
        response: str = self._session.get(link).text
        from re import search
        mirror: str = search(r"url:.*'", response)[0].split("'")[1]
        link: str = mirror.replace("{{APPLICATION_ID}}", "").replace("{{PLAYER_REFERER_HOSTNAME}}", "rutube.ru").replace(
            "{{CONFIG_CHECKSUM_SHA256}}", "")
        return self._session.get(link, headers=self._headers_online).json()

    def rest_api(self, link: str, retry: int = 10) -> (dict, str):
        import xbmc
        xbmc.log(msg=f'Сейчас адрес: {link}', level=xbmc.LOGINFO)
        # Не стандартный модуль импортируется в addon.xml как script.module.requests
        response = self._session.get(link, headers=self._headers, timeout=5)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.rest_api(link, retry - 1)
            elif response.status_code == 404:
                detail = response.json()
                if detail["detail"]:
                    # TODO Добавить оповещение в интерфейс
                    return detail
                # TODO Добавить оповещение в интерфейс
                return "Изменился API"
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            if retry:
                # TODO Добавить оповещение в интерфейс
                from time import sleep
                from random import randint
                sleep(randint(2, 10))
                return self.rest_api(link, retry - 1)
            else:
                return "Что то не то с API..."
