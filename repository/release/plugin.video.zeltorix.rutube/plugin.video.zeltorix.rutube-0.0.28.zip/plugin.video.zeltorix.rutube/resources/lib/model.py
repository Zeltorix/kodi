# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""

import json

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserRuTube
    from .view import View
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.release.rutube.resources.lib.parser import ParserRuTube


    class View:
        __slots__ = []


class ModelRutube:
    __slots__ = []
    _parser = ParserRuTube()
    _view = View()

    def url(self, id_: str) -> str:
        vido_dict: dict = self._parser.rest_api("https://rutube.ru/api/play/options/" + id_)
        import xbmc
        xbmc.log(msg=f'url: {vido_dict}', level=xbmc.LOGINFO)

        # Скорее всего опустить вниз
        if vido_dict.get("detail"):
            if vido_dict["detail"]["name"] == "stream_access_fail":
                title: str = vido_dict["detail"]["languages"][0]["title"]
                description: str = vido_dict["detail"]["languages"][0]["description"]
                self._view.error(title, description)

        elif vido_dict["iframe_url"]:
            return self._parser.online("https:" + vido_dict["iframe_url"])["hls"][0]
        elif vido_dict["video_balancer"]:
            return vido_dict["video_balancer"]["m3u8"]
        elif vido_dict["live_streams"] and vido_dict["live_streams"].get("hls"):
            return vido_dict["live_streams"]["hls"][0]["url"]
        elif not vido_dict["has_video"]:
            self._view.error("Сторонний источник", vido_dict["iframe_url"])
        else:
            raise ValueError("Что то не то с ссылкой на видео")

    @staticmethod
    def check_link_limit(link):
        if "limit" in link:
            if "limit=100" in link:
                link: str = link
            else:
                import re
                link: str = link.replace(re.search(r"limit=\d+", link)[0], "limit=100")
        elif "?" in link:
            link: str = link + "&limit=100"
        else:
            link: str = link + "?limit=100"
        return link

    def feeds_childs(self, link: str, childs: int):
        import xbmc
        xbmc.log(msg=f'feeds_childs: {link}', level=xbmc.LOGINFO)
        link: str = self.check_link_limit(link)
        feeds_dict: dict = self._parser.rest_api(link)
        model_list: list = []
        for item in feeds_dict["results"]:
            if item["id"] == int(childs):
                for i in item["childs"]:
                    if i["is_paid"]:
                        continue
                    model: dict = {
                        "title": str(i["title"]),
                        "posters": str(i["thumbnail_url"]),
                        "data": str(i["id"]),
                        'router': str("play")
                    }
                    model_list.append(model)
        return {
            "category": "Контент",
            "list": tuple(model_list)
        }

    def feeds_4(self, link: str) -> dict:
        import xbmc
        xbmc.log(msg=f'feeds_4: {link}', level=xbmc.LOGINFO)
        feeds_dict: dict = self._parser.rest_api(link)
        model_list: list = []
        for item in feeds_dict["results"]:
            model: dict = {
                "title": str(item["name"]),
                "data": str(link),
                "data_2": str(item["id"]),
                'router': str("feeds_childs")
            }
            model_list.append(model)
        return {
            "category": feeds_dict["name"],
            "list": tuple(model_list)
        }

    def feeds_3(self, link: str) -> dict:
        import xbmc
        xbmc.log(msg=f'feeds_3: {link}', level=xbmc.LOGINFO)
        feeds_dict: dict = self._parser.rest_api(link)
        model_list: list = []
        for item in feeds_dict["results"]:
            model: dict = {
                "title": str(item["title"]),
                "premiered": str(item["created_ts"].split("T")[0]),

                # Нужно проверить на всех типах
                "posters": str(item["picture"]),

                "data": str(item["target"]),
                'router': str("feeds")
            }
            model_list.append(model)
        return {
            "category": "Контент",
            "list": tuple(model_list)
        }

    def feeds_2(self, link: str) -> dict:
        import xbmc
        xbmc.log(msg=f'feeds_2: {link}', level=xbmc.LOGINFO)
        feeds_dict: dict = self._parser.rest_api(link)
        model_list: list = []
        for item in feeds_dict["results"]:
            model: dict = {
                "title": str(item["object"]["name"]),
                "data": str(item["object"]["content"]),
                'router': str("tags_video")
            }
            model_list.append(model)
        if feeds_dict["next"]:
            model_list.append({
                "title": f"===> Далее страница {feeds_dict['page'] + 1} ===>",
                "data": str(feeds_dict["next"]),
                'router': "tags_video"
            })
        return {
            "category": "Контент",
            "list": tuple(model_list)
        }

    def feeds(self, link: str) -> dict:
        import xbmc
        xbmc.log(msg=f'feeds: {link}', level=xbmc.LOGINFO)
        if link.startswith("https://rutube.ru/pangolin/api/web/"):
            link: str = self.check_link_limit(link)
        elif link.startswith("/feeds/"):
            new: str = link.split("/")[2]
            link: str = f"https://rutube.ru/pangolin/api/web/feed/{new}/?limit=100"
        elif link.startswith("https://rutube.ru/api/v1/feeds/promogroup/"):
            link: str = self.check_link_limit(link)
            return self.feeds_3(link)
        elif link.startswith("/tags/video/") or link.startswith("/video/person/"):
            return self.tags_video(link, "Контент")
        elif link.startswith("https://rutube.ru/api/feeds/autowidget/"):
            return self.feeds_4(link)
        elif link.startswith("https://rutube.ru/api/feeds/"):
            link: str = self.check_link_limit(link)
            return self.feeds_2(link)
        else:
            raise ValueError(f"Что же здесь: {link} ?")
        feeds_dict: dict = self._parser.rest_api(link)
        model_list: list = []
        for item in feeds_dict["result"]["feed"]["tabs"]:
            # Платный контент
            if item["id"] in [19911, ]:
                continue
            model: dict = {
                "title": str(item["name"]),
                "data": str(item["slug"]),
                "data_2": str(link),
                'router': str("feed_tabs")
            }
            model_list.append(model)
        if feeds_dict.get("next") and feeds_dict["next"]:
            model_list.append({
                "title": f"===> Далее страница {feeds_dict['page'] + 1} ===>",
                "data": str(feeds_dict["next"]),
                'router': "feed_tabs"
            })
        return {
            "category": feeds_dict["result"]["feed"]["name"],
            "list": tuple(model_list)
        }

    def feed_tabs(self, route: str, link: str) -> dict:
        import xbmc
        xbmc.log(msg=f'feed_tabs: {route} {link}', level=xbmc.LOGINFO)
        model_list: list = []
        link: str = self.check_link_limit(link)
        feeds_dict: dict = self._parser.rest_api(link)
        for items in feeds_dict["result"]["feed"]["tabs"]:
            if items["slug"] == route:
                for item in items["resources"]:
                    # 54414 "Вы смотрели" нужна авторизация
                    # 54680 "Новое из подписок" нужна авторизация
                    # 53074 "RUTUBE НОВОСТИ" сторонний сайт
                    if item["id"] in [54414, 53074, 54680]:
                        continue
                    if "feeds" in item["url"]:
                        router: str = "feeds"
                    else:
                        router: str = "tags_video"
                    model: dict = {
                        "title": str(item["name"]),
                        "plot": str(item["description"]),
                        "premiered": str(item["created_ts"].split("T")[0]),
                        "data": str(item["url"]),
                        'router': router
                    }
                    model_list.append(model)
        return {
            "category": feeds_dict["result"]["feed"]["name"],
            "list": tuple(model_list)
        }

    def tags_video(self, link: str, name: str) -> dict:
        import xbmc
        xbmc.log(msg=f'tags_video: {link}', level=xbmc.LOGINFO)
        if link.startswith("https://rutube.ru/api/tags/video/") \
                or link.startswith("https://rutube.ru/api/v3/search/video") \
                or link.startswith("https://rutube.ru/api/metainfo/tv/") \
                or link.startswith("https://rutube.ru/api/metainfo/person/") \
                or link.startswith("https://rutube.ru/api/video/person/") \
                or link.startswith("https://rutube.ru/api/video/category/") \
                or link.startswith("https://rutube.ru/api/video/topic/") \
                or link.startswith("https://rutube.ru/api/video/list/public/") \
                or link.startswith("https://rutube.ru/api/playlist/custom/"):

            link: str = self.check_link_limit(link)
        elif link.startswith("/tags/video/") or link.startswith("/video/person/"):
            link: str = f"https://rutube.ru/api{link}?limit=100"
        else:
            raise ValueError(f"Что же здесь: {link} ?")
        model_list: list = []
        videos_dict: dict = self._parser.rest_api(link)
        for item in videos_dict["results"]:
            # Убирает платные выдачи
            if item["is_paid"]:
                continue
            if item.get("track_id") and item["track_id"] in [13212012, ]:
                continue
            model: dict = {
                "title": str(item["title"]).replace("\n", ""),
                "plot": f'[B]{item["author"]["name"]}[/B]\n\n{item["description"]}',
                "premiered": str(item["publication_ts"].split("T")[0]),
                'genres': [str(item["category"]["name"])],
                "posters": str(item["thumbnail_url"]),
                "data": str(item["id"]),
                "Duration": int(item["duration"]),
                'router': "play"
            }
            model_list.append(model)
        if videos_dict["next"]:
            model: dict = {
                "title": f"===> Далее страница {videos_dict['page'] + 1} ===>",
                "data": str(videos_dict["next"]),
                'router': "tags_video"
            }
            model_list.append(model)
        return {
            "category": name,
            "list": tuple(model_list)
        }

    def channel_menu(self, id_channel) -> dict:
        model_list: list = [
            {
                "title": "Все видео",
                "data": f"https://rutube.ru/api/video/person/{id_channel}/?limit=100",
                "router": "tags_video",
            },
            {
                "title": "Плейлисты",
                "data": f"https://rutube.ru/api/playlist/user/{id_channel}/?limit=100",
                "router": "playlist_user",
            }
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }

    def playlist_user(self, link):
        import xbmc
        xbmc.log(msg=f'playlist_user: {link}', level=xbmc.LOGINFO)
        videos_dict: dict = self._parser.rest_api(link)
        model_list: list = []
        if videos_dict["results"]:
            for item in videos_dict["results"]:
                # Убирает платные выдачи
                model_list.append({
                    "title": str(item["title"]).replace("\n", ""),
                    "posters": str(item["thumbnail_url"]),
                    "data": f"https://rutube.ru/api/playlist/custom/{item['id']}/videos/?limit=100",
                    'router': "tags_video"
                })
            if videos_dict["next"]:
                model_list.append({
                    "title": f"===> Далее страница {videos_dict['page'] + 1} ===>",
                    "data": str(videos_dict["next"]),
                    'router': "playlist_user"
                })
        return {
            "category": "Плейлисты",
            "list": tuple(model_list)
        }

    def search(self , find_item: str) -> (list, None):
        if not find_item:
            return
        history: str = self._view.get_setting("history_dict")
        if history:
            history_dict: dict =  json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            new_item: dict = {find_item: "search_video_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            self._view.set_setting("history_dict", json.dumps(history_dict))
        return [f"https://rutube.ru/api/v3/search/video?query={find_item}&limit=100", "Найденые видео"]

    def channel_listing(self, link: str) -> dict:
        model_list: list = []
        data_dict: dict = self._parser.rest_api(link)
        for item in data_dict["results"]:
            model_list.append({
                "title": item["name"],
                "data": str(item["id"]),
                "plot": item["description"],
                "router": "channel_menu",
                "posters": item["picture"],
            })
        return {
            "category": "Найденные каналы",
            "list": tuple(model_list)
        }

    def search_channel(self , find_item: str) -> (list, None):
        import xbmc
        xbmc.log(msg=f'search_channel: {find_item}', level=xbmc.LOGINFO)
        if not find_item:
            return
        history: str = self._view.get_setting("history_dict")
        if history:
            history_dict: dict =  json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            new_item: dict = {find_item: "search_channel_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            self._view.set_setting("history_dict", json.dumps(history_dict))
        return f"https://rutube.ru/api/v3/search/authors?query={find_item}&limit=100"

    def search_menu(self) -> dict:
        model_list: list = [
            {
                "title": "Поиск по названию",
                "router": "search_video",
            },
            {
                "title": "Поиск канала",
                "router": "search_channel",
            }
        ]
        history = self._view.get_setting("history_dict")
        if history:
            history_dict: dict = json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            for key, value in history_dict.items():
                model_list.append({
                    "title": f"[COLOR grey]{key}[/COLOR]",
                    "router": value,
                    "data": key,
                })
        return {
            "category": "Меню поиска",
            "list": tuple(model_list)
        }

    def main(self) -> dict:
        model_list: list = []
        data_dict: dict = self._parser.rest_api("https://rutube.ru/pangolin/api/web/navigation/v2/main/")
        for item in data_dict["result"]["main"]["links"]:
            data_2: str = ""
            if item["title"] in ["Подписки", ]:
                continue
            if item["url"].startswith("/tags/video/"):
                data: str = (item["url"])
                router: str = "tags_video"
            elif item["url"].startswith("/feeds/"):
                data: str = (item["url"])
                router: str = "feeds"
            else:
                # Протестирую такой подход
                data: str = f"/feeds{item['url']}"
                router: str = "feeds"
            if item["title"] == "Каталог":
                data: str = str("https://rutube.ru/api/v1/feeds/promogroup/382?limit=100")
                router: str = "feeds"
            if item["title"] == "Главная":
                data = "all"
                data_2: str = str("https://rutube.ru/pangolin/api/web/feed/new_main_page/?limit=100")
                router: str = "feed_tabs"
            model_item: dict = {
                "title": item["title"],
                "data": str(data),
                "data_2": data_2,
                "router": router,
            }
            model_list.append(model_item)
        search: dict = {
            "title": "Поиск",
            "router": "search_menu",
        }
        model_list.append(search)
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
