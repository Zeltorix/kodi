# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2025.04.13
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

from .model import Model


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _history = History()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            elif params_dict.get("search_start"):
                _view.output(_model.search(params_dict["search_item"]))
            else:
                input_text = _view.dialog_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        # Меню поиска
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей поиска
        elif params_dict["router"] == "search_history":
            _view.output(_model.search(params_dict["data"]))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict["data"]):
                _view.output(_history.search_menu())

        # Блок воспроизведения
        elif params_dict["router"] == "play":
            _view.play(_model.play(params_dict["data"]))

        # Блок навигации
        elif params_dict["router"] == "menu":
            _view.output(_model.menu(params_dict["data"]))
        elif params_dict["router"] == "topic":
            _view.output(_model.topic(params_dict["data"]))


        # Блок исключения
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
