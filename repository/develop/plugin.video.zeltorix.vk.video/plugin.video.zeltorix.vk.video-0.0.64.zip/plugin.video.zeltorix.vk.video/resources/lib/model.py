# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import dumps, loads, dump, load
from re import findall
from time import strftime, localtime
import datetime
from itertools import islice

from bs4 import BeautifulSoup

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from get_video_link import VideoLink
    from web_api_request import WebApiRequest, headers, https_checking
    from text_job import clear_html_tags
    from view import View
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.utility.utility.resources.lib.web_api_request import WebApiRequest, headers, https_checking
    from source.utility.utility.resources.lib.text_job import clear_html_tags
    from source.utility.utility.resources.lib.get_video_link import VideoLink


    class View:
        @staticmethod
        def output_logs(data, data_1):
            print(data)


class Model:
    __slots__ = [
        "_post",
        "_web",
        "_vkvideo",
        "_api_vkvideo",
        "_api_live_vkvideo",
    ]

    _video_link = VideoLink()
    _view = View()

    def __init__(self):
        self._post = {
            "al": "1",
            "silent_loading": "1"
        }
        self._vkvideo = "https://vkvideo.ru"
        self._api_vkvideo = "https://api.vkvideo.ru"
        self._api_live_vkvideo = "https://api.live.vkvideo.ru"
        headers["x-requested-with"] = "XMLHttpRequest"
        self._web = WebApiRequest(heads=headers)

    def play(self, url: str) -> str:
        return self._video_link.vk_link(url)

    def search(self, item: str) -> dict:
        post = {
            "q": item,
            "category": "",
            "screen_ref": "search_video_service",
        }
        response = self._web.request_post(
            f"{self._api_live_vkvideo}/method/catalog.getVideoSearchWeb2",
            data=post
        )
        if type(response) is not dict:
            response_json = loads(response.text)["response"]
            self._view.output_logs(dumps(response_json, indent=2, ensure_ascii=False), 1)
            if response_json.get("albums"):
                pass

    def live_play(self, url: str) -> str:
        self._view.output_logs(url, 1)
        api_url = f"https://api.live.vkvideo.ru/v1/blog/{url.split('/')[-1]}/public_video_stream?"
        response = self._web.request_get(link=https_checking(api_url, start_url=self._vkvideo))
        if type(response) is not dict:
            data = loads(response.text)["data"][0]
            for i in data["playerUrls"]:
                if i["type"] in ["live_ondemand_hls", "live_hls", "live_playback_hls"] and i["url"]:
                    return i["url"]
            self._view.output_logs(dumps(data, indent=2, ensure_ascii=False), 1)
            raise

    def live(self) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_get(
            https_checking(f"{self._api_live_vkvideo}/v1/catalog/schema?type=main", start_url=self._api_live_vkvideo))
        if type(response) is not dict:
            blocks = loads(response.text)["data"]["blocks"]
            self._view.output_logs(dumps(blocks, indent=2, ensure_ascii=False), 1)
            for i in blocks:
                if i.get("title") and i["title"]:
                    model.append({
                        "title": i["title"],
                        "router": "",
                        "data": i["sourceUrl"],
                    })

        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def play_list(self, link: str, next_items: str) -> dict:
        model: list = []
        group, playlist = link.split("_")
        if group.startswith("-"):
            group = group
        else:
            group = "-" + group
        post = {"al": "1", "offset": next_items, "oid": group, "section": f"playlist_{playlist}", }
        response = self._web.request_post(
            https_checking("/al_video.php?act=load_videos_silent", self._vkvideo),
            data=post
        )
        if type(response) is not dict:
            self._view.output_logs(dumps(loads(response.text), indent=2, ensure_ascii=False), 1)
            payload = loads(response.text)["payload"][1][0][f"playlist_{playlist}"]
            for i in payload["list"]:
                if int(i[19]):
                    title = clear_html_tags(str(i[3]))
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
                    model.append({
                        "title": title,
                        "router": "play",
                        "data": str(f"{i[0]}_{i[1]}"),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": int(i[19]),
                        "images": str(i[2]),
                        "plot": f"{time_stamp}\n{title}",
                        "play": True,
                    })
            if next_items is None:
                next_items = 0
            if payload['list']:
                model.append({
                    "title": "=>=>=>",
                    "router": "play_list",
                    "data": {
                        "data": str(link),
                        "data_2": str(int(next_items) + int(payload["count"] + 1)),
                    },
                })
        return {
            "category": "",
            "list": tuple(model)
        }

    def list(self, url: str, next_from: str = "") -> dict:
        model: list = []
        category: str = ""
        if next_from:
            self._post["next_from"] = next_from
        response = self._web.request_post(
            link=https_checking(url, start_url=self._vkvideo),
            data=self._post,
        )
        if type(response) is not dict:
            json_data = loads(response.text)
            payload = loads(json_data["payload"][1][0])
            if payload.get("catPlaylists"):
                cat = next(iter(payload["catPlaylists"].values()))
                if cat.get("title"):
                    category = next(iter(payload["catPlaylists"].values()))["title"]
            self._view.output_logs(dumps(payload, indent=2, ensure_ascii=False), 1)
            if payload.get("videos"):
                videos = payload["videos"]
                for i in videos:
                    # Старый формат
                    if type(i) is list:
                        title = clear_html_tags(i[3])
                        router = "play"
                        time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
                        data = f"{i[0]}_{i[1]}"
                        duration = int(i[19])
                        images = i[2]
                    # Новый формат?
                    elif type(i) is dict:
                        title = clear_html_tags(i["3"])
                        router = "live_play"
                        time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i["9"]))
                        # Лучше переписать!
                        data = i["20"]
                        duration = 0
                        images = i["2"]
                    else:
                        raise
                    model.append({
                        "title": title,
                        "router": router,
                        "data": data,
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": duration,
                        "images": images,
                        "plot": f"{time_stamp}\n{title}",
                        "play": True,
                    })
            elif payload.get("playlists"):
                play_lists = payload["playlists"]
                for i in play_lists:
                    if i[1] == 1:
                        title = clear_html_tags(str(i[0]))
                        router = "play"
                        play = True
                        data_link = i[7]
                    elif payload["context"]["ref"] == "video_live_categories":
                        watching = json_data["langKeys"]["local"]["video_live_N_watching"][1]
                        title = clear_html_tags(f"{i[0]} ({watching % i[1]})")
                        router = "video_live_categories"
                        play = False
                        data_link = i[3]
                    else:
                        title = clear_html_tags(f"{i[0]} ({i[1]} видео)")
                        router = "play_list"
                        play = False
                        data_link = f"{i[8]}_{i[6]}"
                    model.append({
                        "title": title,
                        "router": router,
                        "data": data_link,
                        "plot": title,
                        "images": i[2],
                        "play": play,
                    })
            else:
                raise
            next_page = payload["nextFrom"]
            if next_page:
                model.append({
                    "title": "=>=>=>",
                    "router": "list",
                    "data": {
                        "data": url,
                        "next_from": next_page
                    }
                })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, url: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_post(link=https_checking(url, start_url=self._vkvideo), data=self._post)
        if type(response) is not dict:
            payload = loads(loads(response.text)["payload"][1][0])
            if not payload["tabList"]:
                return self.list(url)
            self._view.output_logs(dumps(payload, indent=2, ensure_ascii=False), 1)
            cat = next(iter(payload["catPlaylists"].values()))
            if cat.get("title"):
                category = next(iter(payload["catPlaylists"].values()))["title"]
            tab_list: list = payload["tabList"]
            for i in tab_list:
                if "interactive" in i["url"]:
                    continue
                model.append({
                    "title": i["name"],
                    "data": i["url"],
                    "router": "list",
                })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(link=https_checking(self._vkvideo))
        if type(response) is not dict:
            if True:
                model.append({
                    "title": "[COLOR=blue]Авторизация[/COLOR]",
                    "router": "auth",
                })
            category: str = "Меню"
            soup = BeautifulSoup(response.text, "html.parser")
            find_menu_list: list = soup.find_all(class_="MenuList--redesigned")[0].find_all("a")
            for i in find_menu_list:
                if "live." in i["href"]:
                    router = "live"
                elif "interactives" in i["href"]:
                    continue
                else:
                    router = "catalog"
                model.append({
                    "title": i["data-title"],
                    "data": {
                        "data": i["href"],
                    },
                    "router": router,
                })
            model.append({
                "title": "Меню поиска",
                "router": "search",
            })
        else:
            category: str = "Проблема с доступом"
        return {
            "category": category,
            "list": tuple(model),
        }
