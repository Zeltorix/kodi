# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import dumps, loads, dump, load
from re import findall
from time import strftime, localtime
import datetime
from itertools import islice

from bs4 import BeautifulSoup

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from get_video_link import VideoLink
    from web_api_request import WebApiRequest, headers, https_checking
    from text_job import clear_html_tags
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.utility.utility.resources.lib.web_api_request import WebApiRequest, headers, https_checking
    from source.utility.utility.resources.lib.text_job import clear_html_tags
    from source.utility.utility.resources.lib.get_video_link import VideoLink


class Model:
    __slots__ = [
        "_post",
        "_web",
        "_vkvideo",
    ]

    _video_link = VideoLink()

    def __init__(self):
        self._post = {
            "al": "1",
            "silent_loading": "1"
        }
        self._vkvideo = "https://vkvideo.ru"
        headers["x-requested-with"] = "XMLHttpRequest"
        self._web = WebApiRequest(heads=headers)

    def play(self, url: str) -> str:
        return self._video_link.vk_link(url)

    def list(self, url: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_post(link=https_checking(url, start_url=self._vkvideo), data=self._post)
        videos = loads(loads(response.text)["payload"][1][0])["videos"]
        print(dumps(videos, indent=2, ensure_ascii=False))
        for i in videos:
            title = clear_html_tags(str(i[3]))
            time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
            model.append({
                        "title": title,
                        "router": "play",
                        "data": str(f"{i[0]}_{i[1]}"),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": int(i[19]),
                        "images": str(i[2]),
                        "plot": f"{time_stamp}\n{title}",
                        "play": True,
                    })
        return {
            "category": category,
            "list": tuple(model),
        }

    def catalog(self, url: str) -> dict:
        model: list = []
        category: str = ""
        response = self._web.request_post(link=https_checking(url, start_url=self._vkvideo), data=self._post)
        tab_list = loads(loads(response.text)["payload"][1][0])["tabList"]
        for i in tab_list:
            model.append({
                "title": i["name"],
                "data": {
                    "data": i["url"],
                },
                "router": "list",
            })
        return {
            "category": category,
            "list": tuple(model),
        }

    def main(self) -> dict:
        model: list = []
        response = self._web.request_get(link=https_checking(self._vkvideo))
        soup = BeautifulSoup(response.text, "html.parser")
        find_menu_list = soup.find_all(class_="MenuList--redesigned")[0].find_all("a")
        for i in find_menu_list:
            model.append({
                "title": i["data-title"],
                "data": {
                    "data": i["href"],
                },
                "router": "catalog",
            })
        return {
            "category": "Меню",
            "list": tuple(model),
        }
