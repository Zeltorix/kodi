# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2024.08.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

# Импорт модуля плагина
from .model import Model
# from .library import Library


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _history = History()
    # _library = Library()

    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict['router'] == "search_history":
            _view.output(_model.search(params_dict['data']))
        elif params_dict['router'] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict['router'] == "history_del_item":
            if _history.history_del_item(params_dict['data']):
                _view.output(_history.search_menu())

        # Блок воспроизведения
        elif params_dict["router"] in ["hls", "mpd"]:
            _view.play(params_dict["data"], params_dict["router"])

        # Блок вывода списков
        elif params_dict["router"] == "ongoing":
            _view.output(_model.ongoing())
        elif params_dict["router"] == "catalog":
            _view.output(_model.catalog(params_dict["data"]))
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
