# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.08.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from time import time
from json import loads, dumps, load, dump

from web_api_request import WebApiRequest, headers, https_checking
from view import View
from history import History


class Model:
    __slots__ = []
    _view = View()
    _history = History
    _web = WebApiRequest()
    _base_url = "https://shikimori.one"
    _api = _base_url + "/api"
    _params = {
        "limit": "50",
    }

    def ongoing(self):
        category = "Онгоинги аниме"
        params = {
            **self._params,
            "status": "ongoing",
            "order": "aired_on",
        }
        link = "/animes"
        # link = "https://shikimori.one/api/animes?status=ongoing;limit=50;order=aired_on"
        return self.__anime_list(params=params, link=link, category=category)

    def __anime_list(self, link: str, params: dict, category: str):
        model: list = []
        response = self._web.request_get(
            https_checking(
                link,
                self._api,
            ),
            params=params,
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)
            for item in json_data:
                if item["russian"]:
                    title = f"{item['russian']} ({item['name']})"
                else:
                    title = item["name"]
                model.append({
                    "title": title,
                    "data": item["id"],
                    "premiered": item["aired_on"],
                    "dateadded": item["aired_on"],
                    "plot": item["kind"],
                    "router": "anime",
                    "images": https_checking(item["image"]["original"], self._base_url),
                })
        return {
            "category": category,
            "list": tuple(model),
        }

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)

    def main(self) -> dict:
        model = [
            {
                "title": "Онгоинги аниме",
                "router": "ongoing",
            },
            {
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            },
        ]
        return {
            "category": "Меню",
            "list": tuple(model),
        }
