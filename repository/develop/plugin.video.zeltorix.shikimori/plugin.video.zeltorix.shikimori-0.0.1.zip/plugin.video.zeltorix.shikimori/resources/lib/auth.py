# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.08.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
from time import time
from hashlib import sha1
from uuid import getnode
from json import loads, dumps


from view import View
from web_api_request import WebApiRequest, headers, https_checking
from .model import Model


class Auth:
    __slots__ = []
