# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2025.04.14
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import load, dump, loads, dumps
from re import findall
from time import time
from base64 import standard_b64decode
from math import ceil

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, https_checking, Proxy, headers
from view import View
from history import History
from text_job import clear_html_tags


class Model:
    __slots__ = [
        "_host",
        "_view",
        "_web",
        "_history",
    ]

    def __init__(self):
        self._host: str = "https://dreamerscast.com"
        self._view = View()
        self._web = WebApiRequest()
        self._history = History()

    @staticmethod
    def play(data):
        return {
            "type": "mpd",
            "link_play": data,
        }

    @staticmethod
    def _releases_items(items: list) -> list:
        model: list = []
        for i in items:
            model.append({
                "title": i["russian"],
                "data": i["url"],
                "genres": i["genres"].split(", "),
                "year": i["dateissue"],
                "router": "release",
                "images": https_checking(i["image"]),
            })
        return model

    def _releases(self,
                  *,
                  category: str = "",
                  search: str = None,
                  status: int = 0,
                  ) -> dict:
        model: list = []
        post: dict = {
            "search": search,
            "status": status,
            "pageNumber": 1,
            "pageSize": 16,
        }
        response = self._web.request_post(
            https_checking(
                self._host,
            ),
            data=post,
        )
        if response and type(response) is not dict:
            response_data = loads(response.text)
            model.extend(self._releases_items(response_data["releases"]))
            for i in range(2, ceil(response_data["count"] / 16) + 1):
                post["pageNumber"] = i
                response = self._web.request_post(
                    https_checking(
                        self._host,
                    ),
                    data=post,
                )
                model.extend(self._releases_items(loads(response.text)["releases"]))
        else:
            self._view.output_logs(response.text, 3)
            raise

        if status in [0, 2]:
            return {
                "category": category,
                "list": tuple(model),
                "sort": [
                    10,  # SORT_METHOD_TITLE_IGNORE_THE
                ],
            }
        else:
            return {
                "category": category,
                "list": tuple(model),
            }

    def releases(self, status: (str, int)) -> dict:
        if int(status) == 0:
            category: str = "Все"
        elif int(status) == 1:
            category: str = "Онгоинги"
        elif int(status) == 2:
            category: str = "Законченные"
        else:
            raise ValueError(status)
        return self._releases(
            category=category,
            status=int(status),
        )

    def search(self, search_item) -> dict:
        self._history.history_add_item(search_item)
        return self._releases(
            category=f"Поиск => {search_item}",
            search=search_item,
            status=0,
        )

    def release(self, url: str) -> dict:
        model: list = []
        response = self._web.request_get(
            https_checking(
                url,
                self._host
            ),
        )
        if response and type(response) is not dict:
            response_text = response.text
            soup = BeautifulSoup(response_text, "html.parser")
            category: str = soup.find("h3").text
            plot: str = clear_html_tags(soup.find("div",{"class":"postDesc"}).text)
            series = standard_b64decode(
                findall(r'atob\(".*\)',
                        response_text)[0].replace('atob("', '').replace('")', '')
            ).decode('utf-8').split("||||")
            num: int = 1
            for i in series:
                model.append({
                    "title": f"Серия {num}",
                    "data": i,
                    "router": "play",
                    "plot": plot,
                    "images": https_checking(soup.find_all("img")[2]["src"]),
                    "play": True,
                })
                num += 1
        else:
            self._view.output_logs(response, 3)
            raise
        return {
            "category": category,
            "list": tuple(model),
        }

    @staticmethod
    def main() -> dict:
        model: list = [
            {
                "title": "Новые серии",
                "router": "releases",
                "data": "1",
                "plot": "От недавно вышедших к более старым",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Законченные",
                "router": "releases",
                "data": "2",
                "plot": "По алфавиту",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Все аниме",
                "router": "releases",
                "data": "0",
                "plot": "По алфавиту",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Поиск",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ]
        return {
            "list": tuple(model),
            "category": "Меню",
        }
