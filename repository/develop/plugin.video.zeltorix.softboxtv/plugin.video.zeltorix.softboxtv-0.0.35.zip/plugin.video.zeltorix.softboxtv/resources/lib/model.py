# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.08.25
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from re import findall
from json import loads, dumps
from urllib.parse import parse_qsl
from base64 import standard_b64decode

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from history import History
from view import View
from text_job import date_time_to_local, ras
from kodik import Kodik

from .cache import Cache


class Model:
    __slots__ = [
        "_base_url",
        "_web",
        "_view",
        "_history",
        "_kodik",
        "_cache",
    ]

    def __init__(self):
        self._base_url: str = ras("v02bj5CZoZHd49mY0Z2bz9yL6MHc0RHa")
        headers["Referer"] = self._base_url + "/"
        self._web = WebApiRequest(headers)
        self._view = View()
        self._history = History()
        self._kodik = Kodik()
        self._cache = Cache()

    def kodik_play(
            self,
            link: str,
            season_num: str,
            episode: str,
            translate: str = None,
    ):
        return {
            "type": "hls",
            "link_play": self._kodik.kodik_play(
                link,
                season_num,
                episode,
                translate=translate,
            ),
        }

    def realise(self,
                link: str,
                translate_num: int = None,) -> dict:
        if translate_num is None:
            translate_num = 0
        duration: int = 0
        response = self._cache.web(https_checking(link, self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            if soup.find(class_="page__subcol-side2"):
                li = findall(r"\d+", soup.find(class_="page__subcol-side2").find_all("li")[0].text)
                if li:
                    duration: int = int(li[0]) * 60

            if soup.find(class_="pmovie__poster"):
                images: str = soup.find(class_="pmovie__poster").find("img")["data-src"]
            else:
                images: str = ""

            if soup.find(class_="page__text"):
                plot: str = soup.find(class_="page__text").text
            else:
                plot: str = ""

            link_seasons: str = "https:" + soup.find("meta", property="ya:ovs:content_url")["content"]
            category: str = soup.find(class_="speedbar").text.split("»")[-1].strip()
            return self._kodik.kodik_list(
                link=link_seasons,
                translate_num=translate_num,
                link_site=link,
                plot=plot,
                duration=duration,
                images=images,
                category=category
            )

    def catalog(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._cache.web(https_checking(link, self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            if soup.find(class_="sect__title"):
                category: str = soup.find(class_="sect__title").text
            else:
                category: str = soup.find("h1").text

            if findall(r"\d+", link.split("/")[-2]):
                category = f"{category} => Страница №{link.split('/')[-2]}"

            list_items: list = soup.find_all("article", class_="card d-flex")

            if list_items:
                for item in list_items:
                    if item:
                        context_menu: list = []
                        img: str = item.find("img")["data-src"]
                        plot: str = item.find("div", class_="card__desc").find("p", class_="card__text").text

                        if item.find(lass="ws-nowrap"):
                            genres: list = [genre.text for genre in item.find("li", lass="ws-nowrap").find_all("a")]
                        else:
                            genres: list = []

                        for dis in item.find(class_="card__list").find_all("li"):
                            if dis.find("span"):
                                for a in dis.find_all("a"):
                                    context_menu.append((
                                        f'{dis.find("span").text} {a.text}',
                                        f"Container.Update({self._view.convert_to_url(router='catalog', data=a['href'])})"
                                    ))

                        model.append({
                            "title": item.find("h2").text,
                            "data": item.find("a")["href"],
                            "images": https_checking(img, self._base_url),
                            "plot": plot,
                            "genres": genres,
                            "context_menu": context_menu,
                            "router": "realise",
                        })
            if soup.find(class_="pagination__pages") and soup.find(class_="pagination__pages").find_all("a"):
                link_pages = link.split("page/")
                if link_pages:
                    link: str = link_pages[0]
                for page in range(1, int(soup.find(class_="pagination__pages").find_all("a")[-1].text)):
                    model.append({
                        "title": f"Страница №{page}",
                        "data": https_checking(f"{link}page/{page}/", self._base_url),
                        "router": "catalog",
                    })

        return {
            "category": category,
            "list": tuple(model),
        }

    def menu_sub(self, input_data: str) -> dict:
        model: list = []
        response = self._cache.web(https_checking(input_data, self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            for item in soup.find(class_="side-block__content d-flex jc-space-between").find_all(class_="nav-col"):
                nav_title = item.find_all(class_="nav-title")
                nav_menu = item.find_all(class_="nav-menu")
                num_title: int = len(nav_title)
                for i in range(0, num_title):
                    model.append({
                        "title": f'[B][COLOR=#f8d268]{nav_title[i].text}[/COLOR][/B]',
                        "data": "",
                        "router": "",
                    })
                    all_li = nav_menu[i].find_all("li")
                    for li in all_li:
                        model.append({
                            "title": li.text,
                            "data": li.find("a")["href"],
                            "router": "catalog",
                        })
            model.append({
                "title": f'[B][COLOR=#f8d268]По алфавиту[/COLOR][/B]',
                "data": "",
                "router": "",
            })
            for item in soup.find(class_="ac-catalog").find_all("a"):
                model.append({
                    "title": item.text,
                    "data": item["href"],
                    "router": "catalog",
                })

        return {
            "category": "Главная",
            "list": tuple(model),
        }

    def _collections_items(self, response) -> list:
        model: list = []
        soup = BeautifulSoup(response, features="html.parser")
        for item in soup.find(id="dle-content").find_all(class_="collection__item"):
            model.append({
                "title": f'{item.find(class_="collection__title").text} ({item.find(class_="collection__label").text})',
                "data": item["href"],
                "plot": "Обновлено: " + item.find(class_="collection__date").text,
                "icon": https_checking(item.find("img")["data-src"], self._base_url),
                "router": "catalog",
                "premiered": date_time_to_local(item.find(class_="collection__date").text,
                                                format_input="%d-%m-%Y, %H:%M"),
            })
        return model

    def collections(self, link: str) -> dict:
        model: list = []
        category: str = ""
        response = self._cache.web(https_checking(link, self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            category: str = soup.find(class_="sect__title").text
            model.extend(self._collections_items(response))
            if soup.find(class_="pagination__pages"):
                if soup.find(class_="pagination__pages").find_all("a"):
                    for page in range(2, int(soup.find(class_="pagination__pages").find_all("a")[-1].text) + 1):
                        response_page = self._cache.web(https_checking(f"{link}page/{page}", self._base_url),
                                                        time_expires=self._cache.time_limits("all"))
                        if response_page and type(response_page) is not dict:
                            model.extend(self._collections_items(response_page))

        return {
            "category": category,
            "list": tuple(model),
            "sort": [
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def search(self, item: str) -> dict:
        self._history.history_add_item(item)
        return self.catalog(f"/search/{item}/")

    def main(self) -> dict:
        model: list = []
        response = self._cache.web(https_checking(self._base_url), time_expires=self._cache.time_limits("all"))
        if response and type(response) is not dict:
            soup = BeautifulSoup(response, features="html.parser")
            menu: list = soup.find("nav").find_all("a")
            for item in menu:
                menu_link: str = item["href"]
                if menu_link == "/":
                    model.append({
                        "title": item.text,
                        "data": self._base_url,
                        "router": "menu_sub",
                    })
                elif menu_link == "/collections/":
                    model.append({
                        "title": item.text,
                        "data": menu_link,
                        "router": "collections",
                    })
                elif menu_link == "/ongoings.html":
                    continue
                else:
                    model.append({
                        "title": item.text,
                        "data": menu_link,
                        "router": "catalog",
                    })
        model.append({
            "title": "Поиск",
            "data": "",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        })
        return {
            "category": "Меню",
            "list": tuple(model),
        }
