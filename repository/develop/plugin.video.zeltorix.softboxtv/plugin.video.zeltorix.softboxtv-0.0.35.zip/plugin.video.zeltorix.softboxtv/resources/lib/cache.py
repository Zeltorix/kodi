# -*- coding: utf-8 -*-
# Module: cache
# Author: Zeltorix
# Created on: 2024.08.18
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
from web_api_request import WebCache


class Cache(WebCache):
    def time_limits(self, item: str) -> int:
        if item == "all":
            return self._view.get_setting_int("cache_time_default") * 60
        else:
            raise ValueError(f"Такого значения нет: {item}")
