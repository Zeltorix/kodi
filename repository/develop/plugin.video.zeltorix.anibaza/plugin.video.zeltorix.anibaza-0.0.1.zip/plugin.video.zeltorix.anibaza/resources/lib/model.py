# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from datetime import datetime, timedelta
from pathlib import Path
from time import time
from json import load, dump, dumps


from web_api_request import WebApiRequest, https_checking
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from get_video_link import VideoLink
from view import View, ViewDialogProgressBG
from history import History

from .auth import Auth
from .cache import Cache


class Model:
    __slots__ = [
        "api",
        "cdn",
        "_plugin_folder",
        "_plugin_cache",
        "_file_favorites",
        "_view",
        "_cache",
    ]

    _web = WebApiRequest()
    _view_dialog_progress_bg = ViewDialogProgressBG()
    _history = History()
    _video_link = VideoLink()
    _auth = Auth()

    def __init__(self):
        self._cache = Cache()
        self._view = View()
        self.cdn: str = "https://a.anibaza.com"
        self.api: str = self.cdn + "/api/"
        self._plugin_folder = Path(self._view.plugin_folder)

    def _release(self, id_anime: str, time_expires: int) -> dict:
        params: dict = {
            "populate": "torrents,"
                        "screenshots,"
                        "roleList,"
                        "roleList.komanda,"
                        "preview,"
                        "zhanries,"
                        "episodes.episode,"
                        "studiyas,"
                        "episodes.episode.preview,"
                        "stuffs,"
                        "stuffs.roles,"
                        "stuffs.hide"
        }
        model: list = []
        data = None
        category: str = "Проблемы с получением реализа"

        # response = self._cache.web_cache(self.url + link, params, time_expires=time_expires)
        response = self._web.request_get(f"{self.api}animes/{id_anime}", params)
        if response and type(response) is not dict:
            data = response.json()

        if data:
            attributes = data["data"]["attributes"]
            category: str = attributes["titleRu"]
            images: str = https_checking(
                self.cdn + attributes["preview"]["data"]["attributes"]["url"]
            )
            plot: str = " ".join([children["children"][0]["text"] for children in attributes["desc"]])

            if response["player"]["list"]:
                for episode in response["player"]["list"].values():
                    if episode["preview"]:
                        images: str = https_checking(self.cdn + episode["preview"])
                    model_episode: dict = {
                        "premiered": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "dateadded": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "images": images,
                        "plot": plot,
                        "duration": response["type"]["length"],
                        "router": "play",
                        "play": True,
                    }

        return {
            "list": tuple(model),
            "category": category,
        }

    def _listing_item(self, item: dict):
        context_menu: list = []
        genres: list = []
        attributes: dict = item["attributes"]
        id_title = item["id"]
        self._view.output_logs(dumps(item, indent=2), 1)
        if attributes["zhanries"]:
            genres.extend([i["attributes"]["shortName"] for i in attributes["zhanries"]["data"]])

        # if item["team"]:
        #     if item["team"]["voice"]:
        #         genres.extend(item["team"]["voice"])
        #         for voice in item["team"]["voice"]:
        #             context_menu.append((
        #                 f"Озвучка: {voice}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=voice)})"
        #             ))
        #
        #     if item["team"]["translator"]:
        #         genres.extend(item["team"]["translator"])
        #         for translator in item["team"]["translator"]:
        #             context_menu.append((
        #                 f"Переводчик: {translator}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=translator)})"
        #             ))
        #
        #     if item["team"]["editing"]:
        #         genres.extend(item["team"]["editing"])
        #         for editing in item["team"]["editing"]:
        #             context_menu.append((
        #                 f"Субтитры: {editing}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=editing)})"
        #             ))
        #
        #     if item["team"]["decor"]:
        #         genres.extend(item["team"]["decor"])
        #         for decor in item["team"]["decor"]:
        #             context_menu.append((
        #                 f"Оформитель: {decor}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=decor)})"
        #             ))
        #
        #     if item["team"]["timing"]:
        #         genres.extend(item["team"]["timing"])
        #         for timing in item["team"]["timing"]:
        #             context_menu.append((
        #                 f"Тайминг: {timing}",
        #                 f"Container.Update({self._view.convert_to_url(router='list_for', attributes='team', text_item=timing)})"
        #             ))
        #
        # if self._auth.get_session_id():
        #     if not favorites_online:
        #         context_menu.append((
        #             f"Добавить в онлайн избранное",
        #             f"Container.Update({self._view.convert_to_url(router='favorites_online_add', attributes=item['id'])})"
        #         ))
        #
        #     if favorites_online:
        #         context_menu.append((
        #             f"Удалить из онлайн избранного",
        #             f"Container.Update({self._view.convert_to_url(router='favorites_online_del', attributes=item['id'])})"
        #         ))
        #
        # if self._view.get_setting_bool("download_bool"):
        #     context_menu.append((
        #         f"Загрузить целиком с сервера",
        #         f"RunPlugin({self._view.convert_to_url(router='download_full_anime', attributes=item['code'])})"
        #     ))
        #     context_menu.append((
        #         f"Загрузить торрент",
        #         f"Container.Update({self._view.convert_to_url(router='torrents', attributes=item['code'])})"
        #     ))

        # if attributes["updatedAt"]:
        #     premiered = str(datetime.fromtimestamp(attributes["updatedAt"]))
        # else:
        #     premiered = 0
        premiered = attributes["updatedAt"]

        return {
            "attributes": id_title,
            "title": attributes["titleRu"],
            "images": https_checking(self.cdn + attributes["preview"]["data"]["attributes"]["url"]),
            "premiered": premiered,
            "dateadded": premiered,
            "genres": genres,
            "plot": " ".join([children["children"][0]["text"] for children in attributes["desc"]]),
            "context_menu": context_menu,
            "router": "release",
        }

    def _listing(self,
                 time_expires: int,
                 category: str = "",
                 limit: int = 50
                 ) -> dict:
        model: list = []
        params: dict = {
            "populate": "preview,"
                        "zhanries",
            "sort": "updatedAt:DESC",
            "pagination[start]": "0",
            "pagination[limit]": limit,
        }
        data = None
        # response = self._cache.web_cache(self.api + link, params, time_expires=time_expires)
        response = self._web.request_get(self.api + "animes", params)
        if response and type(response) is not dict:
            data = response.json()

        if data:
            data_list = data["data"]
            self._view_dialog_progress_bg.create(category, "")
            self._view_dialog_progress_bg.update(0, "")
            num = 1
            sum_data = len(data_list)
            for item in data_list:
                self._view_dialog_progress_bg.update(int((num / (sum_data + 1)) * 100), "")
                model.append(
                    self._listing_item(
                        item,
                    )
                )
                num += 1
            self._view_dialog_progress_bg.close()

        return {
            "list": tuple(model),
            "category": category,
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    @staticmethod
    def play(link: str) -> dict:
        return {
            "type": "hls",
            "link_play": link,
        }

    def youtube_id(self, youtube_id: str) -> dict:
        return {
            "type": False,
            "link_play": self._video_link.youtube_link("https://www.youtube.com/watch?v=" + youtube_id),
        }

    def release(self, code: str) -> dict:
        params: dict = {
            "code": code,
        }
        return self._release(link="title", params=params, time_expires=self._cache.cache_limits("release"))

    def favorites_online_add(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params_favorites: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "filter": "id",
                **self._limits("all"),
            }
            response_favorites = self._web.request_get(https_checking(self.url + "user/favorites"),
                                                       params=params_favorites)

            if response_favorites and type(response_favorites) is not dict:
                for i in response_favorites.json()["list"]:
                    if i["id"] == int(id_):
                        self._view.dialog_ok("Онлайн избранно", "Данное аниме уж есть в списке!")
                        return False

            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            post: dict = {}
            response = self._web.request_put(https_checking(self.url + "user/favorites"), params=params, data=post)

            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites_online_del(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            response = self._web.request_delete(https_checking(self.url + "user/favorites"), params=params)

            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites(self) -> dict:
        model: list = []
        if self._auth.get_session_id() and self._auth.get_session_id()["expires"] > time():
            model.append({
                "title": f"[COLOR=red]Онлайн избранное расконектится через: "
                         f"{str(timedelta(seconds=self._auth.get_session_id()['expires'] - time()))}[/COLOR]",
                "dateadded": datetime.fromtimestamp(self._auth.get_session_id()["expires"]).strftime(
                    "%Y-%m-%d %H:%M:%S"),
            })
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                **self._limits("all"),
            }
            model.extend(self._listing(
                link="user/favorites",
                params=params,
                time_expires=0,
                category=f"Избранное",
                title_color="blue",
                favorites_online=True)["list"])

        if self._file_favorites.exists():
            with open(self._file_favorites, "r") as file:
                data_json = load(file)

            if data_json["favorites_list"]:
                params: dict = {
                    "code_list": ",".join(data_json["favorites_list"]),
                }
                model.extend(self._listing(
                    link="title/list",
                    params=params,
                    time_expires=0,
                    category=f"Избранное",
                    title_color="green",
                    favorites_offline=True)["list"])

        return {
            "list": tuple(model),
            "category": "Избранное",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def new(self) -> dict:
        params: dict = {
        }
        return self._listing(category="Новые серии",
                             time_expires=self._cache.cache_limits("new"))

    def random(self) -> dict:
        params: dict = {
        }
        return self._listing(link="title/random",
                             params=params,
                             time_expires=0)

    def search_advanced(self,
                        genres=None,
                        years=None,
                        season_code=None,
                        order_by=None,
                        status=None):
        params: dict = {
            "sort_direction": "0",
        }
        query_list: list = []

        if genres:
            for i in genres.split(","):
                query_list.append("{genres} == " + i)

        if years:
            for i in years.split(","):
                query_list.append("{season.year} == " + i)

        if season_code:
            for i in season_code.split(","):
                query_list.append("{season.code} == " + i)

        if order_by:
            params["order_by"] = order_by

        if status:
            for i in status.split(","):
                query_list.append("{status.code} == " + i)
        return self._listing(link="title/search/advanced",
                             params=params,
                             category=f"Найдено по запросу",
                             time_expires=self._cache.cache_limits("default"))

    def all(self) -> dict:
        params: dict = {
            **self._limits("all")
        }
        return self._listing(link="title/changes",
                             params=params,
                             category=f"Все аниме",
                             time_expires=self._cache.cache_limits("all"))

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)
        params = {
            "search": search_item,
            **self._limits("all"),
        }
        return self._listing(link="title/search",
                             params=params,
                             category=f"Найдено по запросу => {search_item}",
                             time_expires=self._cache.cache_limits("all"))

    def main(self) -> dict:
        model: list = []

        if self._view.get_setting_bool("auth_bool"):
            if not self._auth.token() or self._auth.token()["expires"] < time():
                model.append({
                    "title": "[COLOR=blue]Авторизация[/COLOR]",
                    "router": "auth",
                    "plot": "Нужно для удаленного управления избранным.\nМожно отключить этот пункт в настройках.",
                    "not_folder": True,
                    "icon": "DefaultAddonsRepo.png",

                })
            else:
                model.append({
                    "title": "Избранное",
                    "router": "favorites",
                    "plot": "Онлайн списки",
                    "icon": "DefaultAddonVfs.png",

                })
        model.extend([
            {
                "title": "Новые серии",
                "router": "new",
                "plot": "От недавно вышедших к более старым",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
                "icon": "DefaultAddonInfoLibrary.png",
            },
            {
                "title": "Все аниме",
                "router": "all",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Поиск по тегам",
                "router": "search_menu_advanced",
                "plot": "Поиск по тегам с историей",
                "icon": "DefaultAddonsSearch.png",
            },
            {
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ])

        return {
            "list": tuple(model),
            "category": "Меню",
        }
