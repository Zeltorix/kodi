# -*- coding: utf-8 -*-
# Module: cache
# Author: Zeltorix
# Created on: 2024.06.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from datetime import datetime, timedelta
from pathlib import Path
from time import time
from json import load, dump
from urllib.parse import urlencode

from view import View
from web_api_request import WebApiRequest, https_checking
from text_job import shy, ras, date_to_time_stamp, date_time_to_local


class Cache:
    __slots__ = [
        "url",
        "_view",
        "_web",
        "_plugin_folder",
        "_plugin_cache",
        "_file_favorites",
    ]

    def __init__(self):
        self._view = View()
        self._web = WebApiRequest()
        self._plugin_folder = Path(self._view.plugin_folder)
        self._plugin_cache = Path(self._view.plugin_folder, "cache.json")

    def web_cache(self, link: str, params: dict, time_expires: int) -> (list, dict):
        response_data = None
        data_cache = self.cache(link, params, time_expires=time_expires)

        if data_cache and time_expires:
            response_data = data_cache
        else:
            if link == "title/changes":
                self._web.__init__(timeout=60)
            response = self._web.request_get(https_checking(link), params=params)

            if response and type(response) is not dict:
                response_json = response.json()
                if type(response_json) is dict:
                    if response_json.get("error"):
                        self._view.dialog_ok(
                                "Проблемы с доступом к ресурсу!",
                                f"Код: {response_json['error']['code']}\n"
                                f"Сообщение: {response_json['error']['message']}"
                        )
                        raise
                    elif response_json.get("list"):
                        response_data = response_json["list"]
                    else:
                        response_data = response_json
                    self.cache(link, params, response_data, time_expires)
            else:
                cache_use = self.use_cache(link, params)
                if cache_use:
                    response_data = cache_use
        return response_data

    def cache_clearing(self):
        if self._plugin_cache.exists():
            try:
                with open(self._plugin_cache, "w+", encoding="utf-8") as file:
                    dump({}, file)
                self._view.dialog_ok("Кэш", "Интернет кэш очищена")
                return True
            except:
                return False

    def cache_limits(self, item: str, time_expires=None) -> int:
        if item == "release":
            if time_expires:
                return time_expires
            else:
                return self._view.get_setting_int("cache_time_release") * 60
        elif item == "new":
            return self._view.get_setting_int("cache_time_new") * 60
        elif item == "youtube":
            return self._view.get_setting_int("cache_time_youtube") * 60
        elif item == "default":
            return self._view.get_setting_int("cache_time_default") * 60
        elif item == "all":
            return self._view.get_setting_int("cache_time_all") * 60
        else:
            raise ValueError(f"Такого значения нет: {item}")

    def cache(self, link: str, params: dict, data=None, time_expires: int = 0, use_cache: bool = False):
        url = f"{link}?{urlencode(params)}"

        if self._view.get_setting_bool("cache"):
            if not self._plugin_folder.exists():
                self._plugin_folder.mkdir(parents=True)

            if not self._plugin_cache.exists():
                with open(self._plugin_cache, "w+", encoding="utf-8") as file:
                    dump({}, file)

            if data:
                with open(self._plugin_cache, "r", encoding="utf-8") as file:
                    data_cache: dict = load(file)
                data_cache[url] = {
                    "expires": int(time()),
                    "data": data,
                }
                with open(self._plugin_cache, "w+", encoding="utf-8") as file:
                    dump(data_cache, file)
                    self._view.dialog_notification(
                        f"Кэш обновлён {self.cache_size()}",
                        f'от {datetime.fromtimestamp(data_cache[url]["expires"]).strftime("%Y.%m.%d %H:%M:%S")}',
                        milliseconds=500,
                        sound=False,
                    )
            else:
                with open(self._plugin_cache, "r", encoding="utf-8") as file:
                    data_cache = load(file)

                if data_cache.get(url) and data_cache[url]["expires"] + time_expires > int(time()) \
                        or use_cache:
                    self._view.dialog_notification(
                        f"Используется кэш {self.cache_size()}",
                        f'от {datetime.fromtimestamp(data_cache[url]["expires"]).strftime("%Y.%m.%d %H:%M:%S")}',
                        milliseconds=500,
                        sound=False,
                    )
                    return data_cache[url]["data"]

    def use_cache(self, link: str, params: dict):
        if self._view.dialog_yesno(
                "Проблемы с доступом к ресурсу!",
                "Использовать старую кэш, при её наличии?"
        ):
            return self.cache(link=link, params=params, data=None, time_expires=0, use_cache=True)

    @staticmethod
    def __convert_bytes(size):
        for x in ["байт", "КБ", "МБ", "ГБ", "ТБ"]:
            if size < 1024.0:
                return f"{size: 3.1f} {x}"
            size /= 1024.0

    def cache_size(self):
        return self.__convert_bytes(self._plugin_cache.stat().st_size)
