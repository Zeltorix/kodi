# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

# Импорт модуля плагина для создания модели
from .model import ModelAnimeru
from .view import View


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    # import logging
    # logger = logging.getLogger(__name__)
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    view = View()
    model = ModelAnimeru()
    if params_dict:
        import xbmc
        xbmc.log(msg=f'router: {params_dict}', level=xbmc.LOGINFO)
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                view.main(model.search(search_item=params_dict['keyword']))
            else:
                view.main(model.search(view.search()))
        elif params_dict['router'] == "search_video_history":
            view.main(model.search(search_item=params_dict['data']))
        elif params_dict['router'] == "play":
            view.play(model.play(link=params_dict['data']))
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        view.main(model.main())
