# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
# Модули KODI
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon


class View:
    __slots__ = []
    # Получите URL-адрес плагина в формате plugin:// значение.
    _url = sys.argv[0]
    # Получить заготовка плагина в виде целого числа.
    _handle = int(sys.argv[1])
    _kodi_version_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])

    def get_setting(self, id_: str) -> str:
        id_a: str = self._url.split("//")[1].split("/")[0]
        return xbmcaddon.Addon(id_a).getSetting(id_)

    @staticmethod
    def check_modules() -> None:
        def target_module(check_module: str) -> None:
            try:
                xbmcaddon.Addon(check_module)
            except (ModuleNotFoundError, RuntimeError):
                xbmcgui.Dialog().notification(
                    heading=f'Установка библиотеки {check_module}',
                    message=f'{check_module}',
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin(f'RunPlugin("plugin://{check_module}")')
        target_module('script.module.requests')
        target_module('inputstream.adaptive')

    @staticmethod
    def error(heading: str, message: str, type_message: str = "info") -> None:
        if type_message == "warning":
            notification = xbmcgui.NOTIFICATION_WARNING
        elif type_message == "error":
            notification = xbmcgui.NOTIFICATION_ERROR
        elif type_message == "info":
            notification = xbmcgui.NOTIFICATION_INFO
        else:
            notification = xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification(
            heading=heading,
            message=message,
            icon=notification,
            time=5000,
        )

    def _convert_to_url(self, **kwargs: str) -> str:
        # Преобразование кляча и значения в ссылку данных для дополнения в виде URL
        return f'{self._url}?{urlencode(kwargs)}'

    def play(self, path: str) -> None:
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)

        if self.get_setting("inputstream_adaptive") == "true":
            # Использовать inputstream.adaptive для входящего медиапотока
            play_item.setProperty('inputstream', "inputstream.adaptive")
            # Тип манифеста медиапотока
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            # Подбор разрешения под экран
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

            play_item.setProperty('inputstream.adaptive.live_delay', '120')

            # Тип запрашиваемого контента
            play_item.setMimeType('application/x-mpegURL')

            # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
            play_item.setContentLookup(True)
            # Обновление манифеста, возможно это убирает баг с зависанием
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            # Разрешить начинать воспроизведение LIVE-потока с начала буфера, а не с его конца.
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
            # listitem.setProperty('inputstream.adaptive.stream_headers',
            #                      f'User-Agent={user_agent}')
            # listitem.setProperty('inputstream.adaptive.stream_headers',
            #                      'headername=value&User-Agent=the_user_agent&Cookie=the_cookies')

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def main(self, data: dict) -> None:
        sort_item = xbmcplugin.SORT_METHOD_NONE
        # Установка представления содержимого плагина.
        # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
        # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
        xbmcplugin.setContent(self._handle, 'videos')
        # Путь сверху между слешей("/") с добавленным названием
        xbmcplugin.setPluginCategory(self._handle, data['category'])
        # Перебор либо списка аниме, либо серий
        for item in data['list']:
            list_item = xbmcgui.ListItem(item["Title"])
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item["Title"])
                if item.get("Plot"):
                    vinfo.setPlot(item["Plot"])
                if item.get("Premiered"):
                    vinfo.setPremiered(item["Premiered"])
                if item.get('Genres'):
                    vinfo.setGenres(item['Genres'])
                # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
                # video       For normal video
                # set         For a selection of video
                # musicvideo  To define it as music video
                # movie       To define it as normal movie
                # tvshow      If this is it defined as tvshow
                # season      The type is used as a series season
                # episode     The type is used as a series episode
                vinfo.setMediaType("season")
            else:
                list_item.setInfo('video', {'title': item["Title"]})
                if item.get("Plot"):
                    list_item.setInfo('video', {'plot': item["Plot"]})
                if item.get('genres'):
                    list_item.setInfo('video', {'genre': item['Genres']})
                if item.get("Premiered"):
                    list_item.setInfo('video', {'premiered': item["Premiered"]})
                list_item.setInfo('video', {'mediatype': 'videos'})
            if item.get("Posters"):
                list_item.setArt({'thumb': item['Posters']})
                list_item.setArt({'icon': item['Posters']})
                list_item.setArt({'fanart': item['Posters']})
            is_folder = True
            if item["router"] == "play":
                list_item.setProperty('IsPlayable', 'true')
                is_folder = False
            if item.get("data"):
                data = item['data']
            else:
                data = ""
            if item.get("data_2"):
                data_2 = item['data_2']
            else:
                data_2 = ""
            if item.get("data_3"):
                data_3 = item['data_3']
            else:
                data_3 = ""
            if item.get("data_4"):
                data_4 = item['data_4']
            else:
                data_4 = ""
            url = self._convert_to_url(router=item['router'], data=data, data_2=data_2, data_3=data_3, data_4=data_4)
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, sort_item)
        xbmcplugin.endOfDirectory(self._handle)

    @staticmethod
    def search() -> str:
        return xbmcgui.Dialog().input(
            'Введите название проекта',
            type=xbmcgui.INPUT_ALPHANUM)
