# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""


class ParserOK:
    """
    Клас для получения данных
    """
    __slots__ = []

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0",
        "Accept-Encoding": "gzip, deflate, br",
        "X-Requested-With": "XMLHttpRequest",
    }

    def rest_api(self, link: str, post: dict, retry: int = 10) -> (dict, str):
        # Не стандартный модуль импортируется в addon.xml как script.module.requests
        import requests
        response = requests.post(link, headers=self.headers, timeout=5, data=post)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.rest_api(link=link, post=post, retry=retry - 1)
            elif response.status_code == 404:
                # TODO Добавить оповещение в интерфейс
                raise "Изменился API"
            elif response.status_code == 200:
                return response
        except ConnectionError:
            if retry:
                from time import sleep
                from random import randint
                # TODO Добавить оповещение в интерфейс
                sleep(randint(2, 10))
                return self.rest_api(link=link, post=post, retry=retry - 1)
            else:
                raise "Что то не то с API..."
