# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.26
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserOK
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.develop.ok_video.resources.lib.parser import ParserOK


class ModelOK:
    __slots__ = []
    _parser = ParserOK()

    def play(self, link) -> str:
        if "video/" in link:
            id_: str = link.split("video/")[1]
        else:
            id_ = link
        post: dict = {"st.vpl.id": id_, "st.vpl.bu": link}
        req: str = self._parser.rest_api(link="https://ok.ru/dk?cmd=PopLayerVideo", post=post).text
        from re import search
        link: str = search(r'data-options=".*?"', req)[0].split('"')[1].replace("&quot;", '"')
        hls: dict = json.loads(json.loads(link)["flashvars"]["metadata"])
        if hls.get("hlsMasterPlaylistUrl"):
            video: str = hls["hlsMasterPlaylistUrl"]
        elif hls.get("hlsManifestUrl"):
            video: str = hls["hlsManifestUrl"]
        else:
            raise KeyError("Нужно сообщить на форум")
        return video

    @staticmethod
    def listing(data) -> list:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(data, features="html.parser")
        # import xbmc
        # xbmc.log(msg=f'listing {data}', level=xbmc.LOGINFO)
        model_list: list = []
        for item in soup.find_all("div", {"class": "ugrid_i"}):
            img_link: dict = item.find("img", {"class": "video-card_img"})
            if img_link:
                img: str = img_link["src"]
            else:
                img: str = ""
            if img.startswith("//"):
                img: str = "https:" + img
            title: str = item.find("a", {"class": "video-card_n"}).text
            link: str = item.find("a", {"class": "video-card_lk"})["href"]
            if "?" in link:
                link: str = link.split("?")[0]
            if not link.startswith("http"):
                link = "https://ok.ru" + link
            video_info = item.find("div", {"class": "video-card_info"})
            if len(video_info.find_all("span")) == 3:
                video_info = video_info.find_all("span")[2].text
                from re import search
                if int(search(r'\d+', video_info)[0]):
                    number_of_videos = f"({video_info})"
                else:
                    continue
                router = "playlist"
            else:
                number_of_videos = ""
                router = "play"
            model_dict: dict = {
                "Title": f"{title} {number_of_videos}",
                "router": router,
                "data": link,
                "Posters": img,
            }
            model_list.append(model_dict)
        import xbmc
        xbmc.log(msg=f'listing model_list: {model_list}', level=xbmc.LOGINFO)
        return model_list

    def search(self, type_search: str, search_item: str, next_items, gwt=None) -> dict:
        import xbmc
        xbmc.log(msg=f'search: {type_search} - {search_item} - {next_items} - {gwt}', level=xbmc.LOGINFO)
        if not gwt:
            from re import search
            gwt: str = search(r'gwtHash:".*?"', self._parser.rest_api(link="https://ok.ru/",
                                                                      post={}).text)[0].split('"')[1]
        if type_search == "video":
            link = f"https://ok.ru/dk?cmd=VideoSearchResultMoviesBlock&st.v.sfd=ANY&st.v.srt=Live&st.v.sfhd=off&st.v.sq={search_item}&st.cmd=video&st.prevft=search&st.psft=top&st.m=SEARCH&st.ft=search"
        elif type_search == "channel":
            link = f"https://ok.ru/dk?cmd=VideoSearchResultAlbumsBlock&st.v.srt=Compilation&st.v.sq={search_item}&st.cmd=video&st.psft=top&st.m=SEARCH&st.ft=search"
        else:
            raise
        if next_items == "":
            post = {}
        elif len(next_items) <= 3:
            post = {"st.page": next_items, "gwt.requested": gwt}
        elif next_items:
            post = {"st.lastelem": next_items, "gwt.requested": gwt}
        else:
            raise
        data = self._parser.rest_api(link=link, post=post)
        list_items = self.listing(data.text)
        if data.headers.get("lastelem"):
            next_items = data.headers["lastelem"]
        else:
            if next_items == "":
                next_items = "2"
            else:
                next_items = str(int(next_items) + 1)
        if len(list_items) != 0:
            list_items.append({
                "Title": "Далее",
                "router": "search",
                "data": type_search,
                "data_2": search_item,
                "data_3": next_items,
                "data_4": gwt,
            })
        return {
            "category": "Найдено",
            "list": list_items
        }

    def playlist(self, link: str, next_items: str = "1") -> dict:
        import xbmc
        xbmc.log(msg=f'playlist: {link} - {next_items}', level=xbmc.LOGINFO)
        if next_items == "":
            post = {}
        elif len(next_items) <= 3:
            post = {"st.page": next_items}
        elif next_items:
            post = {"st.lastelem": next_items}
        else:
            raise
        data = self._parser.rest_api(link=link, post=post)
        list_items: list = self.listing(data.text)
        if data.headers.get("lastelem"):
            next_items = data.headers["lastelem"]
        else:
            if next_items == "":
                next_items = "2"
            else:
                next_items = str(int(next_items) + 1)
        if len(list_items) != 0:
            list_items.append({
                "Title": "Далее",
                "router": "playlist",
                "data": link,
                "data_2": next_items,
            })
        return {
            "category": "Контент",
            "list": list_items
        }

    @staticmethod
    def menu(item: str) -> dict:
        if item == "serial":
            category = "Сериалы"
            model_list: list = [
                {
                    "Title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Новинки",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/new?st.cmd=anonymVideo&st.ftag=new&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Драма",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/serialdrama?st.cmd=anonymVideo&st.ftag=serialdrama&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Комедии",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/serialcomedy?st.cmd=anonymVideo&st.ftag=serialcomedy&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Детективы",
                    "router": "playlist",
                    "data": "https://ok.ru/video/serial/serialdetective?st.cmd=anonymVideo&st.ftag=serialdetective&st.m=ALBUMS_CATALOG&st.ft=serial&cmd=VideoAlbumsCatalogBlock",
                },
            ]
        elif item == "tvshow":
            category = "ТВ-шоу"
            model_list: list = [
                {
                    "Title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Шоу",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/show?st.cmd=anonymVideo&st.ftag=show&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Юмор",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/humor?st.cmd=anonymVideo&st.ftag=humor&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Кулинария",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/cookery?st.cmd=anonymVideo&st.ftag=cookery&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Красота",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/beauty?st.cmd=anonymVideo&st.ftag=beauty&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Авто",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/autoshows?st.cmd=anonymVideo&st.ftag=autoshows&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Познавательные",
                    "router": "playlist",
                    "data": "https://ok.ru/video/tvshow/educational?st.cmd=anonymVideo&st.ftag=educational&st.m=ALBUMS_CATALOG&st.ft=tvshow&cmd=VideoAlbumsCatalogBlock",
                },
            ]
        elif item == "bloggers":
            category = "Блоги"
            model_list: list = [
                {
                    "Title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Юмор",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/bloghumor?st.cmd=anonymVideo&st.ftag=bloghumor&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Игры",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/bloggames?st.cmd=anonymVideo&st.ftag=bloggames&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Животные",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/bloganimals?st.cmd=anonymVideo&st.ftag=bloganimals&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Авто",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogauto?st.cmd=anonymVideo&st.ftag=blogauto&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Красота и здоровье",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogbeauty?st.cmd=anonymVideo&st.ftag=blogbeauty&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Рецепты",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogcookery?st.cmd=anonymVideo&st.ftag=blogcookery&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Дети",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogchildren?st.cmd=anonymVideo&st.ftag=blogchildren&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Спорт",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogsport?st.cmd=anonymVideo&st.ftag=blogsport&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Путешествия",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogtravel?st.cmd=anonymVideo&st.ftag=blogtravel&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Познавательное",
                    "router": "playlist",
                    "data": "https://ok.ru/video/bloggers/blogcognitive?st.cmd=anonymVideo&st.ftag=blogcognitive&st.m=ALBUMS_CATALOG&st.ft=bloggers&cmd=VideoAlbumsCatalogBlock",
                }
            ]
        elif item == "children":
            category = "Детям"
            model_list: list = [
                {
                    "Title": "Все",
                    "router": "playlist",
                    "data": "https://ok.ru/video/children?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=children&cmd=VideoAlbumsCatalogBlock",
                },
                {
                    "Title": "Мультфильмы",
                    "router": "playlist",
                    "data": "https://ok.ru/video/children/cartoons?st.cmd=anonymVideo&st.ftag=cartoons&st.m=ALBUMS_CATALOG&st.ft=children&cmd=VideoAlbumsCatalogBlock",
                },
            ]
        elif item == "search_menu":
            category = "Поиск"
            model_list: list = [
                {
                    "Title": "Поиск видео",
                    "router": "search",
                    "data": "video",
                },
                {
                    "Title": "Поиск канала",
                    "router": "search",
                    "data": "channel",
                },
            ]
        else:
            raise
        return {
            "category": category,
            "list": tuple(model_list)
        }

    @staticmethod
    def main() -> dict:
        model_list: list = [
            {
                "Title": "В топе",
                "router": "playlist",
                "data": "https://ok.ru/video/top?st.cmd=anonymVideo&st.m=CATALOG&st.ft=top&cmd=VideoCatalogBlock",
            },
            {
                "Title": "Трансляции",
                "router": "playlist",
                "data": "https://ok.ru/video/live?st.cmd=anonymVideo&st.m=LIVE_SHOWCASE&st.ft=live&cmd=VideoCatalogBlock",
            },
            {
                "Title": "Спорт",
                "router": "playlist",
                "data": "https://ok.ru/video/sport?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=sport&cmd=VideoAlbumsCatalogBlock",
            },
            {
                "Title": "Каталог",
                "router": "playlist",
                "data": "https://ok.ru/video/channels?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=channels&cmd=VideoAlbumsCatalogBlock",
            },
            {
                "Title": "Сериалы",
                "router": "menu",
                "data": "serial",
            },
            {
                "Title": "ТВ-шоу",
                "router": "menu",
                "data": "tvshow",
            },
            {
                "Title": "Фильмы",
                "router": "playlist",
                "data": "https://ok.ru/video/kino?st.cmd=anonymVideo&st.m=ALBUMS_CATALOG&st.ft=kino&cmd=VideoAlbumsCatalogBlock",
            },
            {
                "Title": "Блоги",
                "router": "menu",
                "data": "bloggers",
            },
            {
                "Title": "Детям",
                "router": "menu",
                "data": "children",
            },
            {
                "Title": "Поиск",
                "router": "menu",
                "data": "search_menu",
            },
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
