# -*- coding: utf-8 -*-
# Module: provider:
# Author: Zeltorix
# Created on: 2023.12.07
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
from json import loads, dumps
from re import findall

from web_api_request import WebApiRequest, headers, https_checking
from .model import Model
from view import View


class Provider:
    __slots__ = []
    web = WebApiRequest()
    model = Model()
    view = View()

    def allohatv(self, link: str):
        model: list = []
        category = ""
        # response = self.web.request_get(link).text
        # data_decode = findall(r'Playerjs\(".*?"', response)[0].split('"')[1]
        # print(data_decode)

    def hdvb(self, link: str) -> dict:
        model: list = []
        category = ""
        headers["Referer"] = self.model.link + "/"
        headers["Sec-Fetch-Site"] = "cross-site"
        response: str = WebApiRequest(headers).request_get(https_checking(link)).text
        jd = loads(findall(r"playerConfigs.*?};", response)[0][15:-1])
        start_page = findall(r"https://\w+\d+\.",link)[0]
        headers["Referer"] = link
        headers["Sec-Fetch-Site"] = "same-origin"
        headers["Content-Type"] = "application/x-www-form-urlencoded"
        headers["X-Csrf-Token"] = jd["key"]
        web = WebApiRequest(headers)
        if "playlist" in jd["file"]:
            serial: dict = WebApiRequest(headers).request_post(f"{start_page}{jd['href']}{jd['file']}", data={}).json()
            for season in serial:
                for episode in season["folder"]:
                    for translator in episode["folder"]:
                        if type(translator) is dict:
                            model.append({
                                "title": f"{season['title']}-{episode['title']} ({translator['title']})",
                                "router": "hls",
                                "play": True,
                                "data": web.request_post(https_checking(f"{start_page}{jd['href']}/playlist/{translator['file'][1:]}.txt"), data={}).text,
                                "images": https_checking(jd["poster"]),
                                "plot": translator["title"],
                                "season": int(season["id"]),
                                "episode": int(episode["episode"]),
                            })
        else:
            model.append({
                "title": f"Фильм",
                "play": True,
                "router": "hls",
                "data": WebApiRequest(headers).request_post(f"{start_page}{jd['href']}/playlist/{jd['file'][1:]}.txt", data={}).text,
                "images": https_checking(jd["poster"]),
            })

        return {
            "category": category,
            "list": tuple(model)
        }
