# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.12.07
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from re import findall

from bs4 import BeautifulSoup

from web_api_request import WebApiRequest, headers, https_checking
from view import View
from history import History


class Model(WebApiRequest, History, View):
    __slots__ = []
    link_1: str = "/sbs.esabonik.ur//:sptth"[::-1]
    link: str = findall(r'url" : ".*?"', WebApiRequest().request_get(link_1).text)[0].split('"')[2]

    def realise(self, link: str) -> dict:
        model: list = []
        category = ""
        response = self.request_get(https_checking(link, self.link))
        if response and response is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find(attrs={"aria-current": "page"}).text.strip()
            for button in soup.find_all(class_="btn btn-secondary show-player-btn"):
                router = ""
                player = soup.find(id=f"player-{button['data-player']}").find("script").text
                data = findall(r"var src =.*?';", player)[0].split("'")[1]

                if button['data-player'] == "mnw":
                    raise ValueError(f"Нужно доработать mnw {data}")
                elif button['data-player'] == "hdb":
                    raise ValueError(f"Нужно доработать hdb {data}")
                elif button['data-player'] == "hdg":
                    raise ValueError(f"Нужно доработать hdg {data}")
                elif button['data-player'] == "kodik":
                    raise ValueError(f"Нужно доработать kodik {data}")
                elif button['data-player'] == "videocdn":
                    raise ValueError(f"Нужно доработать videocdn {data}")
                elif button['data-player'] == "legal":
                    raise ValueError(f"Нужно доработать legal {data}")
                elif button['data-player'] == "trailer":
                    raise ValueError(f"Нужно доработать trailer {data}")
                elif button['data-player'] == "direct":
                    raise ValueError(f"Нужно доработать direct {data}")
                elif button['data-player'] == "drm":
                    raise ValueError(f"Нужно доработать drm {data}")
                elif button['data-player'] == "collaps":
                    raise ValueError(f"Нужно доработать collaps {data}")
                elif button['data-player'] == "hdvb":
                    router = "hdvb"
                elif button['data-player'] == "yohoho":
                    raise ValueError(f"Нужно доработать yohoho {data}")
                elif button['data-player'] == "videodb":
                    raise ValueError(f"Нужно доработать videodb {data}")
                elif button['data-player'] == "iframe_video":
                    raise ValueError(f"Нужно доработать iframe_video {data}")
                elif button['data-player'] == "videospider":
                    raise ValueError(f"Нужно доработать videospider {data}")
                elif button['data-player'] == "allohatv":
                    continue

                title = button.text
                if not data:
                    title = f"{button.text} - плеер отсутствует"

                model.append({
                    "title": title,
                    "router": router,
                    "data": data,
                    "images": https_checking(soup.find("source")["srcset"], self.link),
                    "plot": soup.find(class_="movie-info").find_all("p")[1].text,
                })

        return {
            "category": category,
            "list": tuple(model)
        }

    def search(self, find_item: str) -> dict:
        self.history_add_item(find_item)
        return self.catalog(f"{self.link}/search?q={find_item}")

    def catalog(self, link: str) -> dict:
        model: list = []
        category = ""
        response = self.request_get(https_checking(link, self.link))
        if response and response is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            category = soup.find("h1").text.strip()
            for item in soup.find_all(class_="th-item"):
                plot = ""

                if item.find(class_="th-series"):
                    plot += f"{plot}{item.find(class_='th-series').text}"

                model.append({
                    "title": f"{item.find(class_='th-title').text} {item.find(class_='th-year').text}",
                    "router": "realise",
                    "data": item.find("a")["href"],
                    "images": https_checking(item.find("source")["data-srcset"], self.link),
                    "plot": plot,
                })

            if soup.find(class_="pagination"):
                for page in soup.find(class_="pagination").find_all("a"):
                    if page["href"] and page["href"] != "#":
                        model.append({
                            "title": f"Страница {page.text}",
                            "data": page["href"],
                            "router": "catalog",
                        })
        return {
            "category": category,
            "list": tuple(model)
        }

    def main(self) -> dict:
        model: list = []
        response = self.request_get(https_checking(self.link))
        if response and response is not dict:
            soup = BeautifulSoup(response.text, features="html.parser")
            for item in soup.find(class_="navbar-nav").find_all(class_="nav-item"):
                if item.find(class_="nav-link"):
                    title_nav = findall(r'\w+', item.find(class_='nav-link').text)[0].strip()
                    model.append({
                        "title": f"[B][COLOR=grey]{title_nav} =>[/COLOR][/B]",
                        "router": "",
                        "data": "",
                    })
                    for a in item.find(class_="dropdown-menu").find_all(class_="dropdown-item"):
                        title_sub = findall(r'[\w -]+', a.text)[0].strip()
                        model.append({
                            "title": f"[COLOR=grey]{title_nav}[/COLOR] => {title_sub}",
                            "router": "catalog",
                            "data": a["href"],
                        })

            if self.get_setting_bool("history_realise") and self.get_setting_str("history_realise_item"):
                model.append({
                    "title": "Последний просмотр",
                    "router": "last_realise",
                    "data": self.get_setting_str("history_realise_item"),
                    "plot": "Открывает последний просмотренный сериал/фильм",
                    "icon": "DefaultInProgressShows.png",
                })
            model.append({
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            })
        return {
            "category": "Меню",
            "list": tuple(model)
        }
