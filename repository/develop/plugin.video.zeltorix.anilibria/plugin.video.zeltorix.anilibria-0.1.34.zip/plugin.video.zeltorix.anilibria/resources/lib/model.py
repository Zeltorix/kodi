# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from datetime import datetime, timedelta
from pathlib import Path
from time import time
from json import load, dump
from urllib.request import proxy_bypass

from web_api_request import WebApiRequest, https_checking, Proxy
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from get_video_link import VideoLink
from view import View, ViewDialogProgressBG
from history import History

from .auth import Auth
from .cache import Cache


class Model:
    __slots__ = [
        "_web",
        "url",
        "cdn",
        "_plugin_folder",
        "_plugin_cache",
        "_file_favorites",
        "_view",
        "_cache",
        "_proxy",
    ]

    _view_dialog_progress_bg = ViewDialogProgressBG()
    _history = History()
    _video_link = VideoLink()
    _auth = Auth()

    def __init__(self):
        self._cache = Cache()
        self._view = View()
        self.url: str = ras("==wLzY3L2RnLhlmcilGbp5WYukGch9yL6MHc0RHa")
        self.cdn: str = ras("=Umbv5Sby9GdztWZldnLhlmcilGbtMWa0FGdz9yL6MHc0RHa")
        self._plugin_folder = Path(self._view.plugin_folder)
        self._file_favorites = Path(self._view.plugin_folder, "favorites.json")
        if self._view.get_setting_bool("blocking_bool"):
            if not self._view.get_setting_str("proxy_query", "script.module.zeltorix.utilitys"):
                Proxy().proxy_provider_reload()
            self._proxy = self._view.get_setting_str("proxy_query", "script.module.zeltorix.utilitys")
            self._web = WebApiRequest(proxy=self._proxy)
        else:
            self._web = WebApiRequest()


    def _limits(self, item: str) -> dict:
        if item == "new":
            return {
                "limit": self._view.get_setting_int("limits_list_new"),
            }
        elif item == "youtube":
            return {
                "limit": self._view.get_setting_int("limits_list_youtube"),
            }
        elif item == "all":
            return {
                "limit": -1,
            }

    def _release(self, link: str, params: dict, time_expires: int) -> dict:
        params: dict = {
            "filter": "id,"
                      "code,"
                      "names.ru,"
                      "status.string,"
                      "status.code,"
                      "posters.original.url,"
                      "type.string,"
                      "type.length,"
                      "description,"
                      "player.alternative_player,"
                      "player.host,"
                      "player.episodes.string,"
                      "player.list,"
                      "player.rutube",
            **params,
        }
        model: list = []
        category: str = "Проблемы с получением реализа"

        response = self._cache.web_cache(self.url + link, params, time_expires=time_expires)

        if response:
            if response["status"]["code"] == 2:
                category_include: str = f"([COLOR=red]{response['status']['string']}[/COLOR]) "
            elif response["player"]["episodes"]["string"]:
                category_include: str = f"([COLOR=green]{response['player']['episodes']['string']}[/COLOR]) "
            else:
                category_include: str = ""

            category: str = f"{category_include}{response['names']['ru']}"
            images: str = https_checking(self.cdn + response["posters"]["original"]["url"])
            plot: str = response["description"]
            host: str = response["player"]["host"]

            if response["player"]["list"]:
                for episode in response["player"]["list"].values():
                    if episode["preview"]:
                        images: str = https_checking(self.cdn + episode["preview"])
                    model_episode: dict = {
                        "premiered": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "dateadded": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "images": images,
                        "plot": plot,
                        "duration": response["type"]["length"],
                        "router": "play",
                        "play": True,
                    }
                    title: str = response["type"]["string"]

                    if episode["episode"]:
                        title: str = f"[COLOR=green]{title}[/COLOR].[COLOR=yellow]{episode['episode']}[/COLOR]"
                        model_episode["episode"]: int = episode["episode"]

                    if episode["name"]:
                        title: str = f"{title} {episode['name']}"

                    model_episode["title"]: str = title
                    video_size: int = self._view.get_setting_int("video_size")

                    if video_size:
                        height = video_size
                    else:
                        height: int = self._view.get_windows_width_height()["height"]

                    if height < 720:
                        if episode["hls"]["sd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["sd"])
                        elif episode["hls"]["hd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["hd"])
                        elif episode["hls"]["fhd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["fhd"])
                    elif 720 <= height < 1080:
                        if episode["hls"]["hd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["hd"])
                        elif episode["hls"]["sd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["sd"])
                        elif episode["hls"]["fhd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["fhd"])
                    elif 1080 <= height:
                        if episode["hls"]["fhd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["fhd"])
                        elif episode["hls"]["hd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["hd"])
                        elif episode["hls"]["sd"]:
                            model_episode["data"] = https_checking(host + episode["hls"]["sd"])
                    else:
                        raise ValueError("Отсутствия потоков на видео")
                    model.append(model_episode)
            elif response["player"]["rutube"]:
                for episode in response["player"]["rutube"].values():
                    model_episode = {
                        "premiered": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "dateadded": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "images": images,
                        "plot": plot,
                        "duration": response["type"]["length"],
                        "router": "rutube",
                        "play": True,
                        "data": episode["rutube_id"],
                    }
                    title: str = response["type"]["string"]

                    if episode["episode"]:
                        title: str = f"{title}.{episode['episode']}"
                        model_episode["episode"]: int = episode["episode"]
                    model_episode["title"]: str = title
                    model.append(model_episode)

        return {
            "list": tuple(model),
            "category": category,
        }

    def _list_item(self,
                   item: dict,
                   title_color: str,
                   favorites_online: bool,
                   favorites_offline: bool,
                   ):
        context_menu: list = []
        genres: list = []

        if item["genres"]:
            genres.extend(item["genres"])

        genres.append(item['type']['full_string'])
        genres.append(item['status']['string'])

        if item["team"]:
            if item["team"]["voice"]:
                genres.extend(item["team"]["voice"])
                for voice in item["team"]["voice"]:
                    context_menu.append((
                        f"Озвучка: {voice}",
                        f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=voice)})"
                    ))

            if item["team"]["translator"]:
                genres.extend(item["team"]["translator"])
                for translator in item["team"]["translator"]:
                    context_menu.append((
                        f"Переводчик: {translator}",
                        f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=translator)})"
                    ))

            if item["team"]["editing"]:
                genres.extend(item["team"]["editing"])
                for editing in item["team"]["editing"]:
                    context_menu.append((
                        f"Субтитры: {editing}",
                        f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=editing)})"
                    ))

            if item["team"]["decor"]:
                genres.extend(item["team"]["decor"])
                for decor in item["team"]["decor"]:
                    context_menu.append((
                        f"Оформитель: {decor}",
                        f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=decor)})"
                    ))

            if item["team"]["timing"]:
                genres.extend(item["team"]["timing"])
                for timing in item["team"]["timing"]:
                    context_menu.append((
                        f"Тайминг: {timing}",
                        f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=timing)})"
                    ))

        if item["franchises"]:
            genres.append("Франшиза")
            for franchise in item["franchises"]:
                for release in franchise["releases"]:
                    context_menu.append((
                        f"Реализ франшизы: {release['names']['ru']}",
                        f"Container.Update({self._view.convert_to_url(router='release', data=release['code'])})"
                    ))

        if self._auth.get_session_id():
            if not favorites_online:
                context_menu.append((
                    f"Добавить в онлайн избранное",
                    f"Container.Update({self._view.convert_to_url(router='favorites_online_add', data=item['id'])})"
                ))

            if favorites_online:
                context_menu.append((
                    f"Удалить из онлайн избранного",
                    f"Container.Update({self._view.convert_to_url(router='favorites_online_del', data=item['id'])})"
                ))

        if not favorites_offline:
            context_menu.append((
                f"Добавить в офлайн избранное",
                f"Container.Update({self._view.convert_to_url(router='favorites_offline_add', data=item['code'])})"
            ))

        if favorites_offline:
            context_menu.append((
                f"Удалить из офлайн избранного",
                f"Container.Update({self._view.convert_to_url(router='favorites_offline_del', data=item['code'])})"
            ))

        if self._view.get_setting_bool("download_bool"):
            context_menu.append((
                f"Загрузить целиком с сервера",
                f"RunPlugin({self._view.convert_to_url(router='download_full_anime', data=item['code'])})"
            ))
            context_menu.append((
                f"Загрузить торрент",
                f"Container.Update({self._view.convert_to_url(router='torrents', data=item['code'])})"
            ))

        if item["updated"]:
            premiered = str(datetime.fromtimestamp(item["updated"]))
        else:
            premiered = 0

        return {
            "data": item["code"],
            "title": f"[COLOR={title_color}]" + item["names"]["ru"].strip('"') + "[/COLOR]",
            "images": https_checking(self.cdn + item["posters"]["original"]["url"]),
            "premiered": premiered,
            "dateadded": premiered,
            "genres": genres,
            "year": int(item["season"]["year"]),
            "plot": item["description"],
            "context_menu": context_menu,
            "router": "release",
        }

    def _listing(self,
                 link: str,
                 params: dict,
                 time_expires: int,
                 category: str = "",
                 title_color: str = "white",
                 favorites_online=False,
                 favorites_offline=False,
                 ) -> dict:
        model: list = []
        params: dict = {
            "filter": "id,"
                      "code,"
                      "names.ru,"
                      "franchises,"
                      "status.string,"
                      "posters.original.url,"
                      "updated,"
                      "type.full_string,"
                      "genres,"
                      "team,"
                      "season.year,"
                      "description,",
            **params,
        }

        response_data = self._cache.web_cache(self.url + link, params, time_expires=time_expires)

        if type(response_data) is list:
            self._view_dialog_progress_bg.create(category, "")
            self._view_dialog_progress_bg.update(0, "")
            num = 1
            sum_data = len(response_data)
            for item in response_data:
                self._view_dialog_progress_bg.update(int((num / (sum_data + 1)) * 100), "")
                model.append(
                    self._list_item(
                        item,
                        title_color,
                        favorites_online,
                        favorites_offline
                    )
                )
                num += 1
            self._view_dialog_progress_bg.close()

        if type(response_data) is dict:
            model.append(
                self._list_item(
                    response_data,
                    title_color,
                    favorites_online,
                    favorites_offline
                )
            )

        return {
            "list": tuple(model),
            "category": category,
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    @staticmethod
    def play(link: str) -> dict:
        return {
            "type": "hls",
            "link_play": link,
        }

    def rutube(self, id_) -> dict:
        return {
            "type": "hls",
            "link_play": self._video_link.rutube_link(id_),
        }

    def youtube_id(self, youtube_id: str) -> dict:
        return {
            "type": False,
            "link_play": self._video_link.youtube_link("https://www.youtube.com/watch?v=" + youtube_id),
        }

    def release(self, code: str) -> dict:
        params: dict = {
            "code": code,
        }
        return self._release(link="title", params=params, time_expires=self._cache.cache_limits("release"))

    def favorites_online_add(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params_favorites: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "filter": "id",
                **self._limits("all"),
            }
            response_favorites = self._web.request_get(https_checking(self.url + "user/favorites"),
                                                       params=params_favorites)

            if response_favorites and type(response_favorites) is not dict:
                for i in response_favorites.json()["list"]:
                    if i["id"] == int(id_):
                        self._view.dialog_ok("Онлайн избранно", "Данное аниме уж есть в списке!")
                        return False

            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            post: dict = {}
            response = self._web.request_put(https_checking(self.url + "user/favorites"), params=params, data=post)

            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites_online_del(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            response = self._web.request_delete(https_checking(self.url + "user/favorites"), params=params)

            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites_offline_add(self, code: str) -> bool:
        if self._file_favorites.exists():
            with open(self._file_favorites, "r") as file:
                data_json: dict = load(file)
            data_json["favorites_list"].append(code)
            with open(self._file_favorites, "w+") as file:
                dump(data_json, file)
            return True
        else:
            if not self._plugin_folder.exists():
                self._plugin_folder.mkdir(parents=True)
            data_json: dict = {
                "favorites_list": [code],
            }
            with open(self._file_favorites, "w+") as file:
                dump(data_json, file)
            return True

    def favorites_offline_del(self, code: str) -> bool:
        if self._file_favorites.exists():
            with open(self._file_favorites, "r") as file:
                data_json: dict = load(file)
            data_json["favorites_list"].remove(code)
            with open(self._file_favorites, "w+") as file:
                dump(data_json, file)
            return True

    def favorites(self) -> dict:
        model: list = []
        if self._auth.get_session_id() and self._auth.get_session_id()["expires"] > time():
            model.append({
                "title": f"[COLOR=red]Онлайн избранное расконектится через: "
                         f"{str(timedelta(seconds=self._auth.get_session_id()['expires'] - time()))}[/COLOR]",
                "dateadded": datetime.fromtimestamp(self._auth.get_session_id()["expires"]).strftime(
                    "%Y-%m-%d %H:%M:%S"),
            })
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                **self._limits("all"),
            }
            model.extend(self._listing(
                link="user/favorites",
                params=params,
                time_expires=0,
                category=f"Избранное",
                title_color="blue",
                favorites_online=True)["list"])

        if self._file_favorites.exists():
            with open(self._file_favorites, "r") as file:
                data_json = load(file)

            if data_json["favorites_list"]:
                params: dict = {
                    "code_list": ",".join(data_json["favorites_list"]),
                }
                model.extend(self._listing(
                    link="title/list",
                    params=params,
                    time_expires=0,
                    category=f"Избранное",
                    title_color="green",
                    favorites_offline=True)["list"])

        return {
            "list": tuple(model),
            "category": "Избранное",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def new(self) -> dict:
        params: dict = {
            **self._limits("new")
        }
        return self._listing(link="title/updates",
                             params=params,
                             category="Новые серии",
                             time_expires=self._cache.cache_limits("new"))

    def random(self) -> dict:
        params: dict = {
        }
        return self._listing(link="title/random",
                             params=params,
                             time_expires=0)

    def franchise_list(self) -> dict:
        model: list = []
        link = "franchise/list"
        params: dict = {
            "filter": "franchise.name,"
                      "releases",
            **self._limits("all"),
        }

        response_data = self._cache.web_cache(self.url + link, params, time_expires=self._cache.cache_limits("all"))

        if response_data:
            for franchise in response_data:
                model.append({
                    "title": f"[COLOR=grey]{franchise['franchise']['name']} ==>[/COLOR]",
                })
                for release in franchise["releases"]:
                    model.append({
                        "title": f"[COLOR=grey]==>[/COLOR] {release['names']['ru']}",
                        "data": release["code"],
                        "router": "release",
                    })

        return {
            "list": tuple(model),
            "category": "Все франшизы",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
            ]
        }

    def list_for(self, type_item: str = "", text_item: str = "") -> dict:
        if type_item in ["year", "genres"]:
            if type_item == "year":
                type_item_ = "years"
            else:
                type_item_ = type_item

            response = self._web.request_get(https_checking(self.url + type_item_))

            if response and type(response) is not dict:
                response_list: list = [str(i) for i in response.json() if i not in [2120, 2220, 3021, 21111]]
                select_items: list = self._view.dialog_multiselect("Множественный выбор", response_list)
                if select_items:
                    text_item = ",".join([str(response_list[i]) for i in select_items])
        else:
            type_item = "team"

        if text_item:
            params = {
                type_item: text_item,
                **self._limits("all"),
            }
            return self._listing(link="title/search",
                                 params=params,
                                 category=f"Найдено по запросу => {text_item}",
                                 time_expires=self._cache.cache_limits("default"))

    def list_for_a(self, type_item: str = "", text_item: str = "") -> str:
        if type_item in ["year", "genres"]:
            if type_item == "year":
                type_item_ = "years"
            else:
                type_item_ = type_item

            response = self._web.request_get(https_checking(self.url + type_item_))

            if response and type(response) is not dict:
                response_list: list = [str(i) for i in response.json() if i not in [2120, 2220, 3021, 21111]]
                select_items: list = self._view.dialog_multiselect("Множественный выбор", response_list)
                if select_items:
                    text_item = ",".join([str(response_list[i]) for i in select_items])
        else:
            type_item = "team"
            response = self._web.request_get(https_checking(self.url + type_item))

            if response and type(response) is not dict:
                team_list: list = [item for sublist in response.json().values() for item in sublist]
                select_items: list = self._view.dialog_multiselect("Множественный выбор", team_list)

                if select_items:
                    text_item = ",".join([str(team_list[i]) for i in select_items])
        return text_item

    def search_advanced(self,
                        genres=None,
                        years=None,
                        season_code=None,
                        order_by=None,
                        status=None):
        params: dict = {
            "sort_direction": "0",
        }
        query_list: list = []

        if genres:
            for i in genres.split(","):
                query_list.append("{genres} == " + i)

        if years:
            for i in years.split(","):
                query_list.append("{season.year} == " + i)

        if season_code:
            for i in season_code.split(","):
                query_list.append("{season.code} == " + i)

        if order_by:
            params["order_by"] = order_by

        if status:
            for i in status.split(","):
                query_list.append("{status.code} == " + i)
        return self._listing(link="title/search/advanced",
                             params=params,
                             category=f"Найдено по запросу",
                             time_expires=self._cache.cache_limits("default"))

    def all(self) -> dict:
        params: dict = {
            **self._limits("all")
        }
        return self._listing(link="title/changes",
                             params=params,
                             category=f"Все аниме",
                             time_expires=self._cache.cache_limits("all"))

    def youtube_list(self) -> dict:
        model: list = []
        link = "youtube"
        params: dict = {
            "filter": "id,"
                      "title,"
                      "preview.src,"
                      "youtube_id,"
                      "timestamp",
            **self._limits("youtube")
        }

        response_data = self._cache.web_cache(self.url + link, params, time_expires=self._cache.cache_limits("youtube"))

        if response_data:
            for item in response_data:
                model.append({
                    "episode": item["id"],
                    "title": item["title"],
                    "images": f"{self.cdn}{item['preview']['src']}",
                    "data": item["youtube_id"],
                    "premiered": str(datetime.fromtimestamp(item["timestamp"])),
                    "dateadded": str(datetime.fromtimestamp(item["timestamp"])),
                    "router": "youtube_id",
                    "play": True,
                })

        return {
            "list": tuple(model),
            "category": "YouTube",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)
        params = {
            "search": search_item,
            **self._limits("all"),
        }
        return self._listing(link="title/search",
                             params=params,
                             category=f"Найдено по запросу => {search_item}",
                             time_expires=self._cache.cache_limits("all"))

    def torrents(self, code: str) -> dict:
        model: list = []
        category = ""
        params: dict = {
            "code": code,
            "filter": "names.ru,"
                      "status.string,"
                      "status.code,"
                      "posters.original.url,"
                      "type.string,"
                      "torrents.episodes.string,"
                      "torrents.list,"
        }

        response = self._web.request_get(https_checking(self.url + "title"), params=params)

        if response and type(response) is not dict:
            response_data = response.json()

            if response_data["status"]["code"] == 2:
                category_include: str = f"([COLOR=red]{response_data['status']['string']}[/COLOR]) "
            elif response_data["torrents"]["episodes"]["string"]:
                category_include: str = f"([COLOR=green]{response_data['torrents']['episodes']['string']}[/COLOR]) "
            else:
                category_include: str = ""

            category: str = f"{category_include}{response_data['names']['ru']}"
            images: str = https_checking(self.cdn + response_data["posters"]["original"]["url"])

            model.append({
                "title": "[COLOR=red]Функция временно отключена![/COLOR]",
            })

            model.append({
                "title": "[COLOR=red]В данный момент процесс загрузки не отображается![/COLOR]",
            })

            for item in response_data["torrents"]["list"]:
                model.append({
                    "title": f"{item['quality']['string']} {item['episodes']['string']}",
                    "premiered": str(datetime.fromtimestamp(item["uploaded_timestamp"])),
                    "dateadded": str(datetime.fromtimestamp(item["uploaded_timestamp"])),
                    "data": https_checking(item["url"], self.cdn),
                    "router": "download_torrents",
                    "images": images,
                    "plot": f"Тип: {item['quality']['type']}\n"
                            f"Разрешение: {item['quality']['resolution']}\n"
                            f"Кодек: {item['quality']['encoder']}\n"
                            f"Загружают: {item['leechers']}\n"
                            f"Раздают: {item['seeders']}\n"
                            f"Всего загрузок: {item['downloads']}\n"
                            f"Размер: {item['size_string']}\n",
                    "not_folder": True,
                })

        return {
            "list": tuple(model),
            "category": category,
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def main(self) -> dict:
        model: list = []

        if self._view.get_setting_bool("auth_bool"):
            if not self._auth.get_session_id() or self._auth.get_session_id()["expires"] < time():
                model.append({
                    "title": "[COLOR=blue]Авторизация[/COLOR]",
                    "router": "auth",
                    "plot": "Нужно для удаленного управления избранным.\nМожно отключить этот пункт в настройках.",
                    "not_folder": True,
                    "icon": "DefaultAddonsRepo.png",

                })
        model.extend([
            {
                "title": "Избранное",
                "router": "favorites",
                "plot": "Онлайн и офлайн избранное",
                "icon": "DefaultAddonVfs.png",

            },
            {
                "title": "Новые серии",
                "router": "new",
                "plot": "От недавно вышедших к более старым",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
                "icon": "DefaultAddonInfoLibrary.png",
            },
            {
                "title": "Все франшизы",
                "router": "franchise_list",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Список по годам",
                "data": "year",
                "router": "list_for",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Список по жанрам",
                "data": "genres",
                "router": "list_for",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "Все аниме",
                "router": "all",
                "icon": "DefaultMovieTitle.png",
            },
            {
                "title": "YouTube",
                "router": "youtube_list",
                "plot": "Информация о вышедших роликах на YouTube каналах в хронологическом порядке",
                "icon": "DefaultAddonLanguage.png",
            },
            {
                "title": "Поиск по тегам",
                "router": "search_menu_advanced",
                "plot": "Поиск по тегам с историей",
                "icon": "DefaultAddonsSearch.png",
            },
            {
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ])

        return {
            "list": tuple(model),
            "category": "Меню",
        }
