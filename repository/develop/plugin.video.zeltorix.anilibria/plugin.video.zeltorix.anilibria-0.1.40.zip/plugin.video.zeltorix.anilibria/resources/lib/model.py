# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import load, dump, loads, dumps

from web_api_request import WebApiRequest, https_checking, Proxy
from get_video_link import VideoLink
from view import View, ViewDialogProgressBG
from history import History


class Model:
    __slots__ = [
        "_web"
    ]

    _view = View()
    _history = History()
    _video_link = VideoLink()
    _api: str = "https://api.anilibria.app/api/v1"
    _cdn: str = "https://static-libria.weekstorm.one"
    _params_limit: dict = {"limit": 50, }

    def __init__(self):
        self._web = WebApiRequest()

    @staticmethod
    def play(data):
        return {
            "type": "hls",
            "link_play": data,
        }

    def rutube(self, id_: str) -> dict:
        return self._video_link.youtube_link(id_)

    def youtube(self, id_: str) -> dict:
        return self._video_link.rutube_link(id_)

    def age_ratings(self):
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/references/age-ratings",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def genres(self):
        response = self._web.request_get(
            https_checking(
                "/anime/genres",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def genres_random(self) -> dict:
        model: list = []
        num: int = 8
        response = self._web.request_get(
            https_checking(
                f"/anime/genres/random?limit={num}",
                self._api
            ),
        )
        if response and type(response) is not dict:
            for i in loads(response.text):
                model.append({
                    "title": f"{i['name']} ({i['total_releases']})",
                    "data": i["id"],
                    "images": i["image"]["optmized"]["preview"]
                })
        else:
            self._view.output_logs(response, 3)
            raise
        return {
            "category": "Случайные жанры",
            "list": tuple(model),
        }

    def production_statuses(self):
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/references/production-statuses",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def publish_statuses(self):
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/references/publish-statuses",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def seasons(self):
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/references/seasons",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def sorting(self):
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/references/sorting",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def types(self):
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/references/types",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def years(self):
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/references/years",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)

    def _franchises_items(self, item: list) -> list:
        model: list = []
        for i in item:
            model.append({
                "title": i["name"],
                "data": i["id"],
                "year": i["first_year"],
                "router": "franchise_id",
                "plot": f"Года: {i['first_year']}-{i['last_year']}\n"
                        f"Английское название: {i['name_english']}\n"
                        f"Количество эпизодов: {i['total_episodes']}\n"
                        f"Количество сезонов: {i['total_releases']}\n"
                        f"Общая продолжительность: {i['total_duration']}",
                "images": f"{self._cdn}{i['image']['optimized']['preview']}",
                "duration": i["total_duration_in_seconds"],
            })
        return model

    def _franchises(self, url: str) -> dict:
        model: list = []
        response = self._web.request_get(
            https_checking(
                url,
                self._api
            ),
        )
        if response and type(response) is not dict:
            model.extend(self._franchises_items(loads(response.text)))
        else:
            self._view.output_logs(response, 3)
            raise
        return {
            "category": "Франшизы",
            "list": tuple(model),
        }

    def franchises(self) -> dict:
        return self._franchises("/anime/franchises")

    def franchises_random(self) -> dict:
        num: int = 5
        return self._franchises(f"/anime/franchises/random?limit={num}")

    def franchises_release_id(self, id_: str) -> dict:
        return self._franchises(f"/anime/franchises/release/{id_}")

    def franchise_id(self, id_: str) -> dict:
        model: list = []
        response = self._web.request_get(
            https_checking(
                f"/anime/franchises/{id_}",
                self._api
            ),
        )
        if response and type(response) is not dict:
            response_json = loads(response.text)
            category: str = response_json["name"]
            for i in response_json["franchise_releases"]:
                model.extend(self._releases_items([i["release"]]))
        else:
            self._view.output_logs(response, 3)
            raise
        return {
            "category": category,
            "list": tuple(model),
        }

    def _releases_items(self, items: list) -> list:
        model: list = []
        for i in items:
            # if i["age_rating"]["is_adult"] or True:
            #     continue
            context_menu: list = []
            genres: list = []
            year: int = i["year"]
            if i.get("genres"):
                genres.extend([f"{i['name']} ({i['total_releases']})" for i in i["genres"]])
                for g in i["genres"]:
                    context_menu.append((
                        f"Жанр: {g['name']}",
                        f"Container.Update({self._view.convert_to_url(router='releases_genres', data=g['id'])})"
                    ))
            genres.extend([
                i["type"]["description"],
                f"Год выхода: {year}",
                f"Возраст: {i['age_rating']['label']}",
                f"Выход {i['publish_day']['description']}",
                f"Всего серий: {i['episodes_total']}",
                f"Продолжительность серии: {i['average_duration_of_episode']}",
                f"Добавили в коллекции: {i['added_in_users_favorites']}",
            ])
            context_menu.append((
                f"Тип: {i['type']['description']}",
                f"Container.Update({self._view.convert_to_url(router='releases_types', data=i['type']['value'])})"
            ))
            model.append({
                "title": i["name"]["main"],
                "data": i["id"],
                "genres": genres,
                "year": year,
                "premiered": i["created_at"],
                "dateadded": i["fresh_at"],
                "router": "release",
                "plot": i["description"],
                "images": f"{self._cdn}{i['poster']['optimized']['src']}",
                "context_menu": context_menu,
            })
        return model

    def catalog_releases(self, category: str = "") -> dict:
        model: list = []
        response = self._web.request_get(
            https_checking(
                "/anime/catalog/releases",
                self._api
            ),
            params=self._params_limit
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)
            model.extend(self._releases_items(json_data["data"]))
            while True:
                if json_data["meta"]["pagination"]["links"].get("next"):
                    response_next = self._web.request_get(
                        https_checking(
                            json_data["meta"]["pagination"]["links"]["next"],
                            self._api
                        )
                    )
                    if response_next and type(response_next) is not dict:
                        json_data = loads(response_next.text)
                        model.extend(self._releases_items(json_data["data"]))
                else:
                    break
        else:
            self._view.output_logs(response, 3)
            raise
        return {
            "category": category,
            "list": tuple(model),
            "sort": [
                10,     # SORT_METHOD_TITLE_IGNORE_THE
                0,      # SORT_METHOD_NONE
            ],
        }

    def _releases(self, url: str, category: str = "", params: dict = None) -> dict:
        model: list = []
        if params:
            params: dict = {**self._params_limit, **params}
        else:
            params=self._params_limit
        response = self._web.request_get(
            https_checking(
                url,
                self._api
            ),
            params=params
        )
        if response and type(response) is not dict:
            model.extend(self._releases_items(loads(response.text)))
        else:
            self._view.output_logs(response, 3)
            raise
        return {
            "category": category,
            "list": tuple(model),
        }

    def releases_last(self) -> dict:
        return self._releases("/anime/releases/latest", "Последние релизы")

    def releases_random(self) -> dict:
        return self._releases("/anime/releases/random", "Случайные релизы")

    def releases_search(self, search_item) -> dict:
        self._history.history_add_item(search_item)
        return self._releases(
            url = "/app/search/releases",
            category = f"Поиск => {search_item}",
            params={
                "query": search_item,
            }
        )

    def release(self, id_: str) -> dict:
        category: str = ""
        model: list = []
        response = self._web.request_get(
            https_checking(
                f"/anime/releases/{id_}",
                self._api
            ),
        )
        if response and type(response) is not dict:
            json_data = loads(response.text)


            self._view.output_logs(dumps(json_data, indent=2, ensure_ascii=False), 1)

            if json_data["is_blocked_by_geo"] and json_data["episodes"] == []:
                if self._view.get_setting_bool("blocking_bool"):
                    if not self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility"):
                        Proxy().proxy_provider_reload()
                    _proxy = self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility")
                    response = WebApiRequest(proxy=_proxy).request_get(
                        https_checking(
                            f"/anime/releases/{id_}",
                            self._api
                        ),
                    )
                    if response and type(response) is not dict:
                        json_data = loads(response.text)
                else:
                    model.append({
                        "title": f"[COLOR=red]Обнаружена блокировка по геолокации![/COLOR]",
                        "plot": "Требуется включить обход блокировки в настройках плагина! "
                                "Так же его обновлять через инструменты.",

                    })

            context_menu: list = []
            genres: list = []
            year: int = json_data["year"]
            if json_data.get("genres"):
                genres.extend([f"{i['name']} ({i['total_releases']})" for i in json_data["genres"]])
                for g in json_data["genres"]:
                    context_menu.append((
                        f"Жанр: {g['name']}",
                        f"Container.Update({self._view.convert_to_url(router='releases_genres', data=g['id'])})"
                    ))
            genres.extend([
                f"Год выхода: {year}",
                f"Возраст: {json_data['age_rating']['label']}",
                f"Выход {json_data['publish_day']['description']}",
                f"Всего серий: {json_data['episodes_total']}",
                f"Продолжительность серии: {json_data['average_duration_of_episode']}\n"
                f"Добавили в коллекции: {json_data['added_in_users_favorites']}",
            ])
            context_menu.append((
                f"Тип: {json_data['type']['description']}",
                f"Container.Update({self._view.convert_to_url(router='releases_types', data=json_data['type']['value'])})"
            ))
            for i in json_data["episodes"]:
                data = ""
                router = "play"
                video_size = self._view.get_setting_int(
                    "video_resolution",
                    "script.module.zeltorix.utility"
                )
                if video_size:
                    height = video_size
                else:
                    height: int = self._view.get_windows_width_height()["height"]

                if height < 720:
                    if i["hls_480"]:
                        data = https_checking(i["hls_480"])
                    elif i["hls_720"]:
                        data = https_checking(i["hls_720"])
                    elif i["hls_1080"]:
                        data = https_checking(i["hls_1080"])
                elif 720 <= height < 1080:
                    if i["hls_720"]:
                        data = https_checking(i["hls_720"])
                    elif i["hls_1080"]:
                        data = https_checking(i["hls_1080"])
                    elif i["hls_480"]:
                        data = https_checking(i["hls_480"])
                elif 1080 <= height:
                    if i["hls_1080"]:
                        data = https_checking(i["hls_1080"])
                    elif i["hls_720"]:
                        data = https_checking(i["hls_720"])
                    elif i["hls_480"]:
                        data = https_checking(i["hls_480"])

                if not data:
                    if i["rutube_id"]:
                        data = i["rutube_id"]
                        router: str = "rutube"
                    elif i["youtube_id"]:
                        data = i["youtube_id"]
                        router: str = "youtube"
                else:
                    data = data

                model.append({
                    "title": f"[COLOR=red]{json_data['type']['description']}[/COLOR]."
                             f"[COLOR=blue]{i['ordinal']}[/COLOR] "
                             f"{i['name'] or ''}",
                    "data": data,
                    "genres": genres,
                    "year": year,
                    "premiered": json_data["created_at"],
                    "dateadded": json_data["fresh_at"],
                    "router": router,
                    "plot": json_data["description"],
                    "images": f"{self._cdn}{i['preview']['optimized']['src']}",
                    "context_menu": context_menu,
                    "duration": i["duration"],
                    "play": True,
                })
        else:
            self._view.output_logs(response, 3)
            raise
        return {
            "category": category,
            "list": tuple(model),
        }

    def main(self) -> dict:
        model: list = []
        # if not self._view.get_setting_bool("auth_bool") or self._view.get_setting_bool("auth_hide_bool"):
        #     model.append({
        #         "title": "Авторизация",
        #         "router": "auth",
        #         "plot": "Нужно для удаленного управления избранным.\nМожно отключить этот пункт в настройках.",
        #     })
        model.extend([
            # {
            #     "title": "Избранное",
            #     "router": "favorites",
            #     "plot": "Онлайн и офлайн избранное",
            # },
            {
                "title": "Новые серии",
                "router": "new",
                "plot": "От недавно вышедших к более старым",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
            },
            {
                "title": "Все франшизы",
                "router": "franchises",
            },
            {
                "title": "Все аниме",
                "router": "all",
            },
            {
                "title": "Поиск",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ])

        return {
            "list": tuple(model),
            "category": "Меню",
        }
