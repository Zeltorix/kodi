# -*- coding: utf-8 -*-
# Module: auth
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from json import dumps, loads, load, dump
from pathlib import Path
from re import findall
from time import time, gmtime
from datetime import timedelta

from web_api_request import WebApiRequest, https_checking, headers, Proxy
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from view import View


class Auth:
    __slots__ = [
        "_web",
        "_plugin_folder",
        "_plugin_session",
    ]

    _view = View()

    def __init__(self, headers_=headers, proxy=None):
        self._web = WebApiRequest(headers_, proxy=proxy)
        self._plugin_folder = Path(self._view.plugin_folder)
        self._plugin_session = Path(self._view.plugin_folder, "session.json")

    def auth(self):
        post: dict = {
            "mail": self._view.dialog_input(label="Логин или электронная почта от аккаунта"),
            "passwd": self._view.dialog_input(label="Пароль от аккаунта"),
        }

        session_id = None
        time_expires = None

        Proxy().proxy_provider_reload()
        self._web.__init__(proxy=self._view.get_setting_str("proxy_query", "script.module.zeltorix.utility"))
        response = self._web.request_post("https://www.anilibria.tv/public/login.php", data=post)
        if response and type(response) is not dict:
            expires = findall(r"expires=.*?;", response.headers["set-cookie"])[0][8:-1]
            session_id = response.json()["sessionId"]
            time_expires = date_time_to_local(expires, format_input="%a, %d %B %Y %H:%M:%S", second_output=True)
        else:
            self._view.output_logs(response)

        if session_id and time_expires:
            if not self._plugin_folder.exists():
                self._plugin_folder.mkdir(parents=True)
            with open(self._plugin_session, "w+") as file:
                dump({
                    "session_id": session_id,
                    "expires": time_expires,
                }, file, indent=2)

            self._view.dialog_ok("Авторизация", f"Авторизация выполнена.\n"
                                                f"До повторной авторизации осталось:\n"
                                                f"{str(timedelta(seconds=time_expires-time()))}")

    def get_session_id(self) -> dict:
        if self._plugin_session.exists():
            with open(self._plugin_session, "r") as file:
                return load(file)

    def auth_del(self):
        if self._plugin_session.exists():
            self._plugin_session.unlink()
            self._view.dialog_ok("Авторизация", "Авторизация удалена")
