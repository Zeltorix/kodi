# -*- coding: utf-8 -*-
# Module: auth
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from datetime import datetime
from time import time
from urllib.parse import urlencode, parse_qsl
from re import findall

try:
    from web_api_request import WebApiRequest, https_checking, headers, Proxy
    from text_job import shy, ras, date_to_time_stamp, date_time_to_local
    from view import View
except ImportError:
    try:
        from source.release.utilitys.resources.lib.web_api_request import WebApiRequest, https_checking, headers, Proxy
        from source.release.utilitys.resources.lib.text_job import shy, ras, date_to_time_stamp, date_time_to_local


        class View:
            @staticmethod
            def get_setting_int(item):
                if item == "video_size":
                    return 720

            @staticmethod
            def get_setting_bool(item):
                if item == "auth_bool":
                    return False
                if item == "auth_hide_bool":
                    return False

            @staticmethod
            def dialog_input(label) -> str:
                return input(label + ": ")


    except:
        pass


class Auth:
    __slots__ = [
        "_web",
    ]

    _view = View()

    def __init__(self, headers_=headers, proxy=None):
        self._web = WebApiRequest(headers_, proxy=proxy)

    def auth(self):
        post: dict = {
            "mail": self._view.dialog_input(label="Логин или электронная почта от аккаунта"),
            "passwd": self._view.dialog_input(label="Пароль от аккаунта"),
        }

        proxy = Proxy().censortracker()
        self._web.__init__(proxy=proxy)
        response = self._web.request_post("https://www.anilibria.tv/public/login.php", data=post)
        if response and type(response) is not dict:
            expires = findall(r"expires=.*?;", response.headers["set-cookie"])[0][8:-1]
            session_id = response.json()["sessionId"]
            d = date_time_to_local(expires, format_input="%a, %d %B %Y %H:%M:%S", second_output=True)
            print(expires)
            print(d)
            print(session_id)