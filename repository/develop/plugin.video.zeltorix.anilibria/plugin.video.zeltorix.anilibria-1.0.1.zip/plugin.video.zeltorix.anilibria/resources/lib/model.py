# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from datetime import datetime
from time import time
from urllib.parse import urlencode, parse_qsl

try:
    from web_api_request import WebApiRequest, https_checking, headers, Proxy
    from text_job import shy, ras, date_to_time_stamp, date_time_to_local
    from get_video_link import VideoLink
    from view import View
    from history import History
except ImportError:
    try:
        from source.release.utilitys.resources.lib.web_api_request import WebApiRequest, https_checking, headers, Proxy
        from source.release.utilitys.resources.lib.text_job import shy, ras, date_to_time_stamp, date_time_to_local
        from source.release.utilitys.resources.lib.get_video_link import VideoLink


        class View:
            @staticmethod
            def convert_to_url(**kwargs):
                return f"?{urlencode(kwargs)}"

            @staticmethod
            def get_setting_int(item):
                if item == "video_size":
                    return 720

            @staticmethod
            def get_setting_bool(item):
                if item == "auth_bool":
                    return False
                if item == "auth_hide_bool":
                    return False

            @staticmethod
            def get_windows_width_height():
                return {
                    "width": 1280,
                    "height": 720,
                }

            @staticmethod
            def dialog_multiselect(h: str, list_items: list):
                print(list_items, sep="\n")
                return [input(h + ": ").split(" ")]

            @staticmethod
            def dialog_input(label) -> str:
                return input(label + ": ")


        class History:
            @staticmethod
            def history_add_item(item):
                print(item)
    except:
        pass

from .auth import Auth


class Model:
    __slots__ = [
        "api",
        "cdn",
    ]

    _web = WebApiRequest()
    _view = View()
    _history = History()
    _video_link = VideoLink()

    def __init__(self):
        self.api: str = "/3v/vt.airbilina.ipa//:sptth"[::-1]
        self.cdn: str = "eno.mrotskeew.airbil-citats//:sptth"[::-1]

    def _limits(self, item: str) -> dict:
        if item == "new":
            return {
                "limit": -1,
                "since": int(time()) - 7_776_000
            }
        elif item == "youtube":
            return {
                "limit": -1,
            }
        elif item == "all":
            return {
                "limit": -1,
            }

    def _realise(self, link: str, params: dict) -> dict:
        model: list = []
        category: str = "Проблемы с получением реализа"
        response = self._web.request_get(https_checking(self.api + link), params=params)
        if response and type(response) is not dict:
            realise: dict = response.json()

            if realise["status"]["code"] == 2:
                category_include: str = f"({realise['status']['string']}) "
            elif realise["player"]["episodes"]["string"]:
                category_include: str = f"({realise['player']['episodes']['string']}) "
            else:
                category_include: str = ""

            category: str = f"{category_include}{realise['names']['ru']}"
            images: str = https_checking(self.cdn + realise["posters"]["original"]["url"])
            plot: str = realise["description"]
            host: str = realise["player"]["host"]
            if realise["player"]["list"]:
                for episode in realise["player"]["list"].values():
                    model_episode: dict = {
                        "premiered": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "dateadded": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "images": images,
                        "plot": plot,
                        "router": "play",
                        "play": True,
                    }
                    title: str = realise["type"]["string"]
                    if episode["episode"]:
                        title: str = f"{title}.{episode["episode"]}"
                        model_episode["episode"]: int = episode["episode"]
                    if episode["name"]:
                        title: str = f"{title} {episode["name"]}"
                    model_episode["title"]: str = title

                    if episode["preview"]:
                        model_episode["images"]: str = https_checking(self.cdn + episode["preview"])

                    video_size: int = self._view.get_setting_int("video_size")
                    if video_size:
                        if video_size == 480:
                            if episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif video_size == 720:
                            if episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif video_size == 1080:
                            if episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                    else:
                        height: int = self._view.get_windows_width_height()["height"]
                        if height < 720:
                            if episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif 720 < height < 1080:
                            if episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif 1080 <= height:
                            if episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                    model.append(model_episode)
            elif realise["player"]["rutube"]:
                for episode in realise["player"]["rutube"].values():
                    model_episode = {
                        "premiered": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "dateadded": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "images": images,
                        "plot": plot,
                        "router": "rutube",
                        "play": True,
                        "data": episode["rutube_id"],
                    }
                    title: str = realise["type"]["string"]
                    if episode["episode"]:
                        title: str = f"{title}.{episode["episode"]}"
                        model_episode["episode"]: int = episode["episode"]
                    model_episode["title"]: str = title
                    model.append(model_episode)

        return {
            "list": tuple(model),
            "category": category,
        }

    def _listing(self, link: str, params: dict, category: str = "") -> dict:
        model: list = []
        response = self._web.request_get(https_checking(self.api + link), params=params)
        if response and type(response) is not dict:
            for item in response.json()["list"]:
                genres: list = []
                if item["genres"]:
                    genres.extend(item["genres"])
                if item["team"]:
                    if item["team"]["voice"]:
                        genres.extend(item["team"]["voice"])
                    if item["team"]["translator"]:
                        genres.extend(item["team"]["translator"])
                    if item["team"]["editing"]:
                        genres.extend(item["team"]["editing"])
                    if item["team"]["decor"]:
                        genres.extend(item["team"]["decor"])
                    if item["team"]["timing"]:
                        genres.extend(item["team"]["timing"])

                context_menu: list = []
                if item["franchises"]:
                    genres.append("Является частью франшизы")

                    for franchise in item["franchises"]:
                        context_menu.append((
                            f"Франшиза: {franchise['franchise']['name']}",
                            f"Container.Update({self._view.convert_to_url(
                                router='franchises',
                                data=franchise['franchise']['id'])})"
                        ))
                        for release in franchise["releases"]:
                            context_menu.append((
                                f"Реализ франшизы: {release["names"]["ru"]}",
                                f"Container.Update({self._view.convert_to_url(
                                    router='release',
                                    data=release['code'])
                                })"
                            ))

                if item["updated"]:
                    premiered = str(datetime.fromtimestamp(item["updated"]))
                else:
                    premiered = 0

                model.append({
                    "data": f"{item['code']} ({item['type']['full_string']})",
                    "title": item["names"]["ru"],
                    "images": https_checking(self.cdn + item["posters"]["original"]["url"]),
                    "premiered": premiered,
                    "dateadded": premiered,
                    "genres": genres,
                    "year": int(item["season"]["year"]),
                    "plot": item["description"],
                    "context_menu": context_menu,
                    "router": "realise",
                })

        return {
            "list": tuple(model),
            "category": category,
            "sort": [
                0,  # SORT_METHOD_NONE
                3,  # SORT_METHOD_DATE
                9,  # SORT_METHOD_TITLE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def new(self) -> dict:
        params: dict = {
            **self._limits("new")
        }
        return self._listing(link="title/updates", params=params, category=f"Новые серии")

    def random(self) -> dict:
        params: dict = {
        }
        return self._realise(link="title/random", params=params)

    def franchise_list(self) -> dict:
        model: list = []
        params: dict = {
            **self._limits("all")
        }
        response = self._web.request_get(https_checking(self.api + "franchise/list"), params=params)
        if response and type(response) is not dict:
            for item in response.json()["list"]:
                model.append({
                    "data": item["franchise"]["id"],
                    "title": item["franchise"]["name"],
                    "plot": "\n".join([release["names"]["ru"] for release in item["releases"]]),
                    "router": "franchise",
                })

        return {
            "list": tuple(model),
            "category": "Все франшизы",
            "sort": [
                0,  # SORT_METHOD_NONE
                9,  # SORT_METHOD_TITLE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
            ]
        }

    def list_for(self, type_item: str = "", text_item: str = "") -> dict:
        if type_item in ["year", "genres"]:
            if type_item == "year":
                type_item_ = "years"
            else:
                type_item_ = type_item
            response = self._web.request_get(https_checking(self.api + type_item_))
            if response and type(response) is not dict:
                response_list: list = response.json()
                select_items: list = self._view.dialog_multiselect("Множественный выбор", response_list)
                text_item = ",".join([str(response_list[i]) for i in select_items])
        else:
            type_item = "team"
        params = {
            type_item: text_item,
            **self._limits("all"),
        }
        return self._listing(link="title/search", params=params, category=f"Найдено по запросу => {text_item}")

    def all(self) -> dict:
        params: dict = {
            **self._limits("all")
        }
        return self._listing(link="title/changes", params=params, category=f"Все аниме")

    def youtube_id(self, youtube_id: str) -> dict:
        return {
            "type": False,
            "link_play": self._video_link.youtube_link("https://www.youtube.com/watch?v=" + youtube_id),
        }

    def youtube_list(self) -> dict:
        model: list = []
        params: dict = {
            **self._limits("youtube")
        }
        response = self._web.request_get(https_checking(self.api + "youtube"), params=params)
        if response and type(response) is not dict:
            for item in response.json()["list"]:
                model.append({
                    "episode": item["id"],
                    "title": item["title"],
                    "images": f"{self.cdn}{item['preview']['src']}",
                    "data": item["youtube_id"],
                    "premiered": str(datetime.fromtimestamp(item["timestamp"])),
                    "dateadded": str(datetime.fromtimestamp(item["timestamp"])),
                    "router": "youtube_id",
                })

        return {
            "list": tuple(model),
            "category": "YouTube",
            "sort": [
                0,  # SORT_METHOD_NONE
                3,  # SORT_METHOD_DATE
                9,  # SORT_METHOD_TITLE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)
        params = {
            "search": search_item,
            **self._limits("all"),
        }
        return self._listing(link="title/search", params=params, category=f"Найдено по запросу => {search_item}")

    def main(self) -> dict:
        model: list = []
        if not self._view.get_setting_bool("auth_bool") or self._view.get_setting_bool("auth_hide_bool"):
            model.append({
                "title": "Авторизация",
                "router": "auth",
                "plot": "Нужно для удаленного управления избранным.\nМожно отключить этот пункт в настройках.",
            })
        model.extend([
            {
                "title": "Избранное",
                "router": "favorites",
                "plot": "Онлайн и офлайн избранное",
            },
            {
                "title": "Новые серии",
                "router": "new",
                "plot": "От недавно вышедших к более старым",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
            },
            {
                "title": "Все франшизы",
                "router": "franchise_list",
            },
            {
                "title": "Список по годам",
                "data": "year",
                "router": "list_for",
            },
            {
                "title": "Список по жанрам",
                "data": "genres",
                "router": "list_for",
            },
            {
                "title": "Все аниме",
                "router": "all",
            },
            {
                "title": "YouTube",
                "router": "youtube_list",
                "plot": "Информация о вышедших роликах на наших YouTube каналах в хронологическом порядке",
            },
            {
                "title": "Поиск",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ])

        return {
            "list": tuple(model),
            "category": "Меню",
        }
