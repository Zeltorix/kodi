# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
from datetime import datetime
from time import time
from json import dumps

from web_api_request import WebApiRequest, https_checking, headers, Proxy
from text_job import shy, ras, date_to_time_stamp, date_time_to_local
from get_video_link import VideoLink
from view import View
from history import History


from .auth import Auth


class Model:
    __slots__ = [
        "api",
        "cdn",
    ]

    _web = WebApiRequest()
    _view = View()
    _history = History()
    _video_link = VideoLink()
    _auth = Auth()

    def __init__(self):
        self.api: str = ras("==wLzY3L2RnLhlmcilGbp5WYukGch9yL6MHc0RHa")
        self.cdn: str = ras("=Umbv5Sby9GdztWZldnLhlmcilGbtMWa0FGdz9yL6MHc0RHa")

    def _limits(self, item: str) -> dict:
        if item == "new":
            return {
                "limit": -1,
                "since": int(time()) - 7_776_000
            }
        elif item == "youtube":
            return {
                "limit": -1,
            }
        elif item == "all":
            return {
                "limit": -1,
            }

    def _release(self, link: str, params: dict) -> dict:
        params: dict = {
            "filter": "id,"
                      "code,"
                      "names.ru,"
                      "status.string,"
                      "status.code,"
                      "posters.original.url,"
                      "type.string,"
                      "type.length,"
                      "description,"
                      "player.alternative_player,"
                      "player.host,"
                      "player.episodes.string,"
                      "player.list,"
                      "player.rutube",
            **params,
        }
        model: list = []
        category: str = "Проблемы с получением реализа"
        response = self._web.request_get(https_checking(self.api + link), params=params)
        if response and type(response) is not dict:
            release: dict = response.json()

            if release["status"]["code"] == 2:
                category_include: str = f"({release['status']['string']}) "
            elif release["player"]["episodes"]["string"]:
                category_include: str = f"({release['player']['episodes']['string']}) "
            else:
                category_include: str = ""

            category: str = f"{category_include}{release['names']['ru']}"
            images: str = https_checking(self.cdn + release["posters"]["original"]["url"])
            plot: str = release["description"]
            host: str = release["player"]["host"]
            if release["player"]["list"]:
                for episode in release["player"]["list"].values():
                    if episode["preview"]:
                        images: str = https_checking(self.cdn + episode["preview"])
                    model_episode: dict = {
                        "premiered": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "dateadded": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "images": images,
                        "plot": plot,
                        "duration": release["type"]["length"],
                        "router": "play",
                        "play": True,
                    }
                    title: str = release["type"]["string"]
                    if episode["episode"]:
                        title: str = f"[COLOR=green]{title}[/COLOR].[COLOR=yellow]{episode['episode']}[/COLOR]"
                        model_episode["episode"]: int = episode["episode"]
                    if episode["name"]:
                        title: str = f"{title} {episode['name']}"
                    model_episode["title"]: str = title

                    video_size: int = self._view.get_setting_int("video_size")
                    if video_size:
                        if video_size == 480:
                            if episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif video_size == 720:
                            if episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif video_size == 1080:
                            if episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                    else:
                        height: int = self._view.get_windows_width_height()["height"]
                        if height < 720:
                            if episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif 720 <= height < 1080:
                            if episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                            elif episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                        elif 1080 <= height:
                            if episode["hls"]["fhd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["fhd"])
                            elif episode["hls"]["hd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["hd"])
                            elif episode["hls"]["sd"]:
                                model_episode["data"]: str = https_checking(host + episode["hls"]["sd"])
                        else:
                            raise ValueError("Отсутствия потоков на видео")
                    model.append(model_episode)
            elif release["player"]["rutube"]:
                for episode in release["player"]["rutube"].values():
                    model_episode = {
                        "premiered": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "dateadded": str(datetime.fromtimestamp(episode["created_timestamp"])),
                        "images": images,
                        "plot": plot,
                        "duration": release["type"]["length"],
                        "router": "rutube",
                        "play": True,
                        "data": episode["rutube_id"],
                    }
                    title: str = release["type"]["string"]
                    if episode["episode"]:
                        title: str = f"{title}.{episode['episode']}"
                        model_episode["episode"]: int = episode["episode"]
                    model_episode["title"]: str = title
                    model.append(model_episode)

        return {
            "list": tuple(model),
            "category": category,
        }

    def _listing(self, link: str, params: dict, category: str = "", title_color: str = "", favorites=False) -> dict:
        model: list = []
        params: dict = {
            "filter": "id,"
                      "code,"
                      "names.ru,"
                      "franchises,"
                      "status.string,"
                      "posters.original.url,"
                      "updated,"
                      "type.full_string,"
                      "genres,"
                      "team,"
                      "season.year,"
                      "description,",
            **params,
        }

        if link == "title/changes":
            self._web.__init__(timeout=30)
        response = self._web.request_get(https_checking(self.api + link), params=params)

        if response and type(response) is not dict:
            for item in response.json()["list"]:
                context_menu: list = []
                genres: list = []
                if item["genres"]:
                    genres.extend(item["genres"])

                genres.append(item['type']['full_string'])
                genres.append(item['status']['string'])

                if item["team"]:
                    if item["team"]["voice"]:
                        genres.extend(item["team"]["voice"])
                        for voice in item["team"]["voice"]:
                            context_menu.append((
                                f"Озвучка: {voice}",
                                f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=voice)})"
                            ))
                    if item["team"]["translator"]:
                        genres.extend(item["team"]["translator"])
                        for translator in item["team"]["translator"]:
                            context_menu.append((
                                f"Переводчик: {translator}",
                                f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=translator)})"
                            ))
                    if item["team"]["editing"]:
                        genres.extend(item["team"]["editing"])
                        for editing in item["team"]["editing"]:
                            context_menu.append((
                                f"Субтитры: {editing}",
                                f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=editing)})"
                            ))
                    if item["team"]["decor"]:
                        genres.extend(item["team"]["decor"])
                        for decor in item["team"]["decor"]:
                            context_menu.append((
                                f"Оформитель: {decor}",
                                f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=decor)})"
                            ))
                    if item["team"]["timing"]:
                        genres.extend(item["team"]["timing"])
                        for timing in item["team"]["timing"]:
                            context_menu.append((
                                f"Тайминг: {timing}",
                                f"Container.Update({self._view.convert_to_url(router='list_for', data='team', text_item=timing)})"
                            ))

                if item["franchises"]:
                    genres.append("Франшиза")

                    for franchise in item["franchises"]:
                        context_menu.append((
                            f"Франшиза: {franchise['franchise']['name']}",
                            f"Container.Update({self._view.convert_to_url(router='franchises', data=franchise['franchise']['id'])})"
                        ))
                        for release in franchise["releases"]:
                            context_menu.append((
                                f"Реализ франшизы: {release['names']['ru']}",
                                f"Container.Update({self._view.convert_to_url(router='release', data=release['code'])})"
                            ))

                if not favorites:
                    context_menu.append((
                        f"Добавить в онлайн избранное",
                        f"Container.Update({self._view.convert_to_url(router='favorites_online_add', data=item['id'])})"
                    ))
                if favorites:
                    context_menu.append((
                        f"Удалить из онлайн избранного",
                        f"Container.Update({self._view.convert_to_url(router='favorites_online_del', data=item['id'])})"
                    ))

                if item["updated"]:
                    premiered = str(datetime.fromtimestamp(item["updated"]))
                else:
                    premiered = 0

                model.append({
                    "data": item["code"],
                    "title": f"[COLOR={title_color}]{item['names']['ru']}[/COLOR]",
                    "images": https_checking(self.cdn + item["posters"]["original"]["url"]),
                    "premiered": premiered,
                    "dateadded": premiered,
                    "genres": genres,
                    "year": int(item["season"]["year"]),
                    "plot": item["description"],
                    "context_menu": context_menu,
                    "router": "release",
                })

        return {
            "list": tuple(model),
            "category": category,
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    @staticmethod
    def play(link: str) -> dict:
        return {
            "type": None,
            "link_play": link,
        }

    def rutube(self, id_) -> dict:
        return {
            "type": "hls",
            "link_play": self._video_link.rutube_link(id_),
        }

    def youtube_id(self, youtube_id: str) -> dict:
        return {
            "type": False,
            "link_play": self._video_link.youtube_link("https://www.youtube.com/watch?v=" + youtube_id),
        }

    def release(self, code: str) -> dict:
        params: dict = {
            "code": code,
        }
        return self._release(link="title", params=params)

    def favorites_online_add(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            post: dict = {}
            response = self._web.request_put(https_checking(self.api + "user/favorites"), params=params, data=post)
            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites_online_del(self, id_: str) -> bool:
        if self._auth.get_session_id():
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                "title_id": id_,
            }
            response = self._web.request_delete(https_checking(self.api + "user/favorites"), params=params)
            if response and type(response) is not dict:
                if response.json()["success"]:
                    return True

    def favorites(self) -> dict:
        if self._auth.get_session_id():
            params: dict = {
                "session": self._auth.get_session_id()["session_id"],
                **self._limits("all"),
            }
            return self._listing(link="user/favorites",
                                 params=params,
                                 category=f"Избранное",
                                 title_color="blue",
                                 favorites=True)

    def new(self) -> dict:
        params: dict = {
            **self._limits("new")
        }
        return self._listing(link="title/updates", params=params, category=f"Новые серии")

    def random(self) -> dict:
        params: dict = {
        }
        return self._release(link="title/random", params=params)

    def franchise_list(self) -> dict:
        model: list = []
        params: dict = {
            "filter": "franchise.name,"
                      "releases",
            **self._limits("all"),
        }
        response = self._web.request_get(https_checking(self.api + "franchise/list"), params=params)
        if response and type(response) is not dict:
            for franchise in response.json()["list"]:
                model.append({
                    "title": f"[COLOR=grey]{franchise['franchise']['name']} ==>[/COLOR]",
                })
                for release in franchise["releases"]:
                    model.append({
                        "title": f"[COLOR=grey]{franchise['franchise']['name']} ==>[/COLOR] {release['names']['ru']}",
                        "data": release["code"],
                        "router": "release",
                    })

        return {
            "list": tuple(model),
            "category": "Все франшизы",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
            ]
        }

    def list_for(self, type_item: str = "", text_item: str = "") -> dict:
        if type_item in ["year", "genres"]:
            if type_item == "year":
                type_item_ = "years"
            else:
                type_item_ = type_item
            response = self._web.request_get(https_checking(self.api + type_item_))
            if response and type(response) is not dict:
                response_list: list = list(map(str, response.json()))
                select_items: list = self._view.dialog_multiselect("Множественный выбор", response_list)
                if select_items:
                    text_item = ",".join([str(response_list[i]) for i in select_items])
        else:
            type_item = "team"
        if text_item:
            params = {
                type_item: text_item,
                **self._limits("all"),
            }
            return self._listing(link="title/search", params=params, category=f"Найдено по запросу => {text_item}")

    def all(self) -> dict:
        params: dict = {
            **self._limits("all")
        }
        return self._listing(link="title/changes", params=params, category=f"Все аниме")

    def youtube_list(self) -> dict:
        model: list = []
        params: dict = {
            "filter": "id,"
                      "title,"
                      "preview.src,"
                      "youtube_id,"
                      "timestamp",
            **self._limits("youtube")
        }
        response = self._web.request_get(https_checking(self.api + "youtube"), params=params)
        if response and type(response) is not dict:
            for item in response.json()["list"]:
                model.append({
                    "episode": item["id"],
                    "title": item["title"],
                    "images": f"{self.cdn}{item['preview']['src']}",
                    "data": item["youtube_id"],
                    "premiered": str(datetime.fromtimestamp(item["timestamp"])),
                    "dateadded": str(datetime.fromtimestamp(item["timestamp"])),
                    "router": "youtube_id",
                    "play": True,
                })

        return {
            "list": tuple(model),
            "category": "YouTube",
            "sort": [
                0,  # SORT_METHOD_NONE
                10,  # SORT_METHOD_TITLE_IGNORE_THE
                21,  # SORT_METHOD_DATEADDED
            ]
        }

    def search(self, search_item: str) -> dict:
        self._history.history_add_item(search_item)
        params = {
            "search": search_item,
            **self._limits("all"),
        }
        return self._listing(link="title/search", params=params, category=f"Найдено по запросу => {search_item}")

    def main(self) -> dict:
        model: list = []
        # if not self._view.get_setting_bool("auth_bool") or self._view.get_setting_bool("auth_hide_bool"):
        if self._view.get_setting_bool("auth_bool"):
            if self._auth.get_session_id() and self._auth.get_session_id()["time_expires"] < time():
                model.append({
                    "title": "Авторизация",
                    "router": "auth",
                    "plot": "Нужно для удаленного управления избранным.\nМожно отключить этот пункт в настройках.",
                    "not_folder": True,
                })
        model.extend([
            {
                "title": "Избранное",
                "router": "favorites",
                "plot": "Онлайн и офлайн избранное",
            },
            {
                "title": "Новые серии",
                "router": "new",
                "plot": "От недавно вышедших к более старым",
            },
            {
                "title": "Случайное аниме",
                "router": "random",
            },
            {
                "title": "Все франшизы",
                "router": "franchise_list",
            },
            {
                "title": "Список по годам",
                "data": "year",
                "router": "list_for",
            },
            {
                "title": "Список по жанрам",
                "data": "genres",
                "router": "list_for",
            },
            {
                "title": "Все аниме",
                "router": "all",
            },
            {
                "title": "YouTube",
                "router": "youtube_list",
                "plot": "Информация о вышедших роликах на наших YouTube каналах в хронологическом порядке",
            },
            {
                "title": "Меню поиска",
                "router": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            }
        ])

        return {
            "list": tuple(model),
            "category": "Меню",
        }
