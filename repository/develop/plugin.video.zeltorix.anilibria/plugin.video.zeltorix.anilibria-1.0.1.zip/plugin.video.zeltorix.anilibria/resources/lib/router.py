# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2024.03.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View
from history import History

from .model import Model
from .auth import Auth
from .downloads import Downloads


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f"Нельзя представить как словарь: {data_string}")
    _view = View()
    _model = Model()
    _auth = Auth()
    _history = History()
    if params_dict:
        # Блок поиска
        if params_dict["router"] == "search":
            # Интеграция с дополнением United Search
            if params_dict.get("keyword"):
                _view.output(_model.search(params_dict["keyword"]))
            elif params_dict.get("search_start"):
                _view.output(_model.search(params_dict["search_item"]))
            else:
                # Вывод поиска, импортировано из модуля view
                input_text = _view.dialog_text_input()
                if input_text:
                    _view.output(_model.search(input_text))
                _view.output(_history.search_menu())
        elif params_dict["router"] == "search_menu":
            _view.output(_history.search_menu())

        # Блок работы с историей
        elif params_dict["router"] == "search_history":
            _view.output(_model.search(params_dict["data"]))
        elif params_dict["router"] == "history_clearing":
            if _history.history_clearing():
                _view.dialog_ok("Очистка истории поиска", "История поиска очищена")
        elif params_dict["router"] == "history_del_item":
            if _history.history_del_item(params_dict["data"]):
                _view.output(_history.search_menu())
        elif params_dict["router"] == "history_realise":
            _view.output(_model.release(_view.get_setting_str("history_realise")))

        # Блок воспроизведения
        elif params_dict["router"] == "play":
            _view.play(_model.play(params_dict["data"]))
        elif params_dict["router"] == "rutube":
            _view.play(_model.rutube(params_dict["data"]))
        elif params_dict["router"] == "youtube_id":
            _view.play(_model.youtube_id(params_dict["data"]))

        # Блок списка серий
        elif params_dict["router"] == "release":
            _view.output(_model.release(params_dict["data"]))
        elif params_dict["router"] == "random":
            _view.output(_model.random())

        # Блок списков аниме
        elif params_dict["router"] == "new":
            _view.output(_model.new())
        elif params_dict["router"] == "favorites":
            _view.output(_model.favorites())
        elif params_dict["router"] == "franchise_list":
            _view.output(_model.franchise_list())
        elif params_dict["router"] == "list_for":
            if params_dict.get("text_item"):
                _view.output(_model.list_for(params_dict["data"], params_dict["text_item"]))
            else:
                items = _model.list_for(params_dict["data"])
                if items:
                    _view.output(items)
                else:
                    _view.output(_model.main())
        elif params_dict["router"] == "all":
            _view.output(_model.all())
        elif params_dict["router"] == "youtube_list":
            _view.output(_model.youtube_list())

        # Блок обций
        elif params_dict["router"] == "auth":
            _auth.auth()
        elif params_dict["router"] == "favorites_online_add":
            if _model.favorites_online_add(params_dict["data"]):
                _view.output(_model.favorites())
            else:
                _view.output(_model.main())
        elif params_dict["router"] == "favorites_online_del":
            if _model.favorites_online_del(params_dict["data"]):
                _view.output(_model.favorites())
            else:
                _view.output(_model.main())
        # Блок загрузки
        elif params_dict["router"] == "download_full_anime":
            Downloads().download_full_anime(params_dict["data"])

        # Блок исключения
        else:
            raise ValueError(f"Не нашлось нужных ключей: {params_dict}")
    else:
        _view.output(_model.main())
