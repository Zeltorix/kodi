# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.11.21
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули, пакеты
from json import dumps, loads
from pathlib import Path

# Модули с дополнения
from view_base import View
from xmltodict import xmltodict


class Model:
    __slots__ = []
    _view = View()
    addon_data = Path(_view.PLUGIN_FOLDER).parent
    userdata = addon_data.parent
    favourites = Path(userdata, "favourites.xml")
    super_favourites = Path(addon_data, "plugin.program.super.favourites")
    favourites_file_in_sf = Path(super_favourites, "Super Favourites", "Избранное", "favourites.xml")

    def add_f(self):
        super_favourites_folder_favourites = Path(self.super_favourites, "Super Favourites", "Избранное")
        if super_favourites_folder_favourites.is_dir():
            pass
        else:
            super_favourites_folder_favourites.mkdir(parents=True, exist_ok=True)
        self.favourites_file_in_sf.write_bytes(self.favourites.read_bytes())
        self._view.dialog_ok(
                "Избранное скопировано",
                f"Файл {self.favourites} скопирован в {self.favourites_file_in_sf}")

    def main(self) -> dict:
        model: list = []
        if self.favourites.is_file() and \
           self.super_favourites.is_dir():
            model.append({
                "title": "[COLOR=red]Перенос Избранного KODI в Супер Избранное[/COLOR]",
                "router": "add",
                "not_folder": True,
            })
            with open(self.favourites, "r") as file:
                dict_xml = xmltodict.parse(file.read())
            for item in dict_xml["favourites"]["favourite"]:
                model.append({
                    "title": item["@name"],
                    "thumb": item["@thumb"],
                    # "router": item["#text"],
                    "router": "",
                })
        return {
            "category": "Избранное",
            "list": tuple(model)
        }
