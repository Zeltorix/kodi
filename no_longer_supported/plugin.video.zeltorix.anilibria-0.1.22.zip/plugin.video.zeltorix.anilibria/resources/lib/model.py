# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.01.14
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина plugin.video.zeltorix.anilibria для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модуль
from datetime import datetime
import sys
import json

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserAniLibria
    from .view import View
except ImportError:
    # Импорт для тестирования
    from source.release.anilibria.resources.lib.parser import ParserAniLibria
    from source.release.anilibria.resources.lib.view import View


class ModelAniLibria:
    __slots__ = []
    _parser = ParserAniLibria()
    _cdn: str = _parser.cdn()
    _view = View()
    _size_video = View().get_setting("size_video").lower()

    def _title_normalise(self, item: dict) -> dict:
        model: dict = dict()
        posters: str = str(f"{self._cdn}{item['posters']['original']['url']}")
        model["label"]: str = str(item["names"]["ru"])
        model["total_episodes"]: int = int(item["type"]["episodes"] or 0)
        model["video_type"]: str = str(item["type"]["string"])
        model["last"]: int = int(item["player"]["episodes"]["last"] or 0)
        model["plot"]: str = str(item["description"])
        model["plotoutline"]: str = str(item["announce"])
        model["posters"]: str = posters
        model["players"]: tuple = self._title_season_normalise(item["player"], posters)
        return model

    def _title_season_normalise(self, items: dict, posters: str) -> tuple:
        model_list: list = []
        host: str = "https://" + items["host"]
        if items["list"]:
            for values in items["list"].values():
                model: dict = dict()
                model["episode"]: int = int(values["episode"])
                model["title"]: str = str(values["name"] or "")
                model["premiered"]: str = datetime.fromtimestamp(values["created_timestamp"]).strftime('%Y-%m-%d')
                if values["preview"]:
                    model["posters"]: str = f'{self._cdn}{values["preview"]}'
                else:
                    model["posters"]: str = posters
                if values["hls"][self._size_video]:
                    model["player"]: str = host + values["hls"][self._size_video]
                elif values["hls"]["hd"]:
                    model["player"]: str = host + values["hls"]["hd"]
                elif values["hls"]["sd"]:
                    model["player"]: str = host + values["hls"]["sd"]
                elif values["hls"]["fhd"]:
                    model["player"]: str = host + values["hls"]["fhd"]
                model_list.append(model)
        elif items["rutube"]:
            for values in items["rutube"].values():
                model: dict = dict()
                model["episode"]: int = int(values["episode"])
                model["title"]: str = ""
                model["premiered"]: str = datetime.fromtimestamp(values["created_timestamp"]).strftime('%Y-%m-%d')
                model["posters"]: str = posters
                model["player"]: str = values["rutube_id"]
                model_list.append(model)
        return tuple(model_list)

    def _titles_normalise(self, item: dict) -> dict:
        model: dict = dict()
        model["id"]: str = str(item["id"])
        model["title"]: str = str(item["names"]["ru"])
        model["posters"]: str = str(f"{self._cdn}{item['posters']['original']['url']}")
        model["genre"]: str = str(" / ".join(item["genres"]) + ".")
        model["genres"]: list = list(item["genres"])
        model["plot"]: str = str(item["description"])
        return model

    def rutube(self, id_: str) -> str:
        return self._parser.rutube(id_)["video_balancer"]["m3u8"]

    def updates(self) -> tuple:
        data = list(self._titles_normalise(item) for item in self._parser.updates()["list"])
        return tuple(data)

    def changes(self) -> tuple:
        return tuple(self._titles_normalise(item) for item in self._parser.changes()["list"])

    def title(self, title_id: str) -> dict:
        return self._title_normalise(self._parser.title(title_id))

    def random(self) -> tuple:
        return tuple([self._titles_normalise(self._parser.random())])

    def search(self, titles: str) -> tuple:
        model_list = [self._titles_normalise(item) for item in self._parser.search(titles)["list"]]
        history: str = self._view.get_setting("history_dict")
        if history:
            history_dict: dict =  json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            new_item: dict = {titles: f"search_history"}
            history_dict, new_item = new_item, history_dict
            history_dict.update(new_item)
            self._view.set_setting("history_dict", json.dumps(history_dict))
        return tuple(model_list)

    def search_menu(self) -> dict:
        model_list: list = [{
            "title": "Поиск",
            "router": "search",
            "data": "",
        }]
        history: str = self._view.get_setting("history_dict")
        if history:
            history_dict: dict = json.loads(history)
            if len(history_dict) > 10:
                history_dict.popitem()
            for key, value in history_dict.items():
                model_list.append({
                    "title": f"[COLOR grey]{key}[/COLOR]",
                    "router": value,
                    "data": key,
                })
        return {
                "list": tuple(model_list),
                "category": "Меню поиска",
                "sort": False
            }

    def genres(self) -> tuple:
        return tuple(self._parser.genres())

    def years(self) -> tuple:
        return tuple(self._parser.years())

    def youtube(self) -> tuple:
        model_list: list = []
        for item in self._parser.youtube()["list"]:
            model: dict = dict()
            model["episode"]: int = int(item["id"])
            model["title"]: str = str(item["title"])
            model["premiered"]: str = datetime.fromtimestamp(item["timestamp"]).strftime('%Y-%m-%d')
            model["posters"]: str = self._cdn + str(item["preview"]["src"])
            model["player"]: str = f'https://www.youtube.com/watch?v={item["youtube_id"]}'
            model_list.append(model)
        return tuple(model_list)

    def youtube_watch(self, link: str, retry: int = 2):
        import yt_dlp
        video = None
        try:
            with yt_dlp.YoutubeDL({}) as ydl:
                for i in ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"]:
                    if i["fps"] and i.get("audio_channels") and i["audio_channels"] \
                            and i["format_note"] == self._view.get_setting("youtube_video"):
                        video = i["url"]
        except yt_dlp.DownloadError:
            msg_error = str(sys.exc_info()[1])
            self._view.youtube_error(msg_error)
        except TypeError:
            if retry:
                self.youtube_watch(link=link, retry=retry - 1)
        return video

    def main(self) -> tuple:
        model_list: list = []
        updates: dict = {
            "title": "Новые реализы",
            "router": "updates",
            "plot": "От недавно вышедших к более старым",
        }
        model_list.append(updates)
        random: dict = {
            "title": "Случайное аниме",
            "router": "random",
        }
        model_list.append(random)
        changes: dict = {
            "title": "Все аниме",
            "router": "changes",
        }
        model_list.append(changes)

        if self._view.get_setting("youtube") == "true":
            youtube: dict = {
                "title": "Youtube",
                "router": "youtube",
            }
            model_list.append(youtube)

        search: dict = {
            "title": "Поиск",
            "router": "search_menu",
            "plot": "Меню поиска с историей",
            "icon": "DefaultAddonsSearch.png",
        }
        model_list.append(search)
        return tuple(model_list)
