# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.01.14
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина plugin.video.zeltorix.anilibria для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
# Стандартные модули
import re
from time import time, sleep
# Не стандартный модуль импортируется в addon.xml как script.module.requests
from requests import Session

from .view import View


class ParserAniLibria:
    """
    Клас для получения данных
    """
    __slots__ = []
    _link_api: str = "vt.airbilina.ipa//:sptth"[::-1]
    # _link_mirror: str = "1/rorrim/tcerider/ti.airbilkrad//:sptth"[::-1]
    _link_api_rutube: str = "/snoitpo/yalp/ipa/ur.ebutur//:sptth"[::-1]
    _link_reserve: str = "pot.bilina.kv//:sptth"[::-1]
    _link_static_mirror: str = "eno.mrotskeew.airbil-citats//:sptth"[::-1]
    _session = Session()

    _filter_on: str = "filter="
    _filter_on: str = _filter_on + "names.ru,"
    _filter_on: str = _filter_on + "posters.original.url,"
    _filter_on: str = _filter_on + "description,"
    _filter_on: str = _filter_on + "id,"
    _filter_on: str = _filter_on + "genres,"
    _filter_title: str = _filter_on + "announce,"
    _filter_title: str = _filter_title + "player.host,"
    _filter_title: str = _filter_title + "player.list,"
    _filter_title: str = _filter_title + "player.rutube,"
    _filter_title: str = _filter_title + "type,"
    _filter_title: str = _filter_title + "player.episodes.last,"
    _one_year: int = int(time()) - 7_776_000
    _limit: int = -1
    _user_agent: str = "plugin for KODI"
    _accept_encoding: str = "gzip"

    def cdn(self, retry: int = 10) -> str:
        # headers = {
        #     "User-Agent": self._user_agent,
        #     "Accept": "text/html",
        #     "Accept-Encoding": self._accept_encoding,
        # }
        # req = self._session.get(self._link_mirror, headers=headers, timeout=5)
        # if req.ok:
        #     mirror = re.search(r'\w+://\w+-\d+-\d+\.\w+\.\w+', req.text)[0]
        #     if self._session.get(mirror).ok:
        #         return mirror
        # else:
        #     if retry:
        #         sleep(5)
        #         return self.cdn(retry=retry - 1)
        #     else:
        #         View.cdn_error()
        #         return self._link_reserve
        return self._link_static_mirror

    def rutube(self, id_: str) -> dict:
        return self._rest_api(id_, ani=False)

    def _rest_api(self, link: str, retry: int = 10, ani: bool = True) -> (dict, str):
        if ani:
            api: str = self._link_api
        else:
            api: str = self._link_api_rutube
        headers = {
            "User-Agent": self._user_agent,
            "Accept": "application/json",
            "Accept-Encoding": self._accept_encoding,

        }
        response = self._session.get(f"{api}{link}", headers=headers)
        try:
            if response.status_code == 500 | 502 | 503:
                return "Ошибка сервера"
            elif response.status_code == 404:
                return "Произошла смена API"
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            if retry:
                sleep(10)
                return self._rest_api(link, retry - 1)
            else:
                return "Что, где, не то с API..."

    def title(self, title_id: str) -> dict:
        return self._rest_api(f"/v3/title?id={title_id}&{self._filter_title}")

    def updates(self) -> dict:
        return self._rest_api(f"/v3/title/updates?since={self._one_year}&limit={self._limit}&{self._filter_on}")

    def changes(self) -> dict:
        return self._rest_api(f"/v3/title/changes?limit={self._limit}&{self._filter_on}")

    def random(self) -> dict:
        return self._rest_api(f"/v3/title/random?{self._filter_on}")

    def search(self, titles: str) -> dict:
        return self._rest_api(f"/v3/title/search?search={titles}&{self._filter_on}&limit={self._limit}")

    def genres(self) -> tuple:
        return tuple(self._rest_api(f"/v3/genres"))

    def years(self) -> tuple:
        return tuple(self._rest_api(f"/v3/years"))

    def youtube(self) -> dict:
        return self._rest_api(f"/v3/youtube?limit={self._limit}")
