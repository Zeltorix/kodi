# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.01.14
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина plugin.video.zeltorix.anilibria для KODI 19.x "Matrix" и выше.
Модуль переключает на нужный вид преставления интерфейса KODI, в зависимости от поступающих данных.
"""
# Импорт стандартного модуля для разделения поступающей строки на ключ и значение
from urllib.parse import parse_qsl

# Импорт модуля плагина для создания модели
from .model import ModelAniLibria
from .view import View


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    """
    Функция распределения
    :param data_string: Поступающая строка для преобразования в словарь
    :type data_string: str
    """
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}!')
    view = View()
    model = ModelAniLibria()
    if params_dict:
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                keyword = {
                    "titles": model.search(params_dict['keyword']),
                    "category": "Найденные аниме",
                    "sort": True
                }
                view.listing(keyword)
            else:
                # Вывод поиска, импортировано из модуля view
                search = {
                    "titles": model.search(view.search()),
                    "category": "Найденные аниме",
                    "sort": True
                }
                view.listing(search)

        elif params_dict['router'] == 'search_menu':
            view.main(model.search_menu())

        elif params_dict['router'] == 'search_history':
            search = {
                "titles": model.search(params_dict['data']),
                "category": "Найденные аниме",
                "sort": True
            }
            view.listing(search)

        elif params_dict['router'] == 'changes':
            # Выводит всех аниме, импортировано из модуля view
            all_titles ={
                "titles": model.changes(),
                "category": "Все аниме",
                "sort": True
            }
            view.listing(all_titles)
        elif params_dict['router'] == 'random':
            # Выводит случайное аниме, импортировано из модуля view
            random ={
                "titles": model.random(),
                "category": "Случайное аниме",
                "sort": True
            }
            view.listing(random)
        elif params_dict['router'] == 'updates':
            # Выводит случайное аниме, импортировано из модуля view
            updates = {
                "titles": model.updates(),
                "category": "Последние обновления",
                "sort": False
            }
            view.listing(updates)
        elif params_dict['router'] == 'youtube':
            # Выводит случайное аниме, импортировано из модуля view
            youtube = {
                "players": model.youtube(),
                "label": "YouTube",
                "video_type": "",
                "total_episodes": "",
                "plot": "",
            }
            view.season(youtube)
        elif params_dict['router'] == 'title':
            # Вывод списка серий, импортировано из модуля view
            view.season(model.title(params_dict['data']))
        elif params_dict['router'] == 'play':
            if params_dict['data'].endswith('.m3u8'):
                view.play(params_dict['data'])
            elif params_dict['data'].startswith("https://www.youtube.com/watch?v="):
                view.play_youtube(model.youtube_watch(params_dict['data']))
            else:
                view.play(model.rutube(params_dict['data']))
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}!')
    else:
        view.check_modules()
        # Вывод выбора категории действия, импортировано из модуля view
        main = {
            "category": "Меню",
            "list": model.main()
        }
        view.main(main)
