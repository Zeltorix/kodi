# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
# Стандартные
from random import randint, choice

# Не стандартный модуль импортируется в addon.xml как script.module.requests
from requests import Session

# Не стандартный модуль импортируется в addon.xml как script.module.zeltorix.utility
from headers import user_agents


class ParserVK:
    """
    Клас для получения данных
    """
    __slots__ = []
    _api: str = "https://vk.com"
    headers = {
        "Referer": "https://yandex.com",
        "User-Agent": choice(user_agents),
        "x-requested-with": "XMLHttpRequest",
    }
    _session = Session()

    def api(self, path: str, post: dict, retry: int = 10) -> (dict, str):
        link = self._api + path
        import xbmc
        xbmc.log(msg=f'api: {link} ', level=xbmc.LOGINFO)
        response = self._session.post(link, headers=self.headers, timeout=randint(5, 10), data=post)
        try:
            if response.status_code >= 500:
                # TODO Добавить оповещение в интерфейс
                return self.api(path=path, post=post, retry=retry - 1)
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            if retry:
                from time import sleep
                # TODO Добавить оповещение в интерфейс
                sleep(randint(2, 10))
                return self.api(path=path, post=post, retry=retry - 1)
            else:
                return "Что то не то с API..."
