# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
from urllib.parse import parse_qsl

from view import View


# Импорт модуля плагина для создания модели
from .model import ModelVK
from .view import View as V


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    # import logging
    # logger = logging.getLogger(__name__)
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}')
    _view = View()
    view = V()
    model = ModelVK()
    if params_dict:

        # Блок поиска
        if params_dict['router'] == 'search':
            # Интеграция с дополнением United Search
            if params_dict.get('keyword'):
                if params_dict.get('data'):
                    search = params_dict['data']
                    next_items = params_dict['data_2']
                else:
                    search = params_dict['keyword']
                    next_items = None
                _view.output(model.search(search, next_items))
            else:
                if params_dict.get('data'):
                    search = params_dict['data']
                    next_items = params_dict['data_2']
                    _view.output(model.search(search, next_items))
                else:
                    search = view.search()
                    if not search:
                        _view.output(model.menu("search_menu"))
                    else:
                        next_items = None
                        _view.output(model.search(search, next_items))
        elif params_dict['router'] == 'search_group':
            search = view.search()
            if not search:
                view.main(model.menu("search_menu"))
            else:
                view.main(model.search_groups(search))

        # Блок работы с историей
        elif params_dict['router'] == "search_video_history":
            view.main(model.search(params_dict['data']))
        elif params_dict['router'] == "search_groups_history":
            view.main(model.search_groups(params_dict['data']))
        elif params_dict['router'] == "history_clearing":
            model.history_clearing()

        # Блок воспроизведения
        elif params_dict['router'] == 'play':
            _view.play(model.url(params_dict['data']), "hls")

        # Блок навигации
        elif params_dict['router'] == "menu":
            _view.output(model.menu(params_dict['data']))
        elif params_dict['router'] == "video_items":
            if params_dict.get('data_2'):
                _view.output(model.video_items(params_dict['data'], params_dict['data_2']))
            else:
                _view.output(model.video_items(params_dict['data']))
        elif params_dict['router'] == "playlist":
            if params_dict.get('data_2'):
                data = params_dict['data']
                data_2 = params_dict['data_2']
            else:
                data = params_dict['data']
                data_2 = "0"
            _view.output(model.playlist(data, data_2))
        elif params_dict['router'] == "group":
            _view.output(model.menu(params_dict['router'], params_dict['data']))
        elif params_dict['router'] == "group_videos":
            if params_dict.get('data_2'):
                data = params_dict['data']
                data_2 = params_dict['data_2']
            else:
                data = params_dict['data']
                data_2 = "0"
            _view.output(model.group_videos(data, data_2))
        elif params_dict['router'] == "group_playlists":
            if params_dict.get('data_2'):
                data = params_dict['data']
                data_2 = params_dict['data_2']
            else:
                data = params_dict['data']
                data_2 = "0"
            _view.output(model.group_playlists(data, data_2))

        # Блок исключения
        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}')
    else:
        _view.output(model.main())
