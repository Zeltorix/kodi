# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.05.12
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json
import re
from time import strftime, localtime
import datetime
from itertools import islice

from bs4 import BeautifulSoup

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserVK
    from .view import View
    from view import View as V
    from get_video_link import VideoLink
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.release.vk_video.resources.lib.parser import ParserVK


class ModelVK:
    __slots__ = []
    _parser = ParserVK()
    _view = View()
    _v = V()
    _video_link = VideoLink()

    @staticmethod
    def _cleanhtml(raw_html):
        return " ".join(re.sub(re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});'), '', raw_html).split())

    @staticmethod
    def time_to_second(time_string: str):
        if len(time_string.split(":")) == 3:
            time_stamp = "%H:%M:%S"
        else:
            time_stamp = "%M:%S"
        date_time = datetime.datetime.strptime(time_string, time_stamp)
        a_timedelta = date_time - datetime.datetime(1900, 1, 1)
        seconds = a_timedelta.total_seconds()
        return seconds

    def search(self, item: str, next_items: (str, None) = None) -> dict:
        history_limit: int = int(self._view.get_setting("history_limit"))
        history: str = self._view.get_setting("history_dict")

        history_dict: dict = json.loads(history)
        new_item: dict = {item: f"search_video_history"}
        history_dict, new_item = new_item, history_dict
        history_dict.update(new_item)
        history_dict = dict(islice(history_dict.items(), history_limit))
        self._view.set_setting("history_dict", json.dumps(history_dict))

        # if history:
        #     history_dict: dict =  json.loads(history)
        #     if len(history_dict) > history_limit:
        #         history_dict.popitem()
        #     new_item: dict = {item: f"search_video_history"}
        #     history_dict, new_item = new_item, history_dict
        #     history_dict.update(new_item)
        #     self._view.set_setting("history_dict", json.dumps(history_dict))

        if next_items:
            post = {"al": "1", "from": "0", "offset": next_items, "q": item}
        else:
            post = {"al": "1", "from": "0", "offset": "0", "q": item}
        data = self._parser.api(path="/al_video.php?act=search_video", post=post)
        payload = data["payload"][1][2]
        model_list: list = []
        for i in payload['list']:
            title = self._cleanhtml(str(i[3]))
            time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
            if int(i[19]):
                model_dict: dict = {
                    "title": title,
                    "router": "play",
                    "data": str(f"{i[0]}_{i[1]}"),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "duration": int(i[19]),
                    "images": str(i[2]),
                    "plot": f"{time_stamp}\n{title}",
                    "play": True,
                }
                model_list.append(model_dict)
        if not next_items:
            next_items = 0
        if payload['list']:
            model_dict: dict = {
                "title": "Следующая страница",
                "router": "search",
                "data": {
                    "data": str(item),
                    "data_2": str(int(next_items) + int(payload["count"]) + 1),
                },
            }
            model_list.append(model_dict)
        return {
            "category": "Найденные видео",
            "list": tuple(model_list)
        }

    def search_groups(self, item: str) -> dict:
        history_limit: int = int(self._view.get_setting("history_limit"))
        history: str = self._view.get_setting("history_dict")
        history_dict: dict = json.loads(history)
        new_item: dict = {item: f"search_groups_history"}
        history_dict, new_item = new_item, history_dict
        history_dict.update(new_item)
        history_dict = dict(islice(history_dict.items(), history_limit))
        self._view.set_setting("history_dict", json.dumps(history_dict))

        # history: str = self._view.get_setting("history_dict")
        # if history:
        #     history_dict: dict =  json.loads(history)
        #     if len(history_dict) > 10:
        #         history_dict.popitem()
        #     new_item: dict = {item: f"search_groups_history"}
        #     history_dict, new_item = new_item, history_dict
        #     history_dict.update(new_item)
        #     self._view.set_setting("history_dict", json.dumps(history_dict))

        post = {
            "al": "1",
            "c[q]": item,
            "c[section]": "communities",
        }
        data = self._parser.api(path="/al_search.php?act=search_request", post=post)["payload"][1][1]
        soup = BeautifulSoup(data, features="html.parser")
        model_list: list = []
        for group in soup.find_all("div", {"class": "groups_row"}):
            img_link: dict = group.find("img", {"class": "AvatarRich__img"})
            if img_link:
                img: str = img_link["src"]
            else:
                img: str = ""
            title: str = group.find("div", {"class": "info"}).find("a").text
            link: str = group["data-id"]
            info = group.find_all("div", {"class": "labeled"})
            if len(info) == 3:
                genres = group.find_all("div", {"class": "labeled"})[1].text
                subscribers = group.find_all("div", {"class": "labeled"})[2].text
            elif len(info) == 2:
                genres = ""
                subscribers = group.find_all("div", {"class": "labeled"})[1].text
            else:
                genres = ""
                subscribers = ""
            model_dict: dict = {
                "title": f"{title} ({subscribers})",
                "router": "group",
                "data": link,
                "images": img,
                "genres": [genres]
            }
            model_list.append(model_dict)
        return {
            "category": "Найденные группы",
            "list": tuple(model_list)
        }

    def history_clearing(self) -> None:
        self._view.set_setting("history_dict", json.dumps({}))

    def url(self, link: str) -> str:
        return self._video_link.vk_link(link)

    def group_videos(self, group_id: str, next_items: str) -> dict:
        post = {
            "al": "1",
            # "need_albums": "1",  # Если есть то плейлисты
            "need_albums": "0",  # Если есть то плейлисты
            "offset": next_items,
            "oid": f"-{group_id}",
            "rowlen": "3",
            "section": "all",
            "snippet_video": "0",
        }
        data = self._parser.api(path="/al_video.php?act=load_videos_silent", post=post)["payload"][1]
        all_video = data[0]["all"]["list"]
        model_list = []
        for video in all_video:
            if int(video[19]):
                title = self._cleanhtml(str(video[3]))
                time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(video[9]))
                model_dict: dict = {
                    "title": title,
                    "router": "play",
                    "data": str(f"{video[0]}_{video[1]}"),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "duration": int(video[19]),
                    "images": str(video[2]),
                    "plot": f"{time_stamp}\n{title}",
                    "play": True,
                }
                model_list.append(model_dict)
        if all_video:
            model_dict: dict = {
                "title": "Следующая страница",
                "router": "group_videos",
                "data": {
                    "data": str(group_id),
                    "data_2": str(int(next_items) + 1000),
                },
            }
            model_list.append(model_dict)
        return {
            "category": "Список всех видео группы",
            "list": tuple(model_list)
        }

    def group_playlists(self, group_id: str, next_items: (str, None) = None) -> dict:
        if group_id.startswith("-"):
            group_id = group_id
        else:
            group_id = "-" + group_id
        post = {
            "al": "1",
            "need_albums": "1",
            "offset": next_items,
            "oid": f"{group_id}",
            "rowlen": "3",
            "section": "all",
            "snippet_video": "0",
        }
        data = self._parser.api(path="/al_video.php?act=load_videos_silent", post=post)
        playlists = data["payload"][1][1]
        model_list: list = []
        for i in playlists:
            if i[1]:
                model_dict: dict = {
                    "title": f"{i[0]} ({i[1]} видео)",
                    "router": "playlist",
                    "data": {
                        "data": str(f"{i[11]}"),
                        "data_2": "0",
                    },
                    "images": str(i[2]),
                }
                model_list.append(model_dict)
        return {
            "category": "Список плейлистов группы",
            "list": tuple(model_list)
        }

    def playlist(self, link: str, next_items: str) -> dict:
        group, playlist = link.split("_")
        if group.startswith("-"):
            group = group
        else:
            group = "-" + group
        post = {"al": "1", "offset": next_items, "oid": group, "section": f"playlist_{playlist}", }
        data = self._parser.api(path="/al_video.php?act=load_videos_silent", post=post)
        payload = data["payload"][1][0][f"playlist_{playlist}"]
        model_list: list = []
        for i in payload["list"]:
            if int(i[19]):
                title = self._cleanhtml(str(i[3]))
                time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
                model_dict: dict = {
                    "title": title,
                    "router": "play",
                    "data": str(f"{i[0]}_{i[1]}"),
                    "premiered": time_stamp,
                    "dateadded": time_stamp,
                    "duration": int(i[19]),
                    "images": str(i[2]),
                    "plot": f"{time_stamp}\n{title}",
                    "play": True,
                }
                model_list.append(model_dict)
        if next_items is None:
            next_items = 0
        if payload['list']:
            model_dict: dict = {
                "title": "Следующая страница",
                "router": "playlist",
                "data": {
                    "data": str(link),
                    "data_2": str(int(next_items) + int(payload["count"] + 1)),
                },
            }
            model_list.append(model_dict)
        return {
            "category": "Список видео плейлиста",
            "list": tuple(model_list)
        }

    def video_items(self, link: str, next_items: (str, None) = None) -> dict:
        if next_items:
            post = {"al": "1", "next_from": next_items, "silent_loading": "1"}
        else:
            post = {"al": "1", "silent_loading": "1"}
        data = self._parser.api(path=link, post=post)
        payload = json.loads(data["payload"][1][0])
        model_list: list = []
        if payload['videos']:
            for i in payload['videos']:
                if int(i[19]) or i[5] == "Live":
                    title = self._cleanhtml(str(i[3]))
                    time_stamp = strftime("%Y-%m-%d %H:%M:%S", localtime(i[9]))
                    model_dict: dict = {
                        "title": title,
                        "router": "play",
                        "data": str(f"{i[0]}_{i[1]}"),
                        "premiered": time_stamp,
                        "dateadded": time_stamp,
                        "duration": int(i[19]),
                        "images": str(i[2]),
                        "plot": f"{time_stamp}\n{title}",
                        "play": True,
                    }
                    model_list.append(model_dict)
        elif payload['playlists']:
            for i in payload['playlists']:
                if i[1] == 1:
                    title = self._cleanhtml(str(i[0]))
                    router = "play"
                    play = True
                    data_link = str(i[7])
                else:
                    title = self._cleanhtml(f"{i[0]} ({i[1]} видео)")
                    router = "playlist"
                    play = False
                    data_link = f"{i[8]}_{i[6]}"
                model_dict: dict = {
                    "title": title,
                    "router": router,
                    "data": {
                        "data": data_link,
                        "data_2": str(),
                    },
                    "plot": title,
                    "genres": [],
                    "duration": int(),
                    "images": str(i[2]),
                    "play": play,
                }
                model_list.append(model_dict)
        if payload["nextFrom"]:
            model_dict: dict = {
                "title": "Следующая страница",
                "router": "video_items",
                "data": {
                    "data": str(link),
                    "data_2": str(payload["nextFrom"]),
                },
                "plot": str(),
                "genres": [],
                "posters": str(),
            }
            model_list.append(model_dict)
        return {
            "category": "Список видео",
            "list": tuple(model_list)
        }

    def menu(self, link: str, data: str = None) -> dict:
        video = {
            "/video": "Все",
            "/video/interview": "Интервью и шоу",
            "/video/tourisme": "Тревел",
            "/video/technology": "Технологии",
            "/video/music": "Музыка",
            "/video/culture": "Культура",
            "/video/cooking": "Еда",
            "/video/fitness": "Здоровье",
            "/video/education": "Образование",
            "/video/automotive": "Авто",
            "/video/lifestyle": "Мода и красота",
        }
        lives = {
            "/video/lives": "Популярное",
            "/video/lives/games": "Видеоигры",
            "/video/lives/sport": "Спорт",
            "/video/lives/news": "Новости",
            "/video/lives/music": "Музыка",
        }
        sport = {
            "/video/sport": "Все",
            "/video/sport/medialiga": "Медиалига",
            "/video/sport/fnl": "ФНЛ",
            "/video/sport/football": "Футбол",
            "/video/sport/basketball": "Баскетбол",
            "/video/sport/hockey": "Хоккей",
            "/video/sport/mma": "ММА",
            "/video/sport/tennis": "Теннис",
            "/video/sport/volleyball": "Волейбол",
            "/video/sport/other_sport": "Другое",
        }
        movies = {
            "/video/movies": "Все",
            "/video/movies/comedy": "Комедия",
            "/video/movies/adventure": "Приключения",
            "/video/movies/fantastic": "Фантастика",
            "/video/movies/action": "Боевик",
            "/video/movies/family": "Семейный",
            "/video/movies/melodrama": "Мелодрама",
            "/video/movies/drama": "Драма",
            "/video/movies/biography": "Биография",
            "/video/movies/anime": "Аниме",
            "/video/movies/detective": "Детектив",
            "/video/movies/thriller": "Триллер",
            "/video/movies/horror": "Ужасы",
            "/video/movies/soviet": "Советское",
            "/video/movies/documentary": "Документальный",
            "/video/movies/short": "Короткий метр",
        }
        tvshow = {
            "/video/tvshow": "Все",
        }
        for_kids = {
            "/video/for_kids": "Мультфильмы",
            "/video/for_kids/movies": "Фильмы",
        }
        search_menu = {
            "search": "Поиск видео",
            "search_group": "Поиск группы",
        }
        group = {
            "group_playlists": "Плейлисты группы",
            "group_videos": "Все видео группы",
            "group_wall_videos": "Видео на стене",
        }
        menu = {}
        if link in video.keys():
            menu = video
        elif link in lives.keys():
            menu = lives
        elif link in sport.keys():
            menu = sport
        elif link in movies.keys():
            menu = movies
        elif link in tvshow.keys():
            menu = tvshow
        elif link in for_kids.keys():
            menu = for_kids
        model_list: list = []
        if link == "search_menu":
            menu = search_menu
            for key, value in menu.items():
                model_list.append({
                    "title": value,
                    "router": key,
                })
            history = self._view.get_setting("history_dict")
            if history:
                history_dict: dict = json.loads(history)
                if len(history_dict) > 10:
                    history_dict.popitem()
                for key, value in history_dict.items():
                    if value == "search_groups_history":
                        title = f"[COLOR blue]{key}[/COLOR]"
                    else:
                        title = f"[COLOR grey]{key}[/COLOR]"
                    model_list.append({
                        "title": title,
                        "router": value,
                        "data": key,
                    })
        elif link == "group":
            menu = group
            for key, value in menu.items():
                if key == "group_wall_videos":
                    data = f"-{data}_-4"
                    router = "playlist"
                else:
                    router = key
                    data = data

                model_dict: dict = {
                    "title": value,
                    "router": router,
                    "data": data,
                    "data_2": "0"
                }
                model_list.append(model_dict)
        else:
            for key, value in menu.items():
                model_dict: dict = {
                    "title": value,
                    "router": "video_items",
                    "data": key,
                }
                model_list.append(model_dict)
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }

    @staticmethod
    def main() -> dict:
        model_list: list = [
            {
                "title": "Для вас",
                "router": "menu",
                "data": "/video",
            },
            {
                "title": "Трансляции",
                "router": "menu",
                "data": "/video/lives",
            },
            {
                "title": "Спорт",
                "router": "menu",
                "data": "/video/sport",
            },
            {
                "title": "Киберспорт и игры",
                "router": "video_items",
                "data": "/video/cybersport",
            },
            {
                "title": "Фильмы",
                "router": "menu",
                "data": "/video/movies",
            },
            {
                "title": "Сериалы",
                "router": "video_items",
                "data": "/video/serials",
            },
            {
                "title": "Шоу",
                "router": "menu",
                "data": "/video/tvshow",
            },
            {
                "title": "Детям",
                "router": "menu",
                "data": "/video/for_kids",
            },
            {
                "title": "Поиск",
                "router": "menu",
                "data": "search_menu",
                "plot": "Меню поиска с историей",
                "icon": "DefaultAddonsSearch.png",
            },
        ]
        return {
            "category": "Меню",
            "list": tuple(model_list)
        }
