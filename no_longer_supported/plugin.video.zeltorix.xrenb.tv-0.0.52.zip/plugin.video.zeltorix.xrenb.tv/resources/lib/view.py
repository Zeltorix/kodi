# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
import logging
# Модули KODI
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon


class View:
    __slots__ = [
        'logger'
    ]
    # Получите URL-адрес плагина в формате plugin:// значение.
    _url = sys.argv[0]
    # Получить заготовка плагина в виде целого числа.
    _handle = int(sys.argv[1])
    _kodi_version_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def get_setting(self, id_: str) -> str:
        self.logger.debug(f"Запрос настроек по ID: {id_}")
        id_a: str = self._url.split("//")[1].split("/")[0]
        return xbmcaddon.Addon(id_a).getSetting(id_)

    def check_modules(self) -> None:
        self.logger.debug(f"Проверка установленных модулей")
        def target_module(check_module: str) -> None:
            try:
                xbmcaddon.Addon(check_module)
                self.logger.debug(f"Модуль: {check_module} уже установлен")
            except (ModuleNotFoundError, RuntimeError):
                self.logger.debug(f"Установка модуля: {check_module}")
                xbmcgui.Dialog().notification(
                    heading=f'Установка библиотеки {check_module}',
                    message=f'{check_module}',
                    icon=xbmcgui.NOTIFICATION_WARNING,
                    time=5000)
                xbmc.executebuiltin(f'RunPlugin("plugin://{check_module}")')
                self.logger.debug(f"Модуль установлен: {check_module}")
        target_module('script.module.requests')
        target_module('inputstream.adaptive')
        target_module('script.module.zeltorix.utilitys')

    @staticmethod
    def cdn_error() -> None:
        xbmcgui.Dialog().notification(
            heading='Сайт с картинками не доступен',
            message='Сайт с картинка не отвечает',
            icon=xbmcgui.NOTIFICATION_WARNING,
            time=5000)

    def _convert_to_url(self, **kwargs: str) -> str:
        self.logger.debug(f"Преобразование кляча и значения в ссылку")
        # Преобразование кляча и значения в ссылку данных для дополнения в виде URL
        return f'{self._url}?{urlencode(kwargs)}'

    def play(self, path: str) -> None:
        self.logger.debug(f"Получена ссылка для воспроизведения {path}")
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)
        # Использовать inputstream.adaptive для входящего медиапотока
        play_item.setProperty('inputstream', "inputstream.adaptive")
        # Тип манифеста медиапотока
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # Подбор разрешения под экран
        play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

        # Тип запрашиваемого контента
        play_item.setMimeType('application/xml+dash')
        # Если отключено, запросы HEAD, например, для определения типа mime, не будут отправляться.
        play_item.setContentLookup(True)
        # Обновление манифеста, возможно это убирает баг с зависанием
        play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        # Разрешить начинать воспроизведение LIVE-потока с начала буфера, а не с его конца.
        play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
        # listitem.setProperty('inputstream.adaptive.stream_headers',
        #                      f'User-Agent={user_agent}')
        # listitem.setProperty('inputstream.adaptive.stream_headers',
        #                      'headername=value&User-Agent=the_user_agent&Cookie=the_cookies')

        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def play_w(self, path: str) -> None:
        self.logger.debug(f"Получена ссылка для воспроизведения {path}")
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)
        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def project(self, data: dict) -> None:
        self.logger.debug(f"Вывод на экран серий проекта: {data['category']}")
        sort_item = xbmcplugin.SORT_METHOD_NONE
        # Установка представления содержимого плагина.
        # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
        # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
        xbmcplugin.setContent(self._handle, 'episodes')
        # Путь сверху между слешей("/") с добавленным названием
        xbmcplugin.setPluginCategory(self._handle, data['category'])
        # Перебор либо списка аниме, либо серий
        for item in data['players']:
            list_item = xbmcgui.ListItem()
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item["title"])
                vinfo.setPlot(item["plot"])
                vinfo.setPremiered(item["premiered"])
                # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
                # video       For normal video
                # set         For a selection of video
                # musicvideo  To define it as music video
                # movie       To define it as normal movie
                # tvshow      If this is it defined as tvshow
                # season      The type is used as a series season
                # episode     The type is used as a series episode
                vinfo.setMediaType("episode")
            else:
                list_item.setInfo('video', {'title': item["title"]})
                list_item.setInfo('video', {'plot': item["plot"]})
                list_item.setInfo('video', {'premiered': item["premiered"]})
                list_item.setInfo('video', {'mediatype': 'videos'})
            list_item.setArt({'thumb': item['posters']})
            list_item.setArt({'icon': item['posters']})
            list_item.setArt({'fanart': item['posters']})
            list_item.setProperty('IsPlayable', 'true')
            url = self._convert_to_url(router=item['router'], data=item['player'])
            # Переход внутрь не требуется, можно отключить
            is_folder = False
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, sort_item)
        xbmcplugin.endOfDirectory(self._handle)

    def main(self, data: dict) -> None:
        self.logger.debug(f"Вывод на экран списка проектов")
        xbmcplugin.setContent(self._handle, 'videos')
        xbmcplugin.setPluginCategory(self._handle, data["category"])
        for item in data["list"]:
            list_item = xbmcgui.ListItem()
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item['title'])
                vinfo.setPlot(item['plot'])
                vinfo.setMediaType("video")
            else:
                list_item.setInfo('video', {'title': item['title']})
                list_item.setInfo('video', {'plot': item['plot']})
                list_item.setInfo('video', {'mediatype': 'videos'})
            url = self._convert_to_url(router=item["router"], data=item["data"], title=item["title"])
            list_item.setArt({'thumb': item['posters']})
            list_item.setArt({'icon': item['posters']})
            list_item.setArt({'fanart': item['posters']})
            # Внутренний переход есть
            is_folder = True
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self._handle)
