# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Стандартные модули
import json
import logging

try:
    # Импорт модуля плагина из текущего каталога для запроса данных
    from .parser import ParserRenTv
except ImportError:
    # Импорт модуля плагина для тестирования
    from source.develop.xrenb_tv.resources.lib.parser import ParserRenTv


class ModelRenTv:
    __slots__ = [
        "logger"
    ]
    _parser = ParserRenTv()
    projects: dict = {
        76583: (446615, 446441, 446072, 445686, 85301, 63330, 36766, 19320, 446581, 0,),
        54823: (446615, 446441, 446072, 445686, 85301, 63330, 36766, 19320, 8644, 446582,),
        173468: (446615, 446441, 446072, 445686, 85301, 63330, 36766, 446577,),
        445611: (446615, 446441, 446072, 445686,),
        46879: (446615, 446441, 446072, 445686, 85301, 63330, 36766, 19320, 8644,),
        84171: (446615, 446441, 446072, 445686, 85301, 63330, 36766, 19320,),
        383098: (446615, 446441, 446072, 445686, 85301,),
        203564: (446615, 446441, 446072, 445686, 85301, 63330, 36766, 446578,),
        369151: (446615, 446441, 446072, 445686, 85301, 63330,),
        445607: (446615, 446441, 446072, 445686, 85301,),
        446063: (446615, 446441, 446072,),
        446546: (446615, 446441,),
        446429: (446615, 446441,),
        446531: (446615, 446441,),
        446448: (446615, 446441, 446072, 445686, 85301,),
        446098: (446615, 446441, 446072,),
        445817: (446615, 446441, 446072, 445686,),
        1480: (446615, 446441,),
        100075: (
            446615, 446441, 446072, 445686, 85301, 63330, 36766, 19320, 8644, 446584, 446585, 446586, 446587,),
        165: (445686, 85301, 63330, 36766, 19320, 8644, 656, 655, 1822, 1910, 0,),
        34057: (445686, 85301, 63330, 36766, 19320, 8644,),
        446179: (281,),
        300: (281, 1610,),
        285: (85301, 63330, 36766, 19320, 8644, 656, 1641, 1822),
    }

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def _null_to_string(self, check):
        self.logger.debug(f"Проверка на отсутствия строки: {check}")
        if check is None:
            self.logger.debug(f"Строка отсутствует")
            return ""
        else:
            self.logger.debug(f"Строка присутствует")
            return check

    def _null_to_integer(self, check):
        self.logger.debug(f"Проверка на отсутствия целого числа: {check}")
        if check is None:
            self.logger.debug(f"Целое число отсутствует")
            return 0
        else:
            self.logger.debug(f"Целое число присутствует")
            return check

    def _cleanhtml(self, raw_html):
        self.logger.debug(
            f"Очистка текста от HTML тегов, закодированных символов, табуляций, новой строки, лишних пробелов: {raw_html}")
        import re
        return " ".join(re.sub(re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});'), '', raw_html).split())

    def _season(self, data: list) -> tuple:
        self.logger.debug(f"Формирования сезона проекта")
        model_list: list = []
        for item in data:
            model: dict = {
                "title": str(self._null_to_string(item["title"])),
                "premiered": str(self._null_to_string(item["created_at"].split("T")[0])),
                "posters": str(self._null_to_string(item["image"]["url"])),
                "plot": str(self._null_to_string(self._cleanhtml(item["description"])))}
            if item["config"]["provider"] == "rutube":
                if item["config"]["rutube"]:
                    self.logger.debug(f"Видео на платформе: {item['config']['provider']}")
                    model["player"]: str = item["config"]["rutube"]["id"]
                    model["router"]: str = "rutube"
                else:
                    self.logger.debug(f"Видео подпало под цензуру: {self._null_to_string(item['title'])}")
                    model["title"]: str = f"-----Нет потока для видео-----{self._null_to_string(item['title'])}"
                    model["player"]: str = ""
                    model["router"]: str = ""
            elif item["config"]["provider"] == "platformcraft":
                if item["config"]["platformcraft"]:
                    if item["config"]["platformcraft"]["list"]:
                        self.logger.debug(f"Видео на платформе: {item['config']['provider']}")
                        model["player"]: str = "http://" + item["config"]["platformcraft"]["list"][0]["cdn_url"]
                        model["router"]: str = "platformcraft"
                    else:
                        self.logger.debug(f"Видео подпало под цензуру: {self._null_to_string(item['title'])}")
                        model[
                            "title"]: str = f"-----Нет потока для видео-----{self._null_to_string(item['title'])}"
                        model["player"]: str = ""
                        model["router"]: str = ""
                else:
                    self.logger.debug(f"Видео подпало под цензуру: {self._null_to_string(item['title'])}")
                    model["title"]: str = f"-----Нет потока для видео-----{self._null_to_string(item['title'])}"
                    model["player"]: str = ""
                    model["router"]: str = ""
            elif item["config"]["provider"] == "ok":
                self.logger.debug(f"Видео на платформе: {item['config']['provider']}")
                model["player"]: str = "https://ok.ru/video/" + item["config"]["ok"]["id"]
                model["router"]: str = "ok"
            elif item["config"]["provider"] == "vk":
                self.logger.debug(f"Видео на платформе: {item['config']['provider']}")
                model["player"]: str = "https://vk.com/video" + item["config"]["vk"]["id"]
                model["router"]: str = "vk"
            elif item["config"]["provider"] == "youtube":
                self.logger.debug(f"Видео на платформе: {item['config']['provider']}")
                model["player"]: str = item["config"]["youtube"]["id"]
                model["router"]: str = "youtube"
            elif item["config"]["provider"] == "":
                self.logger.debug(f"Видео подпало под цензуру: {self._null_to_string(item['title'])}")
                model["title"]: str = f"-----Нет потока для видео-----{self._null_to_string(item['title'])}"
                model["player"]: str = ""
                model["router"]: str = ""
            else:
                msg: str = f"Неизвестный поставщик видео: {json.dumps(item['config'], indent=2)} - {item['title']}"
                self.logger.error(msg)
                raise Exception(msg)
            model_list.append(model)
        return tuple(model_list)

    def _seasons(self, id_: str, years: tuple):
        self.logger.debug(f"Формирование общего списка всех сезонов")
        model_list: list = []
        for year in years:
            model_list.extend(self._season(self._parser.api(f"episode/list/{id_}/{year}")["data"]))
        return tuple(model_list)

    def project(self, id_project: str, title: str):
        self.logger.info(f"Обработка проекта: id - {id_project}, название - {title}")
        listing: tuple = self._seasons(id_project, self.projects[int(id_project)])
        model: dict = {
            "category": title,
            "players": listing
        }
        return model

    def rutube(self, id_: str) -> str:
        self.logger.info(f"Получения воспроизводимой ссылки - rutube - {id_}")
        return self._parser.rutube(id_)["video_balancer"]["m3u8"]

    def ok(self, link: str) -> str:
        self.logger.info(f"Получения воспроизводимой ссылки - ok - {link}")
        import yt_dlp
        ydl = yt_dlp.YoutubeDL({})
        return ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"][1]["manifest_url"]

    def vk(self, link: str) -> str:
        self.logger.info(f"Получения воспроизводимой ссылки - vk - {link}")
        import yt_dlp
        ydl = yt_dlp.YoutubeDL({})
        return ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"][1]["manifest_url"]

    def youtube(self, link: str) -> str:
        self.logger.info(f"Получения воспроизводимой ссылки - youtube - {link}")
        import yt_dlp
        ydl = yt_dlp.YoutubeDL({})
        return ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"][1]["manifest_url"]

    def get_video(self, link: str) -> str:
        self.logger.info(f"Получения воспроизводимой ссылки - {link}")
        import yt_dlp
        ydl = yt_dlp.YoutubeDL({})
        return ydl.sanitize_info(ydl.extract_info(link, download=False))["formats"][1]["manifest_url"]

    def main(self) -> dict:
        self.logger.info(f"Получение списка проектов")
        listing: list = self._parser.api("project?page=1&limit=0")["data"]["items"]
        model: list = []
        for project in listing:
            if project["id"] in self.projects.keys():
                model_dict: dict = {
                    "title": project["title"], "router": "project", "data": project["id"],
                    "genres": [self._null_to_string(project["genres"][0]["title"])],
                    "plot": self._null_to_string(self._cleanhtml(project["description"])),
                    "posters": self._null_to_string(project["image"]["url"])}
                model.append(model_dict)
        main: dict = {
            "category": "Меню",
            "list": model
        }
        return main
