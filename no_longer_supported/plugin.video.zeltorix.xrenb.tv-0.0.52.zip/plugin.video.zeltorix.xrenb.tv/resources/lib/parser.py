# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
# Стандартные модули
import json

# Не стандартный модуль импортируется в addon.xml как script.module.requests
import requests
import logging


class ParserRenTv:
    """
    Клас для получения данных
    """
    __slots__ = [
        "logger",
    ]
    _link_api_rentv: str = "/0/ipa/vt.ner//:sptth"[::-1]
    _link_api_rutube: str = "/snoitpo/yalp/ipa/ur.ebutur//:sptth"[::-1]
    _headers = {
        "User-Agent": "plugin for KODI",
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
    }

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def api(self, id_: str) -> dict:
        link: str = self._link_api_rentv + id_
        self.logger.debug(f"ID: {id_}, ссылка: {link}")
        api_json: dict = self._rest_api(link)
        self.logger.debug(f"API: {json.dumps(api_json, indent=2, ensure_ascii=False)}")
        return api_json

    def rutube(self, id_: str) -> dict:
        link: str = self._link_api_rutube + id_
        self.logger.debug(f"ID: {id_}, ссылка: {link}")
        api_json: dict = self._rest_api(link)
        self.logger.debug(f"API: {json.dumps(api_json, indent=2, ensure_ascii=False)}")
        return api_json

    def _rest_api(self, link: str, retry: int = 10) -> (dict, str):
        from random import randint
        self.logger.info(f"Ссылка: {link} - количество попыток: {retry}")
        response = requests.get(link, headers=self._headers, timeout=randint(5,15))
        try:
            if response.status_code >= 500:
                self.logger.error("Ошибка сервера")
                return self._rest_api(link, retry - 1)
            elif response.status_code == 404:
                if response.json()["detail"]["languages"][0]["title"] == "Видео скрыто":
                    msg: str = "Видео ещё не опубликовано"
                    self.logger.warning(msg)
                    return msg
                msg: str = "Произошло смена API"
                self.logger.error(msg)
                return msg
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            self.logger.error(f"Неизвестная ошибка, статус код: {response.status_code}")
            if retry:
                from time import sleep
                sleep(randint(2,10))
                self.logger.info("Попытка повторного запроса")
                return self._rest_api(link, retry - 1)
            else:
                self.logger.critical(f"Требуется отредактировать код. Не обрабатываемая ссылка: {link}")
                return "Что, где, не то с API..."
